# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import sys
from pathlib import Path

import numpy as np
import torch

for _parent in Path(__file__).resolve().parents:
    if (_parent / "easyasc" / "a2.py").exists() or (_parent / "easyasc" / "a5.py").exists():
        if str(_parent) not in sys.path:
            sys.path.insert(0, str(_parent))
        break

from easyasc.a2 import *


def to_hif8_reference(x):
    # Only support round half to away for Matrix.
    x = np.array(x)

    m = x.shape[0]
    n = x.shape[1]

    res = np.zeros((m, n))
    for i in unroll(m):
        for j in unroll(n):
            z = x[i, j]
            if z == np.nan or z == np.inf or z == -np.inf:
                res_z = z
            else:
                s = 1.0 if z >= 0 else -1.0
                tmp = np.abs(z)
                if tmp >= 2.0 ** 15 * 1.25:
                    res_z = s * np.inf
                elif tmp < 2.0 ** (-23):
                    res_z = 0.0
                else:
                    e = np.floor(np.log2(tmp))
                    e = -22 if e == -23 else e
                    abs_e = np.abs(e)
                    if abs_e <= 3:
                        res_z = np.floor(tmp * 2.0 ** (-e + 3) + 0.5) * 2.0 ** (e - 3) * s
                    elif abs_e <= 7:
                        res_z = np.floor(tmp * 2.0 ** (-e + 2) + 0.5) * 2.0 ** (e - 2) * s
                    elif abs_e <= 15:
                        res_z = np.floor(tmp * 2.0 ** (-e + 1) + 0.5) * 2.0 ** (e - 1) * s
                    else:
                        res_z = np.floor(tmp * 2.0 ** (-e) + 0.5) * 2.0 ** e * s
            res[i, j] = res_z
    return res


TILE = 512


@kernel()
def a2_hif8_kernel(x: GMTensor, y: GMTensor, total: Var):
    xub = DBuff(DT.float, [1, 512], Position.UB)
    expbuf = Tensor(DT.float, [1, 512], Position.UB)
    expabsbuf = Tensor(DT.float, [1, 512], Position.UB)
    exp_mask = Tensor(DT.uint32, [1, 512], Position.UB)
    le15flag = Tensor(DT.uint8, [1, 512], Position.UB)
    le7flag = Tensor(DT.uint8, [1, 512], Position.UB)
    le3flag = Tensor(DT.uint8, [1, 512], Position.UB)
    eq0flag = Tensor(DT.uint8, [1, 512], Position.UB)
    outub = DBuff(DT.half, [1, 512], Position.UB)

    halfbuf = Tensor(DT.float, [1, 512], Position.UB)
    onesbuf = Tensor(DT.float, [1, 512], Position.UB)
    zerosbuf = Tensor(DT.float, [1, 512], Position.UB)
    expbias1 = Tensor(DT.float, [1, 512], Position.UB)
    expbias2 = Tensor(DT.float, [1, 512], Position.UB)
    expbias3 = Tensor(DT.float, [1, 512], Position.UB)

    with vec_scope():
        n_tiles = CeilDiv(total, TILE)
        tile_per_core = CeilDiv(n_tiles, GetVecNum())
        tile_start = Var(tile_per_core * GetVecIdx())
        tile_end = Min(tile_per_core + tile_start, n_tiles)

    dup(exp_mask, 0x7F800000)
    dup(halfbuf, 0.5)
    dup(onesbuf, 1.0)
    dup(zerosbuf, 0.0)

    cnt = Var(0)

    with auto_sync():
        for t in range(tile_start, tile_end):
            n1 = Var(t * TILE)
            n_valid = Min(total - n1, TILE)

            xub[cnt] <<= x[n1:n1 + n_valid]

            x_u16 = xub[cnt].reinterpret(DT.uint16)
            exp_u16 = expbuf.reinterpret(DT.uint16)
            expkmask_u16 = exp_mask.reinterpret(DT.uint16)
            vand(exp_u16, x_u16, expkmask_u16)

            expabs_u16 = expabsbuf.reinterpret(DT.uint16)
            vnot(expabs_u16, exp_u16)
            vand(expabs_u16, expabs_u16, expkmask_u16)
            expabs_s32 = expabsbuf.reinterpret(DT.int)
            adds(expabs_s32, expabs_s32, -8388608)
            vmax(expabsbuf, expabsbuf, expbuf)

            compare_scalar(le15flag, expabsbuf, 32768.0, CompareMode.LE)
            compare_scalar(le7flag, expabsbuf, 128.0, CompareMode.LE)
            compare_scalar(le3flag, expabsbuf, 8.0, CompareMode.LE)
            compare_scalar(eq0flag, expbuf, 2 ** -23, CompareMode.GE)

            vmaxs(expbuf, expbuf, 2 ** -22)

            select(expbias1, le15flag, halfbuf, 1.0)
            select(expbias2, le7flag, halfbuf, 1.0)
            select(expbias3, le3flag, halfbuf, 1.0)
            expbias3 <<= expbias2 * expbias3
            expbuf <<= expbuf * expbias1
            expbuf <<= expbuf * expbias3

            xub[cnt] <<= xub[cnt] / expbuf
            xub[cnt] <<= xub[cnt].cast()
            xub[cnt] <<= xub[cnt] * expbuf
            select(xub[cnt], eq0flag, xub[cnt], 0.0)
            outub[cnt] <<= xub[cnt].cast()

            y[n1:n1 + n_valid] <<= outub[cnt]

            cnt += 1

    return y


if __name__ == "__main__":
    total = 512 * 80
    torch.manual_seed(0)

    x = torch.randn(total)
    y_ref = to_hif8_reference(x.numpy().reshape([1, total]))[0]
    y_ref = torch.from_numpy(y_ref).half()

    op = OpExec(a2_hif8_kernel, "./test_hif8", simulator=True)
    y_kernel = op(x, y_ref, total)
    print(torch.abs(y_ref - y_kernel).max())
