# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import math
import sys
from pathlib import Path

import torch
from einops import rearrange
import torch.nn.functional as F

for _parent in Path(__file__).resolve().parents:
    if (_parent / "easyasc" / "a2.py").exists() or (_parent / "easyasc" / "a5.py").exists():
        if str(_parent) not in sys.path:
            sys.path.insert(0, str(_parent))
        break

from easyasc.a5 import *
 
@vf()
def scale_add_qk_vf(ubin_nope: Tensor, ubout_qk: Tensor, n_loops: Var):
    nope_reg = Reg(DT.float)
    for i in range(n_loops):
        nope_reg <<= ubin_nope[i * 64]
        nope_reg <<= nope_reg * SCALE
        ubout_qk[i * 64] <<= nope_reg
 
@vf()
def get_skip_flag(ub_qk: Tensor, ub_max: Tensor, ub_expdiff: Tensor, n_rows: Var): #, valid: Tensor):
    regs = RegList(DT.float, BASES // 64) 
    prev_max = Reg(DT.float)
    max_reg = Reg(DT.float)
    expdiffreg = Reg(DT.float)
    
    for i in range(n_rows):
        regs <<= ub_qk[i * BASES]
        prev_max <<= ub_max[i].single()
        # compute m = max(m, mprev)
        max_reg <<= regs.cmax()
        max_reg <<= max_reg.dup()
        max_reg <<= max_reg.vmax(prev_max)
        ub_max[i] <<= max_reg.single_value()
        # compute exp(mprev - m)
        expdiffreg <<= prev_max - max_reg
        ub_expdiff[i] <<= expdiffreg.single_value()
        
        # valid[i] <<= expdiffreg.single_value()
 
@vf()
def set_valid_false(ub_valid: Tensor, n_rows: Var): #, valid: Tensor):
    reg = Reg(DT.float)
    reg <<= 0.0
    for i in range(n_rows): #每次处理1行
        ub_valid[i] <<= reg.single_value()
 
 
@vf()
def get_p_and_max_sum(ub_qk: Tensor, ub_max: Tensor, ub_sum: Tensor, ub_expdiff: Tensor, ub_p: Tensor, ub_valid: Tensor, row_id: Var):
    regs = RegList(DT.float, BASES // 64) 
    # prev_max = Reg(DT.float)
    max_reg = Reg(DT.float)
    prev_sum = Reg(DT.float)
    sum_reg = Reg(DT.float)
    expdiffreg = Reg(DT.float)
    valid_reg = Reg(DT.float)
    
    # for i in range(n_rows): 
    i = Var(0)
    i <<= row_id
    regs <<= ub_qk[i * BASES]
    # prev_max <<= ub_max[i].single()
    prev_sum <<= ub_sum[i].single()
    # # compute m = max(m, mprev)
    # max_reg <<= regs.cmax()
    # max_reg <<= max_reg.dup()
    # max_reg <<= max_reg.vmax(prev_max)
    max_reg <<= ub_max[i].single()
    expdiffreg <<= ub_expdiff[i].single()
    # # compute exp(mprev - m)
    # expdiffreg <<= prev_max - max_reg
    
    expdiffreg <<= expdiffreg.exp()
    # compute exp(x - m)
    regs <<= regs - max_reg
    regs <<= regs.exp()
    # compute sum(e)
    sum_reg <<= regs.cadd()
    sum_reg <<= sum_reg.dup()
    # s = s + expdiff * sprev
    sum_reg <<= sum_reg + expdiffreg * prev_sum
    # # scale p matrix
    # regs <<= regs * 16.0
    # output everything
    ub_p[i * BASES] <<= regs
    # ub_max[i] <<= max_reg.single_value()
    ub_sum[i] <<= sum_reg.single_value()
    ub_expdiff[i] <<= expdiffreg.single_value()
    
    valid_reg <<= 1.0
    ub_valid[i] <<= valid_reg.single_value()
 
@vf()
def init_buffers(qksum: Tensor, qkmax: Tensor, expdiff: Tensor, expdiff1: Tensor, ub_accum: Tensor, valid: Tensor, valid1: Tensor):
    reg = Reg(DT.float)
    reg <<= 0.0
    qksum <<= reg
    for i in range(8 * Dn // 64):
        ub_accum[i * 64] <<= reg
        reg <<= -99999.0
        qkmax <<= reg
        reg <<= 1.0
        expdiff <<= reg
        expdiff1 <<= reg
        valid <<= reg
        valid1 <<= reg
 
@vf()
def accum_pv(accum: Tensor, curr_pv: Tensor, expdiff: Tensor, n_rows: Var):
    regs1 = RegList(DT.float, Dn // 64)
    regs2 = RegList(DT.float, Dn // 64)
    expdiff_reg = Reg(DT.float)
    for i in range(n_rows):
        expdiff_reg <<= expdiff[i].single()
        regs1 <<= accum[i * Dn]
        regs2 <<= curr_pv[i * Dn]
        regs1 <<= regs1 * expdiff_reg
        regs1 <<= regs1 + regs2
        accum[i * Dn] <<= regs1
 
@vf()
def devide_sum(accum: Tensor, sum_ub: Tensor, n_rows: Var):
    regs = RegList(DT.float, Dn // 64)
    sum_reg = Reg(DT.float)
    for i in range(n_rows):
        sum_reg <<= sum_ub[i].single()
        regs <<= accum[i * Dn]
        regs <<= regs / sum_reg
        accum[i * Dn] <<= regs
 
 
@kernel()
def mha_blasst(
        q: GMTensor, k: GMTensor, v: GMTensor, output: GMTensor,
        bh: Var, S: Var, Dn: Var, thres: Var
    ):
    qk_mutex = CvMutex(0, dst_end_pipe=Pipe.V)
    p_mutex = VcMutex(1, dst_end_pipe=Pipe.MTE1)
    pv_mutex = CvMutex(2, dst_end_pipe=Pipe.V)
    
    l1q = DBuff(DT.half, [16, Dn], Position.L1) 
    # l1q = Tensor(DT.half, [16, Dn], Position.L1) 
    l1k = TBuff(DT.half, [BASES, Dn], Position.L1)
    l1v = TBuff(DT.half, [BASES, Dn], Position.L1)
    l1p = DBuff(DT.half, [16, BASES], Position.L1)
    # l1p = DBuff(DT.float, [16, BASES], Position.L1)
    l0cn = DBuff(DT.float, [16, BASES], Position.L0C)
    l0cpv = DBuff(DT.float, [16, Dn], Position.L0C)
    
    ubin_nope = DBuff(DT.float, [8, BASES], Position.UB)
    ubin_pv = DBuff(DT.float, [8, Dn], Position.UB)
    ub_rope_nope_sum = Tensor(DT.float, [8, BASES], Position.UB)
    ubout_qk = DBuff(DT.half, [8, BASES], Position.UB)
    # ubout_qk = DBuff(DT.float, [8, BASES], Position.UB)
    ub_qksum = Tensor(DT.float, [1, 64], Position.UB)
    ub_qkmax = Tensor(DT.float, [1, 64], Position.UB)
    ub_expdiff = DBuff(DT.float, [1, 64], Position.UB)
    ub_accum = Tensor(DT.float, [8, Dn], Position.UB)
    
    ub_valid = DBuff(DT.float, [1, 64], Position.UB)
    
    bh_per_core = CeilDiv(bh, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, bh)
    valid = Var(0)
    rows = Var(1)
    
    skip_cnt = Var(0)
    total_cnt = Var(0)
    
    for bh_idx in range(bh_begin, bh_end):
        l1q[0] <<= q[bh_idx, :] 
        stage1_cnt = Var(0)
        stage2_cnt = Var(0)
        kv_cnt = Var(0)
        init_buffers(ub_qksum, ub_qkmax, ub_expdiff[0], ub_expdiff[1], ub_accum, ub_valid[0], ub_valid[1])
        
        for s in range(0, S + BASES, BASES):
            if s < S:
                with auto_sync():
                    l1k[kv_cnt] <<= k[bh_idx, s:s + BASES, :]
                    l1v[kv_cnt] <<= v[bh_idx, s:s + BASES, :]
                    
                    matmul(l0cn[stage1_cnt], l1q[0], l1k[stage1_cnt], splitk=128)
                    qk_mutex.lock()
                    ubin_nope[stage1_cnt] <<= l0cn[stage1_cnt] 
                    qk_mutex.ready()
                    
                    qk_mutex.wait()
                    scale_add_qk_vf(ubin_nope[stage1_cnt], ub_rope_nope_sum, rows * BASES // 64)
                    
                    get_skip_flag(ub_rope_nope_sum, ub_qkmax, ub_expdiff[stage1_cnt], rows)
                    for i in range(rows):
                        if GetSubBlockIdx() == 0:
                            valid <<= ub_expdiff[stage1_cnt][i:i+1, 0:1]
                            # if valid > thres:
                            get_p_and_max_sum(ub_rope_nope_sum, ub_qkmax, ub_qksum, ub_expdiff[stage1_cnt], ubout_qk[stage1_cnt], ub_valid[stage1_cnt], i)
                            # else:
                            #     set_valid_false(ub_valid[stage1_cnt], rows)
                            #     break
                    qk_mutex.free()
                    
                    p_mutex.lock() # vc
                    valid <<= ub_valid[stage1_cnt][0:1, 0:1]
                    if valid > 0:
                        if GetSubBlockIdx() == 0:
                            l1p[stage1_cnt] <<= ubout_qk[stage1_cnt][:rows, :] 
                    elif GetSubBlockIdx() == 0:
                        skip_cnt += 1
                    p_mutex.ready()
                    
                    kv_cnt += 1
                    stage1_cnt += 1
        
            if s > 0:
                with auto_sync():
                    p_mutex.wait() 
                    valid <<= ub_valid[stage2_cnt][0:1, 0:1]
                    matmul(l0cpv[stage2_cnt], l1p[stage2_cnt], l1v[stage2_cnt].T, splitn=128)
                    # bar_all()
                    # output[bh_idx, :] <<= l0cpv[stage2_cnt]
                    p_mutex.free()
                    
                    pv_mutex.lock()
                    ubin_pv[stage2_cnt] <<= l0cpv[stage2_cnt]
                    pv_mutex.ready()
                    
                    pv_mutex.wait()
                    if valid > 0:
                        if GetSubBlockIdx() == 0:
                            accum_pv(ub_accum, ubin_pv[stage2_cnt], ub_expdiff[stage2_cnt], 1)
                    pv_mutex.free()
                    
                    stage2_cnt += 1
                    total_cnt += 1
    
        # bar_all()
        # if GetSubBlockIdx() == 0:
        # output[bh_idx, :] <<= ub_accum 
        devide_sum(ub_accum, ub_qksum, 1)
        bar_all()
        if GetSubBlockIdx() == 0:
            output[bh_idx, :] <<= ub_accum 
    
    return output#, skip_cnt, total_cnt
 
 
 
 
def self_attn(q, k, v):
    row_max = torch.full([B*H], -99999.0)
    row_sum = torch.zeros([B*H])
    output = torch.zeros(B*H, Dn)
    # output = torch.zeros(B*H, S)
    
    for s in unroll(0, S, BASES):
        qk = torch.einsum("bd,bsd->bs", q.float(), k[:, s:s + BASES, :].float())
        qk = qk * SCALE
        # output[:,s:s + BASES] = qk
        curr_row_max = qk.amax(dim=-1)
        curr_row_max = torch.maximum(row_max, curr_row_max)
        row_exp_diff = torch.exp(row_max - curr_row_max)
        row_max = curr_row_max
        p = torch.exp(qk - curr_row_max[..., None])
        # p = p * 16
        p = p.to(torch.float16) # type: ignore
        # p = torch.exp(qk)
        # output[:,s:s + BASES] = p
        # print(output)
        row_sum = row_sum * row_exp_diff + p.sum(dim=-1)
        curr_output = torch.einsum("bs,bsd->bd", p.float(), v[:, s:s + BASES, :].float())
        # output = output + curr_output
        # print(output)
        output = output * row_exp_diff[..., None] + curr_output
    
    output = output / row_sum[..., None]
    
    return output
 
 
if __name__ == "__main__":
    B = 1
    H = 32
    S = 128
    BASES = 128
    Dn = 128
    SCALE = math.sqrt(1 / Dn)
    torch.manual_seed(42)
    
    
    q = torch.randn(B, H, Dn).to(torch.float16) 
    k = torch.randn(B, H, S, Dn).to(torch.float16) 
    v= torch.randn(B, H, S, Dn).to(torch.float16) 
    
    q = rearrange(q, 'b h d -> (b h) d')
    k = rearrange(k, 'b h s d -> (b h) s d')
    v = rearrange(v, 'b h s d -> (b h) s d')
 
 
    
    # output = torch.nn.functional.scaled_dot_product_attention(q.unsqueeze(1), k, k)
    # print(output.shape) # [64, 1, 512]
    # output = output.squeeze(1)
    
    
    output = self_attn(q, k, v)
    output_kernel = torch.zeros_like(output)
    
    ############## Kernel Attn ###################
    
    
    op = OpExec(mha_blasst, simulator=True, out_dir="./tmp/blasst")
    # op = OpExec(mha, simulator=False, out_dir="./blasst", profile=True)
    
    # k = rearrange(k, 'bh s d -> (bh s) d')
    # op = OpExec(mha_rows, simulator=True, out_dir="./tmp/mha", gen_only=False)
    # out_kernel, skip_cnt, total_cnt = op(
    out_kernel = op(
    q, k, v, output_kernel,
    B*H, S, Dn, math.log(0.0001),
    # shape_bindings={0: [0, 2], 1: [0, 1, 2], 2: [0, 1, 2], 3: [0, 2]}, 
    shape_bindings={0: [0, 2], 1: [0, 1, 2], 2: [0, 1, 2], 3: [0, 1]}, 
    )
    # print(skip_cnt)
    # print(total_cnt)
    # print(out_kernel)
    # torch.testing.assert_close(out_kernel.float(), output.float(), rtol=1e-3, atol=1e-3)
    print(torch.abs(out_kernel.float() - output.float()).max())
    cos_sim = F.cosine_similarity(out_kernel.flatten(1), output.flatten(1), dim=1).mean()
    print("Average cosine similarity:", cos_sim.item())#, 'Layer sparsity:', skip_cnt/total_cnt) #, 'Input shape:', q_nope.shape)
 
