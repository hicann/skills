# A2 Demos

This directory holds manual runnable demos that specifically target the a2 (`easyasc.a2`) surface.

## Current files

- `a2_hif8.py` — hif8 quantization-style vec pipeline demo on a2 simulator
- `a2_matmul_fp32.py` — float-input matmul smoke path on a2
- `a2_sample_matmul.py` — minimal a2 `@kernel` matmul example
- `basic_operations/dsl_syntax/a2_matmul_subblock.py` — a2 subblock vec writeback sample
