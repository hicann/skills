# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Negative demo for a cross-side scalar dependency in shared control flow.

Run this file manually from anywhere:

    python demo/a5/negative_cases/mha_blasst_v1_split_negative.py

The sample is expected to fail during split/codegen validation before the
simulator starts. A successful run is one that raises the expected
side-split inconsistency error.
"""

import math
import sys
from pathlib import Path

REPO_ROOT = None
for _parent in Path(__file__).resolve().parents:
    if (_parent / "easyasc" / "a2.py").exists() or (_parent / "easyasc" / "a5.py").exists():
        REPO_ROOT = _parent
        if str(_parent) not in sys.path:
            sys.path.insert(0, str(_parent))
        break

if REPO_ROOT is None:
    raise RuntimeError("Failed to locate the repository root for demo bootstrap.")

import torch

from easyasc.a5 import *


BASES = 128
Dn = 128
SCALE = math.sqrt(1 / Dn)


@vf()
def scale_add_qk_vf(ubin_nope: Tensor, ubout_qk: Tensor, n_rows: Var):
    nope_regs = RegList(DT.float, BASES // 64)
    for i in range(n_rows):
        nope_regs <<= ubin_nope[i * BASES]
        nope_regs <<= nope_regs * SCALE
        ubout_qk[i * BASES] <<= nope_regs


@vf()
def get_skip_delta(ub_qk: Tensor, ub_max: Tensor, ub_delta: Tensor, n_rows: Var):
    regs = RegList(DT.float, BASES // 64)
    prev_max = Reg(DT.float)
    max_reg = Reg(DT.float)
    for i in range(n_rows):
        regs <<= ub_qk[i * BASES]
        prev_max <<= ub_max[i].single()
        max_reg <<= regs.cmax()
        max_reg <<= max_reg.dup()
        max_reg <<= max_reg - prev_max
        ub_delta[i] <<= max_reg.single_value()


@vf()
def set_skip_state(ub_p: Tensor, ub_expdiff: Tensor, n_rows: Var):
    p_regs = RegList(DT.half, BASES // 64)
    reg = Reg(DT.float)
    for i in range(n_rows):
        p_regs <<= ub_p[i * BASES]
        p_regs <<= p_regs * 0.0
        ub_p[i * BASES] <<= p_regs
    reg <<= 1.0
    for i in range(n_rows):
        ub_expdiff[i] <<= reg.single_value()


@vf()
def get_p_and_max_sum(
    ub_qk: Tensor,
    ub_max: Tensor,
    ub_sum: Tensor,
    ub_expdiff: Tensor,
    ub_p: Tensor,
    row_id: Var,
):
    regs = RegList(DT.float, BASES // 64)
    prev_max = Reg(DT.float)
    max_reg = Reg(DT.float)
    prev_sum = Reg(DT.float)
    sum_reg = Reg(DT.float)
    expdiffreg = Reg(DT.float)

    i = Var(0)
    i <<= row_id
    regs <<= ub_qk[i * BASES]
    prev_max <<= ub_max[i].single()
    prev_sum <<= ub_sum[i].single()
    max_reg <<= regs.cmax()
    max_reg <<= max_reg.dup()
    max_reg <<= max_reg.vmax(prev_max)
    expdiffreg <<= prev_max - max_reg
    expdiffreg <<= expdiffreg.exp()
    regs <<= regs - max_reg
    regs <<= regs.exp()
    sum_reg <<= regs.cadd()
    sum_reg <<= sum_reg.dup()
    sum_reg <<= sum_reg + expdiffreg * prev_sum
    ub_p[i * BASES] <<= regs
    ub_max[i] <<= max_reg.single_value()
    ub_sum[i] <<= sum_reg.single_value()
    ub_expdiff[i] <<= expdiffreg.single_value()


@vf()
def init_buffers(qksum: Tensor, qkmax: Tensor, expdiff: Tensor, expdiff1: Tensor, ub_accum: Tensor):
    reg = Reg(DT.float)
    reg <<= 0.0
    qksum <<= reg
    for i in range(8 * Dn // 64):
        ub_accum[i * 64] <<= reg
    reg <<= -99999.0
    qkmax <<= reg
    reg <<= 1.0
    expdiff <<= reg
    expdiff1 <<= reg


@vf()
def accum_pv(accum: Tensor, curr_pv: Tensor, expdiff: Tensor, n_rows: Var):
    regs1 = RegList(DT.float, Dn // 64)
    regs2 = RegList(DT.float, Dn // 64)
    expdiff_reg = Reg(DT.float)
    for i in range(n_rows):
        expdiff_reg <<= expdiff[i].single()
        regs1 <<= accum[i * Dn]
        regs2 <<= curr_pv[i * Dn]
        regs1 <<= regs1 * expdiff_reg
        regs1 <<= regs1 + regs2
        accum[i * Dn] <<= regs1


@vf()
def devide_sum(accum: Tensor, sum_ub: Tensor, n_rows: Var):
    regs = RegList(DT.float, Dn // 64)
    sum_reg = Reg(DT.float)
    for i in range(n_rows):
        sum_reg <<= sum_ub[i].single()
        regs <<= accum[i * Dn]
        regs <<= regs / sum_reg
        accum[i * Dn] <<= regs


@kernel()
def mha_blasst_v1(
    q: GMTensor,
    k: GMTensor,
    v: GMTensor,
    output: GMTensor,
    bh: Var,
    L: Var,
    S: Var,
    Dn: Var,
    thres: Var,
):
    qk_mutex = CvMutex(0, dst_end_pipe=Pipe.V)
    p_mutex = VcMutex(1, dst_end_pipe=Pipe.MTE1)
    pv_mutex = CvMutex(2, dst_end_pipe=Pipe.V)

    l1q = DBuff(DT.half, [16, Dn], Position.L1)
    l1k = TBuff(DT.half, [BASES, Dn], Position.L1)
    l1v = TBuff(DT.half, [BASES, Dn], Position.L1)
    l1p = DBuff(DT.half, [16, BASES], Position.L1)
    l0cn = DBuff(DT.float, [16, BASES], Position.L0C)
    l0cpv = DBuff(DT.float, [16, Dn], Position.L0C)

    ubin_nope = DBuff(DT.float, [8, BASES], Position.UB)
    ubin_pv = DBuff(DT.float, [8, Dn], Position.UB)
    ub_rope_nope_sum = Tensor(DT.float, [8, BASES], Position.UB)
    ubout_qk = DBuff(DT.half, [8, BASES], Position.UB)
    ub_qksum = Tensor(DT.float, [1, 64], Position.UB)
    ub_qkmax = Tensor(DT.float, [1, 64], Position.UB)
    ub_expdiff = DBuff(DT.float, [1, 64], Position.UB)
    ub_accum = Tensor(DT.float, [8, Dn], Position.UB)
    ub_delta = Tensor(DT.float, [1, 64], Position.UB)

    bh_per_core = CeilDiv(bh, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, bh)

    valid = Var(0.0)
    delayed_keep = Var(0.0)
    curr_keep = Var(0.0)
    rows = Var(1)
    q_cnt = Var(0)

    for bh_idx in range(bh_begin, bh_end):
        l1q[q_cnt][:rows, :] <<= q[bh_idx, :rows, :]
        stage1_cnt = Var(0)
        stage2_cnt = Var(0)
        init_buffers(ub_qksum, ub_qkmax, ub_expdiff[0], ub_expdiff[1], ub_accum)
        delayed_keep <<= 0.0

        with auto_sync():
            for s in range(0, S + BASES, BASES):
                if s > 0:
                    prev_s = Var(s - BASES)
                    if delayed_keep > 0:
                        l1v[stage2_cnt] <<= v[bh_idx, prev_s:prev_s + BASES, :]

                        p_mutex.wait()
                        matmul(l0cpv[stage2_cnt], l1p[stage2_cnt], l1v[stage2_cnt].T, splitn=128)
                        p_mutex.free()

                        pv_mutex.lock()
                        ubin_pv[stage2_cnt][:rows, :] <<= l0cpv[stage2_cnt][:rows, :]
                        pv_mutex.ready()

                        pv_mutex.wait()
                        accum_pv(ub_accum, ubin_pv[stage2_cnt], ub_expdiff[stage2_cnt], rows)
                        pv_mutex.free()
                    else:
                        p_mutex.wait()
                        p_mutex.free()

                    stage2_cnt += 1

                if s < S:
                    curr_keep <<= 1.0
                    l1k[stage1_cnt] <<= k[bh_idx, s:s + BASES, :]
                    matmul(l0cn[stage1_cnt], l1q[q_cnt], l1k[stage1_cnt], splitk=128)
                    qk_mutex.lock()
                    ubin_nope[stage1_cnt][:rows, :] <<= l0cn[stage1_cnt][:rows, :]
                    qk_mutex.ready()

                    qk_mutex.wait()
                    scale_add_qk_vf(ubin_nope[stage1_cnt], ub_rope_nope_sum, rows)
                    get_skip_delta(ub_rope_nope_sum, ub_qkmax, ub_delta, rows)
                    setflag(Pipe.V, Pipe.S, 3)
                    waitflag(Pipe.V, Pipe.S, 3)
                    valid <<= 0.0
                    for i in range(rows):
                        valid <<= ub_delta[i:i + 1, 0:1]
                        if valid > thres:
                            get_p_and_max_sum(
                                ub_rope_nope_sum,
                                ub_qkmax,
                                ub_qksum,
                                ub_expdiff[stage1_cnt],
                                ubout_qk[stage1_cnt],
                                i,
                            )
                        else:
                            curr_keep <<= 0.0
                            set_skip_state(ubout_qk[stage1_cnt], ub_expdiff[stage1_cnt], rows)
                            break
                    qk_mutex.free()

                    p_mutex.lock()
                    if curr_keep > 0 and GetSubBlockIdx() == 0:
                        l1p[stage1_cnt][:rows, :] <<= ubout_qk[stage1_cnt][:rows, :]
                    p_mutex.ready()
                    delayed_keep <<= curr_keep
                    stage1_cnt += 1

        devide_sum(ub_accum, ub_qksum, rows)
        bar_all()
        if GetSubBlockIdx() == 0:
            output[bh_idx, :rows, :] <<= ub_accum[:rows, :]

        q_cnt += 1

    return output


def run_negative_case() -> str:
    b = 1
    l = 1
    h = 32
    s = 256
    dn = 128
    thres = math.log(0.1)

    torch.manual_seed(42)
    q = torch.randn(b, h, l, dn).to(torch.float16).reshape(b * h, l, dn)
    k = torch.randn(b, h, s, dn).to(torch.float16).reshape(b * h, s, dn)
    v = torch.randn(b, h, s, dn).to(torch.float16).reshape(b * h, s, dn)
    output_kernel = torch.zeros((b * h, l, dn), dtype=torch.float32)

    op = OpExec(
        mha_blasst_v1,
        simulator=True,
        out_dir=str(REPO_ROOT / "tmp" / "blasst_v1_negative"),
        cann_path="",
        gen_only=True,
    )

    try:
        op(
            q,
            k,
            v,
            output_kernel,
            b * h,
            l,
            s,
            dn,
            thres,
            shape_bindings={0: [0, 1, 3], 1: [0, 2, 3], 2: [0, 2, 3], 3: [0, 1, 3]},
        )
    except ValueError as exc:
        message = str(exc)
        if "Side-split inconsistency" not in message:
            raise AssertionError("Negative sample failed, but not with the expected split validation") from exc
        return message

    raise AssertionError("Negative sample unexpectedly passed; split validation did not trigger")


if __name__ == "__main__":
    error_message = run_negative_case()
    print("Expected failure captured.")
    print(error_message)
