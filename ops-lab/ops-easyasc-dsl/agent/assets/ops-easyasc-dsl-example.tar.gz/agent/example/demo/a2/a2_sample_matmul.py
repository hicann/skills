# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import sys
from pathlib import Path

for _parent in Path(__file__).resolve().parents:
    if (_parent / "easyasc" / "a2.py").exists() or (_parent / "easyasc" / "a5.py").exists():
        if str(_parent) not in sys.path:
            sys.path.insert(0, str(_parent))
        break

from easyasc.a2 import *


@kernel()
def a2_sample_matmul_kernel(x: GMTensor, y: GMTensor, z: GMTensor, m: Var, n: Var, k: Var):
    l1x = Tensor(DT.half, [m, k], Position.L1)
    l1y = Tensor(DT.half, [n, k], Position.L1)
    l0c = Tensor(DT.float, [m, n], Position.L0C)

    l1x <<= x[:, :]
    l1y <<= y[:, :]
    matmul(l0c, l1x, l1y, m=m, n=n, k=k, is_init=True)
    z[:, :] <<= l0c
    return z


if __name__ == "__main__":
    import torch

    m = 32
    n = 48
    k = 16

    torch.manual_seed(0)
    x = torch.randn((m, k), dtype=torch.float16)
    y = torch.randn((n, k), dtype=torch.float16)
    z = torch.zeros((m, n), dtype=torch.float32)

    z_kernel = OpExec(a2_sample_matmul_kernel, simulator=True)(x, y, z, m, n, k)
    z_ref = x.float() @ y.float().t()
    torch.testing.assert_close(z_kernel, z_ref, rtol=3e-3, atol=3e-3)
    print(f"max_abs_diff={torch.abs(z_kernel - z_ref).max().item():.6e}")
