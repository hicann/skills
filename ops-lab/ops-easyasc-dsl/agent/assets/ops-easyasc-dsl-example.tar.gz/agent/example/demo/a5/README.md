# A5 Demos

This directory holds manual runnable demos that target the a5/general authoring surface.

## Current files

- `matmul_l0c_to_l1_demo.py` — keep an intermediate matmul result on chip via `L0C -> L1`
- `problem.py` — larger a5 attention-style experiment
- `torchapimgr_demo.py` — `TorchApiManager` compile/demo flow
- `basic_operations/` — focused a5 syntax, pipeline, simulator, and vec/micro samples
- `negative_cases/` — manual repros that are expected to fail early
