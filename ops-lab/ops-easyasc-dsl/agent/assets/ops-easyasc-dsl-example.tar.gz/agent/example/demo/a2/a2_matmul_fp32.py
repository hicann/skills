# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------

import sys
from pathlib import Path

import torch

for _parent in Path(__file__).resolve().parents:
    if (_parent / "easyasc" / "a2.py").exists() or (_parent / "easyasc" / "a5.py").exists():
        if str(_parent) not in sys.path:
            sys.path.insert(0, str(_parent))
        break

from easyasc.a2 import *


@kernel()
def test_f32mm(x, y, z, M, N, K):
    l1x = Tensor(DT.float, [K, M], Position.L1)
    l1y = Tensor(DT.float, [K, N], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)

    with auto_sync():
        l1x <<= x[:, :]
        l1y <<= y[:, :]

        matmul(l0c, l1x.T, l1y.T, splitn=64)

        z[:, :] <<= l0c 

    return z 


if __name__=='__main__':
    M = 128 
    N = 256
    K = 64 
    torch.manual_seed(42)

    x = torch.randn(K, M)
    y = torch.randn(K, N)
    
    z = x.t() @ y

    op = OpExec(test_f32mm, './test_f32mm', debug=True)
    z_kernel = op(x, y, z, M, N, K, shape_bindings={0:[2, 0], 1:[2,1], 2:[0,1]})
    print(z_kernel)
    print(z)

    print(torch.abs(z - z_kernel).max())
