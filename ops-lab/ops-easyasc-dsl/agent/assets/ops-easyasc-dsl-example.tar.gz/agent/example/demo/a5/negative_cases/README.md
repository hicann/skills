# A5 Negative Cases

This directory holds manual runnable demos that are expected to fail.

Use these files when you want a concrete reproducer for an invalid DSL pattern,
split inconsistency, or other early-validation error that should be caught
before simulator execution or hardware compilation.

## Current examples

- `mha_blasst_v1_split_negative.py`
  - reproduces a cross-side scalar dependency leaking into shared control flow
  - expected result: split/codegen validation raises a `Side-split inconsistency` error

## What belongs here

- known-bad patterns that should remain rejected
- manual repros used during parser/split/simulator debugging
- samples that verify the repository fails early with a clear error

## What does not belong here

- automated regression tests
  - keep those under `historical automated tests/` (removed from this skill bundle)
- valid runnable examples
  - keep those under `agent/example/demo/a5/`
