# A2 Basic Operation Demos

Manual runnable examples that exercise a2-specific DSL behavior.

## Current files

- `dsl_syntax/a2_matmul_subblock.py` — a2 API matmul with subblock vec writeback
