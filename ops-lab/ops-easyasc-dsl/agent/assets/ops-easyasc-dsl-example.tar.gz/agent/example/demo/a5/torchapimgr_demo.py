# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------

import sys
from pathlib import Path

for _parent in Path(__file__).resolve().parents:
    if (_parent / "easyasc" / "a2.py").exists() or (_parent / "easyasc" / "a5.py").exists():
        if str(_parent) not in sys.path:
            sys.path.insert(0, str(_parent))
        break

from easyasc.a5 import *


BLK = 128
LANES = 4

@vf()
def simple_micro(x: Tensor, out: Tensor, n_loops: Var):
    xreg = Reg(DT.float)
    for i in range(n_loops):
        xreg <<= x[i*64]
        xreg <<= xreg.abs() + 1.0
        out[i*64] <<= xreg


@kernel()
def cubefunc(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0)

    l1x = DBuff(DT.half, [BLK, K], Position.L1)
    l1y = DBuff(DT.half, [N, K], Position.L1)
    l0c = DBuff(DT.float, [BLK, N], Position.L0C)
    inbuf = DBuff(DT.half, [2, K], Position.UB)
    xbuf = DBuff(DT.float, [BLK//2, N], Position.UB)
    outbuf = DBuff(DT.float, [BLK//2, N], Position.UB)

    cnt = Var(0)

    m_per_core = CeilDiv(M, GetCubeNum())
    m1 = Var(m_per_core * GetCubeIdx())
    m2 = Min(m1 + m_per_core, M)

    with auto_sync():
        for m in range(m1, m2, BLK):
            l1x[cnt] <<= x[m:m+BLK, :]
            l1y[cnt] <<= y[:, :]
            matmul(l0c[cnt], l1x[cnt], l1y[cnt], splitn=True)
            matmul(l0c[cnt], l1x[cnt], l1y[cnt])
            
            cvmutex.lock()
            xbuf[cnt] <<= l0c[cnt]
            cvmutex.ready()

            inbuf[cnt] <<= x[:2, :]
            valid_m = Min(BLK, m2 - m)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = GetSubBlockIdx()
            row_begin = sb_idx * half_rows
            row_end = Min(row_begin + half_rows, valid_m)
            row_count = row_end - row_begin

            for i in range(100):
                cvmutex.wait()
                simple_micro(xbuf[cnt], outbuf[cnt], BLK//2*N//64)
                cvmutex.free()
                z[m + row_begin:m + row_end, :] <<= outbuf[cnt][0:row_count, :]
            cvmutex.wait()
            simple_micro(xbuf[cnt], outbuf[cnt], BLK//2*N//64)
            cvmutex.free()
            z[m + row_begin:m + row_end, :] <<= outbuf[cnt][0:row_count, :]
            cnt += 1 

    return z


@kernel()
def cubefunc2(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0)

    l1x = DBuff(DT.half, [BLK, K], Position.L1)
    l1y = DBuff(DT.half, [N, K], Position.L1)
    l0c = DBuff(DT.float, [BLK, N], Position.L0C)
    inbuf = DBuff(DT.half, [2, K], Position.UB)
    xbuf = DBuff(DT.float, [BLK//2, N], Position.UB)
    outbuf = DBuff(DT.float, [BLK//2, N], Position.UB)

    cnt = Var(0)

    m_per_core = CeilDiv(M, GetCubeNum())
    m1 = Var(m_per_core * GetCubeIdx())
    m2 = Min(m1 + m_per_core, M)

    with auto_sync():
        for m in range(m1, m2, BLK):
            l1x[cnt] <<= x[m:m+BLK, :]
            l1y[cnt] <<= y[:, :]
            matmul(l0c[cnt], l1x[cnt], l1y[cnt], splitn=True)
            matmul(l0c[cnt], l1x[cnt], l1y[cnt])
            
            cvmutex.lock()
            xbuf[cnt] <<= l0c[cnt]
            cvmutex.ready()

            inbuf[cnt] <<= x[:2, :]
            valid_m = Min(BLK, m2 - m)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = GetSubBlockIdx()
            row_begin = sb_idx * half_rows
            row_end = Min(row_begin + half_rows, valid_m)
            row_count = row_end - row_begin

            for i in range(100):
                cvmutex.wait()
                simple_micro(xbuf[cnt], outbuf[cnt], BLK//2*N//64)
                cvmutex.free()
                z[m + row_begin:m + row_end, :] <<= outbuf[cnt][0:row_count, :]
            cvmutex.wait()
            simple_micro(xbuf[cnt], outbuf[cnt], BLK//2*N//64)
            cvmutex.free()
            z[m + row_begin:m + row_end, :] <<= outbuf[cnt][0:row_count, :]
            cnt += 1 

    return z


class Mgr(TorchApiManager):
    def initialize(self):
        self.op1 = OpExec(cubefunc)
        self.op2 = OpExec(cubefunc2)

    def run_op1(self, x, y, z):
        M = x.shape[0]
        K = x.shape[1]
        N = y.shape[0]
        self.op1(x, y, z, M, N, K)

    def run_op2(self, x, y, z):
        M = x.shape[0]
        K = x.shape[1]
        N = y.shape[0]
        self.op2(x, y, z, M, N, K)


if __name__ == "__main__":
    import torch 

    out_dir = "test_cust_op"

    M = 64*64 
    N = 64
    K = 128 
    x = torch.ones(M, K).half()
    y = torch.ones(N, K).half()
    z = x.float() @ y.float().t()
    z = torch.abs(z) + 1.0 

    mgr = Mgr(out_dir)
    mgr.run_op1(x, y, z)
    mgr.run_op2(x, y, z)
    mgr.compile()
    
