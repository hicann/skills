# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import argparse
import sys
from pathlib import Path
from typing import Tuple

import torch

for _parent in Path(__file__).resolve().parents:
    if (_parent / "easyasc" / "a2.py").exists() or (_parent / "easyasc" / "a5.py").exists():
        if str(_parent) not in sys.path:
            sys.path.insert(0, str(_parent))
        break

from easyasc import globvars
from easyasc.a5 import *


BLK = 64


@vf()
def interleave_micro(src0: Tensor, src1: Tensor, dst0: Tensor, dst1: Tensor, stride: Var):
    reg0 = Reg(src0.dtype)
    reg1 = Reg(src1.dtype)
    out0 = Reg(src0.dtype)
    out1 = Reg(src1.dtype)
    for i in range(BLK):
        reg0 <<= src0[i * stride]
        reg1 <<= src1[i * stride]
        interleave(out0, out1, reg0, reg1)
        dst0[i * stride] <<= out0
        dst1[i * stride] <<= out1


@vf()
def interleave_alias_micro(src0: Tensor, src1: Tensor, dst0: Tensor, dst1: Tensor, stride: Var):
    reg0 = Reg(src0.dtype)
    reg1 = Reg(src1.dtype)
    for i in range(BLK):
        reg0 <<= src0[i * stride]
        reg1 <<= src1[i * stride]
        interleave(reg0, reg1, reg0, reg1)
        dst0[i * stride] <<= reg0
        dst1[i * stride] <<= reg1


@vf()
def roundtrip_micro(src0: Tensor, src1: Tensor, dst0: Tensor, dst1: Tensor, stride: Var):
    reg0 = Reg(src0.dtype)
    reg1 = Reg(src1.dtype)
    tmp0 = Reg(src0.dtype)
    tmp1 = Reg(src1.dtype)
    out0 = Reg(src0.dtype)
    out1 = Reg(src1.dtype)
    for i in range(BLK):
        reg0 <<= src0[i * stride]
        reg1 <<= src1[i * stride]
        interleave(tmp0, tmp1, reg0, reg1)
        deinterleave(out0, out1, tmp0, tmp1)
        dst0[i * stride] <<= out0
        dst1[i * stride] <<= out1


@kernel()
def run_interleave(
    src0: GMTensor,
    src1: GMTensor,
    out0: GMTensor,
    out1: GMTensor,
    rows: Var,
    cols: Var,
):
    ub_src0 = DBuff(src0.dtype, [BLK, cols], Position.UB)
    ub_src1 = DBuff(src1.dtype, [BLK, cols], Position.UB)
    ub_out0 = DBuff(out0.dtype, [BLK, cols], Position.UB)
    ub_out1 = DBuff(out1.dtype, [BLK, cols], Position.UB)
    cnt = Var(0)

    rows_per_vec = CeilDiv(rows, GetVecNum())
    begin = Var(rows_per_vec * GetVecIdx())
    end = Min(begin + rows_per_vec, rows)
    with auto_sync():
        for row in range(begin, end, BLK):
            ub_src0[cnt] <<= src0[row : row + BLK, :]
            ub_src1[cnt] <<= src1[row : row + BLK, :]
            interleave_micro(ub_src0[cnt], ub_src1[cnt], ub_out0[cnt], ub_out1[cnt], cols)
            out0[row : row + BLK, :] <<= ub_out0[cnt]
            out1[row : row + BLK, :] <<= ub_out1[cnt]
            cnt += 1
    return out0, out1


@kernel()
def run_interleave_alias(
    src0: GMTensor,
    src1: GMTensor,
    out0: GMTensor,
    out1: GMTensor,
    rows: Var,
    cols: Var,
):
    ub_src0 = DBuff(src0.dtype, [BLK, cols], Position.UB)
    ub_src1 = DBuff(src1.dtype, [BLK, cols], Position.UB)
    ub_out0 = DBuff(out0.dtype, [BLK, cols], Position.UB)
    ub_out1 = DBuff(out1.dtype, [BLK, cols], Position.UB)
    cnt = Var(0)

    rows_per_vec = CeilDiv(rows, GetVecNum())
    begin = Var(rows_per_vec * GetVecIdx())
    end = Min(begin + rows_per_vec, rows)
    with auto_sync():
        for row in range(begin, end, BLK):
            ub_src0[cnt] <<= src0[row : row + BLK, :]
            ub_src1[cnt] <<= src1[row : row + BLK, :]
            interleave_alias_micro(
                ub_src0[cnt], ub_src1[cnt], ub_out0[cnt], ub_out1[cnt], cols
            )
            out0[row : row + BLK, :] <<= ub_out0[cnt]
            out1[row : row + BLK, :] <<= ub_out1[cnt]
            cnt += 1
    return out0, out1


@kernel()
def run_roundtrip(
    src0: GMTensor,
    src1: GMTensor,
    out0: GMTensor,
    out1: GMTensor,
    rows: Var,
    cols: Var,
):
    ub_src0 = DBuff(src0.dtype, [BLK, cols], Position.UB)
    ub_src1 = DBuff(src1.dtype, [BLK, cols], Position.UB)
    ub_out0 = DBuff(out0.dtype, [BLK, cols], Position.UB)
    ub_out1 = DBuff(out1.dtype, [BLK, cols], Position.UB)
    cnt = Var(0)

    rows_per_vec = CeilDiv(rows, GetVecNum())
    begin = Var(rows_per_vec * GetVecIdx())
    end = Min(begin + rows_per_vec, rows)
    with auto_sync():
        for row in range(begin, end, BLK):
            ub_src0[cnt] <<= src0[row : row + BLK, :]
            ub_src1[cnt] <<= src1[row : row + BLK, :]
            roundtrip_micro(ub_src0[cnt], ub_src1[cnt], ub_out0[cnt], ub_out1[cnt], cols)
            out0[row : row + BLK, :] <<= ub_out0[cnt]
            out1[row : row + BLK, :] <<= ub_out1[cnt]
            cnt += 1
    return out0, out1


def _vec_num_for_device() -> int:
    device = str(globvars.device_type).lower()
    if device in ("b3", "b4"):
        return 40
    if device in ("b1", "b2"):
        return 48
    if device == "950":
        return 64
    raise ValueError(f"Unsupported device_type for simulator test: {device}")


def _lane_count(torch_dtype: torch.dtype) -> int:
    if torch_dtype == torch.float16:
        return 128
    if torch_dtype == torch.int8:
        return 256
    raise ValueError(f"Unsupported torch dtype for test: {torch_dtype}")


def _build_inputs(
    torch_dtype: torch.dtype,
    rows: int,
    cols: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    base = torch.arange(rows * cols, dtype=torch.int32).view(rows, cols)
    if torch_dtype == torch.float16:
        src0 = (base.to(torch.float32) * 0.1).to(torch.float16)
        src1 = (1000.0 + base.to(torch.float32) * 0.1).to(torch.float16)
        return src0, src1
    if torch_dtype == torch.int8:
        src0 = ((base % 127) - 63).to(torch.int8)
        src1 = (((base + 17) % 127) - 63).to(torch.int8)
        return src0, src1
    raise ValueError(f"Unsupported torch dtype for input construction: {torch_dtype}")


def _expected_interleave(
    src0: torch.Tensor,
    src1: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    if src0.shape != src1.shape:
        raise ValueError(f"interleave input shape mismatch: {src0.shape} vs {src1.shape}")
    lanes = int(src0.shape[-1])
    if lanes % 2 != 0:
        raise ValueError(f"interleave requires even lane count, got: {lanes}")
    half = lanes // 2
    dst0 = torch.empty_like(src0)
    dst1 = torch.empty_like(src1)
    dst0[..., 0::2] = src0[..., :half]
    dst0[..., 1::2] = src1[..., :half]
    dst1[..., 0::2] = src0[..., half:]
    dst1[..., 1::2] = src1[..., half:]
    return dst0, dst1


def _assert_equal(actual: torch.Tensor, expected: torch.Tensor, label: str) -> None:
    if torch.equal(actual, expected):
        return
    mismatch = actual != expected
    if bool(mismatch.any()):
        idx = mismatch.nonzero(as_tuple=False)[0].tolist()
        raise AssertionError(
            f"{label} mismatch at index {idx}: "
            f"actual={actual[tuple(idx)].item()} expected={expected[tuple(idx)].item()}"
        )
    raise AssertionError(f"{label} mismatch with no explicit mismatch index")


def _run_kernel(
    kernel_fn,
    src0: torch.Tensor,
    src1: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    out0 = torch.zeros_like(src0)
    out1 = torch.zeros_like(src1)
    op = OpExec(kernel_fn, out_dir="test_cust_op", simulator=True)
    rows = int(src0.shape[0])
    cols = int(src0.shape[1])
    result = op(src0, src1, out0, out1, rows, cols)
    if not isinstance(result, tuple) or len(result) != 2:
        raise TypeError(f"Expected 2-tuple simulator result, got: {type(result)}")
    return result


def _run_stub_validation_checks() -> None:
    class _FakeMicro:
        def __init__(self) -> None:
            self.instructions = []

    reg_half_a = Reg(DT.half, "r_half_a")
    reg_half_b = Reg(DT.half, "r_half_b")
    reg_int8 = Reg(DT.int8, "r_int8")
    fake_micro = _FakeMicro()
    prev_micro = globvars.active_micro
    globvars.active_micro = fake_micro
    try:
        try:
            interleave(reg_half_a, reg_half_b, reg_half_a, reg_int8)
        except ValueError:
            pass
        else:
            raise AssertionError("interleave dtype mismatch should raise ValueError")

        try:
            interleave(reg_half_a, reg_half_b, reg_half_a, 1)  # type: ignore[arg-type]
        except TypeError:
            pass
        else:
            raise AssertionError("interleave non-Reg argument should raise TypeError")
    finally:
        globvars.active_micro = prev_micro


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dtype", choices=("float16", "int8"), required=True)
    parser.add_argument("--run-alias", action="store_true")
    args = parser.parse_args()

    torch_dtype = torch.float16 if args.dtype == "float16" else torch.int8
    rows = BLK * _vec_num_for_device()
    cols = _lane_count(torch_dtype)
    src0, src1 = _build_inputs(torch_dtype, rows, cols)
    exp0, exp1 = _expected_interleave(src0, src1)

    _run_stub_validation_checks()

    out0, out1 = _run_kernel(run_interleave, src0, src1)
    _assert_equal(out0, exp0, f"interleave dst0 ({args.dtype})")
    _assert_equal(out1, exp1, f"interleave dst1 ({args.dtype})")

    rt0, rt1 = _run_kernel(run_roundtrip, src0, src1)
    _assert_equal(rt0, src0, f"interleave->deinterleave dst0 ({args.dtype})")
    _assert_equal(rt1, src1, f"interleave->deinterleave dst1 ({args.dtype})")

    if args.run_alias:
        alias0, alias1 = _run_kernel(run_interleave_alias, src0, src1)
        _assert_equal(alias0, exp0, f"interleave alias dst0 ({args.dtype})")
        _assert_equal(alias1, exp1, f"interleave alias dst1 ({args.dtype})")

    print(f"micro_interleave ({args.dtype}): PASS")


if __name__ == "__main__":
    main()
