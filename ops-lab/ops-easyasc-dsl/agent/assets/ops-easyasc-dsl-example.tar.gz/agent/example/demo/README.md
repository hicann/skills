# Demo Layout

The `agent/example/demo/` tree holds manual runnable examples and negative-case repros that are
kept outside the default pytest suite.

## Top-level structure

- `a2/`
  - a2-specific runnable demos
  - includes `basic_operations/` for a2-targeted feature samples
- `a5/`
  - a5-specific runnable demos
  - includes `basic_operations/` for a5/general DSL samples
  - includes `negative_cases/` for a5 repros that are expected to fail early

## Current examples

### `agent/example/demo/a2/`
- `a2_matmul_fp32.py`
- `a2_hif8.py`
- `a2_sample_matmul.py`
- `basic_operations/dsl_syntax/a2_matmul_subblock.py`

### `agent/example/demo/a5/`
- `matmul_l0c_to_l1_demo.py`
- `problem.py`
- `torchapimgr_demo.py`
- `basic_operations/`
- `negative_cases/`

## Usage

Run demo files directly, for example:

```bash
python demo/a2/a2_sample_matmul.py
python demo/a2/a2_hif8.py
python demo/a5/matmul_l0c_to_l1_demo.py
python demo/a5/negative_cases/mha_blasst_v1_split_negative.py
```
