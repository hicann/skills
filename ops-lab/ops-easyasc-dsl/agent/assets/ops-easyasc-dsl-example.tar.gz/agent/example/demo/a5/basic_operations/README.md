# A5 Basic Operation Demos

Manual runnable examples that demonstrate individual DSL features and simulator behaviors.
These files are **not** pytest tests; run them directly with `python <file>`.

## Directory layout

### `dsl_syntax/`
DSL language features and basic API usage on the a5/general authoring surface.

- `syntax_sugar.py` — UB tensor syntax sugar (`.exp()`, elementwise ops, `maximum`/`minimum`, `cast`)
- `vec_ops.py` — UB vec operation syntax with `@ea.kernel` decorator
- `compound_reg_ops.py` — `RegOP` compound expressions in `@vf` and `@cubefunc`

### `vec_micro/`
Vector register and micro-level primitive demos.

- `a5_vec_basic.py` — a5 vec register and micro primitive coverage (`gen_only`)
- `a5_vec_lshift.py` — `<<=` / `RegOP` arithmetic and shift operators
- `reglist_full.py` — `RegList` binary/unary/reduction full operator table
- `reglist_minimal.py` — `RegList` minimal read/write smoke path
- `micro_interleave.py` — interleave / deinterleave round-trip (CLI with `--dtype`)

### `pipeline_sync/`
Pipeline topology and synchronization pattern demos.

- `cube_vec_mix.py` — cube-to-vec mutex event and conditional datamove
- `all_vec_pipeline.py` — large cube+vec kernel with barriers, masks, reinterpret, and atomics
- `cube_autosync.py` — 11-section cube `auto_sync` + `mmad`/L1/L0 interleave scenarios
- `vec_autosync.py` — vec `auto_sync` multi-section UB access patterns

### `simulator/`
Minimal simulator invocation examples.

- `sim_cube_matmul.py` — cube-only matmul simulation with golden comparison
- `sim_vec_dbuff.py` — vec-side DBuff micro simulation
