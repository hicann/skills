# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------

import math

import torch
import torch.nn.functional as F
from einops import rearrange

from easyasc.a5 import *


BASES = 256
D_HEAD = 128
SPLIT_K = 64
SPLIT_N = 64
PACK_REG_LANES = 128
SCALE = math.sqrt(1.0 / D_HEAD)

# Row-specialized streamed MHA example that publishes probability tiles to L1 in NZ layout.
# This variant keeps the NZ handoff path from `mha_ifa_nz.py` while widening the streamed S tile to 256.


@vf()
def scale_qk_row(ub_qk: Tensor, ub_scaled_qk: Tensor):
    qk_regs = RegList(DT.float, BASES // 64)
    qk_regs <<= ub_qk[0]
    qk_regs <<= qk_regs * SCALE
    ub_scaled_qk[0] <<= qk_regs


@vf()
def get_p_and_max_sum_row(ub_qk: Tensor, ub_max: Tensor, ub_sum: Tensor, ub_expdiff: Tensor, ub_p: Tensor):
    regs = RegList(DT.float, BASES // 64)
    prev_max = Reg(DT.float)
    max_reg = Reg(DT.float)
    prev_sum = Reg(DT.float)
    sum_reg = Reg(DT.float)
    expdiff_reg = Reg(DT.float)

    regs <<= ub_qk[0]
    prev_max <<= ub_max[0].single()
    prev_sum <<= ub_sum[0].single()

    max_reg <<= regs.cmax()
    max_reg <<= max_reg.dup()
    max_reg <<= max_reg.vmax(prev_max)

    expdiff_reg <<= prev_max - max_reg
    expdiff_reg <<= expdiff_reg.exp()

    regs <<= regs - max_reg
    regs <<= regs.exp()

    sum_reg <<= regs.cadd()
    sum_reg <<= sum_reg.dup()
    sum_reg <<= sum_reg + expdiff_reg * prev_sum

    ub_p[0] <<= regs
    ub_max[0] <<= max_reg.single_value()
    ub_sum[0] <<= sum_reg.single_value()
    ub_expdiff[0] <<= expdiff_reg.single_value()


@vf()
def pack_p_to_nz_row(src_nd: Tensor, dst_nz: Tensor, n_rows: Var):
    reg0 = Reg(DT.half)
    reg1 = Reg(DT.half)
    for i in range(n_rows):
        reg0 <<= src_nd[i * BASES]
        reg1 <<= src_nd[i * BASES + PACK_REG_LANES]
        reg_to_ub(dst_nz[i * 16], reg0, n_rows)
        # The second half-row starts at block 8 in packed-NZ order, so it advances by 128 * n_rows.
        reg_to_ub(dst_nz[i * 16 + PACK_REG_LANES * n_rows], reg1, n_rows)


@vf()
def init_buffers(qk_sum: Tensor, qk_max: Tensor, expdiff0: Tensor, expdiff1: Tensor, ub_accum: Tensor):
    reg = Reg(DT.float)
    reg <<= 0.0

    qk_sum <<= reg
    for i in range(8 * D_HEAD // 64):
        ub_accum[i * 64] <<= reg

    reg <<= -99999.0
    qk_max <<= reg

    reg <<= 1.0
    expdiff0 <<= reg
    expdiff1 <<= reg


@vf()
def accum_pv_row(accum: Tensor, curr_pv: Tensor, expdiff: Tensor):
    accum_regs = RegList(DT.float, D_HEAD // 64)
    curr_regs = RegList(DT.float, D_HEAD // 64)
    expdiff_reg = Reg(DT.float)

    expdiff_reg <<= expdiff[0].single()
    accum_regs <<= accum[0]
    curr_regs <<= curr_pv[0]
    accum_regs <<= accum_regs * expdiff_reg
    accum_regs <<= accum_regs + curr_regs
    accum[0] <<= accum_regs


@vf()
def divide_sum_row(accum: Tensor, sum_ub: Tensor):
    regs = RegList(DT.float, D_HEAD // 64)
    sum_reg = Reg(DT.float)

    sum_reg <<= sum_ub[0].single()
    regs <<= accum[0]
    regs <<= regs / sum_reg
    accum[0] <<= regs


@kernel()
def mha_ifa_nz_256(
    q: GMTensor, k: GMTensor, v: GMTensor, output: GMTensor,
    bh: Var, L: Var, S: Var, Dn: Var,
):
    qk_mutex = CvMutex(0, dst_end_pipe=Pipe.V)
    p_mutex = VcMutex(1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)
    pv_mutex = CvMutex(2, dst_end_pipe=Pipe.V)

    l1q = DBuff(DT.half, [16, Dn], Position.L1)
    l1k = TBuff(DT.half, [BASES, Dn], Position.L1)
    l1v = TBuff(DT.half, [BASES, Dn], Position.L1)
    l1p = DBuff(DT.half, [16, BASES], Position.L1)
    l0c_qk = DBuff(DT.float, [16, BASES], Position.L0C)
    l0c_pv = DBuff(DT.float, [16, Dn], Position.L0C)

    ub_qk = DBuff(DT.float, [8, BASES], Position.UB)
    ub_pv = DBuff(DT.float, [8, Dn], Position.UB)
    ub_scaled_qk = Tensor(DT.float, [8, BASES], Position.UB)
    ub_p_nd = DBuff(DT.half, [8, BASES], Position.UB)
    ub_p_nz = DBuff(DT.half, [8, BASES], Position.UB)
    ub_qk_sum = Tensor(DT.float, [1, 64], Position.UB)
    ub_qk_max = Tensor(DT.float, [1, 64], Position.UB)
    ub_expdiff = DBuff(DT.float, [1, 64], Position.UB)
    ub_accum = Tensor(DT.float, [8, Dn], Position.UB)

    bh_per_core = CeilDiv(bh, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, bh)

    rows = Var(1)
    q_cnt = Var(0)
    stage1_cnt = Var(0)
    stage2_cnt = Var(0)

    for bh_idx in range(bh_begin, bh_end):
        l1q[q_cnt][:rows, :] <<= q[bh_idx, :rows, :]
        bar_all()
        init_buffers(ub_qk_sum, ub_qk_max, ub_expdiff[0], ub_expdiff[1], ub_accum)

        with auto_sync():
            for s in range(0, S + BASES, BASES):
                if s > 0:
                    prev_s = Var(s - BASES)
                    l1v[stage2_cnt] <<= v[bh_idx, prev_s:prev_s + BASES, :]

                    p_mutex.wait()
                    matmul(l0c_pv[stage2_cnt], l1p[stage2_cnt], l1v[stage2_cnt].T, splitn=SPLIT_N)
                    p_mutex.free()

                    pv_mutex.lock()
                    ub_pv[stage2_cnt][:rows, :] <<= l0c_pv[stage2_cnt][:rows, :]
                    pv_mutex.ready()

                    pv_mutex.wait()
                    accum_pv_row(ub_accum, ub_pv[stage2_cnt], ub_expdiff[stage2_cnt])
                    pv_mutex.free()
                    stage2_cnt += 1

                if s < S:
                    l1k[stage1_cnt] <<= k[bh_idx, s:s + BASES, :]
                    matmul(l0c_qk[stage1_cnt], l1q[q_cnt], l1k[stage1_cnt], splitk=SPLIT_K)

                    qk_mutex.lock()
                    ub_qk[stage1_cnt][:rows, :] <<= l0c_qk[stage1_cnt][:rows, :]
                    qk_mutex.ready()

                    qk_mutex.wait()
                    scale_qk_row(ub_qk[stage1_cnt], ub_scaled_qk)
                    get_p_and_max_sum_row(
                        ub_scaled_qk,
                        ub_qk_max,
                        ub_qk_sum,
                        ub_expdiff[stage1_cnt],
                        ub_p_nd[stage1_cnt],
                    )
                    qk_mutex.free()

                    p_mutex.lock()
                    if GetSubBlockIdx() == 0:
                        pack_p_to_nz_row(ub_p_nd[stage1_cnt], ub_p_nz[stage1_cnt], rows)
                        l1p[stage1_cnt][:rows, :] <<= ub_p_nz[stage1_cnt][:rows, :].nz()
                    p_mutex.ready()
                    stage1_cnt += 1

        divide_sum_row(ub_accum, ub_qk_sum)
        bar_all()
        if GetSubBlockIdx() == 0:
            output[bh_idx, :rows, :] <<= ub_accum[:rows, :]

        q_cnt += 1

    return output


def self_attn_reference(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    if q.shape[1] != 1:
        raise ValueError("self_attn_reference expects q shape [BH, 1, D].")

    bh, q_rows, dim_v = q.shape[0], q.shape[1], v.shape[2]
    seq_len = k.shape[1]

    row_max = torch.full((bh, q_rows), -99999.0, dtype=torch.float32, device=q.device)
    row_sum = torch.zeros((bh, q_rows), dtype=torch.float32, device=q.device)
    output = torch.zeros((bh, q_rows, dim_v), dtype=torch.float32, device=q.device)

    for s_begin in unroll(0, seq_len, BASES):
        qk = torch.einsum("bld,bsd->bls", q.float(), k[:, s_begin:s_begin + BASES, :].float())
        qk = qk * SCALE

        curr_row_max = qk.amax(dim=-1)
        curr_row_max = torch.maximum(row_max, curr_row_max)
        row_exp_diff = torch.exp(row_max - curr_row_max)
        row_max = curr_row_max

        p = torch.exp(qk - curr_row_max[..., None])
        p = p.to(torch.float16)  # type: ignore

        row_sum = row_sum * row_exp_diff + p.sum(dim=-1)
        curr_output = torch.einsum("bls,bsd->bld", p.float(), v[:, s_begin:s_begin + BASES, :].float())
        output = output * row_exp_diff[..., None] + curr_output

    output = output / row_sum[..., None]
    return output


if __name__ == "__main__":
    B = 2
    L = 1
    H = 8
    S = 3 * BASES
    Dn = D_HEAD

    if L != 1:
        raise ValueError("mha_ifa_nz_256 is the row-specialized L=1 variant.")

    torch.manual_seed(42)

    q = torch.randn(B, H, L, Dn).to(torch.float16)
    k = torch.randn(B, H, S, Dn).to(torch.float16)
    v = torch.randn(B, H, S, Dn).to(torch.float16)

    q = rearrange(q, "b h l d -> (b h) l d")
    k = rearrange(k, "b h s d -> (b h) s d")
    v = rearrange(v, "b h s d -> (b h) s d")

    output = self_attn_reference(q, k, v)
    output_kernel = torch.zeros_like(output)

    op = OpExec(mha_ifa_nz_256, simulator=True, out_dir="./tmp/mha_ifa_nz_256")
    out_kernel = op(
        q, k, v, output_kernel,
        B * H, L, S, Dn,
        shape_bindings={0: [0, 1, 3], 1: [0, 2, 3], 2: [0, 2, 3], 3: [0, 1, 3]},
    )

    torch.testing.assert_close(out_kernel.float(), output.float(), rtol=1e-3, atol=1e-3)
    print(f"max_abs_diff={torch.abs(out_kernel.float() - output.float()).max().item():.6e}")
    cos_sim = F.cosine_similarity(out_kernel.flatten(1), output.flatten(1), dim=1).mean()
    print("Average cosine similarity:", cos_sim.item())
