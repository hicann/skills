# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import builtins
import json
import os
import sys
from typing import Tuple

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import torch

from easyasc import globvars
from easyasc.a5 import *


# Pseudo-reference comparison kernel specialized for the C=8 experiment.
BATCH = 2
HEADS = 32
BATCH_HEADS = BATCH * HEADS
CHUNKS = 8
TOKENS = 64
DIM = 128
HALF_TOKENS = TOKENS // 2
HALF_DIM = DIM // 2
FLOAT_REGS_PER_ROW = DIM // 64
SCALAR_COLS = 8
SPLIT_N = 128
TRACE_PATH = os.path.join(REPO_ROOT, "tmp", "delta_h_psudo_state_bridge_c8_kernel_trace.json")


@vf()
def cast_state_rows_to_half_vf(src_f32: Tensor, dst_f16: Tensor, n_loops: Var):
    reg_f32 = Reg(DT.float)
    for i in range(n_loops):
        reg_f32 <<= src_f32[i * 64]
        dst_f16[i * 64] <<= reg_f32


@vf()
def stage1_postprocess_vf(
    vprime_ub: Tensor, u_ub: Tensor, g_rows_ub: Tensor, g_last_ub: Tensor, v_new_ub: Tensor, v_scaled_ub: Tensor, rows_this: Var,
):
    g_last_reg = Reg(DT.float)
    g_row_reg = Reg(DT.float)
    factor_reg = Reg(DT.float)
    u_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    vprime_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    delta_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    scaled_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    g_last_reg <<= g_last_ub[0:1, 0:1].single()
    for r in range(rows_this):
        u_regs <<= u_ub[r:r + 1, 0:DIM]
        vprime_regs <<= vprime_ub[r:r + 1, 0:DIM]
        delta_regs <<= u_regs - vprime_regs
        v_new_ub[r:r + 1, 0:DIM] <<= delta_regs

        g_row_reg <<= g_rows_ub[r:r + 1, 0:1].single()
        factor_reg <<= g_last_reg - g_row_reg
        factor_reg <<= factor_reg.exp()
        scaled_regs <<= delta_regs * factor_reg
        v_scaled_ub[r:r + 1, 0:DIM] <<= scaled_regs


@vf()
def decay_state_rows_vf(state_rows: Tensor, g_last_ub: Tensor, rows_this: Var):
    decay_reg = Reg(DT.float)
    row_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    decay_reg <<= g_last_ub[0:1, 0:1].single()
    decay_reg <<= decay_reg.exp()
    for r in range(rows_this):
        row_regs <<= state_rows[r:r + 1, 0:DIM]
        row_regs <<= row_regs * decay_reg
        state_rows[r:r + 1, 0:DIM] <<= row_regs


@vf()
def decay_state_rows_inplace_to_half_vf(state_rows: Tensor, dst_f16: Tensor, g_last_ub: Tensor, rows_this: Var):
    decay_reg = Reg(DT.float)
    row_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    decay_reg <<= g_last_ub[0:1, 0:1].single()
    decay_reg <<= decay_reg.exp()
    for r in range(rows_this):
        row_regs <<= state_rows[r:r + 1, 0:DIM]
        row_regs <<= row_regs * decay_reg
        state_rows[r:r + 1, 0:DIM] <<= row_regs
        dst_f16[r:r + 1, 0:DIM] <<= row_regs


@vf()
def add_delta_rows_vf(state_rows: Tensor, delta_rows: Tensor, rows_this: Var):
    state_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    delta_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    for r in range(rows_this):
        state_regs <<= state_rows[r:r + 1, 0:DIM]
        delta_regs <<= delta_rows[r:r + 1, 0:DIM]
        state_regs <<= state_regs + delta_regs
        state_rows[r:r + 1, 0:DIM] <<= state_regs


@vf()
def add_delta_and_snapshot_half_vf(state_rows: Tensor, delta_rows: Tensor, dst_f16: Tensor, rows_this: Var):
    state_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    delta_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    for r in range(rows_this):
        state_regs <<= state_rows[r:r + 1, 0:DIM]
        delta_regs <<= delta_rows[r:r + 1, 0:DIM]
        state_regs <<= state_regs + delta_regs
        state_rows[r:r + 1, 0:DIM] <<= state_regs
        dst_f16[r:r + 1, 0:DIM] <<= state_regs


@kernel()
def delta_h_psudo_state_bridge_c8_kernel_legacy(
    k: GMTensor, w: GMTensor, u: GMTensor, g: GMTensor, initial_state: GMTensor,
    h_out: GMTensor, v_new_out: GMTensor, final_state_out: GMTensor,
):
    state_bridge_mutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    stage1_out_mutex = CvMutex(1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    vscaled_bridge_mutex = VcMutex(2, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    delta_out_mutex = CvMutex(3, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    delta_bridge_mutex = VcMutex(4, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    state_f_ub = Tensor(DT.float, [DIM, DIM], Position.UB)
    state_h_ub = Tensor(DT.half, [HALF_DIM, DIM], Position.UB)
    delta_h_ub = Tensor(DT.half, [HALF_DIM, DIM], Position.UB)
    vprime_ub = Tensor(DT.float, [HALF_TOKENS, DIM], Position.UB)
    u_ub = Tensor(DT.half, [HALF_TOKENS, DIM], Position.UB)
    v_new_ub = Tensor(DT.half, [HALF_TOKENS, DIM], Position.UB)
    v_scaled_ub = Tensor(DT.half, [HALF_TOKENS, DIM], Position.UB)
    g_rows_ub = Tensor(DT.float, [HALF_TOKENS, SCALAR_COLS], Position.UB)
    g_last_ub = Tensor(DT.float, [1, SCALAR_COLS], Position.UB)
    delta_ub = Tensor(DT.float, [HALF_DIM, DIM], Position.UB)

    state_h_l1 = Tensor(DT.half, [DIM, DIM], Position.L1)
    delta_h_l1 = Tensor(DT.half, [DIM, DIM], Position.L1)
    w_l1 = Tensor(DT.half, [TOKENS, DIM], Position.L1)
    k_l1 = Tensor(DT.half, [TOKENS, DIM], Position.L1)
    v_scaled_l1 = Tensor(DT.half, [TOKENS, DIM], Position.L1)

    vprime_l0c = Tensor(DT.float, [TOKENS, DIM], Position.L0C)
    delta_l0c = Tensor(DT.float, [DIM, DIM], Position.L0C)

    bh_per_core = CeilDiv(BATCH_HEADS, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, BATCH_HEADS)

    row_begin_d = Var(GetSubBlockIdx() * HALF_DIM)
    row_end_d = Var(row_begin_d + HALF_DIM)
    row_begin_l = Var(GetSubBlockIdx() * HALF_TOKENS)
    row_end_l = Var(row_begin_l + HALF_TOKENS)
    state_cast_loops = Var(HALF_DIM * DIM // 64)

    with auto_sync():
        for bh_idx in range(bh_begin, bh_end):
            state_row0 = Var(bh_idx * DIM)
            chunk0_row0 = Var(bh_idx * CHUNKS * TOKENS)
            h_chunk0_row0 = Var(bh_idx * CHUNKS * DIM)
            state_f_ub[row_begin_d:row_end_d, 0:DIM] <<= initial_state[state_row0 + row_begin_d:state_row0 + row_end_d, 0:DIM]

            state_bridge_mutex.lock()
            cast_state_rows_to_half_vf(
                state_f_ub[row_begin_d:row_end_d, 0:DIM],
                state_h_ub[0:HALF_DIM, 0:DIM],
                state_cast_loops,
            )
            state_h_l1[row_begin_d:row_end_d, 0:DIM] <<= state_h_ub[0:HALF_DIM, 0:DIM]
            state_bridge_mutex.ready()

            h_out[h_chunk0_row0 + row_begin_d:h_chunk0_row0 + row_end_d, 0:DIM] <<= state_h_ub[0:HALF_DIM, 0:DIM]
            w_l1[0:TOKENS, 0:DIM] <<= w[chunk0_row0:chunk0_row0 + TOKENS, 0:DIM]
            state_bridge_mutex.wait()
            matmul(vprime_l0c, w_l1, state_h_l1.T, splitn=SPLIT_N)
            state_bridge_mutex.free()

            stage1_out_mutex.lock()
            vprime_ub[0:HALF_TOKENS, 0:DIM] <<= vprime_l0c
            stage1_out_mutex.ready()

            for chunk_idx in range(0, CHUNKS):
                chunk_row0 = Var((bh_idx * CHUNKS + chunk_idx) * TOKENS)

                if chunk_idx > 0:
                    prev_chunk_idx = Var(chunk_idx - 1)
                    prev_chunk_row0 = Var((bh_idx * CHUNKS + prev_chunk_idx) * TOKENS)
                    h_row0 = Var((bh_idx * CHUNKS + chunk_idx) * DIM)

                    k_l1[0:TOKENS, 0:DIM] <<= k[prev_chunk_row0:prev_chunk_row0 + TOKENS, 0:DIM]
                    vscaled_bridge_mutex.wait()
                    matmul(delta_l0c, k_l1.T, v_scaled_l1.T, splitn=SPLIT_N)
                    vscaled_bridge_mutex.free()

                    delta_out_mutex.lock()
                    delta_ub[0:HALF_DIM, 0:DIM] <<= delta_l0c
                    delta_out_mutex.ready()

                    delta_out_mutex.wait()
                    add_delta_rows_vf(state_f_ub[row_begin_d:row_end_d, 0:DIM], delta_ub[0:HALF_DIM, 0:DIM], HALF_DIM)
                    cast_state_rows_to_half_vf(
                        state_f_ub[row_begin_d:row_end_d, 0:DIM],
                        state_h_ub[0:HALF_DIM, 0:DIM],
                        state_cast_loops,
                    )
                    h_out[h_row0 + row_begin_d:h_row0 + row_end_d, 0:DIM] <<= state_h_ub[0:HALF_DIM, 0:DIM]

                    delta_bridge_mutex.lock()
                    cast_state_rows_to_half_vf(delta_ub[0:HALF_DIM, 0:DIM], delta_h_ub[0:HALF_DIM, 0:DIM], state_cast_loops)
                    delta_h_l1[row_begin_d:row_end_d, 0:DIM] <<= delta_h_ub[0:HALF_DIM, 0:DIM]
                    delta_bridge_mutex.ready()

                    w_l1[0:TOKENS, 0:DIM] <<= w[chunk_row0:chunk_row0 + TOKENS, 0:DIM]
                    state_bridge_mutex.wait()
                    matmul(vprime_l0c, w_l1, state_h_l1.T, splitn=SPLIT_N)
                    state_bridge_mutex.free()

                    delta_bridge_mutex.wait()
                    matmul(vprime_l0c, w_l1, delta_h_l1.T, splitn=SPLIT_N, is_init=False)
                    delta_bridge_mutex.free()

                    stage1_out_mutex.lock()
                    vprime_ub[0:HALF_TOKENS, 0:DIM] <<= vprime_l0c
                    stage1_out_mutex.ready()
                    delta_out_mutex.free()

                stage1_vec_row0 = chunk_row0
                u_ub[0:HALF_TOKENS, 0:DIM] <<= u[stage1_vec_row0 + row_begin_l:stage1_vec_row0 + row_end_l, 0:DIM]
                g_rows_ub[0:HALF_TOKENS, 0:1] <<= g[stage1_vec_row0 + row_begin_l:stage1_vec_row0 + row_end_l, 0:1]
                g_last_ub[0:1, 0:1] <<= g[stage1_vec_row0 + TOKENS - 1:stage1_vec_row0 + TOKENS, 0:1]
                stage1_out_mutex.wait()
                stage1_postprocess_vf(vprime_ub, u_ub, g_rows_ub, g_last_ub, v_new_ub, v_scaled_ub, HALF_TOKENS)
                stage1_out_mutex.free()

                v_new_out[stage1_vec_row0 + row_begin_l:stage1_vec_row0 + row_end_l, 0:DIM] <<= v_new_ub[0:HALF_TOKENS, 0:DIM]
                decay_state_rows_vf(state_f_ub[row_begin_d:row_end_d, 0:DIM], g_last_ub, HALF_DIM)

                if chunk_idx < CHUNKS - 1:
                    state_bridge_mutex.lock()
                    cast_state_rows_to_half_vf(
                        state_f_ub[row_begin_d:row_end_d, 0:DIM],
                        state_h_ub[0:HALF_DIM, 0:DIM],
                        state_cast_loops,
                    )
                    state_h_l1[row_begin_d:row_end_d, 0:DIM] <<= state_h_ub[0:HALF_DIM, 0:DIM]
                    state_bridge_mutex.ready()

                vscaled_bridge_mutex.lock()
                v_scaled_l1[row_begin_l:row_end_l, 0:DIM] <<= v_scaled_ub[0:HALF_TOKENS, 0:DIM]
                vscaled_bridge_mutex.ready()

            k_last_row0 = Var((bh_idx * CHUNKS + CHUNKS - 1) * TOKENS)
            k_l1[0:TOKENS, 0:DIM] <<= k[k_last_row0:k_last_row0 + TOKENS, 0:DIM]
            vscaled_bridge_mutex.wait()
            matmul(delta_l0c, k_l1.T, v_scaled_l1.T, splitn=SPLIT_N)
            vscaled_bridge_mutex.free()

            delta_out_mutex.lock()
            delta_ub[0:HALF_DIM, 0:DIM] <<= delta_l0c
            delta_out_mutex.ready()
            delta_out_mutex.wait()
            add_delta_rows_vf(state_f_ub[row_begin_d:row_end_d, 0:DIM], delta_ub[0:HALF_DIM, 0:DIM], HALF_DIM)
            delta_out_mutex.free()

            final_state_out[state_row0 + row_begin_d:state_row0 + row_end_d, 0:DIM] <<= state_f_ub[row_begin_d:row_end_d, 0:DIM]
            bar_all()

    return h_out, v_new_out, final_state_out


# Official pseudo kernel implementation following `_psudo_code_delta_h_impl`.
@kernel()
def delta_h_psudo_state_bridge_c8_kernel(
    k: GMTensor, w: GMTensor, u: GMTensor, g: GMTensor, initial_state: GMTensor,
    h_out: GMTensor, v_new_out: GMTensor, final_state_out: GMTensor,
):
    delta_h_mutex = CvMutex(0, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    vprime_mutex = CvMutex(1, depth=1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    vscaled_bridge_mutex = VcMutex(2, depth=1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    h_cur_cube_mutex = VcMutex(3, depth=1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)

    h_cur_vec_ub = Tensor(DT.float, [DIM, DIM], Position.UB)
    h_out_half_ub = Tensor(DT.half, [HALF_DIM, DIM], Position.UB)
    h_cur_half_ub = Tensor(DT.half, [HALF_DIM, DIM], Position.UB)
    delta_h_ub = Tensor(DT.float, [HALF_DIM, DIM], Position.UB)
    u_ub = Tensor(DT.half, [HALF_TOKENS, DIM], Position.UB)
    vprime_ub = Tensor(DT.float, [HALF_TOKENS, DIM], Position.UB)
    v_new_ub = Tensor(DT.half, [HALF_TOKENS, DIM], Position.UB)
    v_scaled_ub = Tensor(DT.half, [HALF_TOKENS, DIM], Position.UB)
    g_rows_ub = Tensor(DT.float, [HALF_TOKENS, SCALAR_COLS], Position.UB)
    g_last_ub = Tensor(DT.float, [1, SCALAR_COLS], Position.UB)

    h_cur_l1 = Tensor(DT.half, [DIM, DIM], Position.L1)
    w_chunk_l1 = Tensor(DT.half, [TOKENS, DIM], Position.L1)
    k_chunk_l1 = Tensor(DT.half, [TOKENS, DIM], Position.L1)
    v_scale_buf_l1 = Tensor(DT.half, [TOKENS, DIM], Position.L1)
    delta_h_l1 = Tensor(DT.half, [DIM, DIM], Position.L1)

    vprime_l0c = Tensor(DT.float, [TOKENS, DIM], Position.L0C)
    delta_h_l0c = Tensor(DT.float, [DIM, DIM], Position.L0C)

    bh_per_core = CeilDiv(BATCH_HEADS, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, BATCH_HEADS)

    row_begin_d = Var(GetSubBlockIdx() * HALF_DIM)
    row_end_d = Var(row_begin_d + HALF_DIM)
    row_begin_l = Var(GetSubBlockIdx() * HALF_TOKENS)
    row_end_l = Var(row_begin_l + HALF_TOKENS)
    state_cast_loops = Var(HALF_DIM * DIM // 64)

    with auto_sync():
        for bh_idx in range(bh_begin, bh_end):
            state_row0 = Var(bh_idx * DIM)
            h_cur_vec_ub[row_begin_d:row_end_d, 0:DIM] <<= initial_state[state_row0 + row_begin_d:state_row0 + row_end_d, 0:DIM]
            cast_state_rows_to_half_vf(
                h_cur_vec_ub[row_begin_d:row_end_d, 0:DIM],
                h_out_half_ub[0:HALF_DIM, 0:DIM],
                state_cast_loops,
            )
            h_cur_cube_mutex.lock()
            cast_state_rows_to_half_vf(
                h_cur_vec_ub[row_begin_d:row_end_d, 0:DIM],
                h_cur_half_ub[0:HALF_DIM, 0:DIM],
                state_cast_loops,
            )
            h_cur_l1[row_begin_d:row_end_d, 0:DIM] <<= h_cur_half_ub[0:HALF_DIM, 0:DIM]
            h_cur_cube_mutex.ready()

            for chunk_idx in range(0, CHUNKS):
                chunk_row0 = Var((bh_idx * CHUNKS + chunk_idx) * TOKENS)
                h_chunk_row0 = Var((bh_idx * CHUNKS + chunk_idx) * DIM)

                if chunk_idx == 0:
                    # chunk 0:
                    #   w_chunk_buf <<= w[...]
                    #   h_cur_delta_h_buf <<= h_cur[...]
                    #   matmul(v_prime_l0c, w_chunk_buf, h_cur_delta_h_buf.T)
                    #   v_prime_ub <<= v_prime_l0c
                    w_chunk_l1[0:TOKENS, 0:DIM] <<= w[chunk_row0:chunk_row0 + TOKENS, 0:DIM]
                    h_cur_cube_mutex.wait()
                    matmul(vprime_l0c, w_chunk_l1, h_cur_l1.T, splitn=SPLIT_N)
                    h_cur_cube_mutex.free()
                    vprime_mutex.lock()
                    vprime_ub[0:HALF_TOKENS, 0:DIM] <<= vprime_l0c
                    vprime_mutex.ready()
                else:
                    prev_chunk_row0 = Var((bh_idx * CHUNKS + chunk_idx - 1) * TOKENS)

                    # chunk > 0:
                    #   k_chunk_buf <<= k[prev]
                    #   delta_h = k_chunk.T @ v_scaled
                    #   DSL matmul is A @ B.T, so:
                    #   delta_h_l0c = matmul(k_chunk_buf.T, v_scale_buf.T)
                    #   delta_h_l1 <<= delta_h_l0c
                    #   delta_h_fix_to_l1_ready.set()
                    #   delta_h_fix_to_l1_ready.wait()
                    #   delta_h_mutex.lock()
                    #   delta_h_ub <<= delta_h_l0c
                    #   delta_h_mutex.ready()
                    #   w_chunk_buf <<= w[cur]
                    #   v_prime_l0c += matmul(w_chunk_buf, delta_h_l1.T)
                    #   v_prime_ub <<= v_prime_l0c
                    k_chunk_l1[0:TOKENS, 0:DIM] <<= k[prev_chunk_row0:prev_chunk_row0 + TOKENS, 0:DIM]
                    vscaled_bridge_mutex.wait()
                    matmul(delta_h_l0c, k_chunk_l1.T, v_scale_buf_l1.T, splitn=SPLIT_N)
                    vscaled_bridge_mutex.free()
                    # `delta_h_l1.T` is consumed as a full matrix by both cube subblocks.
                    # A direct half-row L0C->L1 split copy does not preserve the source
                    # row offset in current lowering, so one subblock materializes the full
                    # matrix and we synchronize before the correction matmul reads it.
                    if GetSubBlockIdx() == 0:
                        delta_h_l1[0:DIM, 0:DIM] <<= delta_h_l0c[0:DIM, 0:DIM]
                    bar_all()
                    delta_h_mutex.lock()
                    delta_h_ub[0:HALF_DIM, 0:DIM] <<= delta_h_l0c
                    delta_h_mutex.ready()
                    w_chunk_l1[0:TOKENS, 0:DIM] <<= w[chunk_row0:chunk_row0 + TOKENS, 0:DIM]
                    # This is the correction term in `v_prime += torch.matmul(w_chunk.float(), delta_h.float())`.
                    matmul(vprime_l0c, w_chunk_l1, delta_h_l1.T, splitn=SPLIT_N, is_init=False)
                    vprime_mutex.lock()
                    vprime_ub[0:HALF_TOKENS, 0:DIM] <<= vprime_l0c
                    vprime_mutex.ready()

                # vec-side state update, stopping at:
                #   h_cur_vec = h_cur_vec * decay.unsqueeze(-1).unsqueeze(-1)
                g_last_ub[0:1, 0:1] <<= g[chunk_row0 + TOKENS - 1:chunk_row0 + TOKENS, 0:1]
                if chunk_idx > 0:
                    delta_h_mutex.wait()
                    add_delta_and_snapshot_half_vf(
                        h_cur_vec_ub[row_begin_d:row_end_d, 0:DIM],
                        delta_h_ub[0:HALF_DIM, 0:DIM],
                        h_out_half_ub[0:HALF_DIM, 0:DIM],
                        HALF_DIM,
                    )
                    delta_h_mutex.free()
                decay_state_rows_inplace_to_half_vf(
                    h_cur_vec_ub[row_begin_d:row_end_d, 0:DIM],
                    h_cur_half_ub[0:HALF_DIM, 0:DIM],
                    g_last_ub,
                    HALF_DIM,
                )
                h_out[h_chunk_row0 + row_begin_d:h_chunk_row0 + row_end_d, 0:DIM] <<= h_out_half_ub[0:HALF_DIM, 0:DIM]
                if chunk_idx < CHUNKS - 1:
                    next_chunk_row0 = Var((bh_idx * CHUNKS + chunk_idx + 1) * TOKENS)
                    h_cur_cube_mutex.lock()
                    h_cur_l1[row_begin_d:row_end_d, 0:DIM] <<= h_cur_half_ub[0:HALF_DIM, 0:DIM]
                    h_cur_cube_mutex.ready()
                    w_chunk_l1[0:TOKENS, 0:DIM] <<= w[next_chunk_row0:next_chunk_row0 + TOKENS, 0:DIM]
                    h_cur_cube_mutex.wait()
                    matmul(vprime_l0c, w_chunk_l1, h_cur_l1.T, splitn=SPLIT_N)
                    h_cur_cube_mutex.free()

                # vec-side postprocess:
                #   v_delta = u_chunk - v_prime
                #   factor = exp(g_last - g_chunk)
                #   v_scaled = (v_delta * factor).to(u.dtype)
                #   v_new = v_delta.to(u.dtype)
                u_ub[0:HALF_TOKENS, 0:DIM] <<= u[chunk_row0 + row_begin_l:chunk_row0 + row_end_l, 0:DIM]
                g_rows_ub[0:HALF_TOKENS, 0:1] <<= g[chunk_row0 + row_begin_l:chunk_row0 + row_end_l, 0:1]
                vprime_mutex.wait()
                stage1_postprocess_vf(
                    vprime_ub,
                    u_ub,
                    g_rows_ub,
                    g_last_ub,
                    v_new_ub,
                    v_scaled_ub,
                    HALF_TOKENS,
                )
                vprime_mutex.free()
                v_new_out[chunk_row0 + row_begin_l:chunk_row0 + row_end_l, 0:DIM] <<= v_new_ub[0:HALF_TOKENS, 0:DIM]
                vscaled_bridge_mutex.lock()
                v_scale_buf_l1[row_begin_l:row_end_l, 0:DIM] <<= v_scaled_ub[0:HALF_TOKENS, 0:DIM]
                vscaled_bridge_mutex.ready()

            # final_state = h_cur_vec + (k_last.T @ v_scaled_last)
            k_last_row0 = Var((bh_idx * CHUNKS + CHUNKS - 1) * TOKENS)
            k_chunk_l1[0:TOKENS, 0:DIM] <<= k[k_last_row0:k_last_row0 + TOKENS, 0:DIM]
            vscaled_bridge_mutex.wait()
            matmul(delta_h_l0c, k_chunk_l1.T, v_scale_buf_l1.T, splitn=SPLIT_N)
            vscaled_bridge_mutex.free()
            delta_h_mutex.lock()
            delta_h_ub[0:HALF_DIM, 0:DIM] <<= delta_h_l0c
            delta_h_mutex.ready()
            delta_h_mutex.wait()
            add_delta_rows_vf(
                h_cur_vec_ub[row_begin_d:row_end_d, 0:DIM],
                delta_h_ub[0:HALF_DIM, 0:DIM],
                HALF_DIM,
            )
            delta_h_mutex.free()
            final_state_out[state_row0 + row_begin_d:state_row0 + row_end_d, 0:DIM] <<= h_cur_vec_ub[row_begin_d:row_end_d, 0:DIM]
            bar_all()

    return h_out, v_new_out, final_state_out


# Backward-compatible alias for earlier debugging scripts.
delta_h_psudo_state_bridge_c8_kernel_rewrite_v0 = delta_h_psudo_state_bridge_c8_kernel


def _build_inputs() -> Tuple[torch.Tensor, ...]:
    torch.manual_seed(0)

    data_scale = 0.05
    k = torch.randn(BATCH, HEADS, CHUNKS, TOKENS, DIM, dtype=torch.float16) * data_scale
    w = torch.randn(BATCH, HEADS, CHUNKS, TOKENS, DIM, dtype=torch.float16) * data_scale
    u = torch.randn(BATCH, HEADS, CHUNKS, TOKENS, DIM, dtype=torch.float16) * data_scale
    g = torch.log(torch.sigmoid(torch.randn(BATCH, HEADS, CHUNKS, TOKENS, dtype=torch.float32)))
    initial_state = torch.zeros(BATCH, HEADS, DIM, DIM, dtype=torch.float32)
    return k, w, u, g, initial_state


def _flatten_inputs(
    k: torch.Tensor, w: torch.Tensor, u: torch.Tensor, g: torch.Tensor, initial_state: torch.Tensor,
) -> Tuple[torch.Tensor, ...]:
    k_f = k.reshape(BATCH_HEADS * CHUNKS * TOKENS, DIM).contiguous()
    w_f = w.reshape(BATCH_HEADS * CHUNKS * TOKENS, DIM).contiguous()
    u_f = u.reshape(BATCH_HEADS * CHUNKS * TOKENS, DIM).contiguous()
    g_f = g.reshape(BATCH_HEADS * CHUNKS * TOKENS, 1).contiguous()
    initial_state_f = initial_state.reshape(BATCH_HEADS * DIM, DIM).contiguous()

    h_out_f = torch.empty((BATCH_HEADS * CHUNKS * DIM, DIM), dtype=torch.float16)
    v_new_out_f = torch.empty((BATCH_HEADS * CHUNKS * TOKENS, DIM), dtype=torch.float16)
    final_state_out_f = torch.empty((BATCH_HEADS * DIM, DIM), dtype=torch.float32)
    return k_f, w_f, u_f, g_f, initial_state_f, h_out_f, v_new_out_f, final_state_out_f


def _psudo_code_delta_h_impl(
    k: torch.Tensor, w: torch.Tensor, u: torch.Tensor, g: torch.Tensor, initial_state: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    batch, heads, chunks, tokens, dim = k.shape
    v_new = torch.empty((batch, heads, chunks, tokens, dim), dtype=u.dtype, device=u.device)
    h_cur_cube = initial_state
    h_cur_vec = initial_state

    h = torch.empty((batch, heads, chunks, dim, dim), dtype=k.dtype, device=k.device)
    h[:, :, 0] = h_cur_vec

    for chunk_idx in builtins.range(chunks):
        w_chunk = w[:, :, chunk_idx]
        u_chunk = u[:, :, chunk_idx]
        g_chunk = g[:, :, chunk_idx]
        g_last = g_chunk[:, :, -1]

        if chunk_idx == 0:
            v_prime = torch.matmul(w_chunk.half().float(), h_cur_cube.half().float())
        else:
            k_chunk = k[:, :, chunk_idx - 1]
            delta_h = torch.matmul(k_chunk.transpose(-1, -2).float(), v_scaled.float())
            v_prime += torch.matmul(w_chunk.float(), delta_h.float())

        decay = torch.exp(g_last)
        if chunk_idx > 0:
            h_cur_vec = h_cur_vec + delta_h
            h[:, :, chunk_idx] = h_cur_vec
        h_cur_vec = h_cur_vec * decay.unsqueeze(-1).unsqueeze(-1)

        v_delta = u_chunk - v_prime
        factor = torch.exp(g_last.unsqueeze(-1) - g_chunk).unsqueeze(-1)
        v_scaled = (v_delta * factor).to(u.dtype)
        v_new[:, :, chunk_idx] = v_delta.to(u.dtype)

        if chunk_idx < chunks - 1:
            w_chunk_next = w[:, :, chunk_idx + 1]
            h_cur_cube = h_cur_vec.half()
            v_prime = torch.matmul(w_chunk_next.float(), h_cur_cube.float())

    k_chunk = k[:, :, -1]
    delta_h = torch.matmul(k_chunk.transpose(-1, -2).float(), v_scaled.float())
    final_state = h_cur_vec + delta_h
    return h, v_new, final_state


def _pseudo_reference(
    k: torch.Tensor, w: torch.Tensor, u: torch.Tensor, g: torch.Tensor, initial_state: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    return _psudo_code_delta_h_impl(k, w, u.to(torch.float32), g, initial_state)


def _trace_makespan(trace_path: str) -> float:
    with open(trace_path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)

    timed_events = [event for event in payload.get("traceEvents", []) if event.get("ph") == "X"]
    if not timed_events:
        raise ValueError(f"trace contains no timed events: {trace_path}")
    return max(float(event.get("ts", 0.0)) + float(event.get("dur", 0.0)) for event in timed_events)


def _print_debug_diffs(name: str, actual: torch.Tensor, ref: torch.Tensor) -> None:
    diff = (actual.float() - ref.float()).abs()
    max_idx_flat = int(diff.reshape(-1).argmax().item())
    max_idx = tuple(int(i) for i in torch.unravel_index(torch.tensor(max_idx_flat), diff.shape))
    print(f"{name}_max_abs_diff={diff.max().item():.6e}")
    print(f"{name}_mean_abs_diff={diff.mean().item():.6e}")
    print(f"{name}_max_diff_index={max_idx}")
    print(f"{name}_actual_at_max={actual[max_idx].item():.6e}")
    print(f"{name}_ref_at_max={ref[max_idx].item():.6e}")
    if diff.ndim >= 3:
        leading = diff
        while leading.ndim > 3:
            leading = leading.amax(dim=-1)
        if leading.ndim == 3:
            per_chunk = leading.mean(dim=(0, 1))
            print(f"{name}_per_chunk_mean_max={[float(x) for x in per_chunk]}")


def run_validation(enable_trace: bool = False) -> Tuple[float, float, float, float, str]:
    trace_path = TRACE_PATH
    if enable_trace:
        os.makedirs(os.path.dirname(trace_path), exist_ok=True)

    k, w, u, g, initial_state = _build_inputs()
    h_ref, v_new_ref, final_state_ref = _pseudo_reference(k, w, u, g, initial_state)

    k_f, w_f, u_f, g_f, initial_state_f, h_out_f, v_new_out_f, final_state_out_f = _flatten_inputs(
        k, w, u, g, initial_state
    )

    saved_trace_event = getattr(globvars, "trace_event", False)
    globvars.trace_event = False
    try:
        h_kernel_f, v_new_kernel_f, final_state_kernel_f = OpExec(
            delta_h_psudo_state_bridge_c8_kernel,
            simulator=True,
            trace=trace_path if enable_trace else None,
        )(k_f, w_f, u_f, g_f, initial_state_f, h_out_f, v_new_out_f, final_state_out_f)
    finally:
        globvars.trace_event = saved_trace_event

    h_kernel = h_kernel_f.reshape(BATCH, HEADS, CHUNKS, DIM, DIM)
    v_new_kernel = v_new_kernel_f.reshape(BATCH, HEADS, CHUNKS, TOKENS, DIM)
    final_state_kernel = final_state_kernel_f.reshape(BATCH, HEADS, DIM, DIM)

    h_diff = torch.abs(h_kernel.float() - h_ref.float()).max().item()
    v_new_diff = torch.abs(v_new_kernel.float() - v_new_ref.float()).max().item()
    final_state_diff = torch.abs(final_state_kernel.float() - final_state_ref.float()).max().item()
    if os.environ.get("DELTA_H_DEBUG", "") == "1":
        _print_debug_diffs("h", h_kernel, h_ref)
        _print_debug_diffs("v_new", v_new_kernel, v_new_ref)
        _print_debug_diffs("final_state", final_state_kernel, final_state_ref)

    torch.testing.assert_close(h_kernel.float(), h_ref.float(), rtol=5e-2, atol=5e-2)
    torch.testing.assert_close(v_new_kernel.float(), v_new_ref.float(), rtol=5e-2, atol=5e-2)
    torch.testing.assert_close(final_state_kernel.float(), final_state_ref.float(), rtol=5e-2, atol=5e-2)

    final_cycle = _trace_makespan(trace_path) if enable_trace else float("nan")
    return h_diff, v_new_diff, final_state_diff, final_cycle, trace_path


if __name__ == "__main__":
    enable_trace = os.environ.get("DELTA_H_TRACE", "") == "1"
    max_h_diff, max_v_new_diff, max_final_state_diff, final_cycle, trace_path = run_validation(enable_trace=enable_trace)
    print(f"max_h_diff={max_h_diff:.6e}")
    print(f"max_v_new_diff={max_v_new_diff:.6e}")
    print(f"max_final_state_diff={max_final_state_diff:.6e}")
    print(f"final_cycle={final_cycle:.6e}")
    print(f"trace_path={trace_path}")
    print(f"trace_enabled={enable_trace}")
