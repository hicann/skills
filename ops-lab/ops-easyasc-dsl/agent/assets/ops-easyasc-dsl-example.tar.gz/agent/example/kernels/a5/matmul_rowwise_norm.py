# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from easyasc.a5 import *


TILE_M = 128
TILE_N = 256
TILE_K = 128
SPLIT_N = 128
VEC_WIDTH = 64
REGS_PER_ROW = TILE_N // VEC_WIDTH


@vf()
def normalize_rows_vf(src: Tensor, dst: Tensor, rows: Var):
    row_regs = RegList(DT.float, REGS_PER_ROW)
    sum_reg = Reg(DT.float)
    denom_reg = Reg(DT.float)

    for r in range(rows):
        src_row = src[r:r + 1, :]
        dst_row = dst[r:r + 1, :]

        row_regs <<= src_row
        sum_reg <<= row_regs.cadd()
        denom_reg <<= sum_reg.dup()
        row_regs <<= row_regs / denom_reg
        dst_row <<= row_regs


@kernel()
def matmul_rowwise_norm_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [TILE_M, TILE_K], Position.L1)
    l1y = DBuff(DT.half, [TILE_N, TILE_K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)
    xbuf = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)
    outbuf = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)

    tile_cnt = Var(0)
    vf_rows = Var(TILE_M // 2)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)

            l1x[tile_cnt] <<= x[m0:m0 + valid_m, 0:K]
            l1y[tile_cnt] <<= y[0:N, 0:K]
            matmul(l0c[tile_cnt], l1x[tile_cnt], l1y[tile_cnt], splitn=SPLIT_N)

            cvmutex.lock()
            xbuf[tile_cnt] <<= l0c[tile_cnt]
            cvmutex.ready()

            cvmutex.wait()
            normalize_rows_vf(xbuf[tile_cnt], outbuf[tile_cnt], vf_rows)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = GetSubBlockIdx()
            row_begin = sb_idx * half_rows
            row_end = Min(row_begin + half_rows, valid_m)
            row_count = row_end - row_begin
            z[m0 + row_begin:m0 + row_end, 0:N] <<= outbuf[tile_cnt][0:row_count, :]
            cvmutex.free()
            tile_cnt += 1
    return z


if __name__ == "__main__":
    import torch

    M = 5120
    N = 256
    K = 128
    torch.manual_seed(0)

    # Keep row sums positive so this sample measures normalization fidelity,
    # not cancellation around a near-zero denominator.
    x = torch.rand((M, K), dtype=torch.float16)
    y = torch.rand((N, K), dtype=torch.float16)
    z = torch.zeros((M, N), dtype=torch.float32)

    z_ref = x.float() @ y.float().t()
    z_ref = z_ref / z_ref.sum(dim=-1, keepdim=True)

    z_kernel = OpExec(matmul_rowwise_norm_kernel, simulator=True)(x, y, z, M, N, K)

    torch.testing.assert_close(z_kernel, z_ref, rtol=2e-3, atol=2e-3)
    print(f"max_abs_diff={torch.abs(z_kernel - z_ref).max().item():.6e}")
