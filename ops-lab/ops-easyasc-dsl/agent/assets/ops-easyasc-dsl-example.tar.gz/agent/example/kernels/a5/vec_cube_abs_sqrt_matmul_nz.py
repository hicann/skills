# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from easyasc.a5 import *


TILE_M = 64
TILE_N = 128
TILE_K = 128
HALF_TILE_M = (TILE_M + 1) // 2


@vf()
def abs_sqrt_pack_nz_vf(x_nd: Tensor, out_nz: Tensor, n_rows: Var):
    f32reg_0 = Reg(DT.float)
    f32reg_1 = Reg(DT.float)
    f16reg_0 = Reg(DT.half)
    f16reg_1 = Reg(DT.half)
    out_reg = Reg(DT.half)
    dummy_reg = Reg(DT.half)

    for i in range(n_rows):
        # Force float compute in vf for abs/sqrt before packing back to half.
        f32reg_0 <<= x_nd[i:, 0:64]
        f32reg_1 <<= x_nd[i:, 64:128]
        f32reg_0 <<= f32reg_0.abs().sqrt()
        f32reg_1 <<= f32reg_1.abs().sqrt()
        f16reg_0 <<= f32reg_0.astype(DT.half)
        f16reg_1 <<= f32reg_1.astype(DT.half)
        deinterleave(out_reg, dummy_reg, f16reg_0, f16reg_1)
        # Write each logical row into packed-NZ source layout for UB2L1_NZ.
        reg_to_ub(out_nz[i * 16], out_reg, n_rows)


@kernel()
def vec_cube_abs_sqrt_matmul_nz_kernel(x: GMTensor, y: GMTensor, z_ref: GMTensor, M: Var, N: Var, K: Var):
    # Vec producer ends on MTE3 (ub_to_l1_nz); cube consumer completes on FIX.
    vcmutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)

    l1x = DBuff(DT.half, [TILE_M, TILE_K], Position.L1)
    l1y = DBuff(DT.half, [TILE_N, TILE_K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)
    x_nd_ub = DBuff(DT.half, [HALF_TILE_M, TILE_K], Position.UB)
    x_nz_ub = DBuff(DT.half, [HALF_TILE_M, TILE_K], Position.UB)

    xcnt = Var(0)
    ycnt = Var(0)
    vcnt = Var(0)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)

            vcmutex.lock()
            half_rows = CeilDiv(valid_m, 2)
            row_begin = Var(GetSubBlockIdx() * half_rows)
            if row_begin < valid_m:
                row_end = Min(row_begin + half_rows, valid_m)
                row_count = Var(row_end - row_begin)
                x_nd_ub[vcnt][0:row_count, 0:TILE_K] <<= x[m0 + row_begin:m0 + row_end, 0:TILE_K]
                abs_sqrt_pack_nz_vf(x_nd_ub[vcnt], x_nz_ub[vcnt], row_count)
                l1x[xcnt][row_begin:row_end, 0:TILE_K] <<= x_nz_ub[vcnt][0:row_count, 0:TILE_K].nz()
            vcnt += 1
            vcmutex.ready()

            vcmutex.wait()
            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                l1y[ycnt][0:valid_n, 0:TILE_K] <<= y[n0:n0 + valid_n, 0:TILE_K]
                matmul(l0c[ycnt], l1x[xcnt], l1y[ycnt])
                z_ref[m0:m0 + valid_m, n0:n0 + valid_n] <<= l0c[ycnt][0:valid_m, 0:valid_n]
                ycnt += 1
            vcmutex.free()
            xcnt += 1

    return z_ref


if __name__ == "__main__":
    import torch

    M = 128 * 32
    N = 1024
    K = 128

    torch.manual_seed(0)
    x = torch.randn(M, K).half()
    y = torch.randn(N, K).half()
    z_ref = torch.zeros(M, N).float()

    z_kernel = OpExec(vec_cube_abs_sqrt_matmul_nz_kernel, simulator=True)(x, y, z_ref, M, N, K)
    z_golden = x.float().abs().sqrt().half().float() @ y.float().t()
    torch.testing.assert_close(z_kernel, z_golden, rtol=1e-3, atol=1e-3)
    print(f"max_abs_diff={torch.abs(z_kernel - z_golden).max().item():.6e}")
