# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------

from easyasc.a5 import *


BLK = 64
LANES = 4

@vf()
def simple_micro(x: Tensor, out: Tensor):
    xreg = Reg(DT.half)
    for i in range(BLK):
        xreg <<= x[i*128]
        xreg <<= xreg.exp() + 2.0
        out[i*128] <<= xreg


@kernel()
def cubefunc(x: GMTensor, y: GMTensor, M: Var, K: Var):
    xbuf = DBuff(DT.half, [BLK, 128], Position.UB)
    outbuf = DBuff(DT.half, [BLK, 128], Position.UB)

    tile_cnt = Var(0)

    m_per_core = CeilDiv(M, GetVecNum())
    m1 = Var(m_per_core * GetVecIdx())
    m2 = Min(m1 + m_per_core, M)

    with auto_sync():
        for m in range(m1, m2, BLK):
            xbuf[tile_cnt] <<= x[m:m+BLK, :]
            if GetVecIdx()==0:
                sim_print(xbuf[tile_cnt], pipe=Pipe.MTE2)
            simple_micro(xbuf[tile_cnt], outbuf[tile_cnt])
            y[m:m+BLK, :] <<= outbuf[tile_cnt]
            tile_cnt += 1 

    return y


if __name__ == "__main__":
    import torch 

    out_dir = "test_cust_op"

    M = 64*64 
    K = 100 
    x = torch.ones(M, K).half()
    y = torch.ones(M, K).half()

    op = OpExec(cubefunc, out_dir, simulator=True)
    z_kernel = op(x, y, M, K)

    z_golden = torch.exp(x) + 2.0
    torch.testing.assert_close(z_kernel, z_golden, rtol=1e-3, atol=1e-3)
    print(torch.abs(z_kernel - z_golden).max())
