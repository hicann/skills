# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import builtins

import torch

from easyasc.a5 import *


# This kernel follows the side-pruning root case scaffold and is specialized for D=128.
D = 128
VEC_WIDTH = 64
REGS_PER_ROW = D // VEC_WIDTH

# UB second-dimension alignment (float32: 8 elements == 32B).
SCALAR_COLS = 8


@vf()
def recurrent_step_vf(
    state_ub: Tensor, q_ub: Tensor, k_ub: Tensor, v_ub: Tensor, g_ub: Tensor, beta_ub: Tensor, out_ub: Tensor,
):
    g_reg = Reg(DT.float)
    beta_reg = Reg(DT.float)
    scalar_reg = Reg(DT.float)
    row_regs = RegList(DT.float, REGS_PER_ROW)
    acc_regs = RegList(DT.float, REGS_PER_ROW)
    kv_regs = RegList(DT.float, REGS_PER_ROW)
    delta_regs = RegList(DT.float, REGS_PER_ROW)

    g_reg <<= g_ub[0:1, 0:1].single()
    g_reg <<= g_reg.exp()
    beta_reg <<= beta_ub[0:1, 0:1].single()

    # Merge:
    # 1) last_recurrent_state *= exp(g_t)
    # 2) kv_mem = sum(last_recurrent_state * k_t.unsqueeze(-1), dim=-2)
    kv_regs.fill(0.0)

    for r in range(0, D):
        row_regs <<= state_ub[r:r + 1, 0:D]
        row_regs <<= row_regs * g_reg
        state_ub[r:r + 1, 0:D] <<= row_regs

        scalar_reg <<= k_ub[0:1, r:r + 1].single()
        acc_regs <<= row_regs * scalar_reg
        kv_regs <<= kv_regs + acc_regs

    # delta = (v_t - kv_mem) * beta_t
    delta_regs <<= v_ub[0:1, 0:D]
    delta_regs <<= delta_regs - kv_regs
    delta_regs <<= delta_regs * beta_reg

    # last_recurrent_state += k_t.unsqueeze(-1) * delta.unsqueeze(-2)
    for r in range(0, D):
        scalar_reg <<= k_ub[0:1, r:r + 1].single()
        row_regs <<= delta_regs * scalar_reg
        acc_regs <<= state_ub[r:r + 1, 0:D]
        row_regs <<= row_regs + acc_regs
        state_ub[r:r + 1, 0:D] <<= row_regs

    # core_attn_out = sum(last_recurrent_state * q_t.unsqueeze(-1), dim=-2)
    acc_regs.fill(0.0)

    for r in range(0, D):
        scalar_reg <<= q_ub[0:1, r:r + 1].single()
        row_regs <<= state_ub[r:r + 1, 0:D]
        row_regs <<= row_regs * scalar_reg
        acc_regs <<= acc_regs + row_regs

    out_ub[0:1, 0:D] <<= acc_regs


@kernel()
def recurrent_state_attn_vec_kernel(
    query: GMTensor, key: GMTensor, value: GMTensor, g: GMTensor, beta: GMTensor, last_state: GMTensor, last_recurrent_state: GMTensor, core_attn_out: GMTensor,
    BH: Var, S: Var,
):
    # UB/DBuff second dim stays 32B-aligned (or stronger).
    state_ub = DBuff(DT.float, [D, D], Position.UB)
    q_ub = DBuff(DT.float, [1, D], Position.UB)
    k_ub = DBuff(DT.float, [1, D], Position.UB)
    v_ub = DBuff(DT.float, [1, D], Position.UB)
    out_ub = DBuff(DT.float, [1, D], Position.UB)
    g_ub = DBuff(DT.float, [1, SCALAR_COLS], Position.UB)
    beta_ub = DBuff(DT.float, [1, SCALAR_COLS], Position.UB)

    bh_per_core = CeilDiv(BH, GetVecNum())
    bh_begin = Var(bh_per_core * GetVecIdx())
    bh_end = Min(bh_begin + bh_per_core, BH)

    with auto_sync():
        # Split by B*H and loop S inside each core.
        for bh_idx in range(bh_begin, bh_end):
            state_row0 = Var(bh_idx * D)
            state_ub[0][0:D, 0:D] <<= last_state[state_row0:state_row0 + D, 0:D]
            token_buf_idx = Var(0)

            for s_idx in range(0, S):
                token_idx = Var(bh_idx * S + s_idx)

                q_ub[token_buf_idx][0:1, 0:D] <<= query[token_idx:token_idx + 1, 0:D]
                k_ub[token_buf_idx][0:1, 0:D] <<= key[token_idx:token_idx + 1, 0:D]
                v_ub[token_buf_idx][0:1, 0:D] <<= value[token_idx:token_idx + 1, 0:D]
                g_ub[token_buf_idx][0:1, 0:1] <<= g[bh_idx:bh_idx + 1, s_idx:s_idx + 1]
                beta_ub[token_buf_idx][0:1, 0:1] <<= beta[bh_idx:bh_idx + 1, s_idx:s_idx + 1]

                recurrent_step_vf(state_ub[0], q_ub[token_buf_idx], k_ub[token_buf_idx], v_ub[token_buf_idx], g_ub[token_buf_idx], beta_ub[token_buf_idx], out_ub[token_buf_idx])
                core_attn_out[token_idx:token_idx + 1, 0:D] <<= out_ub[token_buf_idx][0:1, 0:D]
                token_buf_idx += 1

            last_recurrent_state[state_row0:state_row0 + D, 0:D] <<= state_ub[0][0:D, 0:D]
            bar_all()

    return last_recurrent_state, core_attn_out
if __name__ == "__main__":
    torch.manual_seed(0)

    B = 2
    H = 4
    S = 16
    query = torch.rand(B, H, S, D, dtype=torch.float32)
    key = torch.rand(B, H, S, D, dtype=torch.float32) * 0.1
    value = torch.rand(B, H, S, D, dtype=torch.float32)
    # g must be non-positive so that exp(g) ∈ (0, 1] acts as a decay factor.
    # In real models (HGRN2/RetNet) g = log(sigmoid(raw)), here we use the same.
    g = torch.log(torch.sigmoid(torch.randn(B, H, S, dtype=torch.float32)))
    beta = torch.rand(B, H, S, dtype=torch.float32) * 0.1
    last_state = torch.zeros(B, H, D, D, dtype=torch.float32)

    bh = B * H
    query_f = query.reshape(bh * S, D).contiguous()
    key_f = key.reshape(bh * S, D).contiguous()
    value_f = value.reshape(bh * S, D).contiguous()
    g_f = g.reshape(bh, S).contiguous()
    beta_f = beta.reshape(bh, S).contiguous()
    last_state_f = last_state.reshape(bh * D, D).contiguous()
    last_recurrent_state_f = torch.zeros_like(last_state_f)
    core_attn_out_f = torch.zeros((bh * S, D), dtype=query.dtype, device=query.device)

    state_ref = last_state.clone()
    attn_ref = torch.zeros(B, H, S, D, dtype=query.dtype)
    for i in builtins.range(S):
        q_t = query[:, :, i]
        k_t = key[:, :, i]
        v_t = value[:, :, i]
        g_t = g[:, :, i].exp().unsqueeze(-1).unsqueeze(-1)
        beta_t = beta[:, :, i].unsqueeze(-1)

        state_ref = state_ref * g_t
        kv_mem = (state_ref * k_t.unsqueeze(-1)).sum(dim=-2)
        delta = (v_t - kv_mem) * beta_t
        state_ref = state_ref + k_t.unsqueeze(-1) * delta.unsqueeze(-2)
        attn_ref[:, :, i] = (state_ref * q_t.unsqueeze(-1)).sum(dim=-2)

    state_kernel, attn_kernel = OpExec(recurrent_state_attn_vec_kernel, simulator=True)(query_f, key_f, value_f, g_f, beta_f, last_state_f, last_recurrent_state_f, core_attn_out_f, bh, S)
    state_kernel = state_kernel.reshape(B, H, D, D)
    attn_kernel = attn_kernel.reshape(B, H, S, D)

    torch.testing.assert_close(state_kernel, state_ref, rtol=1e-4, atol=1e-4)
    torch.testing.assert_close(attn_kernel, attn_ref, rtol=1e-4, atol=1e-4)

    max_state_diff = torch.abs(state_kernel - state_ref).max().item()
    max_attn_diff = torch.abs(attn_kernel - attn_ref).max().item()
    print(f"max_state_diff={max_state_diff:.6e}")
    print(f"max_attn_diff={max_attn_diff:.6e}")
