# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from easyasc.a5 import *


TILE_M = 128
TILE_N = 128
TILE_K = 128
SPLIT_N = 128
CHUNK_N = 128
REGS_PER_CHUNK = CHUNK_N // 64


@vf()
def normalize_absmax_chunk_vf(src_f32_ub: Tensor, dst_f32_ub: Tensor, rows: Var):
    row_regs = RegList(DT.float, REGS_PER_CHUNK)
    abs_regs = RegList(DT.float, REGS_PER_CHUNK)
    max_reg = Reg(DT.float)
    max_dup_reg = Reg(DT.float)

    for r in range(rows):
        src_row = src_f32_ub[r:r + 1, :]
        dst_row = dst_f32_ub[r:r + 1, :]
        row_regs <<= src_row
        abs_regs <<= row_regs.abs()
        max_reg <<= abs_regs.cmax()
        max_dup_reg <<= max_reg.dup()
        row_regs <<= row_regs / max_dup_reg
        dst_row <<= row_regs


@kernel()
def matmul_chunk_absmax_norm128_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [TILE_M, TILE_K], Position.L1)
    l1y = DBuff(DT.half, [TILE_N, TILE_K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)
    xbuf = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)
    outbuf = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)

    l0c_ub_cnt = Var(0)
    l1cnt = Var(0)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = Var(GetSubBlockIdx())
            row_start = Var(m0 + sb_idx * half_rows)
            rows = Min(half_rows, valid_m - sb_idx * half_rows)

            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)

                for k0 in range(0, K, TILE_K):
                    valid_k = Min(TILE_K, K - k0)
                    l1x[l1cnt] <<= x[m0:m0 + valid_m, k0:k0 + valid_k]
                    l1y[l1cnt] <<= y[n0:n0 + valid_n, k0:k0 + valid_k]
                    matmul(l0c[l0c_ub_cnt], l1x[l1cnt], l1y[l1cnt], splitn=SPLIT_N, is_init=(k0 == 0))
                    l1cnt += 1

                cvmutex.lock()
                xbuf[l0c_ub_cnt] <<= l0c[l0c_ub_cnt]
                cvmutex.ready()

                cvmutex.wait()
                normalize_absmax_chunk_vf(xbuf[l0c_ub_cnt][0:rows, :], outbuf[l0c_ub_cnt][0:rows, :], rows)
                z[row_start:row_start + rows, n0:n0 + valid_n] <<= outbuf[l0c_ub_cnt][0:rows, 0:valid_n]
                cvmutex.free()
                l0c_ub_cnt += 1
    return z


if __name__ == "__main__":
    import torch
    from easyasc.a5 import OpExec

    M = 512
    N = 1280
    K = 1024
    torch.manual_seed(0)

    x = torch.randn((M, K), dtype=torch.float16)
    y = torch.randn((N, K), dtype=torch.float16)
    z = torch.zeros((M, N), dtype=torch.float32)

    z_gt = x.float() @ y.float().t()
    z_gt_chunk128 = z_gt.unflatten(-1, (-1, CHUNK_N))
    absmax_chunk128 = z_gt_chunk128.abs().amax(dim=-1, keepdim=True)
    z_gt = (z_gt_chunk128 / absmax_chunk128).flatten(-2, -1)

    z_kernel = OpExec(matmul_chunk_absmax_norm128_kernel, simulator=True)(x, y, z, M, N, K)

    torch.testing.assert_close(z_kernel, z_gt, rtol=3e-3, atol=3e-3)
    print(f"max_abs_diff={torch.abs(z_kernel - z_gt).max().item():.6e}")
