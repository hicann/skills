# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------

from easyasc.a5 import *


TILE_M = 64
SPLIT_N = 128


@vf()
def abs_sqrt_cast_half_vf(src_f16: Tensor, dst_f16: Tensor, n_loops: Var):
    reg_f32 = Reg(DT.float)
    for i in range(n_loops):
        reg_f32 <<= src_f16[i * 64]
        reg_f32 <<= reg_f32.abs().sqrt()
        # Store as fp16 through the implicit cast/downsample path.
        dst_f16[i * 64] <<= reg_f32


@kernel()
def vec_cube_abs_sqrt_matmul_kernel(x: GMTensor, y: GMTensor, z_ref: GMTensor, M: Var, N: Var, K: Var):
    # Vec producer ends on MTE3 (L1 <<= UB routes to ub_to_l1_nd2nz); cube consumer completes on FIX.
    vcmutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)

    l1x = DBuff(DT.half, [TILE_M, K], Position.L1)
    l1y = DBuff(DT.half, [N, K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, N], Position.L0C)
    x_ub = DBuff(DT.half, [TILE_M // 2, K], Position.UB)
    x_proc_ub = DBuff(DT.half, [TILE_M // 2, K], Position.UB)

    ccnt = Var(0)
    vcnt = Var(0)
    half_rows = Var(TILE_M // 2)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)

            vcmutex.lock()
            row_start = Var(GetSubBlockIdx() * half_rows)
            if row_start < valid_m:
                row_end = Min(row_start + half_rows, valid_m)
                rows_this = Var(row_end - row_start)
                vf_loops = Var(rows_this * K // 64)
                x_ub[vcnt] <<= x[m0 + row_start:m0 + row_end, 0:K]
                abs_sqrt_cast_half_vf(x_ub[vcnt], x_proc_ub[vcnt], vf_loops)
                l1x[ccnt][row_start:row_end, 0:K] <<= x_proc_ub[vcnt][0:rows_this, 0:K]
            vcnt += 1
            vcmutex.ready()

            vcmutex.wait()
            l1y[ccnt] <<= y[:, 0:K]
            matmul(l0c[ccnt], l1x[ccnt], l1y[ccnt], splitn=SPLIT_N)
            z_ref[m0:m0 + valid_m, 0:N] <<= l0c[ccnt][0:valid_m, 0:N]
            vcmutex.free()
            ccnt += 1

    return z_ref


if __name__ == "__main__":
    import torch

    M = 128 * 32
    N = 512
    K = 128

    torch.manual_seed(0)
    x = torch.randn(M, K).half()
    y = torch.randn(N, K).half()
    z_ref = torch.zeros(M, N).float()

    z_kernel = OpExec(vec_cube_abs_sqrt_matmul_kernel, simulator=True)(x, y, z_ref, M, N, K)
    z_golden = x.float().abs().sqrt().half().float() @ y.float().t()
    torch.testing.assert_close(z_kernel, z_golden, rtol=1e-3, atol=1e-3)
    print(f"max_abs_diff={torch.abs(z_kernel - z_golden).max().item():.6e}")
