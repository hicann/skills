# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from easyasc.a5 import *
from easyasc.utils.castconfig import CastConfig, RegLayout


TILE_M = 128
BLOCK_N = 128
TILE_K = 128
SCALE_DENOM = 224.0
REGS_PER_BLOCK = BLOCK_N // 64

# Prefer Tensor <<= RegList path first. If this path fails on a target,
# switch to True to force explicit cast + pack4 writes.
USE_PACK4_FALLBACK = False

SHAPE_BINDINGS = {
    0: [2, 0],  # x[K, M]
    1: [2, 1],  # y[K, N]
    2: [0, 1],  # z[M, N]
    3: [0, None],  # scale[M, N//BLOCK_N]
}


@vf()
def blockwise_quant_e5m2_vf(src_f32_ub: Tensor, dst_e5m2_ub: Tensor, dst_scale_ub: Tensor, rows: Var):
    row_regs = RegList(DT.float, REGS_PER_BLOCK)
    abs_regs = RegList(DT.float, REGS_PER_BLOCK)
    max_reg = Reg(DT.float)
    scale_reg = Reg(DT.float)
    scale_dup_reg = Reg(DT.float)

    for r in range(rows):
        row_regs <<= src_f32_ub[r:r + 1, 0:BLOCK_N]
        abs_regs <<= row_regs.abs()
        max_reg <<= abs_regs.cmax()
        scale_reg <<= max_reg / SCALE_DENOM
        scale_dup_reg <<= scale_reg.dup()
        row_regs <<= row_regs / scale_dup_reg
        dst_e5m2_ub[r:r + 1, 0:BLOCK_N] <<= row_regs

        # Store one scalar per row/block by filling a 64-lane row then slicing 0:1 later.
        dst_scale_ub[r:r + 1, 0:64] <<= scale_dup_reg


@vf()
def blockwise_quant_e5m2_pack4_vf(src_f32_ub: Tensor, dst_e5m2_ub: Tensor, dst_scale_ub: Tensor, rows: Var):
    if REGS_PER_BLOCK != 2:
        raise ValueError(f"pack4 fallback currently expects REGS_PER_BLOCK=2, got {REGS_PER_BLOCK}")

    row_regs = RegList(DT.float, REGS_PER_BLOCK)
    abs_regs = RegList(DT.float, REGS_PER_BLOCK)
    max_reg = Reg(DT.float)
    scale_reg = Reg(DT.float)
    scale_dup_reg = Reg(DT.float)
    cfg_zero = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_blockwise_quant_e5m2")
    fp8_reg0 = Reg(DT.e5m2)
    fp8_reg1 = Reg(DT.e5m2)

    for r in range(rows):
        row_regs <<= src_f32_ub[r:r + 1, 0:BLOCK_N]
        abs_regs <<= row_regs.abs()
        max_reg <<= abs_regs.cmax()
        scale_reg <<= max_reg / SCALE_DENOM
        scale_dup_reg <<= scale_reg.dup()
        row_regs <<= row_regs / scale_dup_reg

        fp8_reg0 <<= row_regs[0].astype(DT.e5m2, cfg_zero)
        fp8_reg1 <<= row_regs[1].astype(DT.e5m2, cfg_zero)
        dst_e5m2_ub[r:r + 1, 0:64] <<= fp8_reg0.pack4()
        dst_e5m2_ub[r:r + 1, 64:128] <<= fp8_reg1.pack4()

        # Store one scalar per row/block by filling a 64-lane row then slicing 0:1 later.
        dst_scale_ub[r:r + 1, 0:64] <<= scale_dup_reg


BLOCKWISE_QUANT_VF = blockwise_quant_e5m2_pack4_vf if USE_PACK4_FALLBACK else blockwise_quant_e5m2_vf


@kernel()
def matmul_kmkn_blockwise_quant128_kernel(
    x: GMTensor, y: GMTensor, z: GMTensor, scale: GMTensor,
    M: Var, N: Var, K: Var,
):
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [TILE_K, TILE_M], Position.L1)
    l1y = DBuff(DT.half, [TILE_K, BLOCK_N], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, BLOCK_N], Position.L0C)

    xbuf = DBuff(DT.float, [TILE_M // 2, BLOCK_N], Position.UB)
    zbuf = DBuff(DT.e5m2, [TILE_M // 2, BLOCK_N], Position.UB)
    scalebuf = DBuff(DT.float, [TILE_M // 2, 64], Position.UB)

    l1_cnt = Var(0)
    l0c_ub_cnt = Var(0)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = Var(GetSubBlockIdx())
            row_start = Var(m0 + sb_idx * half_rows)
            rows = Min(half_rows, valid_m - sb_idx * half_rows)

            n_blk = Var(0)
            for n0 in range(0, N, BLOCK_N):
                valid_n = Min(BLOCK_N, N - n0)

                for k0 in range(0, K, TILE_K):
                    valid_k = Min(TILE_K, K - k0)
                    l1x[l1_cnt] <<= x[k0:k0 + valid_k, m0:m0 + valid_m]
                    l1y[l1_cnt] <<= y[k0:k0 + valid_k, n0:n0 + valid_n]
                    matmul(l0c[l0c_ub_cnt][:valid_m, :valid_n], l1x[l1_cnt].T, l1y[l1_cnt].T, m=valid_m, n=valid_n, k=valid_k, is_init=(k0 == 0))
                    l1_cnt += 1

                cvmutex.lock()
                xbuf[l0c_ub_cnt] <<= l0c[l0c_ub_cnt]
                cvmutex.ready()

                cvmutex.wait()
                BLOCKWISE_QUANT_VF(xbuf[l0c_ub_cnt][0:rows, 0:BLOCK_N], zbuf[l0c_ub_cnt][0:rows, 0:BLOCK_N], scalebuf[l0c_ub_cnt][0:rows, 0:64], rows)
                z[row_start:row_start + rows, n0:n0 + valid_n] <<= zbuf[l0c_ub_cnt][0:rows, 0:valid_n]
                scale[row_start:row_start + rows, n_blk:n_blk + 1] <<= scalebuf[l0c_ub_cnt][0:rows, 0:1]
                cvmutex.free()

                l0c_ub_cnt += 1
                n_blk += 1

    return z, scale


def check_dims(m: int, n: int, k: int) -> None:
    if m % 16 != 0:
        raise ValueError(f"M must be divisible by 16 for transpose matmul path, got M={m}")
    if n % 16 != 0:
        raise ValueError(f"N must be divisible by 16 for transpose matmul path, got N={n}")
    if k % 16 != 0:
        raise ValueError(f"K must be divisible by 16 for transpose matmul path, got K={k}")
    if n % BLOCK_N != 0:
        raise ValueError(
            "N must be divisible by 128 to match unflatten(-1, (-1, 128)) semantics, "
            f"got N={n}"
        )


if __name__ == "__main__":
    import time

    import torch

    if not hasattr(torch, "float8_e5m2"):
        raise RuntimeError("Current torch build does not support torch.float8_e5m2")

    def _torch_reference(x: torch.Tensor, y: torch.Tensor):
        z_tmp = x.float().t() @ y.float()
        z_chunk = z_tmp.unflatten(-1, (-1, BLOCK_N))
        scale_ref = z_chunk.abs().amax(-1, keepdim=True) / SCALE_DENOM
        z_ref = (z_chunk / scale_ref).flatten(-2, -1).to(torch.float8_e5m2)  # type: ignore[attr-defined]
        return z_ref, scale_ref.squeeze(-1)

    def _run_case(m: int, n: int, k: int) -> None:
        check_dims(m, n, k)
        torch.manual_seed(0)

        x = torch.randn((k, m), dtype=torch.float16)
        y = torch.randn((k, n), dtype=torch.float16)
        z = torch.empty((m, n), dtype=torch.float8_e5m2)  # type: ignore[attr-defined]
        scale = torch.zeros((m, n // BLOCK_N), dtype=torch.float32)

        start = time.time()
        z_kernel, scale_kernel = OpExec(matmul_kmkn_blockwise_quant128_kernel, simulator=True)(x, y, z, scale, m, n, k, shape_bindings=SHAPE_BINDINGS)
        sim_time_s = time.time() - start

        start = time.time()
        z_ref, scale_ref = _torch_reference(x, y)
        ref_time_s = time.time() - start

        torch.testing.assert_close(scale_kernel, scale_ref, rtol=3e-3, atol=3e-3)
        torch.testing.assert_close(z_kernel.float(), z_ref.float(), rtol=2e-1, atol=2e-1)

        print(f"shape=(M={m}, N={n}, K={k})")
        print(f"simulator_time_s={sim_time_s:.3f}")
        print(f"reference_time_s={ref_time_s:.3f}")
        print(
            "z_max_abs_diff_float="
            f"{torch.abs(z_kernel.float() - z_ref.float()).max().item():.6e}"
        )
        print(f"scale_max_abs_diff={torch.abs(scale_kernel - scale_ref).max().item():.6e}")

    _run_case(128, 128, 128)
