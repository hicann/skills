# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------

from easyasc.a5 import *


BLK = 128
LANES = 4

@vf()
def simple_micro(x: Tensor, out: Tensor, n_loops: Var):
    xreg = Reg(DT.float)
    for i in range(n_loops):
        xreg <<= x[i*64]
        xreg <<= xreg.abs() + 1.0
        out[i*64] <<= xreg


@kernel()
def cubefunc(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    # Producer: l0c_to_ub finishes on FIX. Consumer: simple_micro runs on V.
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [BLK, K], Position.L1)
    l1y = DBuff(DT.half, [N, K], Position.L1)
    l0c = DBuff(DT.float, [BLK, N], Position.L0C)
    xbuf = DBuff(DT.float, [BLK//2, N], Position.UB)
    outbuf = DBuff(DT.float, [BLK//2, N], Position.UB)

    tile_cnt = Var(0)

    m_per_core = CeilDiv(M, GetCubeNum())
    m1 = Var(m_per_core * GetCubeIdx())
    m2 = Min(m1 + m_per_core, M)

    with auto_sync():
        for m in range(m1, m2, BLK):
            l1x[tile_cnt] <<= x[m:m+BLK, :]
            l1y[tile_cnt] <<= y[:, :]
            matmul(l0c[tile_cnt], l1x[tile_cnt], l1y[tile_cnt])
            
            cvmutex.lock()
            xbuf[tile_cnt] <<= l0c[tile_cnt]
            cvmutex.ready()

            cvmutex.wait()
            simple_micro(xbuf[tile_cnt], outbuf[tile_cnt], BLK//2*N//64)
            cvmutex.free()
            valid_m = Min(BLK, m2 - m)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = GetSubBlockIdx()
            row_begin = sb_idx * half_rows
            row_end = Min(row_begin + half_rows, valid_m)
            row_count = row_end - row_begin
            z[m + row_begin:m + row_end, :] <<= outbuf[tile_cnt][0:row_count, :]
            tile_cnt += 1 

    return z


if __name__ == "__main__":
    import torch 

    out_dir = "test_cust_op"

    M = 64*64 
    N = 64
    K = 128 
    torch.manual_seed(0)
    x = torch.randn(M, K).half()
    y = torch.randn(N, K).half()
    z = torch.abs(x.float() @ y.float().t()) + 1.0 

    op = OpExec(cubefunc, out_dir, simulator=True)
    z_kernel = op(x, y, z, M, N, K)

    torch.testing.assert_close(z_kernel, z, rtol=1e-3, atol=1e-3)
    print(f"max_abs_diff={torch.abs(z_kernel - z).max().item():.6e}")
