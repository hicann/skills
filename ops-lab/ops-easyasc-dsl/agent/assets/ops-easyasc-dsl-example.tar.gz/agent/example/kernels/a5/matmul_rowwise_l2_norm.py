# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------

from easyasc.a5 import *


TILE_M = 64
TILE_N = 256
TILE_K = 128
SPLIT_N = 128
VEC_WIDTH = 64
REGS_PER_ROW = TILE_N // VEC_WIDTH
SHAPE_BINDINGS = {0: [0, 2], 1: [1, 2], 2: [0, 1]}


@vf()
def accumulate_row_l2_vf(src_tile: Tensor, row_sqsum_dup: Tensor, dst_tile: Tensor, rows: Var):
    row_regs = RegList(DT.float, REGS_PER_ROW)
    sq_regs = RegList(DT.float, REGS_PER_ROW)
    sum_reg = Reg(DT.float)
    sum_dup_reg = Reg(DT.float)
    acc_reg = Reg(DT.float)

    for r in range(rows):
        src_row = src_tile[r:r + 1, :]
        dst_row = dst_tile[r:r + 1, :]
        sqsum_row = row_sqsum_dup[r:r + 1, :]

        row_regs <<= src_row
        sq_regs <<= row_regs * row_regs
        sum_reg <<= sq_regs.cadd()
        sum_dup_reg <<= sum_reg.dup()
        acc_reg <<= sqsum_row
        acc_reg <<= acc_reg + sum_dup_reg
        sqsum_row <<= acc_reg
        dst_row <<= row_regs


@vf()
def normalize_rows_l2_vf(src_tile: Tensor, row_sqsum_dup: Tensor, dst_tile: Tensor, rows: Var):
    row_regs = RegList(DT.float, REGS_PER_ROW)
    denom_reg = Reg(DT.float)

    for r in range(rows):
        src_row = src_tile[r:r + 1, :]
        sqsum_row = row_sqsum_dup[r:r + 1, :]
        dst_row = dst_tile[r:r + 1, :]

        row_regs <<= src_row
        denom_reg <<= sqsum_row
        denom_reg <<= denom_reg.sqrt()
        row_regs <<= row_regs / denom_reg
        dst_row <<= row_regs


@vf()
def zero_row_sqsum_vf(row_sqsum_dup: Tensor, rows: Var):
    zero_reg = Reg(DT.float)
    zero_reg <<= 0.0
    for r in range(rows):
        row_sqsum_dup[r:r + 1, :] <<= zero_reg


@kernel()
def matmul_rowwise_l2_norm_kernel(x: GMTensor, w: GMTensor, out: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [TILE_M, TILE_K], Position.L1)
    l1w = DBuff(DT.half, [TILE_N, TILE_K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)
    tile_ub = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)
    out_ub = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)
    row_sqsum_ub = Tensor(DT.float, [TILE_M // 2, VEC_WIDTH], Position.UB)

    pass1_cnt = Var(0)
    pass2_cnt = Var(0)
    l1_cnt = Var(0)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    for mt in range(tile_m_begin, tile_m_end):
        with auto_sync():
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)
            half_rows = CeilDiv(valid_m, 2)
            sb_idx = Var(GetSubBlockIdx())
            row_start = Var(m0 + sb_idx * half_rows)
            rows = Min(half_rows, valid_m - sb_idx * half_rows)
            zero_row_sqsum_vf(row_sqsum_ub[0:rows, :], rows)

            # Pass-1 stores the raw matmul result and accumulates the per-row squared sum.
            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                for k0 in range(0, K, TILE_K):
                    valid_k = Min(TILE_K, K - k0)
                    l1x[l1_cnt] <<= x[m0:m0 + valid_m, k0:k0 + valid_k]
                    l1w[l1_cnt] <<= w[n0:n0 + valid_n, k0:k0 + valid_k]
                    matmul(
                        l0c[pass1_cnt], l1x[l1_cnt], l1w[l1_cnt],
                        m=valid_m, n=valid_n, k=valid_k,
                        splitn=SPLIT_N, is_init=(k0 == 0)
                    )
                    l1_cnt += 1

                cvmutex.lock()
                tile_ub[pass1_cnt] <<= l0c[pass1_cnt]
                cvmutex.ready()

                cvmutex.wait()
                accumulate_row_l2_vf(tile_ub[pass1_cnt][0:rows, :], row_sqsum_ub[0:rows, :], out_ub[pass1_cnt][0:rows, :], rows)
                out[row_start:row_start + rows, n0:n0 + valid_n] <<= out_ub[pass1_cnt][0:rows, 0:valid_n]
                cvmutex.free()
                pass1_cnt += 1

        pass2_cnt <<= pass1_cnt
        with auto_sync():
            # Pass-2 reloads the temporary matmul result and divides by sqrt(sum(z^2)).
            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                tile_ub[pass2_cnt][0:rows, 0:valid_n] <<= out[row_start:row_start + rows, n0:n0 + valid_n]
                normalize_rows_l2_vf(tile_ub[pass2_cnt][0:rows, :], row_sqsum_ub[0:rows, :], out_ub[pass2_cnt][0:rows, :], rows)
                out[row_start:row_start + rows, n0:n0 + valid_n] <<= out_ub[pass2_cnt][0:rows, 0:valid_n]
                pass2_cnt += 1
    return out


def run_matmul_rowwise_l2_norm(x, w, out, M, N, K, simulator=True):
    if M % TILE_M != 0:
        raise ValueError(f"M must be divisible by {TILE_M}, got M={M}")
    if N % TILE_N != 0:
        raise ValueError(f"N must be divisible by {TILE_N}, got N={N}")
    if K % TILE_K != 0:
        raise ValueError(f"K must be divisible by {TILE_K}, got K={K}")
    return OpExec(matmul_rowwise_l2_norm_kernel, out_dir='./testai', simulator=simulator)(
        x, w, out, M, N, K, shape_bindings=SHAPE_BINDINGS
    )


if __name__ == "__main__":
    import torch

    M = 512
    N = 256
    K = 128
    torch.manual_seed(0)

    x = torch.rand((M, K), dtype=torch.float16)
    w = torch.rand((N, K), dtype=torch.float16)
    out = torch.zeros((M, N), dtype=torch.float32)

    z = x.float() @ w.float().t()
    sqrt_sum = torch.sqrt(torch.sum(z ** 2, dim=1, keepdim=True))
    out_ref = z / sqrt_sum

    out_kernel = run_matmul_rowwise_l2_norm(x, w, out, M, N, K, simulator=True)

    torch.testing.assert_close(out_kernel, out_ref, rtol=2e-2, atol=2e-2)
    print(f"max_abs_diff={torch.abs(out_kernel - out_ref).max().item():.6e}")
