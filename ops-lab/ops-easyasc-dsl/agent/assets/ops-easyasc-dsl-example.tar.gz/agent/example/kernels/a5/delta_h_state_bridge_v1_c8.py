# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import json
import os
import sys
from typing import Tuple

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import torch

from easyasc import globvars
from easyasc.a5 import *
from tmp_delta_h import delta_h_true_golden


# Fixed aligned state-bridge baseline specialized for the C=8 experiment.
BATCH = 2
HEADS = 32
BATCH_HEADS = BATCH * HEADS
CHUNKS = 8
TOKENS = 64
DIM = 128
HALF_TOKENS = TOKENS // 2
HALF_DIM = DIM // 2
FLOAT_REGS_PER_ROW = DIM // 64
SCALAR_COLS = 8
SPLIT_N = 128
TRACE_PATH = os.path.join(REPO_ROOT, "tmp", "delta_h_state_bridge_v1_c8_kernel_trace.json")


@vf()
def cast_state_rows_to_half_vf(src_f32: Tensor, dst_f16: Tensor, n_loops: Var):
    reg_f32 = Reg(DT.float)
    for i in range(n_loops):
        reg_f32 <<= src_f32[i * 64]
        dst_f16[i * 64] <<= reg_f32


@vf()
def stage1_postprocess_vf(
    vprime_ub: Tensor, u_ub: Tensor, g_rows_ub: Tensor, g_last_ub: Tensor, v_new_ub: Tensor, v_scaled_ub: Tensor, rows_this: Var,
):
    g_last_reg = Reg(DT.float)
    g_row_reg = Reg(DT.float)
    factor_reg = Reg(DT.float)
    u_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    vprime_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    delta_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    scaled_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    g_last_reg <<= g_last_ub[0:1, 0:1].single()
    for r in range(rows_this):
        u_regs <<= u_ub[r:r + 1, 0:DIM]
        vprime_regs <<= vprime_ub[r:r + 1, 0:DIM]
        delta_regs <<= u_regs - vprime_regs
        v_new_ub[r:r + 1, 0:DIM] <<= delta_regs

        g_row_reg <<= g_rows_ub[r:r + 1, 0:1].single()
        factor_reg <<= g_last_reg - g_row_reg
        factor_reg <<= factor_reg.exp()
        scaled_regs <<= delta_regs * factor_reg
        v_scaled_ub[r:r + 1, 0:DIM] <<= scaled_regs


@vf()
def decay_state_rows_vf(state_rows: Tensor, g_last_ub: Tensor, rows_this: Var):
    decay_reg = Reg(DT.float)
    row_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    decay_reg <<= g_last_ub[0:1, 0:1].single()
    decay_reg <<= decay_reg.exp()
    for r in range(rows_this):
        row_regs <<= state_rows[r:r + 1, 0:DIM]
        row_regs <<= row_regs * decay_reg
        state_rows[r:r + 1, 0:DIM] <<= row_regs


@vf()
def add_delta_rows_vf(state_rows: Tensor, delta_rows: Tensor, rows_this: Var):
    state_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)
    delta_regs = RegList(DT.float, FLOAT_REGS_PER_ROW)

    for r in range(rows_this):
        state_regs <<= state_rows[r:r + 1, 0:DIM]
        delta_regs <<= delta_rows[r:r + 1, 0:DIM]
        state_regs <<= state_regs + delta_regs
        state_rows[r:r + 1, 0:DIM] <<= state_regs


@kernel()
def delta_h_state_bridge_v1_c8_kernel(
    k: GMTensor, w: GMTensor, u: GMTensor, g: GMTensor, initial_state: GMTensor,
    h_out: GMTensor, v_new_out: GMTensor, final_state_out: GMTensor,
):
    state_bridge_mutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    stage1_out_mutex = CvMutex(1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
    vscaled_bridge_mutex = VcMutex(2, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.MTE1)
    stage2_out_mutex = CvMutex(3, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    state_f_ub = Tensor(DT.float, [DIM, DIM], Position.UB)
    state_h_ub = Tensor(DT.half, [HALF_DIM, DIM], Position.UB)
    vprime_ub = Tensor(DT.float, [HALF_TOKENS, DIM], Position.UB)
    u_ub = Tensor(DT.half, [HALF_TOKENS, DIM], Position.UB)
    v_new_ub = Tensor(DT.half, [HALF_TOKENS, DIM], Position.UB)
    v_scaled_ub = Tensor(DT.half, [HALF_TOKENS, DIM], Position.UB)
    g_rows_ub = Tensor(DT.float, [HALF_TOKENS, SCALAR_COLS], Position.UB)
    g_last_ub = Tensor(DT.float, [1, SCALAR_COLS], Position.UB)
    delta_ub = Tensor(DT.float, [HALF_DIM, DIM], Position.UB)

    state_h_l1 = Tensor(DT.half, [DIM, DIM], Position.L1)
    w_l1 = Tensor(DT.half, [TOKENS, DIM], Position.L1)
    k_l1 = Tensor(DT.half, [TOKENS, DIM], Position.L1)
    v_scaled_l1 = Tensor(DT.half, [TOKENS, DIM], Position.L1)

    vprime_l0c = Tensor(DT.float, [TOKENS, DIM], Position.L0C)
    delta_l0c = Tensor(DT.float, [DIM, DIM], Position.L0C)

    bh_per_core = CeilDiv(BATCH_HEADS, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, BATCH_HEADS)

    row_begin_d = Var(GetSubBlockIdx() * HALF_DIM)
    row_end_d = Var(row_begin_d + HALF_DIM)
    row_begin_l = Var(GetSubBlockIdx() * HALF_TOKENS)
    row_end_l = Var(row_begin_l + HALF_TOKENS)
    state_cast_loops = Var(HALF_DIM * DIM // 64)

    with auto_sync():
        for bh_idx in range(bh_begin, bh_end):
            state_row0 = Var(bh_idx * DIM)
            state_f_ub[row_begin_d:row_end_d, 0:DIM] <<= initial_state[state_row0 + row_begin_d:state_row0 + row_end_d, 0:DIM]

            snapshot_stage_idx = Var(0)
            stage1_cube_idx = Var(0)
            stage1_vec_idx = Var(0)
            stage2_cube_idx = Var(0)
            stage2_vec_idx = Var(0)

            for _ in range(0, CHUNKS):
                snapshot_chunk_idx = Var(bh_idx * CHUNKS + snapshot_stage_idx)
                snapshot_row0 = Var(snapshot_chunk_idx * DIM)
                stage1_cube_chunk_idx = Var(bh_idx * CHUNKS + stage1_cube_idx)
                stage1_cube_row0 = Var(stage1_cube_chunk_idx * TOKENS)

                state_bridge_mutex.lock()
                cast_state_rows_to_half_vf(
                    state_f_ub[row_begin_d:row_end_d, 0:DIM],
                    state_h_ub[0:HALF_DIM, 0:DIM],
                    state_cast_loops,
                )
                state_h_l1[row_begin_d:row_end_d, 0:DIM] <<= state_h_ub[0:HALF_DIM, 0:DIM]
                state_bridge_mutex.ready()
                snapshot_stage_idx += 1

                h_out[snapshot_row0 + row_begin_d:snapshot_row0 + row_end_d, 0:DIM] <<= state_h_ub[0:HALF_DIM, 0:DIM]
                w_l1[0:TOKENS, 0:DIM] <<= w[stage1_cube_row0:stage1_cube_row0 + TOKENS, 0:DIM]
                state_bridge_mutex.wait()
                matmul(vprime_l0c, w_l1, state_h_l1.T, splitn=SPLIT_N)
                state_bridge_mutex.free()

                stage1_out_mutex.lock()
                vprime_ub[0:HALF_TOKENS, 0:DIM] <<= vprime_l0c
                stage1_out_mutex.ready()
                stage1_cube_idx += 1

                stage1_vec_chunk_idx = Var(bh_idx * CHUNKS + stage1_vec_idx)
                stage1_vec_row0 = Var(stage1_vec_chunk_idx * TOKENS)
                u_ub[0:HALF_TOKENS, 0:DIM] <<= u[stage1_vec_row0 + row_begin_l:stage1_vec_row0 + row_end_l, 0:DIM]
                g_rows_ub[0:HALF_TOKENS, 0:1] <<= g[stage1_vec_row0 + row_begin_l:stage1_vec_row0 + row_end_l, 0:1]
                g_last_ub[0:1, 0:1] <<= g[stage1_vec_row0 + TOKENS - 1:stage1_vec_row0 + TOKENS, 0:1]
                stage1_out_mutex.wait()
                stage1_postprocess_vf(vprime_ub, u_ub, g_rows_ub, g_last_ub, v_new_ub, v_scaled_ub, HALF_TOKENS)
                stage1_out_mutex.free()

                vscaled_bridge_mutex.lock()
                v_scaled_l1[row_begin_l:row_end_l, 0:DIM] <<= v_scaled_ub[0:HALF_TOKENS, 0:DIM]
                vscaled_bridge_mutex.ready()
                stage1_vec_idx += 1

                v_new_out[stage1_vec_row0 + row_begin_l:stage1_vec_row0 + row_end_l, 0:DIM] <<= v_new_ub[0:HALF_TOKENS, 0:DIM]
                decay_state_rows_vf(state_f_ub[row_begin_d:row_end_d, 0:DIM], g_last_ub, HALF_DIM)
                stage2_cube_chunk_idx = Var(bh_idx * CHUNKS + stage2_cube_idx)
                stage2_cube_row0 = Var(stage2_cube_chunk_idx * TOKENS)
                k_l1[0:TOKENS, 0:DIM] <<= k[stage2_cube_row0:stage2_cube_row0 + TOKENS, 0:DIM]
                vscaled_bridge_mutex.wait()
                matmul(delta_l0c, k_l1.T, v_scaled_l1.T, splitn=SPLIT_N)
                vscaled_bridge_mutex.free()

                stage2_out_mutex.lock()
                delta_ub[0:HALF_DIM, 0:DIM] <<= delta_l0c
                stage2_out_mutex.ready()
                stage2_cube_idx += 1

                stage2_out_mutex.wait()
                add_delta_rows_vf(
                    state_f_ub[row_begin_d:row_end_d, 0:DIM],
                    delta_ub[0:HALF_DIM, 0:DIM],
                    HALF_DIM,
                )
                stage2_out_mutex.free()
                stage2_vec_idx += 1

            final_state_out[state_row0 + row_begin_d:state_row0 + row_end_d, 0:DIM] <<= state_f_ub[row_begin_d:row_end_d, 0:DIM]
            bar_all()

    return h_out, v_new_out, final_state_out


def _build_inputs() -> Tuple[torch.Tensor, ...]:
    torch.manual_seed(0)

    data_scale = 0.05
    k = torch.randn(BATCH, HEADS, CHUNKS, TOKENS, DIM, dtype=torch.float16) * data_scale
    w = torch.randn(BATCH, HEADS, CHUNKS, TOKENS, DIM, dtype=torch.float16) * data_scale
    u = torch.randn(BATCH, HEADS, CHUNKS, TOKENS, DIM, dtype=torch.float16) * data_scale
    g = torch.log(torch.sigmoid(torch.randn(BATCH, HEADS, CHUNKS, TOKENS, dtype=torch.float32)))
    initial_state = torch.zeros(BATCH, HEADS, DIM, DIM, dtype=torch.float32)
    return k, w, u, g, initial_state


def _flatten_inputs(
    k: torch.Tensor, w: torch.Tensor, u: torch.Tensor, g: torch.Tensor, initial_state: torch.Tensor,
) -> Tuple[torch.Tensor, ...]:
    k_f = k.reshape(BATCH_HEADS * CHUNKS * TOKENS, DIM).contiguous()
    w_f = w.reshape(BATCH_HEADS * CHUNKS * TOKENS, DIM).contiguous()
    u_f = u.reshape(BATCH_HEADS * CHUNKS * TOKENS, DIM).contiguous()
    g_f = g.reshape(BATCH_HEADS * CHUNKS * TOKENS, 1).contiguous()
    initial_state_f = initial_state.reshape(BATCH_HEADS * DIM, DIM).contiguous()

    h_out_f = torch.empty((BATCH_HEADS * CHUNKS * DIM, DIM), dtype=torch.float16)
    v_new_out_f = torch.empty((BATCH_HEADS * CHUNKS * TOKENS, DIM), dtype=torch.float16)
    final_state_out_f = torch.empty((BATCH_HEADS * DIM, DIM), dtype=torch.float32)
    return k_f, w_f, u_f, g_f, initial_state_f, h_out_f, v_new_out_f, final_state_out_f


def _trace_final_cycle(trace_path: str) -> float:
    with open(trace_path, "r", encoding="utf-8") as f:
        trace_payload = json.load(f)
    trace_events = trace_payload.get("traceEvents", [])
    timed_events = [event for event in trace_events if event.get("ph") == "X"]
    if not timed_events:
        return 0.0
    return max(float(event.get("ts", 0.0)) + float(event.get("dur", 0.0)) for event in timed_events)


def run_validation(enable_trace: bool = False) -> Tuple[float, float, float, float, str]:
    trace_path = TRACE_PATH
    if enable_trace:
        os.makedirs(os.path.dirname(trace_path), exist_ok=True)

    k, w, u, g, initial_state = _build_inputs()
    h_ref, v_new_ref, final_state_ref = delta_h_true_golden(k, w, u, g, initial_state)

    k_f, w_f, u_f, g_f, initial_state_f, h_out_f, v_new_out_f, final_state_out_f = _flatten_inputs(
        k, w, u, g, initial_state
    )

    saved_trace_event = getattr(globvars, "trace_event", False)
    globvars.trace_event = False
    try:
        h_kernel_f, v_new_kernel_f, final_state_kernel_f = OpExec(
            delta_h_state_bridge_v1_c8_kernel,
            simulator=True,
            trace=trace_path if enable_trace else None,
        )(k_f, w_f, u_f, g_f, initial_state_f, h_out_f, v_new_out_f, final_state_out_f)
    finally:
        globvars.trace_event = saved_trace_event

    h_kernel = h_kernel_f.reshape(BATCH, HEADS, CHUNKS, DIM, DIM)
    v_new_kernel = v_new_kernel_f.reshape(BATCH, HEADS, CHUNKS, TOKENS, DIM)
    final_state_kernel = final_state_kernel_f.reshape(BATCH, HEADS, DIM, DIM)

    torch.testing.assert_close(h_kernel, h_ref, rtol=0.0, atol=0.0)
    torch.testing.assert_close(v_new_kernel, v_new_ref, rtol=5e-2, atol=5e-2)
    torch.testing.assert_close(final_state_kernel, final_state_ref, rtol=5e-2, atol=5e-2)

    h_diff = torch.abs(h_kernel - h_ref).max().item()
    v_new_diff = torch.abs(v_new_kernel - v_new_ref).max().item()
    final_state_diff = torch.abs(final_state_kernel - final_state_ref).max().item()
    final_cycle = _trace_final_cycle(trace_path) if enable_trace else 0.0
    return h_diff, v_new_diff, final_state_diff, final_cycle, trace_path


if __name__ == "__main__":
    enable_trace = os.environ.get("DELTA_H_TRACE", "") == "1"
    max_h_diff, max_v_new_diff, max_final_state_diff, final_cycle, trace_path = run_validation(enable_trace=enable_trace)
    print(f"max_h_diff={max_h_diff:.6e}")
    print(f"max_v_new_diff={max_v_new_diff:.6e}")
    print(f"max_final_state_diff={max_final_state_diff:.6e}")
    print(f"final_cycle={final_cycle:.6e}")
    print(f"trace_path={trace_path}")
    print(f"trace_enabled={enable_trace}")
