# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import builtins
import math
import time
from typing import Dict, Tuple

import torch

from easyasc.a5 import *


BASES = 256
D_HEAD = 128
P_SCALE = 16.0
NEG_INF = -99999.0
SPLIT_K = 64
SPLIT_N = 64
SOFTMAX_SCALE = 1.0 / math.sqrt(D_HEAD)


@vf()
def init_row_state(qk_sum: Tensor, qk_max: Tensor, expdiff0: Tensor, expdiff1: Tensor, ub_accum: Tensor):
    zero_reg = Reg(DT.float)
    neg_reg = Reg(DT.float)

    zero_reg <<= 0.0
    qk_sum <<= zero_reg
    for i in range(8 * D_HEAD // 64):
        ub_accum[i * 64] <<= zero_reg

    neg_reg <<= NEG_INF
    qk_max <<= neg_reg

    zero_reg <<= 1.0
    expdiff0 <<= zero_reg
    expdiff1 <<= zero_reg


@vf()
def scale_qk_row(ub_qk: Tensor, ub_scaled_qk: Tensor, scale: Var):
    qk_regs = RegList(DT.float, BASES // 64)
    qk_regs <<= ub_qk[0]
    qk_regs <<= qk_regs * scale
    ub_scaled_qk[0] <<= qk_regs


@vf()
def scale_qk_row_tail(ub_qk: Tensor, ub_scaled_qk: Tensor, scale: Var, valid_cols: Var):
    cols = Reg(DT.int)
    qk_reg = Reg(DT.float)
    neg_reg = Reg(DT.float)
    mask = MaskReg(DT.int, init_mode=MaskType.NONE)

    neg_reg <<= NEG_INF
    for chunk in range(BASES // 64):
        qk_reg <<= ub_qk[chunk * 64]
        qk_reg <<= qk_reg * scale
        cols.arange(chunk * 64)
        compare(mask, cols, valid_cols, CompareMode.LT)
        select(qk_reg, qk_reg, neg_reg, mask=mask)
        ub_scaled_qk[chunk * 64] <<= qk_reg


@vf()
def get_p_and_max_sum_row(ub_qk: Tensor, ub_max: Tensor, ub_sum: Tensor, ub_expdiff: Tensor, ub_p: Tensor):
    regs = RegList(DT.float, BASES // 64)
    prev_max = Reg(DT.float)
    max_reg = Reg(DT.float)
    prev_sum = Reg(DT.float)
    sum_reg = Reg(DT.float)
    expdiff_reg = Reg(DT.float)

    regs <<= ub_qk[0]
    prev_max <<= ub_max[0].single()
    prev_sum <<= ub_sum[0].single()

    max_reg <<= regs.cmax()
    max_reg <<= max_reg.dup()
    max_reg <<= max_reg.vmax(prev_max)

    expdiff_reg <<= prev_max - max_reg
    expdiff_reg <<= expdiff_reg.exp()

    regs <<= regs - max_reg
    regs <<= regs.exp()

    sum_reg <<= regs.cadd()
    sum_reg <<= sum_reg.dup()
    sum_reg <<= sum_reg + expdiff_reg * prev_sum

    regs <<= regs * P_SCALE
    ub_p[0] <<= regs
    ub_max[0] <<= max_reg.single_value()
    ub_sum[0] <<= sum_reg.single_value()
    ub_expdiff[0] <<= expdiff_reg.single_value()


@vf()
def accum_pv_row(accum: Tensor, curr_pv: Tensor, expdiff: Tensor):
    accum_regs = RegList(DT.float, D_HEAD // 64)
    curr_regs = RegList(DT.float, D_HEAD // 64)
    expdiff_reg = Reg(DT.float)

    expdiff_reg <<= expdiff[0].single()
    accum_regs <<= accum[0]
    curr_regs <<= curr_pv[0]
    accum_regs <<= accum_regs * expdiff_reg
    accum_regs <<= accum_regs + curr_regs
    accum[0] <<= accum_regs


@vf()
def finalize_output_row(accum: Tensor, sum_ub: Tensor, scale_v: Var):
    regs = RegList(DT.float, D_HEAD // 64)
    sum_reg = Reg(DT.float)

    sum_reg <<= sum_ub[0].single()
    regs <<= accum[0]
    regs <<= regs * scale_v
    regs <<= regs / sum_reg
    accum[0] <<= regs


@kernel()
def mha_ifa_fp8_scale_256(
    q: GMTensor, k: GMTensor, v: GMTensor, output: GMTensor,
    bh: Var, L: Var, S: Var, Dn: Var, scale_q: Var, scale_k: Var, scale_v: Var,
):
    qk_mutex = CvMutex(0, dst_end_pipe=Pipe.V)
    p_mutex = VcMutex(1, dst_end_pipe=Pipe.MTE1)
    pv_mutex = CvMutex(2, dst_end_pipe=Pipe.V)

    l1q = DBuff(DT.e4m3, [16, Dn], Position.L1)
    l1k = TBuff(DT.e4m3, [BASES, Dn], Position.L1)
    l1v = TBuff(DT.e4m3, [BASES, Dn], Position.L1)
    l1p = DBuff(DT.e4m3, [16, BASES], Position.L1)
    l0c_qk = DBuff(DT.float, [16, BASES], Position.L0C)
    l0c_pv = DBuff(DT.float, [16, Dn], Position.L0C)

    ub_qk = DBuff(DT.float, [8, BASES], Position.UB)
    ub_pv = DBuff(DT.float, [8, Dn], Position.UB)
    ub_scaled_qk = Tensor(DT.float, [8, BASES], Position.UB)
    ub_p = DBuff(DT.e4m3, [8, BASES], Position.UB)
    ub_qk_sum = Tensor(DT.float, [1, 64], Position.UB)
    ub_qk_max = Tensor(DT.float, [1, 64], Position.UB)
    ub_expdiff = DBuff(DT.float, [1, 64], Position.UB)
    ub_accum = Tensor(DT.float, [8, Dn], Position.UB)

    qk_scale = scale_q * SOFTMAX_SCALE
    qk_scale = qk_scale * scale_k
    out_scale = scale_v / P_SCALE

    bh_per_core = CeilDiv(bh, GetCubeNum())
    bh_begin = Var(bh_per_core * GetCubeIdx())
    bh_end = Min(bh_begin + bh_per_core, bh)

    rows = Var(1)
    q_cnt = Var(0)
    stage1_cnt = Var(0)
    stage2_cnt = Var(0)

    for bh_idx in range(bh_begin, bh_end):
        l1q[q_cnt][:rows, :] <<= q[bh_idx, :rows, :]
        bar_all()
        init_row_state(ub_qk_sum, ub_qk_max, ub_expdiff[0], ub_expdiff[1], ub_accum)

        with auto_sync():
            for s in range(0, S + BASES, BASES):
                if s < S:
                    valid_cols = Min(BASES, S - s)
                    l1k[stage1_cnt] <<= k[bh_idx, s:s + valid_cols, :]
                    matmul(l0c_qk[stage1_cnt], l1q[q_cnt], l1k[stage1_cnt], splitk=SPLIT_K)

                    qk_mutex.lock()
                    ub_qk[stage1_cnt][:rows, :] <<= l0c_qk[stage1_cnt][:rows, :]
                    qk_mutex.ready()

                    qk_mutex.wait()
                    if valid_cols < BASES:
                        scale_qk_row_tail(ub_qk[stage1_cnt], ub_scaled_qk, qk_scale, valid_cols)
                    else:
                        scale_qk_row(ub_qk[stage1_cnt], ub_scaled_qk, qk_scale)
                    get_p_and_max_sum_row(
                        ub_scaled_qk,
                        ub_qk_max,
                        ub_qk_sum,
                        ub_expdiff[stage1_cnt],
                        ub_p[stage1_cnt],
                    )
                    qk_mutex.free()

                    p_mutex.lock()
                    if GetSubBlockIdx() == 0:
                        l1p[stage1_cnt][:rows, :] <<= ub_p[stage1_cnt][:rows, :]
                    p_mutex.ready()
                    stage1_cnt += 1

                if s > 0:
                    prev_s = Var(s - BASES)
                    prev_valid_cols = Min(BASES, S - prev_s)
                    l1v[stage2_cnt] <<= v[bh_idx, prev_s:prev_s + prev_valid_cols, :]

                    p_mutex.wait()
                    matmul(l0c_pv[stage2_cnt], l1p[stage2_cnt], l1v[stage2_cnt].T, splitn=SPLIT_N)
                    p_mutex.free()

                    pv_mutex.lock()
                    ub_pv[stage2_cnt][:rows, :] <<= l0c_pv[stage2_cnt][:rows, :]
                    pv_mutex.ready()

                    pv_mutex.wait()
                    accum_pv_row(ub_accum, ub_pv[stage2_cnt], ub_expdiff[stage2_cnt])
                    pv_mutex.free()
                    stage2_cnt += 1

        finalize_output_row(ub_accum, ub_qk_sum, out_scale)
        bar_all()
        if GetSubBlockIdx() == 0:
            output[bh_idx, :rows, :] <<= ub_accum[:rows, :]

        q_cnt += 1

    return output


def reference_mha_ifa_fp8_scale_256(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    scale_q: torch.Tensor,
    scale_k: torch.Tensor,
    scale_v: torch.Tensor,
) -> torch.Tensor:
    if q.shape[1] != 1:
        raise ValueError("reference expects q shape [BH, 1, D].")

    bh, q_rows, _ = q.shape
    _, seq_len, dim_v = v.shape

    row_max = torch.full((bh, q_rows), NEG_INF, dtype=torch.float32, device=q.device)
    row_sum = torch.zeros((bh, q_rows), dtype=torch.float32, device=q.device)
    output = torch.zeros((bh, q_rows, dim_v), dtype=torch.float32, device=q.device)

    for s_begin in builtins.range(0, seq_len, BASES):
        k_blk = k[:, s_begin:s_begin + BASES, :]
        v_blk = v[:, s_begin:s_begin + BASES, :]

        qk = torch.einsum("bld,bsd->bls", q.float(), k_blk.float())
        qk = qk * scale_q * SOFTMAX_SCALE * scale_k

        max_j = qk.amax(dim=-1)
        if s_begin == 0:
            new_row_max = max_j
            expdiff = torch.ones_like(new_row_max)
        else:
            new_row_max = torch.maximum(row_max, max_j)
            expdiff = torch.exp(row_max - new_row_max)

        p = torch.exp(qk - new_row_max[..., None])
        sum_j = p.sum(dim=-1)
        p = (p * P_SCALE).to(torch.float8_e4m3fn)  # type: ignore[attr-defined]

        curr_output = torch.einsum("bls,bsd->bld", p.float() / P_SCALE, v_blk.float())
        curr_output = curr_output * scale_v

        if s_begin == 0:
            row_sum = sum_j
            output = curr_output
        else:
            row_sum = row_sum * expdiff + sum_j
            output = output * expdiff[..., None] + curr_output
        row_max = new_row_max

    return output / row_sum[..., None]


def _error_stats(a: torch.Tensor, b: torch.Tensor) -> Dict[str, float]:
    diff = (a.float() - b.float()).abs()
    denom = b.float().abs().clamp_min(1e-12)
    rel = diff / denom
    return {
        "max_abs": diff.max().item(),
        "mean_abs": diff.mean().item(),
        "rmse": torch.sqrt((diff ** 2).mean()).item(),
        "max_rel": rel.max().item(),
        "mean_rel": rel.mean().item(),
    }


def _make_inputs(
    B: int, H: int, S: int, D: int, seed: int,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    g = torch.Generator(device="cpu")
    g.manual_seed(seed)
    q = torch.randn(B, H, 1, D, generator=g, dtype=torch.float32).to(torch.float8_e4m3fn)  # type: ignore[attr-defined]
    k = torch.randn(B, H, S, D, generator=g, dtype=torch.float32).to(torch.float8_e4m3fn)  # type: ignore[attr-defined]
    v = torch.randn(B, H, S, D, generator=g, dtype=torch.float32).to(torch.float8_e4m3fn)  # type: ignore[attr-defined]
    scale_q = torch.rand((), generator=g, dtype=torch.float32) + 0.5
    scale_k = torch.rand((), generator=g, dtype=torch.float32) + 0.5
    scale_v = torch.rand((), generator=g, dtype=torch.float32) + 0.5
    return q, k, v, scale_q, scale_k, scale_v


def _run_case(case_name: str, B: int, H: int, S: int, D: int, seed: int, rtol: float, atol: float) -> None:
    if D != D_HEAD:
        raise ValueError(f"{case_name}: expected D={D_HEAD}, got {D}")

    q_4d, k_4d, v_4d, scale_q, scale_k, scale_v = _make_inputs(B, H, S, D, seed)
    q = q_4d.reshape(B * H, 1, D)
    k = k_4d.reshape(B * H, S, D)
    v = v_4d.reshape(B * H, S, D)
    out_init = torch.zeros((B * H, 1, D), dtype=torch.float32)

    out_ref = reference_mha_ifa_fp8_scale_256(q, k, v, scale_q, scale_k, scale_v)
    op = OpExec(mha_ifa_fp8_scale_256, simulator=True, out_dir="./tmp/mha_ifa_fp8_scale_256")

    start = time.time()
    out_kernel = op(
        q, k, v, out_init,
        B * H, 1, S, D,
        float(scale_q.item()), float(scale_k.item()), float(scale_v.item()),
        shape_bindings={0: [0, 1, 3], 1: [0, 2, 3], 2: [0, 2, 3], 3: [0, 1, 3]},
    )
    elapsed_s = time.time() - start

    stats = _error_stats(out_kernel, out_ref)
    print("\n" + "=" * 80)
    print(
        f"{case_name}: B={B} H={H} S={S} D={D} seed={seed} "
        f"max_abs={stats['max_abs']:.8e} mean_abs={stats['mean_abs']:.8e} "
        f"rmse={stats['rmse']:.8e} max_rel={stats['max_rel']:.8e} "
        f"mean_rel={stats['mean_rel']:.8e} elapsed_s={elapsed_s:.3f}"
    )
    torch.testing.assert_close(out_kernel.float(), out_ref.float(), rtol=rtol, atol=atol)
    print(f"assert_close: PASS (rtol={rtol}, atol={atol})")


def run_cases() -> None:
    if not hasattr(torch, "float8_e4m3fn"):
        raise RuntimeError("Current torch build does not support torch.float8_e4m3fn")

    cases = [
        ("tail_s65", 1, 1, 65, D_HEAD, 7, 5e-2, 5e-2),
        ("aligned_s256", 1, 1, 256, D_HEAD, 7, 5e-2, 5e-2),
        ("tail_s321", 1, 1, 321, D_HEAD, 7, 5e-2, 5e-2),
        ("bh2_tail_s321", 1, 2, 321, D_HEAD, 7, 5e-2, 5e-2),
        ("tail_s513", 1, 2, 513, D_HEAD, 7, 5e-2, 5e-2),
        ("long_s2048", 1, 1, 2048, D_HEAD, 7, 5e-2, 5e-2),
        ("long_tail_s2049", 1, 1, 2049, D_HEAD, 7, 5e-2, 5e-2),
    ]
    for case in cases:
        _run_case(*case)


if __name__ == "__main__":
    run_cases()
