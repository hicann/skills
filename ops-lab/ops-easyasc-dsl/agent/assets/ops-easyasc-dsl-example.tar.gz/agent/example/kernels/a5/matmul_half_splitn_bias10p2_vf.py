# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------

from easyasc.a5 import *


TILE_M = 128
TILE_N = 256
TILE_K = 128
SPLIT_N = 128
ADD_BIAS = 10.2


@vf()
def add_bias_cast_vf(src_f32_ub: Tensor, dst_f16_ub: Tensor, n_loops: Var):
    reg_f32 = Reg(DT.float)
    for i in range(n_loops):
        reg_f32 <<= src_f32_ub[i * 64]
        reg_f32 <<= reg_f32 + ADD_BIAS
        # This uses the built-in cast(RegLayout.ZERO) + downsample path.
        dst_f16_ub[i * 64] <<= reg_f32


@kernel()
def matmul_half_splitn_kernel(x: GMTensor, y_t: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [TILE_M, TILE_K], Position.L1)
    l1y = DBuff(DT.half, [TILE_N, TILE_K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)
    xbuf = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)
    outbuf = DBuff(DT.half, [TILE_M // 2, TILE_N], Position.UB)

    l1_cnt = Var(0)
    tile_cnt = Var(0)
    vf_loops = Var(TILE_M // 2 * TILE_N // 64)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)
            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                for k0 in range(0, K, TILE_K):
                    valid_k = Min(TILE_K, K - k0)
                    # valid_* keep GM boundaries safe for unaligned shapes.
                    l1x[l1_cnt] <<= x[m0:m0 + valid_m, k0:k0 + valid_k]
                    l1y[l1_cnt] <<= y_t[n0:n0 + valid_n, k0:k0 + valid_k]
                    matmul(l0c[tile_cnt], l1x[l1_cnt], l1y[l1_cnt], splitn=SPLIT_N, is_init=(k0 == 0))

                cvmutex.lock()
                xbuf[tile_cnt] <<= l0c[tile_cnt]
                cvmutex.ready()

                cvmutex.wait()
                add_bias_cast_vf(xbuf[tile_cnt], outbuf[tile_cnt], vf_loops)
                cvmutex.free()

                half_rows = CeilDiv(valid_m, 2)
                sb_idx = GetSubBlockIdx()
                row_begin = sb_idx * half_rows
                row_end = Min(row_begin + half_rows, valid_m)
                row_count = row_end - row_begin
                z[m0 + row_begin:m0 + row_end, n0:n0 + valid_n] <<= outbuf[tile_cnt][0:row_count, 0:valid_n]
                l1_cnt += 1
                tile_cnt += 1
    return z


if __name__ == "__main__":
    import time
    import torch

    M = 1024
    N = 512
    K = 128

    torch.manual_seed(0)
    x = torch.rand((M, K), dtype=torch.float16)
    y = torch.rand((K, N), dtype=torch.float16)
    y_t = y.t().contiguous()
    z = torch.zeros((M, N), dtype=torch.float16)

    start = time.time()
    z_kernel = OpExec(matmul_half_splitn_kernel, simulator=True)(x, y_t, z, M, N, K)
    sim_time_s = time.time() - start

    start = time.time()
    z_gt = ((x.float() @ y.float()) + ADD_BIAS).half()
    ref_time_s = time.time() - start

    torch.testing.assert_close(z_kernel, z_gt, rtol=5e-3, atol=5e-2)
    max_abs = torch.abs(z_kernel - z_gt).max().item()
    print(f"simulator_time_s={sim_time_s:.3f}")
    print(f"reference_time_s={ref_time_s:.3f}")
    print(f"max_abs_diff={max_abs:.6e}")
