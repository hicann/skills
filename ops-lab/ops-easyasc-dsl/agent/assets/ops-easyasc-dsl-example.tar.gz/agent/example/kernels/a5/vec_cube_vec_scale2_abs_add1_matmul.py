# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------

from easyasc.a5 import *


TILE_M = 128
TILE_N = 128
SPLIT_N = 128


@vf()
def scale2_half_vf(src: Tensor, dst: Tensor, n_loops: Var):
    reg_h = Reg(DT.half)
    for i in range(n_loops):
        reg_h <<= src[i * 128]
        reg_h <<= reg_h * 2.0
        dst[i * 128] <<= reg_h


@vf()
def abs_add1_vf(src: Tensor, dst: Tensor, n_loops: Var):
    reg_f = Reg(DT.float)
    for i in range(n_loops):
        reg_f <<= src[i * 64]
        reg_f <<= reg_f.abs() + 1.0
        dst[i * 64] <<= reg_f


@kernel()
def vec_cube_vec_scale2_abs_add1_matmul_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    # Vec producer: L1 <<= UB (routes to ub_to_l1_nd2nz) on MTE3. Cube consumer ends on FIX after matmul.
    vcmutex = VcMutex(0, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)
    # Cube producer: l0c_to_ub on FIX. Vec consumer: @vf on V.
    cvmutex = CvMutex(1, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [TILE_M, K], Position.L1)
    l1y = DBuff(DT.half, [TILE_N, K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)

    x_ub = DBuff(DT.half, [TILE_M // 2, K], Position.UB)
    x2_ub = DBuff(DT.half, [TILE_M // 2, K], Position.UB)
    mat_ub = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)
    out_ub = DBuff(DT.float, [TILE_M // 2, TILE_N], Position.UB)

    x_pre_cnt = Var(0)
    l1x_cnt = Var(0)
    l1y_cnt = Var(0)
    tile_cnt = Var(0)
    half_rows = Var(TILE_M // 2)

    tile_m = CeilDiv(M, TILE_M)
    tile_m_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_m_begin = Var(tile_m_per_core * GetCubeIdx())
    tile_m_end = Min(tile_m_begin + tile_m_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)

            vcmutex.lock()
            row_start = Var(GetSubBlockIdx() * half_rows)
            if row_start < valid_m:
                row_end = Min(row_start + half_rows, valid_m)
                rows_this = Var(row_end - row_start)
                pre_loops = Var(rows_this * K // 128)
                x_ub[x_pre_cnt] <<= x[m0 + row_start:m0 + row_end, 0:K]
                scale2_half_vf(x_ub[x_pre_cnt], x2_ub[x_pre_cnt], pre_loops)
                l1x[l1x_cnt][row_start:row_end, 0:K] <<= x2_ub[x_pre_cnt][0:rows_this, 0:K]
            vcmutex.ready()

            vcmutex.wait()
            for n0 in range(0, N, TILE_N):
                valid_n = Min(TILE_N, N - n0)
                l1y[l1y_cnt] <<= y[n0:n0 + valid_n, 0:K]
                matmul(l0c[tile_cnt], l1x[l1x_cnt], l1y[l1y_cnt], splitn=SPLIT_N)

                cvmutex.lock()
                mat_ub[tile_cnt] <<= l0c[tile_cnt]
                cvmutex.ready()

                cvmutex.wait()
                post_loops = Var(TILE_M // 2 * TILE_N // 64)
                abs_add1_vf(mat_ub[tile_cnt], out_ub[tile_cnt], post_loops)
                cvmutex.free()

                half_valid = CeilDiv(valid_m, 2)
                sb_idx = GetSubBlockIdx()
                row_begin = sb_idx * half_valid
                if row_begin < valid_m:
                    row_end = Min(row_begin + half_valid, valid_m)
                    row_count = row_end - row_begin
                    z[m0 + row_begin:m0 + row_end, n0:n0 + valid_n] <<= out_ub[tile_cnt][0:row_count, 0:valid_n]

                l1y_cnt += 1
                tile_cnt += 1

            vcmutex.free()
            x_pre_cnt += 1
            l1x_cnt += 1

    return z


if __name__ == "__main__":
    import torch

    torch.manual_seed(0)

    M = 128 * 64
    N = 128
    K = 128

    x = torch.randn(M, K).half()
    y = torch.randn(N, K).half()
    z = torch.zeros(M, N).float()

    z_kernel = OpExec(vec_cube_vec_scale2_abs_add1_matmul_kernel, simulator=True)(x, y, z, M, N, K, shape_bindings={0: [0, 2], 1: [1, 2], 2: [0, 1]})
    z_ref = ((x * 2).half().float() @ y.float().t()).abs() + 1.0

    torch.testing.assert_close(z_kernel, z_ref, rtol=1e-3, atol=1e-3)
    print(f"max_abs_diff={torch.abs(z_kernel - z_ref).max().item():.6e}")
