# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------

from easyasc.a5 import *


BLK = 64


@vf()
def abs_add1_micro(x: Tensor, out: Tensor, n_loops: Var):
    reg = Reg(DT.float)
    for i in range(n_loops):
        reg <<= x[i * 64]
        reg <<= reg.abs() + 1.0
        out[i * 64] <<= reg


@kernel()
def cube_vec_atomic_add_two_outputs(
    x: GMTensor, y: GMTensor, out_cube: GMTensor, out_vec: GMTensor,
    M: Var, N: Var, K: Var,
):
    # Producer: l0c_to_ub on FIX. Consumer: abs_add1_micro on V.
    cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

    l1x = DBuff(DT.half, [BLK, K], Position.L1)
    l1y = DBuff(DT.half, [N, K], Position.L1)
    l0c = DBuff(DT.float, [BLK, N], Position.L0C)
    xbuf = DBuff(DT.float, [BLK // 2, N], Position.UB)
    outbuf = DBuff(DT.float, [BLK // 2, N], Position.UB)

    tile_cnt = Var(0)

    tile_m = CeilDiv(M, BLK)
    tiles_per_core = CeilDiv(tile_m, GetCubeNum())
    tile_begin = Var(tiles_per_core * GetCubeIdx())
    tile_end = Min(tile_begin + tiles_per_core, tile_m)

    with auto_sync():
        for mt in range(tile_begin, tile_end):
            m = Var(mt * BLK)
            valid_m = Min(BLK, M - m)

            l1x[tile_cnt] <<= x[m:m + valid_m, 0:K]
            l1y[tile_cnt] <<= y[0:N, 0:K]
            matmul(l0c[tile_cnt], l1x[tile_cnt], l1y[tile_cnt], splitn=128)

            with atomic_add():
                out_cube[m:m + valid_m, 0:N] <<= l0c[tile_cnt]

            cvmutex.lock()
            xbuf[tile_cnt] <<= l0c[tile_cnt]
            cvmutex.ready()

            cvmutex.wait()
            abs_add1_micro(xbuf[tile_cnt], outbuf[tile_cnt], BLK // 2 * N // 64)
            cvmutex.free()

            half_rows = CeilDiv(valid_m, 2)
            sb_idx = GetSubBlockIdx()
            row_begin = sb_idx * half_rows
            row_end = Min(row_begin + half_rows, valid_m)
            row_count = row_end - row_begin

            with atomic_add():
                out_vec[m + row_begin:m + row_end, 0:N] <<= outbuf[tile_cnt][0:row_count, 0:N]

            tile_cnt += 1

    return out_cube, out_vec


if __name__ == "__main__":
    import torch

    torch.manual_seed(0)

    M = 64 * 16
    N = 128
    K = 128

    x = torch.randn(M, K).half()
    y = torch.randn(N, K).half()
    out_cube_init = torch.randn(M, N).float()
    out_vec_init = torch.randn(M, N).float()

    matmul_ref = x.float() @ y.float().t()
    out_cube_ref = out_cube_init + matmul_ref
    out_vec_ref = out_vec_init + matmul_ref.abs() + 1.0

    out_cube_kernel, out_vec_kernel = OpExec(cube_vec_atomic_add_two_outputs, simulator=True)(x, y, out_cube_init.clone(), out_vec_init.clone(), M, N, K, shape_bindings={0: [0, 2], 1: [1, 2], 2: [0, 1], 3: [0, 1]})

    torch.testing.assert_close(out_cube_kernel, out_cube_ref, rtol=1e-3, atol=1e-3)
    torch.testing.assert_close(out_vec_kernel, out_vec_ref, rtol=1e-3, atol=1e-3)

    max_cube_diff = torch.abs(out_cube_kernel - out_cube_ref).max().item()
    max_vec_diff = torch.abs(out_vec_kernel - out_vec_ref).max().item()
    print(f"max_cube_diff={max_cube_diff:.6e}")
    print(f"max_vec_diff={max_vec_diff:.6e}")
