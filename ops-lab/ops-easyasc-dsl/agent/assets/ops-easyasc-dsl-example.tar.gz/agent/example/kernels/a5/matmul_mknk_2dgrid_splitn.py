# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import os
import sys
from typing import Tuple

from easyasc.a5 import *

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'scripts'))
from estimate_matmul_datamove import (
    SPLIT_MODE_MIX,
    estimate_multi_core,
    generate_split_candidates,
)


TILE_M = 128
TILE_N = 256
TILE_K = 128
SPLIT_N = 128

SHAPE_BINDINGS = {
    0: [0, 2],  # x[M, K]
    1: [1, 2],  # y[N, K]
    2: [0, 1],  # z[M, N]
}


def select_mknk_2dgrid_split(m: int, n: int, k: int, num_core: int = 32) -> Tuple[int, int, int]:
    best = None

    for m_split, n_split in generate_split_candidates(num_core, SPLIT_MODE_MIX):
        datamove = estimate_multi_core(
            m,
            n,
            k,
            m_split,
            n_split,
            TILE_M,
            TILE_N,
            TILE_K,
            dbuf_l0c=True,
        )
        split_diff = m_split - n_split if m_split >= n_split else n_split - m_split
        shared_depth = m_split if m_split <= n_split else n_split
        candidate = (
            datamove,
            0 if m_split > 1 and n_split > 1 else 1,
            split_diff,
            -shared_depth,
            m_split,
            n_split,
        )
        if best is None or candidate < best[0]:
            best = (candidate, m_split, n_split, datamove)

    if best is None:
        raise ValueError("No valid m_split/n_split found for matmul_mknk_2dgrid_splitn")

    _, m_split, n_split, datamove = best
    return m_split, n_split, datamove


@kernel()
def matmul_mknk_2dgrid_splitn_kernel(
    x: GMTensor, y: GMTensor, z: GMTensor,
    M: Var, N: Var, K: Var, M_SPLIT: Var, N_SPLIT: Var,
):
    l1x = DBuff(DT.half, [TILE_M, TILE_K], Position.L1)
    l1y = DBuff(DT.half, [TILE_N, TILE_K], Position.L1)
    l0c = DBuff(DT.float, [TILE_M, TILE_N], Position.L0C)

    l1_cnt = Var(0)
    l0c_cnt = Var(0)

    core_m_idx = Var(GetCubeIdx() // N_SPLIT)
    core_n_idx = Var(GetCubeIdx() % N_SPLIT)
    tile_m = CeilDiv(M, TILE_M)
    tile_n = CeilDiv(N, TILE_N)
    tile_m_per_split = CeilDiv(tile_m, M_SPLIT)
    tile_n_per_split = CeilDiv(tile_n, N_SPLIT)
    tile_m_begin = Var(tile_m_per_split * core_m_idx)
    tile_m_end = Min(tile_m_begin + tile_m_per_split, tile_m)
    tile_n_begin = Var(tile_n_per_split * core_n_idx)
    tile_n_end = Min(tile_n_begin + tile_n_per_split, tile_n)

    with auto_sync():
        for mt in range(tile_m_begin, tile_m_end):
            m0 = Var(mt * TILE_M)
            valid_m = Min(TILE_M, M - m0)
            for nt in range(tile_n_begin, tile_n_end):
                n0 = Var(nt * TILE_N)
                valid_n = Min(TILE_N, N - n0)
                for k0 in range(0, K, TILE_K):
                    valid_k = Min(TILE_K, K - k0)
                    l1x[l1_cnt] <<= x[m0:m0 + valid_m, k0:k0 + valid_k]
                    l1y[l1_cnt] <<= y[n0:n0 + valid_n, k0:k0 + valid_k]
                    matmul(
                        l0c[l0c_cnt][0:valid_m, 0:valid_n],
                        l1x[l1_cnt],
                        l1y[l1_cnt],
                        splitn=SPLIT_N,
                        m=valid_m,
                        n=valid_n,
                        k=valid_k,
                        is_init=(k0 == 0),
                    )
                    l1_cnt += 1
                z[m0:m0 + valid_m, n0:n0 + valid_n] <<= l0c[l0c_cnt][0:valid_m, 0:valid_n]
                l0c_cnt += 1
    return z


if __name__ == "__main__":
    import torch

    test_shapes = [(128, 256, 128)]

    for M, N, K in test_shapes:
        m_split, n_split, _ = select_mknk_2dgrid_split(8192, 5120, 5120)
        torch.manual_seed(0)
        x = torch.rand((M, K), dtype=torch.float16)
        y = torch.rand((N, K), dtype=torch.float16)
        z = torch.zeros((M, N), dtype=torch.float32)

        z_kernel = OpExec(matmul_mknk_2dgrid_splitn_kernel, simulator=True)(
            x,
            y,
            z,
            M,
            N,
            K,
            m_split,
            n_split,
            shape_bindings=SHAPE_BINDINGS,
        )
        z_ref = x.float() @ y.float().t()

        torch.testing.assert_close(z_kernel, z_ref, rtol=3e-3, atol=3e-3)
        print(f"shape=(M={M}, N={N}, K={K})")
        print(f"selected_split=(m_split={m_split}, n_split={n_split})")
        print(f"max_abs_diff={torch.abs(z_kernel - z_ref).max().item():.6e}")
