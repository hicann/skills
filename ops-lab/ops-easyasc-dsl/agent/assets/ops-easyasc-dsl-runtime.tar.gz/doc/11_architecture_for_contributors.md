# Architecture for Contributors

This document is for contributors who need to change the framework itself, not only author kernels on top of it.

If this checkout does not currently contain `easyasc/`, `doc/`, or `doc_cn/`, restore them first with `bash agent/scripts/init.sh`.

## 1. Repository structure

The main repository areas are:

- `easyasc/`
  - public DSL surface
  - parser and lowering
  - simulator runtime
  - instruction emitters and helpers
- `agent/example/kernels/`
  - curated kernel examples and kernel-focused notes
- `historical automated tests/` (removed from this skill bundle)
  - automated pytest coverage plus reusable fixtures under `historical testcases/fixtures/` (removed from this skill bundle)
- `agent/scripts/`
  - standalone repository utilities and maintenance scripts
- `doc/`
  - English project and API documentation
- `doc_cn/`
  - Chinese mirror of the documentation set
- `agent/`
  - router-first guidance, catalogs, and implementation maps for repository work
  - includes a2-specific staged-pipeline pattern notes under `agent/references/patterns/`, including the normalized online-softmax route for a2 flash attention
- `agent/example/demo/`
  - manual runners or compile/integration demos that are useful to keep but should not run as part of the default pytest suite
  - grouped by device family under `agent/example/demo/a2/` and `agent/example/demo/a5/`
  - current negative-case repros live under `agent/example/demo/a5/negative_cases/`

High-level owner files:

- `README.md`, `README_CN.md`
  - top-level project and documentation entry points
- `AGENTS.md`
  - repository-local working rules for agent-style contributors
- `agent/references/repo-map.md`
  - quick top-level layout and ownership map
- `agent/references/code-paths.md`
  - fast implementation-path lookup
- `historical testcases/README.md` (removed from this skill bundle)
  - test-suite layout, fixture placement, and the line between pytest coverage and demos

## 2. Device family mapping

Before interpreting any hardware-specific branch, keep this mapping straight:

- `device_type == "950"` corresponds to the C310 path
- `device_type.startswith("b")` corresponds to the C220 path
- in `easyasc/resources/tensorutils.h`, `__DAV_C310__` is the `950` branch
- in `easyasc/resources/tensorutils.h`, `__DAV_C220_CUBE__` is the `b*` branch

Several support checks, helper choices, and generated code paths depend on this mapping. Do not invert it when reading the repository.

## 3. End-to-end control flow

The typical internal path is:

1. a decorated Python function is transformed by `easyasc/pythonic.py`
2. `@kernel` wraps it in `KernelBase`
3. DSL objects emit `Instruction` records into the active kernel or micro context
4. `OpExec` binds runtime inputs and triggers either simulator or generation flow
5. the parser splits and lowers instructions into cube and vec code
6. the simulator or generated runtime consumes the result
7. `shape_bindings` is used when repeated scalar values make shape inference ambiguous

The key entry modules are:

- `easyasc/decorators.py`
- `easyasc/kernelbase/kernelbase.py`
- `easyasc/torchplugin.py`

## 4. Public surface modules

- `easyasc/a2.py`
- `easyasc/a5.py`
- `easyasc/flowcontrol.py`
- `easyasc/utils/Tensor.py`
- `easyasc/utils/var.py`

When changing the public API, start here and determine which surface the behavior belongs to: `a2`, `a5`, or both. Do not assume every public-API change should land in both surfaces, because they target different architecture styles and instruction sequences.

## 5. Parser and lowering

The parser stack lives under `easyasc/parser/`.

Important roles:

- `asc.py`
  - instruction splitting
  - side classification
  - autosync insertion
  - translation dispatch
- `asc_pruning.py`
  - cleanup and pruning passes
- `asc_autosync.py`
  - event insertion for supported same-side pipe pairs
- `asc_handlers/`
  - per-op lowering handlers

If you add a new instruction family, expect to touch:

1. the stub emitter
2. handler registration or dispatch
3. possibly the simulator
4. maybe autosync classification if the instruction belongs to a known pipe stage

## 6. Stub emitters

The authoring API mostly emits instructions through stubs under:

- `easyasc/stub_functions/`
- `easyasc/stub_functions/vec/`
- `easyasc/stub_functions/micro/`

These modules define the legal DSL authoring surface that kernels actually call. They are the first place to inspect when a DSL statement does not behave the way you expected.

## 7. Simulator internals

The simulator lives under `easyasc/simulator/`.

Major areas:

- orchestration: `base.py`, `core.py`
- cube runtime: `cube.py`
- vec runtime: `vec.py`
- pipe implementations
- shared helpers
- micro runtime
- trace export

When you add or change instruction semantics, make sure the simulator remains in sync with parser expectations.

## 8. Micro modules

`@vf` functions are wrapped by `easyasc/micro/micromodule.py`.

Important details:

- micro functions are cached as reusable modules
- temporary register declarations are hoisted into micro scope
- read and write sync keys are collected from the emitted micro instructions
- kernel calls to a micro emit `call_micro` instructions

Any change to micro dataflow should be checked against both parser lowering and simulator runtime behavior.

## 9. Testing and demos

- `historical automated tests/` (removed from this skill bundle) is for automated regression coverage.
  - parser, pruning, and codegen behavior
  - simulator semantics and runtime invariants
  - synchronization paths such as autosync, barriers, atomics, and coordination helpers
  - tool-level CLI and metadata regression coverage
  - reusable source assets under `historical testcases/fixtures/` (removed from this skill bundle)
- `agent/example/demo/` is for manual runners or compile/integration examples that are useful to keep but should not run as part of the default regression suite.
- prefer `agent/example/demo/a2/` or `agent/example/demo/a5/` so the device target is obvious from the path.
- If a root-level executable script becomes important, either convert it into a pytest test under `historical automated tests/` (removed from this skill bundle) or move it under `agent/example/demo/`. Do not let the repository root regrow ad-hoc runners.

## 10. Synchronization model

The current repository has two synchronization layers:

1. autosync
   - same-side pipeline handshakes inserted during lowering
2. explicit cross-side mutexes and wait/ready paths
   - used when ownership crosses between cube and vec

Changes here are high-risk because they affect:

- parser lowering
- simulator scheduling
- trace output
- many existing tests

Keep changes small and validate them with focused tests.

## 11. Generated resources

The runtime generation path also depends on template and helper files under:

- `easyasc/resources/`

If you change emitted code shape, check whether host/runtime templates or helper headers also need to change.

## 12. High-level maps and summaries

Use the smallest owner file that answers the question:

- top-level layout or ownership -> `agent/references/repo-map.md`
- implementation-path lookup -> `agent/references/code-paths.md`
- kernel examples and kernel-specific notes -> `agent/references/examples/kernel-catalog.md`
- tool behavior summaries -> `agent/scripts/tools_summary.md`
- test-suite structure -> `historical testcases/README.md` (removed from this skill bundle)

## 13. Contribution checklist

When changing framework internals:

1. identify the authoring API impact
2. update lowering and simulator consistently
3. add or update a focused test
4. refresh the owner docs that actually describe the changed area:
   - structure or subsystem ownership -> `agent/references/repo-map.md` and/or this file
   - implementation-path lookup -> `agent/references/code-paths.md`
   - kernel additions or meaningful kernel changes -> `agent/references/examples/kernel-catalog.md`
   - new reusable pipeline patterns -> matching file under `agent/references/patterns/` and any router/playbook entry that should point to it
   - tool changes -> `agent/scripts/tools_summary.md`
   - test organization changes -> `historical testcases/README.md` (removed from this skill bundle)
5. if a new kernel is added under `agent/example/kernels/`, update the kernel summaries too

This repository is easiest to maintain when parser, simulator, tests, documentation, and examples evolve together.
