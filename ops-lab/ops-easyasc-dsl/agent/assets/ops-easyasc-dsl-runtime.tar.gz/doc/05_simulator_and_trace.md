# Simulator and Trace

The simulator is the safest first execution target in this repository. It lets you validate kernel semantics without depending on the generated runtime path.

## 1. What the simulator covers

The simulator executes the instruction streams emitted by the kernel after the authoring stage. The current codebase includes:

- core orchestration
- cube-side execution
- vec-side execution
- micro runtime execution
- event and synchronization behavior
- optional trace export

This makes it the default choice for:

- first-pass validation
- debugging synchronization
- reproducing parser and runtime behavior in tests

## 2. How to run in simulator mode

Use:

```python
out = OpExec(kernel_fn, simulator=True)(...)
```

You can also select the backend explicitly:

```python
out = OpExec(kernel_fn, simulator="legacy")(...)
out = OpExec(kernel_fn, simulator="v2")(...)
```

In this mode:

- input PyTorch tensors are cloned into `GMTensor.data`
- the kernel runs through `run_sim(...)`
- output `GMTensor` objects are mapped back into PyTorch tensors

Notes:

- `simulator=True` is equivalent to `simulator="legacy"`
- `simulator="v2"` is currently an explicit experimental path
- the V2 path now first tries a default bridge from legacy lowered instructions to `KernelProgram`
- the default bridge is intentionally narrow today: single-core, linear pure-cube or pure-vec kernels with contiguous GM slices and already-ported V2 pipe ops
- mixed cube/vec kernels are still expected to provide an explicit V2 bridge for now
- if the kernel falls outside that subset, provide `build_simulator_v2_program()` (or an equivalent injected hook)

## 3. Why simulator-first is the repository norm

Most runnable kernel files in `agent/example/kernels/` validate themselves with:

```python
OpExec(..., simulator=True)
```

The main advantages are:

- faster iteration on kernel logic
- easier comparison against PyTorch references
- direct visibility into synchronization and pipe behavior
- no need to trust codegen before your math is correct

## 4. Generating a trace

Trace export is only supported in simulator mode.

Example:

```python
trace_path = os.path.join(out_dir, "trace.json")
out = OpExec(kernel_fn, out_dir, simulator=True, trace=trace_path)(...)
```

The generated file is intended to be compatible with Chrome or Perfetto-style timeline viewers.

The repository's `historical testcases/test_trace.py` (removed from this skill bundle) demonstrates:

- running a mixed cube/vec kernel with tracing enabled
- checking that the trace file exists
- verifying that timed events were emitted

## 5. What the trace is good for

Use the trace when you need to answer questions like:

- which side ran first
- whether a producer/consumer handoff happened in the order you expected
- whether events, waits, or barriers are stalling the flow
- whether the pipeline shape matches your intended topology

The trace is especially helpful for mixed kernels with:

- `auto_sync()`
- cross-side mutexes
- one-tile lookahead patterns
- delayed consumers

## 6. Suggested debugging loop

When a new kernel does not work:

1. reduce the shape
2. run in simulator mode
3. compare against a direct PyTorch reference
4. if synchronization is involved, enable tracing
5. only after the simulator is correct, try generation or hardware-facing flow

## 7. Simulator-oriented tests

The `historical automated tests/` (removed from this skill bundle) tree contains many simulator-first tests, including:

- autosync metadata
- cross-core and all-core waits
- micro cast and mask behavior
- datamove helpers
- timeout behavior
- runtime optimization behaviors

These tests are often the best documentation for edge cases.

## 8. Important runtime checks

Some useful failure modes come directly from `OpExec`:

- `trace is only supported when simulator is enabled`
- invalid tensor/scalar argument ordering
- unsupported PyTorch dtypes
- ambiguous shape inference without `shape_bindings`

These are usually user-input issues, not parser bugs.

## 9. Files to inspect

- `historical testcases/test_trace.py` (removed from this skill bundle)
- `easyasc/simulator/base.py`
- `easyasc/simulator/core.py`
- `easyasc/simulator/cube.py`
- `easyasc/simulator/vec.py`
- `easyasc/simulator/trace.py`
- `easyasc/simulator_v2/compat/kernel_bridge.py`
