# Kernel 模式库

`agent/example/kernels/` 目录不只是示例文件夹，它其实是这个仓库里关于“合法 DSL 用法”和“稳定实现形态”的模式库。

## 1. 如何使用 kernel 目录

阅读已有 kernel，主要是为了回答这些问题：

- 最短的合法 matmul baseline 是什么样
- 一个 cube -> vec 的交接应该长什么样
- tail 写回应该怎么处理
- fp8 cast 目前是怎么建模的
- 在这个 DSL 里，多阶段流水代码通常长什么样

不要机械地把某个 kernel 的主体直接复制到新 kernel 里。正确做法是从目标公式出发，只借鉴那些确实被该公式需要的模式。

## 2. 最短正确性基线

建议先看这些文件：

- `agent/example/kernels/a5/matmul_float_mmad.py`
  - 最短的纯 cube matmul 路径
- `agent/example/kernels/a5/matmul_e5m2_shortcut.py`
  - float8 输入、float 输出的 matmul
- `agent/example/kernels/a5/matmul_kmkn_fp32_out.py`
  - 原生 `KM @ KN -> MN` 布局

## 3. cube -> vec 后处理模式

当 matmul 结果在最终写回前还需要做 vector 处理时，这组模式就很有用。

- `agent/example/kernels/a5/basic_cube_vec_mix.py`
  - `abs(matmul) + 1`
- `agent/example/kernels/a5/matmul_rowwise_norm.py`
  - 按行规约再广播除法
- `agent/example/kernels/a5/matmul_rowwise_norm_large_nk.py`
  - 面向更大 shape 的两遍归一化

当输出变换天然更适合放在 vec 侧，而且不需要立刻重新融回 cube 时，就应该优先看这组文件。

## 4. vec -> cube 预处理模式

当公式要求某个操作数在 matmul 之前先做变换时，这组模式就很适合：

- `agent/example/kernels/a5/vec_cube_abs_sqrt_matmul.py`
- `agent/example/kernels/a5/vec_cube_abs_sqrt_matmul_nz.py`
- `agent/example/kernels/a5/recompute_wu_cube_vec.py`

这类模式的共同思路是：

- 先在 UB 里计算
- 如果需要，就先 cast 或重新打包
- 用 `ub_to_l1_nd2nz` 或 `ub_to_l1_nz` 发布到 L1
- 再由 cube 侧 matmul 消费

## 5. 多阶段 mixed pipeline 模式

下面这些文件展示了如何把不止一次的交接组合起来：

- `agent/example/kernels/a5/vec_cube_vec_scale2_abs_add1_matmul.py`
  - vec 预处理 -> cube -> vec 后处理
- `agent/example/kernels/a5/cube_vec_atomic_add_two_outputs.py`
  - 带双输出与原子写回的 mixed pipeline

当一个新公式无法被写成单一纯阶段时，就应该优先研究这些文件。

## 6. 流式与 lookahead 模式

保留下来的最复杂示例是：

- `agent/example/kernels/a5/test_mla_entire.py`

它展示了：

- one-tile lookahead 调度
- delayed consumer 的生命周期
- 流式 `row_max` 与 `row_sum`
- 在不把中间状态回写到 GM 的前提下，让 vec 和 cube 协作

建议先掌握较小的 mixed kernel，再来读这个文件。

## 7. 纯 vec 与 micro 模式

适合参考的文件有：

- `agent/example/kernels/a5/vec_unaligned_gm_to_ub_pad.py`
- `agent/example/kernels/a5/micro_cast_fp8_pack4_dual.py`

这些 kernel 可以回答的问题包括：

- 纯 vec kernel 应该怎么写
- 怎样通过 `single()` 做标量抽取
- 宽度不对齐时应该如何处理
- 在 micro 代码里，fp8 的 `pack4` 写回到底是什么语义

## 8. 模式选择指南

如果你的目标 kernel 是：

- 最短纯 matmul：从 `matmul_float_mmad.py` 起步
- cube matmul 加 vec epilogue：从 `basic_cube_vec_mix.py` 起步
- 先做 vec 预处理再 matmul：从 `vec_cube_abs_sqrt_matmul.py` 起步
- 两段 mixed stage：从 `vec_cube_vec_scale2_abs_add1_matmul.py` 起步
- 更高级的流式 attention 类路径：去研究 `test_mla_entire.py`

## 9. 配套说明

仓库里还有两个专门用来补充 kernel 模式库的文件：

- `agent/references/examples/kernel-catalog.md`

当你要基于现有模式推导新 kernel 时，建议把它和源码一起对照着看。
