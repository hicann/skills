# 常见问题排查

本页聚焦于你在这个仓库里编写或运行 kernel 时，最可能遇到的失败模式。

## 1. `Invalid argument order: torch.Tensor must come before int/float`

原因：

- `OpExec.__call__` 要求所有张量参数放在前面，标量参数放在后面

修复办法：

- 先传运行时张量
- 把 `M`、`N`、`K` 以及其他标量参数移动到参数列表末尾

## 2. `Ambiguous scalar match for tensor #... dim #...`

原因：

- 有两个或更多标量参数在运行时拥有相同的值
- `OpExec` 无法判断某个张量维度到底应该绑定到哪个标量

修复办法：

- 增加显式的 `shape_bindings`

例如：

```python
shape_bindings={
    0: [0, 2],
    1: [1, 2],
    2: [0, 1],
}
```

## 3. `shape_bindings[...] mismatches tensor dim value`

原因：

- 你给出的 `shape_bindings` 条目指向了一个标量，但这个标量的值与真实张量维度并不相等

修复办法：

- 逐个核对你选中的标量索引与真实张量维度是否一致

## 4. `trace is only supported when simulator=True`

原因：

- 你传了 `trace=...`，但当前选择的是生成模式

修复办法：

- 只有在 `simulator=True` 时才启用 tracing

## 5. `VecOP only supports UB position`

原因：

- 你把 vec 操作用到了不在 `UB` 上的张量

修复办法：

- 先把数据搬到 UB 张量里，再进入 vec 阶段

## 6. `MicroModule only accepts Tensor inputs in UB`

原因：

- 你调用 `@vf` 函数时，传入的张量来自 `L1`、`L0C` 或全局内存，而不是 UB

修复办法：

- 只用 UB 张量和标量输入去调用 micro helper

## 7. `GMTensor has not bound a mutex yet`

原因：

- 你在某个 `GMTensor` 上调用了 `lock()`、`ready()`、`wait()` 或 `free()`，但它事先并没有绑定 mutex

修复办法：

- 先调用 `bind_cv_mutex(...)` 或 `bind_vc_mutex(...)`
- 或者直接显式使用 `CvMutex` / `VcMutex` 对象

## 8. kernel 能跑，但数学结果不对

检查清单：

1. 确认 PyTorch 公式本身是否精确
2. 确认 cast 顺序
3. 确认操作数布局与转置位置
4. 缩小 shape，在模拟器模式下重跑
5. 检查 tail 写回逻辑
6. 如果涉及同步，就补一个 simulator trace

在这个仓库里，数学不对最常见的原因往往是：

- cast 放错了位置
- `x @ y.t()` 对应的 `y` 布局错了
- tail slice 的 subblock 边界算错了
- 把跨侧交接错误地只交给了 `auto_sync()`

## 9. kernel 死锁或看起来卡住了

最可能的原因有：

- producer / consumer 顺序没闭合
- mutex 生命周期不平衡
- event 或 wait 挂在了错误的一侧

建议做法：

1. 缩小 shape
2. 先只保留一个 tile
3. 打开 simulator trace
4. 拿你的流水去和一个拓扑相同但更小的现有 kernel 对照

## 10. 生成模式失败，但模拟器模式正常

这通常说明问题出在以下某一层：

- parser lowering
- 生成产物所依赖的假设
- 本地构建或运行脚本
- 环境相关工具链配置

排查时不要跳过模拟器阶段。应先在模拟器里证明 kernel 逻辑没问题，再去看生成路径的特有行为。

## 11. 有用的对照文件

卡住的时候，可以优先对照：

- `agent/example/kernels/a5/matmul_float_mmad.py`，最短 baseline
- `agent/example/kernels/a5/basic_cube_vec_mix.py`，cube -> vec
- `agent/example/kernels/a5/vec_cube_abs_sqrt_matmul.py`，vec -> cube
- `testcases/simulator/trace/test_trace.py`，模拟器 trace
- `testcases/simulator/opexec/test_torchplugin_shape_bindings.py`，shape-binding 失败场景
