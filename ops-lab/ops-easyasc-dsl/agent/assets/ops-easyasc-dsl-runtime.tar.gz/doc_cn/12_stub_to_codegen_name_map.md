# Stub 与 Codegen 名字对照表

这份文档用于快速查表：当你手里有一个来自 `easyasc.a2` 或 `easyasc.a5` 的公开 helper 名字时，可以在这里找到它在生成代码里对应的 C++ helper、宏，或内联表达式形式。

如果你需要先理解完整的 lowering 流程，建议先看 [代码生成与运行时](06_codegen_and_runtime.md)。
这份文档不解释语义、合法性约束或 simulator 行为。

## 适用范围

- “A2” 指 `easyasc.a2` 公开接口，以及 `device_type.startswith("b")` 的 codegen 路径。
- “A5” 指 `easyasc.a5` 公开接口，以及 `device_type == "950"` 的 codegen 路径。
- 下文列出的生成名字来自 `easyasc/parser/asc_handlers/`。
- 下表描述的是 `easyasc.a2` 和 `easyasc.a5` 顶层模块实际导出的名字，不是 `easyasc/stub_functions/` 目录下所有“存在但未必导出”的 helper 文件。
- 有些 helper 最终生成的是 view 声明或内联表达式，而不是单个 runtime helper 调用。
- `sim_print` 和 `sim_dump_tensor` 仅用于 simulator；它们不会生成 C++ 语句。
- `easyasc.a5` 会在导入 `stub_functions` 之后再导入 `stub_functions.micro`，因此有一批顶层名字会被 A5 的 micro helper 有意覆盖。

## 先看一个最重要的差异

同一个顶层名字，在 A2 和 A5 上不一定属于同一类 helper 家族。

```python
from easyasc.a2 import add   # vec Tensor helper
from easyasc.a5 import add   # micro Reg helper
```

所以看下面的对照表时，应该以“公开导入面”作为判断依据，而不是只看 `easyasc/stub_functions/` 里的原始文件名。

## 顶层同名，但 lowering 家族不同

这些名字同时存在于 `easyasc.a2` 和 `easyasc.a5`，但会走不同的 handler 家族。

| 顶层名字 | `easyasc.a2` 来源 | A2 生成符号 | `easyasc.a5` 来源 | A5 生成符号 | 说明 |
| --- | --- | --- | --- | --- | --- |
| `add`, `sub`, `mul`, `div`, `vmax`, `vmin`, `vand`, `vor` | `stub_functions.vec.binary` | `Add`, `Sub`, `Mul`, `Div`, `Max`, `Min`, `And`, `Or` | `stub_functions.micro.binary` | `MicroAPI::Add`, `MicroAPI::Sub`, `MicroAPI::Mul`, `MicroAPI::Div`, `MicroAPI::Max`, `MicroAPI::Min`, `MicroAPI::And`, `MicroAPI::Or` | A2 这一行是 vec Tensor 运算；A5 这一行是 micro Reg 运算。 |
| `exp`, `ln`, `abs`, `relu`, `sqrt`, `vnot` | `stub_functions.vec.unary` | `Exp`, `Ln`, `Abs`, `Relu`, `Sqrt`, `Not` | `stub_functions.micro.unary` | `MicroAPI::Exp`, `MicroAPI::Ln`, `MicroAPI::Abs`, `MicroAPI::Relu`, `MicroAPI::Sqrt`, `MicroAPI::Not` | 公开名字相同，但执行层不同。 |
| `adds`, `muls`, `vmaxs`, `vmins`, `lrelu`, `axpy` | `stub_functions.vec.unaryscalar` | `Adds`, `Muls`, `Maxs`, `Mins`, `LeakyRelu`, `Axpy` | `stub_functions.micro.unaryscalar` | `MicroAPI::Adds`, `MicroAPI::Muls`, `MicroAPI::Maxs`, `MicroAPI::Mins`, `MicroAPI::LeakyRelu`, `MicroAPI::Axpy` | A5 的这组标量算子工作在 `Reg + MaskReg` 上，而不是 vec Tensor tile。 |
| `cast` | `stub_functions.vec.cast` | `Cast<dst, src, false>(..., RoundMode::...)` | `stub_functions.micro.cast` | `MicroAPI::Cast<dst, src, config>(...)` | A5 micro cast 会带 `CastConfig` 模板参数。 |
| `compare`, `select` | `stub_functions.vec.compare`, `stub_functions.vec.select` | `Compare`, `CompareScalar`, `Select` | `stub_functions.micro.compare` | `MicroAPI::Compare`, `MicroAPI::CompareScalar`, `MicroAPI::Select` | `easyasc.a5.select` 来自 micro compare 模块，不是 vec select。 |
| `dup` | `stub_functions.vec.dupbrcb` | `Duplicate` | `stub_functions.micro.dup` | `MicroAPI::Duplicate` | 名字相同，但操作数类型不同。 |
| `cadd`, `cgadd`, `cpadd`, `cmax`, `cgmax`, `cmin`, `cgmin` | `stub_functions.vec.group` | `WholeReduceSum`, `BlockReduceSum`, `PairReduceSum`, `WholeReduceMax`, `BlockReduceMax`, `WholeReduceMin`, `BlockReduceMin` | `stub_functions.micro.group` | `MicroAPI::ReduceSum`, `MicroAPI::ReduceSumWithDataBlock`, `MicroAPI::PairReduceSum`, `MicroAPI::ReduceMax`, `MicroAPI::ReduceMaxWithDataBlock`, `MicroAPI::ReduceMin`, `MicroAPI::ReduceMinWithDataBlock` | 公开名字一致，但 reduction 所在层级不同。 |
| `gather` | `stub_functions.vec.gatherscatter` | `Gather` | `stub_functions.micro.datamove` | `MicroAPI::Gather` | A2 的 gather 使用 vec Tensor + offset；A5 的 gather 使用 Reg + index Reg。 |

## 顶层共享名字

这些 helper 在 A2 和 A5 顶层上都存在，并保持相同的顶层含义。

### 标量与形状辅助

| Helper | A2 生成形式 | A5 生成形式 | 说明 |
| --- | --- | --- | --- |
| `GetCubeNum` | `GetBlockNum()` | `GetBlockNum()` | 标量 helper。 |
| `GetCubeIdx` | `get_block_idx()` | `get_block_idx()` | 标量 helper。 |
| `GetVecNum` | `GetBlockNum() * 2` | `GetBlockNum() * 2` | 当前 lowering 假设每个 cube block 对应两个 vec sub-block。 |
| `GetVecIdx` | `GetBlockIdx()` | `GetBlockIdx()` | 标量 helper。 |
| `GetSubBlockIdx` | `get_subblockid()` | `get_subblockid()` | 标量 helper。 |
| `CeilDiv` | `CeilDiv(...)` | `CeilDiv(...)` | 直接 helper 调用。 |
| `Min`, `Max` | `Min(...)`, `Max(...)` | `Min(...)`, `Max(...)` | 直接 helper 调用。 |
| `Align16`, `Align32`, `Align64`, `Align128`, `Align256` | `Align16B`, `Align32B`, `Align64B`, `Align128B`, `Align256B` | 相同 | 这些 stub 名字会映射到带 `B` 后缀的字节对齐 helper。 |
| `scalar_sqrt` | `sqrt(...)` | `sqrt(...)` | 内联标量表达式。 |
| `var_mul`, `var_add`, `var_sub`, `var_div`, `var_mod` | 内联 `*`, `+`, `-`, `/`, `%` 表达式 | 相同 | 作为标量表达式 lowering，而不是 helper 调用。 |

### Cube 与片上数据搬运

| Helper | A2 生成符号 | A5 生成符号 | 说明 |
| --- | --- | --- | --- |
| `gm_to_l1_nd2nz` | float `L1` 目标时为 `GM2L1_ND2ZZ`，否则为 `GM2L1_ND2NZ` | `GM2L1_ND2NZ` | 这是主要的族间 cube datamove 名字差异。 |
| `set_constant_to_l1` | `InitConstValue` | `InitConstValue` | 常量填充 helper。 |
| `l1_to_l0` | float `L1`：`L0ZZ2ZZ`、`L0ZZ2NN`、`L0ZZ2NZ`、`L0ZZ2ZN`；<br>非 float `L1`：`L0NZ2ZZ`、`L0NZ2NN`、`L0NZ2NZ`、`L0NZ2ZN` | `L0NZ2NZ` 或 `L0NZ2ZN` | 在 A2 上，dtype 和 transpose 都会影响名字；在 A5 上，当前 handler 总是走 NZ-source 这一支。 |
| `mmad` | `MMAD` | `MMAD` | 共享的 cube compute helper。 |
| `l0c_to_gm_nz2nd` | `L0C2GM_NZ2ND` | `L0C2GM_NZ2ND` | 共享写回 helper。 |
| `l0c_to_l1` | `L0C2L1` | `L0C2L1` | 共享片上交接 helper。 |
| `l0c_to_ub` | `easyasc.a2` 不导出 | `L0C2UB_NZ2ND` | 仅从 `easyasc.a5` 顶层可用。 |

### 共享 vec 与 UB helper

| Helper | A2 生成符号 | A5 生成符号 | 说明 |
| --- | --- | --- | --- |
| `gm_to_ub_pad`, `ub_to_gm_pad`, `ub_to_ub` | `GM2UBPAD`, `UB2GMPAD`, `UB2UB` | 相同 | 共享 vec datamove helper。 |

## 仅 A2 顶层导出的 helper

这些名字由 `easyasc.a2` 导出，但不会从 `easyasc.a5` 顶层导出。

| A2-only helper | A2 生成符号 | 说明 |
| --- | --- | --- |
| `rec`, `rsqrt` | `Reciprocal`, `Rsqrt` | vec unary helper，但没有在 `easyasc.a5` 顶层重新导出。 |
| `brcb` | `Brcb` | vec broadcast helper，只在 A2 顶层公开。 |
| `scatter` | `Scatter` | A5 导出的是 micro `reg_to_ub_scatter`，而不是顶层 vec `scatter`。 |
| `compare_scalar` | `CompareScalar` | 在 A2 上作为独立顶层 helper 保留。 |
| `muladddst` | `MulAddDst` | 仅 A2 顶层有这个 helper。 |
| `sort32`, `mergesort4`, `mergesort_2seq` | `Sort32`, `MERGESORT4`, `MERGESORT2SEQ` | 这些 sort helper 没有从 `easyasc.a5` 顶层重导出。 |
| `set_mask`, `reset_mask` | `SetVectorMask<half, MaskMode::NORMAL>`, `ResetMask` | vec mask helper，只从 `easyasc.a2` 顶层导出。 |
| `set_cmpmask` | `SetCmpMask` | compare-mask helper，只从 `easyasc.a2` 顶层导出。 |

### 同步、原子与杂项 helper

| Helper | A2 生成形式 | A5 生成形式 | 说明 |
| --- | --- | --- | --- |
| `bar_m`, `bar_v`, `bar_mte3`, `bar_mte2`, `bar_mte1`, `bar_fix`, `bar_all` | `PipeBarrier<PIPE_M/V/MTE3/MTE2/MTE1/FIX/ALL>()` | 相同 | 这些公开包装最终都走一个 `barrier` 指令家族。 |
| `cube_ready`, `vec_ready`, `wait_cube`, `wait_vec`, `allcube_ready`, `allvec_ready`, `allcube_wait`, `allvec_wait` | `CUBE_READY`, `VEC_READY`, `WAIT_CUBE`, `WAIT_VEC`, `ALLCUBE_READY`, `ALLVEC_READY`, `ALLCUBE_WAIT`, `ALLVEC_WAIT` | 相同 | 跨核 flag helper。 |
| `setflag`, `waitflag` | `set_flag`, `wait_flag` | 相同 | 这是 pipe event 指令，不是 `SEvent` / `DEvent` 对象本身。 |
| `atomic_add`, `atomic_max`, `atomic_min` | `SetAtomicAdd<float>()`, `SetAtomicMax<float>()`, `SetAtomicMin<float>()` | 相同 | 对应 context-manager 退出时会生成 `SetAtomicNone()`。 |
| `reset_cache` | `pipe_ptr->Reset();` 和 `OccupyMMTE1Events();` | 相同 | 框架维护的 cache reset 前导。 |
| `clean_dcache` | `DataCacheCleanAndInvalid<...>` | 相同 | 会生成模板化的 cache-line helper。 |
| `split_workspace` | `shiftAddr<dtype>(workspace, ...)` 加 `SetGlobalBuffer(...)` | 相同 | 生成的是 GM workspace view，而不是单个 helper 调用。 |
| `reinterpret` | `ReinterpretCast<dst_dtype>()` | 相同 | 生成本地 tensor view。 |
| `kernel_print` | `printf(...)` | 相同 | 生成期调试打印。 |
| `kernel_dump_tensor` | `DumpTensor(...)` | 相同 | 生成期 dump hook。 |
| `inline` | 原样内联 C++ 代码 | 相同 | 没有额外 wrapper helper。 |
| `sim_print`, `sim_dump_tensor` | `easyasc.a2` 不导出 | 不生成代码 | 仅 simulator 使用，并由 `easyasc.a5` 顶层导出。 |

## 仅 A5 顶层导出的 helper

这些名字只存在于 `easyasc.a5` 顶层公开接口。

### Micro 寄存器与 Mask 家族

| A5-only helper | A5 生成符号 | 说明 |
| --- | --- | --- |
| `arange` | `MicroAPI::Arange` | A5-only micro helper。 |
| `vxor`, `prelu` | `MicroAPI::Xor`, `MicroAPI::Prelu` | A2 顶层不暴露的额外 micro binary helper。 |
| `log`, `log2`, `log10`, `neg`, `vcopy` | `MicroAPI::Log`, `MicroAPI::Log2`, `MicroAPI::Log10`, `MicroAPI::Neg`, `MicroAPI::Copy` | 额外的 micro unary helper。 |
| `shiftls`, `shiftrs` | `MicroAPI::ShiftLefts`, `MicroAPI::ShiftRights` | A5-only micro scalar helper。 |
| `deinterleave`, `interleave` | `MicroAPI::DeInterleave`, `MicroAPI::Interleave` | 寄存器 lane 重排 helper。 |
| `ub_to_l1_nd2nz`, `ub_to_l1_nz` | `UB2L1_ND2NZ`, `UB2L1_NZ` | 仅 A5 导出的 vec-to-L1 publish helper。 |
| `ub_to_reg`, `reg_to_ub` | `MicroAPI::DataCopy<..., MicroAPI::DataCopyMode::DATA_BLOCK_COPY>` | A5 micro datacopy 的基础配对。 |
| `ub_to_reg_continuous`, `reg_to_ub_continuous` | `MicroAPI::DataCopy<..., MicroAPI::LoadDist::...>` / `MicroAPI::DataCopy<..., MicroAPI::StoreDist::...>` | 具体分发模式由 distribution mode 决定。 |
| `reg_to_ub_downsample`, `reg_to_ub_pack4`, `reg_to_ub_single`, `ub_to_reg_single`, `ub_to_reg_upsample`, `ub_to_reg_downsample`, `ub_to_reg_unpack`, `ub_to_reg_unpack4`, `ub_to_reg_brcb` | 同属 `MicroAPI::DataCopy` 家族 | 这些 convenience wrapper 先选 `LoadDist` / `StoreDist`，再走同一套 codegen handler。 |
| `ub_to_reg_gather`, `reg_to_ub_scatter`, `gather_mask` | `MicroAPI::DataCopyGather`, `MicroAPI::DataCopyScatter`, `MicroAPI::GatherMask` | A5-only micro datamove helper。 |
| `mask_not`, `mask_and`, `mask_or`, `mask_xor`, `mask_mov`, `mask_interleave`, `mask_deinterleave`, `mask_sel` | `MicroAPI::MaskNot`, `MaskAnd`, `MaskOr`, `MaskXor`, `MaskMov`, `MaskInterleave`, `MaskDeInterleave`, `MaskSel` | Mask 寄存器运算。 |
| `move_mask_spr`, `update_mask` | `MicroAPI::MoveMask`, `MicroAPI::UpdateMask` | 返回值会被赋给 `MaskReg`。 |
| `mask_pack`, `mask_unpack` | `MicroAPI::MaskPack<...>`, `MicroAPI::MaskUnPack<...>` | mode 编码在模板参数里。 |
| `LoadDist`, `LoadDistValue`, `StoreDist`, `StoreDistValue` | 自身不生成代码 | 这是 A5 micro datamove wrapper 使用的配置枚举。 |

## 需要核对或扩展时，优先看这些源文件

如果你要继续补表或确认细节，优先查这些文件：

- 公开入口：`easyasc/a2.py`、`easyasc/a5.py`
- handler 注册：`easyasc/parser/asc_handlers/__init__.py`
- 标量 helper：`easyasc/parser/asc_handlers/math_ops.py`
- cube helper：`easyasc/parser/asc_handlers/cube.py`
- vec helper：`easyasc/parser/asc_handlers/vec_binary.py`、`vec_unary.py`、`vec_unary_scalar.py`、`vec_group.py`、`vec_dupbrcb.py`、`vec_gatherscatter.py`、`vec_datamove.py`、`vec_cast.py`、`vec_compare.py`、`vec_select.py`、`vec_sort.py`、`vec_mask.py`
- 同步与杂项：`easyasc/parser/asc_handlers/pipe_ops.py`、`atomic.py`、`misc.py`、`core.py`、`reinterpret.py`
- A5 micro helper：`easyasc/parser/asc_handlers/vec_micro_ops.py`
