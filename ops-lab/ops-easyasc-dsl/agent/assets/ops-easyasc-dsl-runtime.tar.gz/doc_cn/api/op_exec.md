# OpExec

本页文档说明一个在概念上由 `easyasc.a2` 与 `easyasc.a5` 共同使用的公开运行时入口辅助。

`shape_bindings` 属于 `OpExec(...)` 的调用时 API。它只在 Python 运行时侧生效，而且发生在 kernel 主体执行之前。它的作用是告诉 `OpExec`：当仅凭运行时数值去匹配形状会产生歧义时，每个输入/输出张量维度应该复用哪个运行时标量，来充当对应的符号形状变量。

## 1. `OpExec`

### `OpExec(op_func, out_dir="", cann_path=None, custom_op_path=None, profile=False, gen_only=False, simulator=False, skip_compile=False, trace=None)`

- 作用：把运行时输入绑定到一个 kernel 上，然后根据配置走模拟器路径或生成路径。
- 参数：
  - `op_func`：由 `@kernel` 创建出来的 kernel wrapper
  - `out_dir`：生成模式下使用的输出目录前缀
  - `cann_path`：可选的工具链路径覆盖
  - `custom_op_path`：可选的自定义算子模板路径
  - `profile`：启用偏 profile 的生成行为
  - `gen_only`：只生成产物，不运行生成路径
  - `simulator`：开启模拟器执行；当前 `True`、`"v2"`、`"legacy"` 等真值写法都会通过 `KernelBase.run_sim()` 路由到 `easyasc/simulator_v2/` 下的当前 V2 运行时
  - `skip_compile`：在生成模式下跳过 `b.sh`
  - `trace`：模拟器 trace 输出路径
- 运行时调用形式：

```python
OpExec(...)(*tensor_args, *scalar_args, shape_bindings=...)
```

- 限制：
  - `op_func` 必须是 `KernelBase` 实例
  - 运行时参数顺序必须严格遵守：先传所有 `torch.Tensor`，之后才是标量 `int` / `float`
  - `trace` 只允许在 `simulator=True` 时使用
  - 如果多个标量值重复，可能需要显式给出 `shape_bindings`
- 返回值：
  - 在模拟器模式下，返回 `torch.Tensor` 输出
  - 在生成模式下，返回值遵循 `OpExec` 生成路径的正常运行时契约
- 示例：

```python
z_out = OpExec(my_kernel, simulator=True)(
    x,
    y,
    z,
    M,
    N,
    K,
    shape_bindings={0: [0, 2], 1: [1, 2], 2: [0, 1]},
)
```

## 2. `shape_bindings`

### 作用

`shape_bindings` 控制的是：`OpExec` 如何根据运行时 `torch.Tensor` 形状和运行时标量参数，重建带符号语义的 `GMTensor` 形状。

例如当你这样调用：

```python
OpExec(my_kernel)(x, y, z, M, N, K, shape_bindings=...)
```

`OpExec` 需要构造出类似下面这样的 kernel 侧对象：

```python
GMTensor(dtype, [M, K])
GMTensor(dtype, [N, K])
GMTensor(dtype, [M, N])
```

但在运行时，它看到的只有一些具体数值，比如：

```python
x.shape == (5, 5)
y.shape == (9, 5)
z.shape == (5, 9)
M == 5
N == 9
K == 5
```

在这种情况下，一个值为 `5` 的张量维度，既可能表示 `M`，也可能表示 `K`。`shape_bindings` 就是用来消除这种歧义的。

### 类型

```python
shape_bindings: Dict[int, Sequence[Optional[int]]]
```

### 索引含义

- 字典 key：张量参数索引，只在 `torch.Tensor` 参数内部计数
- 序列中的元素：标量参数索引，只在所有张量之后出现的标量参数（`int` / `float`）内部计数
- `None`：不强制把这个张量维度绑定到某个特定标量，让 `OpExec` 自己推断

对于：

```python
OpExec(my_kernel)(x, y, z, M, N, K, shape_bindings=...)
```

索引关系如下：

- 张量 `0` -> `x`
- 张量 `1` -> `y`
- 张量 `2` -> `z`
- 标量 `0` -> `M`
- 标量 `1` -> `N`
- 标量 `2` -> `K`

因此：

```python
shape_bindings = {
    0: [0, 2],  # x.shape == [M, K]
    1: [1, 2],  # y.shape == [N, K]
    2: [0, 1],  # z.shape == [M, N]
}
```

表示：

- 把 `x.shape[0]` 绑定到标量 `M`
- 把 `x.shape[1]` 绑定到标量 `K`
- 把 `y.shape[0]` 绑定到标量 `N`
- 把 `y.shape[1]` 绑定到标量 `K`
- 把 `z.shape[0]` 绑定到标量 `M`
- 把 `z.shape[1]` 绑定到标量 `N`

### 精确的运行时行为

对于每个张量维度，`OpExec` 都会按下面的规则处理。

#### 情况 1：显式给出了 binding

如果 `shape_bindings[tensor_idx][dim_idx]` 是一个整数 `scalar_idx`，那么 `OpExec` 会：

1. 检查 `scalar_idx` 是否在合法范围内
2. 读取对应的运行时标量
3. 检查 `scalar_value == tensor.shape[dim_idx]`
4. 如果相等，就在构造出来的 `GMTensor` 形状中复用这个标量 `Var`
5. 如果不相等，就抛出错误

例如：

```python
x.shape == (5, 7)
M == 5
K == 3

shape_bindings = {
    0: [0, 2],  # tries to bind x.shape[1] to K
}
```

这会失败，因为 `x.shape[1] == 7`，而 `K == 3`。

#### 情况 2：没有显式 binding，而且没有任何标量值匹配

如果没有任何标量值等于这个张量维度，`OpExec` 会把它保留成普通整数字面量。

例如：

```python
x.shape == (32, 48)
M == 32
K == 64
```

这时 `x.shape[1] == 48` 和任何标量都不匹配，所以构造出来的形状会等价于：

```python
[M, 48]
```

#### 情况 3：没有显式 binding，而且恰好只有一个标量值匹配

如果恰好只有一个标量值与该维度相等，`OpExec` 会自动把这个维度绑定到对应标量。

例如：

```python
x.shape == (32, 64)
M == 32
K == 64
```

那么 `x` 会被推断为：

```python
[M, K]
```

这种情况不需要额外写 `shape_bindings`。

#### 情况 4：没有显式 binding，而且有多个标量值都匹配

如果有不止一个标量值与该维度相同，`OpExec` 不会猜，而是直接抛出歧义错误。

例如：

```python
x.shape == (5, 5)
y.shape == (9, 5)
z.shape == (5, 9)
M == 5
N == 9
K == 5
```

这里所有值为 `5` 的维度都存在歧义，因为 `M` 和 `K` 都等于 `5`。这时必须显式绑定这些有歧义的维度。

### 它为什么存在

kernel 主体里通常会在这些地方使用 `M`、`N`、`K` 这样的符号标量变量：

- 张量声明
- 循环边界
- tile 计算
- tail 处理
- 地址计算

因此，`OpExec` 在构建 `GMTensor` 形状时，会尽量复用运行时标量 `Var`。这样才能保留张量维度与标量参数之间的符号关系。`shape_bindings` 存在的原因，就是单纯依赖运行时数值相等有时无法恢复这种关系。

### 什么时候需要它

当下面两个条件同时成立时，就应该使用 `shape_bindings`：

1. kernel 标量参数里有一部分确实表示张量维度
2. 其中两个或更多标量在运行时取值相同，导致某个张量维度可能匹配多个标量

典型场景：

```python
M = 128
N = 256
K = 128
```

这时，一个值为 `128` 的维度，既可能是 `M`，也可能是 `K`。

### 什么时候不需要

通常在下面这些情况下，不需要 `shape_bindings`：

- 每个张量维度至多只会匹配一个标量值
- 某个维度根本不匹配任何标量，可以直接保留为字面量
- kernel 本身没有显式的标量形状参数

一个没有歧义的例子：

```python
M = 64
N = 128
K = 256
x.shape == (64, 256)
y.shape == (128, 256)
z.shape == (64, 128)
```

每个维度值都只对应唯一一个标量，因此 `OpExec` 可以自动推断出符号映射。

### 可以只写部分 binding

你不必把所有张量维度都写出来。只需要绑定那些原本会产生歧义的维度即可。

例如：

```python
shape_bindings = {
    0: [0, 2],      # fully bind x
    2: [0, None],   # bind z.shape[0], infer z.shape[1]
}
```

只要那些没有显式绑定的维度在运行时仍然不歧义，这种写法就是合法的。

### 校验规则

`OpExec` 会严格校验 `shape_bindings`：

- `shape_bindings` 必须是 `dict`
- 每个 value 必须是 `list` 或 `tuple`
- binding 的 rank 必须和对应张量 rank 一致
- 每个元素都必须是 `int` 或 `None`
- 显式给出的标量索引必须在合法范围内
- 显式 binding 的值必须和真实运行时张量维度相等

### 常见错误

#### 歧义错误

如果某个维度能匹配多个标量值，而你又没有显式绑定，`OpExec` 会抛出：

```python
ValueError: Ambiguous scalar match for tensor #... dim #...
```

这表示运行时无法判断这个维度到底应当属于哪个标量变量。

#### mismatch 错误

如果你把某个维度显式绑定到了错误的标量索引上，`OpExec` 会抛出：

```python
ValueError: shape_bindings[...][...] mismatches tensor dim value
```

这表示你声明的符号绑定关系和真实运行时形状不一致。

### 完整示例

kernel 签名：

```python
@kernel()
def my_kernel(x: GMTensor, y: GMTensor, z: GMTensor, m: Var, n: Var, k: Var):
    return z
```

运行时调用：

```python
m = 5
n = 9
k = 5

x = torch.randn((m, k), dtype=torch.float16)
y = torch.randn((n, k), dtype=torch.float16)
z = torch.randn((m, n), dtype=torch.float16)

out = OpExec(my_kernel, simulator=True)(
    x,
    y,
    z,
    m,
    n,
    k,
    shape_bindings={
        0: [0, 2],
        1: [1, 2],
        2: [0, 1],
    },
)
```

如果没有 `shape_bindings`，所有值为 `5` 的维度都会产生歧义。

### 一条实用经验

如果你的 kernel 带有 `M`、`N`、`K`、`B`、`H`、`S` 这类显式标量形状参数，而且其中两个值在运行时可能相等，那么就在 `OpExec(...)` 的调用点显式加上 `shape_bindings`。它成本很低，也能避免让形状推导依赖“碰巧唯一”的运行时数值。
