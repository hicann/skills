# 装饰器

本页文档说明 `easyasc` 公开接口中共享的装饰器。

这些装饰器定义了框架最主要的几种编写上下文：

- kernel 入口点
- 可复用的辅助函数
- 带有 auto-sync 标记的区域
- 可复用的 micro module

## 1. `kernel()`

- 作用：把一个 Python 函数包装成 kernel 入口点，并返回一个以 `KernelBase` 为后端的可调用对象。
- 参数：
  - 正常用法下不需要额外装饰器参数；通常写成 `@kernel()`
- 限制：
  - 被装饰对象必须是可调用的
  - 当这个 kernel 通过框架调用时，它绑定后的参数必须能解析成 `GMTensor` 和 `Var`
  - kernel 代码应当写在被装饰函数体内部，而不是写在外面
- 示例：

```python
from easyasc.a5 import *


@kernel()
def copy_kernel(x: GMTensor, y: GMTensor, M: Var, N: Var):
    ub = Tensor(DT.float, [M, N], Position.UB)
    ub <<= x[:, :]
    y[:, :] <<= ub
    return y
```

## 2. `func()`

- 作用：应用和 `@kernel` 相同的 Python-to-DSL 变换，但保留为辅助函数，而不是 kernel 入口点。
- 参数：
  - 正常用法下不需要额外装饰器参数；通常写成 `@func()`
- 限制：
  - 适合在激活的 kernel 或 micro 上下文中编写可复用的“发射指令”辅助函数
  - 它不会创建 kernel wrapper，因此不能作为独立 kernel 执行
- 示例：

```python
@func()
def zero_l1(buf: Tensor):
    set_constant_to_l1(buf, 0.0)
```

## 3. `auto_sync()`

- 作用：为某个区域或辅助函数调用打上标记，使 parser 在后续可以插入受支持的同侧同步事件。
- 参数：
  - 正常用法下不需要额外装饰器参数；常见形式是 `@auto_sync()` 和 `with auto_sync():`
- 限制：
  - 只能在 kernel 代码中使用
  - 它本身不能解决 cube-to-vec 或 vec-to-cube 的 ownership 交接
  - 当前只有 `asc_autosync.py` 中硬编码的 pipe 对会被处理
- 示例：

```python
with auto_sync():
    l1x <<= x[:, :]
    matmul(l0c, l1x, l1y)
```

## 4. `vf()`

- 作用：把一个函数包装成可复用的 micro module。
- 参数：
  - 没有额外装饰器参数；写法就是 `@vf()`
- 限制：
  - 只在 `easyasc.a5` 中提供
  - micro 函数只接受 UB `Tensor` 输入，以及类似 `Var` 的标量输入
  - micro 代码使用的是 `Reg`、`RegList` 和 `MaskReg`，而不是 cube 侧的 `Tensor` 数学
- 示例：

```python
@vf()
def add_one(src: Tensor, dst: Tensor):
    r = Reg(DT.float)
    r <<= src[0]
    r <<= r + 1.0
    dst[0] <<= r
```
