# A5 Micro Cast

本页文档说明 `easyasc.a5` 导出的 micro 侧 cast 辅助能力。

这里描述的行为基于以下实现：

- `easyasc/stub_functions/micro/cast.py` 中公开给用户使用的接口
- `easyasc/utils/reg.py` 里 `Reg` 提供的便捷方法
- `easyasc/simulator/micro/runtime/ops_vector.py` 中当前的模拟器实现
- `historical testcases/test_sim_micro_cast.py` (removed from this skill bundle) 中围绕 cast 的模拟器测试

本页所有 cast API 都有这些共同点：

- 要求处在激活的 `@vf` 上下文中
- 操作对象是 `Reg` 和 `MaskReg`
- 对于被 mask 屏蔽掉的 lane，或者没有被填充到的目标 lane，采用清零语义

## 1. Cast 基础构件

### `RoundModeType`

- 作用：表示一个具体的 micro cast 舍入模式值。
- 常见用法：
  - 一般不需要手动构造它
  - 而是直接传 `RoundMode.*` 中预定义好的值

这个类本身很小，但它仍然重要，因为 `CastConfig` 会校验 `round_mode` 是否为 `RoundModeType`。

重要行为：

- `str(mode)` 会返回后端 token 名，例如 `CAST_RINT`
- `repr(mode)` 会返回 `RoundModeType('...')`
- 相等比较按模式名进行
- 如果拿它和非 `RoundModeType` 对象比较，会抛出 `TypeError`

示例：

```python
str(RoundMode.TO_EVEN)        # "CAST_RINT"
repr(RoundMode.FLOOR)         # "RoundModeType('CAST_FLOOR')"
RoundMode.CEIL == RoundMode.CEIL
```

实践规则：

- 使用预定义的 `RoundMode.*` 成员
- 不要把 `"CAST_RINT"` 这样的原始字符串直接传给 `CastConfig`

### `RoundMode`

- 作用：为预定义的 micro cast 舍入模式提供一个类似枚举的命名空间。
- 值类型：
  - 每个成员都是一个 `RoundModeType`

可用成员如下：

| 公开名称 | 后端 token | 期望含义 |
| --- | --- | --- |
| `RoundMode.NONE` | `CAST_NONE` | 不指定额外舍入策略 |
| `RoundMode.TO_EVEN` | `CAST_RINT` | 四舍六入五成双 |
| `RoundMode.AWAY_FROM_ZERO` | `CAST_ROUND` | 朝远离零方向取整 |
| `RoundMode.FLOOR` | `CAST_FLOOR` | 向负无穷方向取整 |
| `RoundMode.CEIL` | `CAST_CEIL` | 向正无穷方向取整 |
| `RoundMode.TRUNC` | `CAST_TRUNC` | 朝零方向截断 |

这里说的“期望含义”是指：

- 这些模式会作为语义选项告诉后端 C++ trait
- 当 cast 需要丢弃精度或小数信息时，它们最重要
- 常见场景包括 `float -> half`、`float -> int8`、`float -> e4m3`、`float -> e5m2`

什么时候 round mode 往往几乎看不出效果：

- 同宽 cast，例如 `half -> half`
- 源值本来就能被目标类型精确表示的 cast
- 当前 Python 模拟器，因为它还不会把每种 round mode 分开建模

当前模拟器行为：

- 模拟器会在 `CastConfig` 中保留选中的 `RoundMode` 对象
- 但模拟器目前不会针对 `TO_EVEN`、`FLOOR`、`TRUNC` 等模式分别走不同分支
- 目前数值转换主要依赖 `torch.Tensor.to(dtype)` 加上框架侧的饱和逻辑

当前代码生成行为：

- 选中的模式会以 `RoundMode::{token}` 的形式写入生成出的 trait
- 例如，`RoundMode.TO_EVEN` 会变成 `RoundMode::CAST_RINT`

示例：

```python
cfg_floor = CastConfig(
    round_mode=RoundMode.FLOOR,
    reg_layout=RegLayout.ZERO,
    name="cfg_floor",
)
```

再例如：

```python
cfg_trunc = CastConfig(
    round_mode=RoundMode.TRUNC,
    reg_layout=RegLayout.ZERO,
    name="cfg_trunc",
)
```

### `CastConfig(round_mode=RoundMode.TO_EVEN, reg_layout=RegLayout.ZERO, saturate=False, name="")`

- 作用：保存一次 micro cast 应使用的策略。
- 构造参数：
  - `round_mode`：请求的 `RoundMode`
  - `reg_layout`：当源和目标元素宽度不同时，应该从哪个逻辑槽位读取或写入
  - `saturate`：溢出时是否做钳位，而不是采用默认 dtype 转换行为
  - `name`：生成 C++ 时发射出去的符号名

每个参数的含义：

- `round_mode`：
  - 必须是 `RoundModeType`
  - 指定附着到生成 cast trait 上的 `RoundMode.*` 策略
  - 会作为 `MicroAPI::CastTrait` 的一部分进入代码生成
  - 当前模拟器说明：
    - 模拟器不会单独建模每种 round mode
    - 它目前依赖 `torch.Tensor.to(dtype)` 的转换行为
- `reg_layout`：
  - 只有当 `src.dtype.size != dst.dtype.size` 时才有意义
  - 用来决定每个 cast ratio 分组中采用哪个 slot
- `saturate`：
  - 当为 `False` 时，模拟器行为跟随 `torch` 的 dtype 转换
  - 当为 `True` 时，模拟器会在转换前先做钳位
- `name`：
  - 到 `cast()` 发射指令时必须非空
  - 如果你在激活的 micro 内部构造 `CastConfig`，它会自动注册到当前 micro 中，并自动加上前缀

自动注册行为：

- 当在激活的 `@vf` 内部创建 `CastConfig` 时，它会被追加到 micro module 的 `cast_cfg_list`
- 代码生成时，这个列表会变成生成 C++ 中的 `MicroAPI::CastTrait` 定义
- 这也是为什么 config 名字需要稳定且唯一

示例：

```python
cfg_zero = CastConfig(
    round_mode=RoundMode.TO_EVEN,
    reg_layout=RegLayout.ZERO,
    saturate=False,
    name="cfg_zero",
)
```

默认配置行为：

- `cast(..., config=None)` 会向当前 micro module 请求一个默认配置
- 在当前实现中，大多数目标类型会使用默认的 `RoundMode.TO_EVEN`
- 当前的特殊情况是 `Datatype.hif8`，它默认使用 `RoundMode.AWAY_FROM_ZERO`

这里特别提到 `Datatype.hif8`，是因为：

- micro module 内部维护了两个缓存的默认配置
- 通用默认值是 `RoundMode.TO_EVEN`
- `hif8` 会单独使用一个以 `RoundMode.AWAY_FROM_ZERO` 创建的缓存配置
- 这会影响 `cast(..., config=None)` 在这些目标类型上的实际含义

### `RegLayout`

- 作用：描述位宽转换分组中哪一个 slot 处于激活状态。
- 可选值：
  - `RegLayout.ZERO`
  - `RegLayout.ONE`
  - `RegLayout.TWO`
  - `RegLayout.THREE`

`RegLayout` 存在的原因：

- Micro 寄存器总是有固定的字节预算
- 当源和目标元素大小不同时，一个源 lane 并不会和一个目标 lane 一一对应
- 所以 cast 实际上是在按 ratio 大小的分组工作
- `RegLayout` 用来选择每个分组里要读或要写的那个 slot

当前合法 slot 规则：

| Cast ratio | 含义 | 合法 layout |
| --- | --- | --- |
| `1` | 同宽 cast | 目前所有 layout 都接受，但会被忽略 |
| `2` | 16 位 <-> 32 位，或 8 位 <-> 16 位 | `ZERO`、`ONE` |
| `4` | 8 位 <-> 32 位 | `ZERO`、`ONE`、`TWO`、`THREE` |

如果 layout 对当前位宽 ratio 来说越界了，模拟器会报错。

示例：

```python
cfg_one = CastConfig(reg_layout=RegLayout.ONE, name="cfg_one")
```

## 2. 核心 API

### `cast(dst, src, config=None, mask=None)`

- 作用：把一个寄存器 cast 到另一个寄存器。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 `Reg`
  - `config`：可选的 `CastConfig`
  - `mask`：可选的 `MaskReg`

一般行为：

- `dst` 总是会先被清零
- 源寄存器会先做快照，所以像 `cast(reg, reg, cfg, mask)` 这样的别名写法仍然有稳定语义
- 目标 mask 会按照 `dst.dtype` 解析
- 被 mask 掉的 lane 保持为零

当前模拟器支持的 dtype：

- `half`
- `float`
- `bfloat16`
- `int8`
- `uint8`
- `int32`
- `float8_e4m3_t`
- `float8_e5m2_t`

当前模拟器注意点：

- `round_mode` 会保留在 `CastConfig` 里，也会进入代码生成，但当前还不会在模拟阶段分别实现
- 某些不受支持的 dtype 组合可能会先通过 stub 层，然后在模拟器里失败

### 2.1 同宽 Cast

这指的是：

- `src.dtype.size == dst.dtype.size`

寻址规则：

- 对每个激活的 lane `i`：
  - `dst[i] = cast(src[i])`

说明：

- 在这种情况下，`reg_layout` 不会改变寻址映射
- 因为不需要做 slot 查找，所以同宽 cast 目前接受所有 `RegLayout` 值
- 被 mask 掉的 lane 会保持为零

示例：

```text
src  = [a0, a1, a2, a3, a4, a5, ...]
mask = active at lanes [0..7]
dst  = [cast(a0), cast(a1), ..., cast(a7), 0, 0, ...]
```

这和模拟器测试里的行为一致：即使在 `half -> half` 的同宽 cast 上选择 `RegLayout.THREE`，它仍然会按 1:1 复制激活 lane，并把其余 lane 清零。

### 2.2 窄转宽 Cast

这指的是：

- `src.dtype.size < dst.dtype.size`

设：

- `ratio = dst.dtype.size / src.dtype.size`
- `slot = reg_layout`

寻址规则：

- 对每个激活的目标 lane `i`：
  - `src_index = i * ratio + slot`
  - `dst[i] = cast(src[src_index])`

理解方式：

- 每个宽目标 lane 会从源寄存器中一个 ratio 大小的分组里挑一个元素
- `RegLayout.ZERO` 选每组的第一个元素
- `RegLayout.ONE` 选第二个，以此类推

示例：`half -> float`（`ratio = 2`）

```text
src = [h0, h1, h2, h3, h4, h5, ...]

RegLayout.ZERO:
dst = [float(h0), float(h2), float(h4), ...]

RegLayout.ONE:
dst = [float(h1), float(h3), float(h5), ...]
```

示例：`int8 -> float`（`ratio = 4`）

```text
src group 0 = [b0, b1, b2, b3]
src group 1 = [b4, b5, b6, b7]

RegLayout.ZERO -> [float(b0), float(b4), ...]
RegLayout.ONE  -> [float(b1), float(b5), ...]
RegLayout.TWO  -> [float(b2), float(b6), ...]
RegLayout.THREE-> [float(b3), float(b7), ...]
```

### 2.3 宽转窄 Cast

这指的是：

- `src.dtype.size > dst.dtype.size`

设：

- `ratio = src.dtype.size / dst.dtype.size`
- `slot = reg_layout`

寻址规则：

- 源 lane 下标为 `src_index = dst_index // ratio`
- 只有满足 `dst_index % ratio == slot` 的目标 lane 会被写入
- 其他目标 lane 都保持为零

理解方式：

- 一个宽源 lane 会扇出到一个 ratio 大小的目标分组
- `RegLayout` 决定这个目标分组里哪一个 slot 接收转换后的值

示例：`float -> half`（`ratio = 2`）

```text
src = [f0, f1, f2, f3, ...]

RegLayout.ZERO:
dst = [half(f0), 0, half(f1), 0, half(f2), 0, ...]

RegLayout.ONE:
dst = [0, half(f0), 0, half(f1), 0, half(f2), ...]
```

示例：`float -> int8`（`ratio = 4`）

```text
RegLayout.ZERO:
dst[0], dst[4], dst[8], ... = cast(src[0]), cast(src[1]), cast(src[2]), ...
all other lanes remain 0
```

这正是为什么 `float -> fp8` 或 `float -> int8` cast 之后，通常还会接一个 `pack4()`：cast 只会在每 4 个 lane 中填一个 slot，而 `pack4()` 会把这些 lane 压紧后再写回 UB。

### 2.4 饱和行为

当 `config.saturate == False` 时：

- 模拟器采用 `torch.Tensor.to(dst_dtype)` 的语义
- 因此溢出、NaN 和舍入行为都跟随 `torch`，而不是自定义硬件模型

当 `config.saturate == True` 时：

- 对浮点目标：
  - 有限值会先钳位到该 dtype 的有限值范围
  - `inf`、`-inf` 和 `nan` 留给最终的浮点 cast 逻辑处理
- 对整数目标：
  - 有限值会先钳位到整数范围
  - `+inf` 会变成该整数类型的最大值
  - `-inf` 会变成该整数类型的最小值
  - `nan` 会变成 `0`

示例：带饱和的 `float -> int8`

```text
src = [-300.0, -129.0, -128.0, 127.0, 128.0, inf, -inf, nan]

after saturation:
[-128, -128, -128, 127, 127, 127, -128, 0]
```

### 2.5 Mask 行为

对于 `cast()`：

- mask 是按目标 lane 解析的
- 不会做 `C0` 扩展
- 没有被选中的目标 lane 保持为零

示例：

```text
mask = VL8
dst[0:8]   = converted values
dst[8:...] = 0
```

### 2.6 直接示例

float 到 half，两个不同 layout：

```python
src_reg = Reg(DT.float)
dst_zero = Reg(DT.half)
dst_one = Reg(DT.half)
mask = MaskReg(DT.half)

cfg_zero = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")
cfg_one = CastConfig(reg_layout=RegLayout.ONE, name="cfg_one")

cast(dst_zero, src_reg, cfg_zero, mask)
cast(dst_one, src_reg, cfg_one, mask)
```

half 到 float：

```python
src_reg = Reg(DT.half)
dst_reg = Reg(DT.float)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")
cast(dst_reg, src_reg, cfg)
```

float 到 fp8，并打包后写回 UB：

```python
src_reg = Reg(DT.float)
dst_fp8 = Reg(DT.e5m2)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")

cast(dst_fp8, src_reg, cfg)
dst_ub <<= dst_fp8.pack4()
```

限制：

- `dst` 和 `src` 都必须是 `Reg`
- `config` 在默认解析完成后必须是 `CastConfig`
- `mask` 必须是 `MaskReg`
- 选择的 `RegLayout` 必须对当前位宽 ratio 合法
- 当前模拟器只支持前面列出的那些 dtype

## 3. `Reg` 便捷方法

### `Reg.cast(cfg=None)`

- 作用：构造一个 `RegOP` cast 节点，输出仍保持源寄存器的逻辑 dtype。
- 常见用途：
  - 显式套用某个 cast config，同时保持寄存器 dtype 不变
  - 先构造一个 cast 节点，稍后通过赋值发射出去

重要细节：

- `Reg.cast()` 不会指定新的输出 dtype
- 所以生成出来的 `RegOP` 会保持源 dtype
- 如果你希望明确得到一个新 dtype，更适合用 `Reg.astype(...)`

示例：

```python
src = Reg(DT.half)
dst = Reg(DT.half)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg")
dst <<= src.cast(cfg)
```

### `Reg.astype(dtype, cfg=None)`

- 作用：构造一个带显式输出 dtype 的 `RegOP` cast 节点。
- 参数：
  - `dtype`：目标 `DT.*` 值
  - `cfg`：可选的 `CastConfig`

写 micro 代码时，这通常是最实用的便捷形式，
因为它同时把下面两件事表达出来了：

- 目标 dtype
- cast 策略

示例：

```python
r_h = Reg(DT.half)
r_f = Reg(DT.float)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")

r_f <<= r_h.astype(DT.float, cfg)
```

### `Reg.pack4()`

- 作用：构造一个使用 `StoreDist.PACK4` 进行存储的 `RegOP`。
- 它为什么会出现在 cast 文档里：
  - 当做 ratio 为 `4` 的宽转窄 cast 时，每 4 个 lane 里只有 1 个 lane 真正带值
  - `pack4()` 会把 `0, 4, 8, ...` 这些 lane 压成连续的 UB 输出流

典型的 fp8 工作流：

1. 用 `RegLayout.ZERO` 先做 `float -> e5m2` 或 `float -> e4m3`
2. cast 会把转换后的值放在寄存器的 `0, 4, 8, ...` 这些 lane 上
3. 写回 UB 时再用 `pack4()` 把这些 lane 压紧

示例：

```python
src = Reg(DT.float)
dst = Reg(DT.e5m2)
cfg = CastConfig(reg_layout=RegLayout.ZERO, name="cfg_zero")

cast(dst, src, cfg)
packed_ub <<= dst.pack4()
```

关于 `PACK4` 存储的精确定义，请参见 [a5_micro_data_movement.md](a5_micro_data_movement.md)。

## 4. 常用理解方式

调试 cast 时，可以按这个检查顺序来：

1. 比较 `src.dtype.size` 和 `dst.dtype.size`
2. 算出位宽 ratio
3. 检查选定的 `RegLayout` 对这个 ratio 是否合法
4. 判断当前 cast 属于哪一类：
   - 从每个源分组里选一个 lane（`narrow -> wide`）
   - 或者在每个目标分组里填一个 slot（`wide -> narrow`）
5. 记住，被 mask 掉的 lane 和没有被填到的目标 lane 都会变成零
6. 如果溢出有影响，检查是否需要 `saturate=True`
7. 如果在意模拟器中的舍入行为，要记住当前实现跟随 `torch`，
   而不是单独实现每种 round mode
