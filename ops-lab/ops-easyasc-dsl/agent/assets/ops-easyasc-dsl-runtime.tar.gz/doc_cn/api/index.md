# 详细 API 参考

这个目录包含 `easyasc` 公开接口的详细 API 参考。

本参考的范围包括：

- `easyasc.a2` 导出的符号
- `easyasc.a5` 导出的符号
- 这两个模块希望用户直接接触的主要公开辅助类

不在范围内的内容包括：

- 名字以下划线 `_` 开头的内部辅助对象
- 不属于公开接口、只供 parser / simulator / codegen 内部使用的实现细节

## 先看这一节

同一个函数名，在 `a2` 和 `a5` 里可能表示完全不同的东西。

例如：

- `easyasc.a2.add`：作用于 `Tensor` 的 UB 向量加法
- `easyasc.a5.add`：作用于 `Reg` 的 micro 寄存器加法
- `easyasc.a2.abs`：UB 向量单目操作
- `easyasc.a5.abs`：micro 寄存器单目操作
- `easyasc.a2.compare`：把结果写到 UB mask tensor 的向量 compare
- `easyasc.a5.compare`：把结果写到 `MaskReg` 的 micro compare

因此，阅读下面这些页面时，一定要始终记住当前导入的是哪一套接口。

## 文件地图

- [装饰器](decorators.md)
  - `kernel`、`func`、`auto_sync`、`vf`
- [流程控制](flow_control.md)
  - `range`、`unroll`、`break_`、`continue_`、`If`、`Elif`、`Else`
  - 原生 Python `if/elif/else` 与 `break` / `continue` 的改写说明
- [OpExec](op_exec.md)
  - `OpExec`
- [Shortcut](shortcuts.md)
  - `matmul`
  - `maximum` 和 `minimum`
- [共享标量辅助函数](scalars.md)
  - `GetCubeIdx`、`GetVecNum` 这类 worker 查询辅助
  - `CeilDiv`、`Align128`、`Min`、`Max` 这类算术与对齐辅助
- [数据类型](datatype.md)
  - `DT`、`Datatype`、`DataTypeValue`
  - 预定义 dtype 成员、`.size`、`.C0` 以及单例使用规则
- [存储位置](position.md)
  - `Position` 和 `PositionType`
  - 本地内存域、`.cpp` 映射，以及单例使用规则
- [Pipe](pipe.md)
  - `Pipe` 和 `PipeType`
  - 本地执行 pipe、`S` / `ALL`，以及同步相关使用规则
- [Var](var.md)
  - `Var`
  - 标量算术、比较 `Expr`，以及标量 IO 辅助
- [Tensor 与 Buffer 类型](tensor_buffer.md)
  - `Tensor`、`GMTensor`、`DBuff`、`TBuff`
  - 视图语义、赋值分发、切片，以及槽位缓冲行为
- [寄存器与掩码类型](register.md)
  - `Reg`、`RegList`、`MaskReg`
  - `MaskType` 和 `MaskTypeValue`
  - builder 方法、代理语义，以及 mask 附着规则
- [同步](synchronize.md)
  - `CvMutex`、`VcMutex`、原始跨侧/全核同步操作、`setflag` / `waitflag`、`SEvent`、`DEvent`
  - 跨侧 token 流、collective wait、本地 flag 行为与本地事件行为
- [Barrier](barrier.md)
  - `barrier(pipe)` 和 `bar_*` 辅助
  - 单 pipe 顺序约束与 `Pipe.ALL` drain 行为之间的区别
- [原子上下文管理器](atomic.md)
  - `atomic_add`、`atomic_max`、`atomic_min`
  - 原子写回作用域机制以及支持的 GM store 路径
- [杂项辅助](helpers.md)
  - `sim_print`、`dump_tensor`、`inline`、`clean_dcache`
  - 仅用于模拟器的调试辅助、后端逃生口，以及 cache 维护 helper
- [Cube 数据搬运与计算](cube.md)
  - cube 数据搬运、打包布局转换以及 `mmad`
  - `DualMode` / `DualModeType` 和 `l0c_to_ub` 路由
- [A2 向量数学](a2_vec_math.md)
  - 二元、单目、标量、复制以及 group 风格向量算子
- [A2 与共享 Vec 数据搬运](vec_data_movement.md)
  - GM / UB / L1 传输辅助
  - `gm_to_ub_pad`、`ub_to_gm_pad`、`ub_to_ub`
  - `ub_to_l1_nd2nz`、`ub_to_l1_nz`
- [A2 Vec 控制与访问辅助](a2_vec_control.md)
  - vec cast、compare、select、gather/scatter，以及 vec mask
- [A2 Vec 排序与归并辅助](vec_sort.md)
  - `sort32`
  - `mergesort4`
  - `mergesort_2seq`
- [A5 Micro 数学](a5_micro_math.md)
  - 寄存器级数学、compare/select，以及规约风格 micro 辅助
- [A5 Micro 数据搬运](a5_micro_data_movement.md)
  - UB / 寄存器传输辅助
  - gather/scatter 辅助
  - interleave 辅助
- [A5 Micro Cast](a5_micro_cast.md)
  - `CastConfig` 和 `RegLayout`
  - `RoundMode` 和 `RoundModeType`
  - micro `cast()` 和 `Reg.astype()`
  - 在 fp8/int8 cast 流水中的 `pack4()`
- [A5 Micro 比较与选择](a5_micro_compare_select.md)
  - `compare` 和 `select`
  - compare mode、执行 mask，以及 alias-safe 的 select 语义
- [A5 Micro 掩码操作](a5_micro_mask_operations.md)
  - mask 布尔运算、路由、pack/unpack，以及 `update_mask`

## 推荐阅读顺序

如果你刚接触这个框架：

1. 先读 [decorators.md](decorators.md)
2. 再读 [flow_control.md](flow_control.md)
3. 再读 [op_exec.md](op_exec.md)
4. 再读 [shortcuts.md](shortcuts.md)
5. 再读 [scalars.md](scalars.md)
6. 再读 [datatype.md](datatype.md)
7. 再读 [position.md](position.md)
8. 再读 [pipe.md](pipe.md)
9. 再读 [var.md](var.md)
10. 再读 [tensor_buffer.md](tensor_buffer.md)
11. 再读 [register.md](register.md)
12. 再读 [synchronize.md](synchronize.md)
13. 再读 [barrier.md](barrier.md)
14. 再读 [atomic.md](atomic.md)
15. 再读 [helpers.md](helpers.md)
16. 然后选择一条路径：
   - `a2` 路径：[a2_vec_math.md](a2_vec_math.md)、[vec_data_movement.md](vec_data_movement.md)、[a2_vec_control.md](a2_vec_control.md)、[vec_sort.md](vec_sort.md)
   - `a5` 路径：[a5_micro_math.md](a5_micro_math.md)、[a5_micro_data_movement.md](a5_micro_data_movement.md)、[a5_micro_cast.md](a5_micro_cast.md)、[a5_micro_compare_select.md](a5_micro_compare_select.md)、[a5_micro_mask_operations.md](a5_micro_mask_operations.md)
17. 当你的 kernel 开始跨越 cube 内存域，或者需要精确的打包布局行为时，再回来看 [cube.md](cube.md)

## 导入接口概览

### `easyasc.a2`

在这些场景下使用 `a2`：

- 需要针对 A2 风格架构与指令序列来写 kernel
- 需要直接调用 `add`、`abs`、`gather`、`compare` 这类 vec 函数
- 需要使用 A2 这套公开 DSL 接口；它与 `a5` 是并列入口，不是兼容子集

### `easyasc.a5`

在这些场景下使用 `a5`：

- 需要完整的主线 kernel 编写能力
- 需要 `@vf` micro helper
- 需要 `Reg`、`RegList`、`MaskReg` 和 `CastConfig`
- 需要 micro 级寄存器和 mask 操作
- 需要 `ub_to_l1_nd2nz` / `ub_to_l1_nz`

## 本参考使用的约定

- `UB`、`L1`、`L0A`、`L0B`、`L0C` 都表示 `Position` 的取值。
- “推导”表示函数会根据当前张量形状或切片元数据，自动计算缺失参数。
- “上下文限制”表示函数只能在 `@kernel`、`@vf` 或其他激活的 DSL 上下文中使用。
