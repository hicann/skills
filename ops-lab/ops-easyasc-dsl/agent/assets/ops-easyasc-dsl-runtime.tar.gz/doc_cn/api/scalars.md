# 共享标量辅助函数

本页文档说明一些在概念上由 `easyasc.a2` 与 `easyasc.a5` 共同使用的公开标量辅助。

这些辅助主要用来构造或查询标量 `Var` 值，常见用途包括：

- tiling 计算
- worker 调度
- 对齐
- 作用在循环边界与形状值上的标量算术

## 1. 调度与 worker 查询辅助

### `CeilDiv(a, b, name="")`

- 作用：创建一个 `Var`，其值等于 `a / b` 的向上取整结果。
- 参数：
  - `a`、`b`：`Var` 或 `int`
  - `name`：可选的输出变量名
- 限制：
  - 只接受 `Var` 和 `int`
- 示例：

```python
tiles = CeilDiv(M, 128)
```

### `GetCubeNum(name="")`

- 作用：返回当前可用 cube worker 数量，类型为 `Var`。
- 参数：
  - `name`：可选的输出变量名
- 限制：
  - 主要用于 kernel 侧调度逻辑
- 示例：

```python
num_cube = GetCubeNum()
```

### `GetCubeIdx(name="")`

- 作用：返回当前 cube worker 的索引，类型为 `Var`。
- 参数：
  - `name`：可选的输出变量名
- 限制：
  - 主要用于 kernel 侧调度逻辑
- 示例：

```python
cube_idx = GetCubeIdx()
```

### `GetVecNum(name="")`

- 作用：返回当前可用 vec worker 数量，类型为 `Var`。
- 参数：
  - `name`：可选的输出变量名
- 限制：
  - 主要用于 vec 侧 ownership 逻辑
- 示例：

```python
num_vec = GetVecNum()
```

### `GetVecIdx(name="")`

- 作用：返回当前 vec worker 的索引，类型为 `Var`。
- 参数：
  - `name`：可选的输出变量名
- 限制：
  - 主要用于 vec 侧 ownership 逻辑
- 示例：

```python
vec_idx = GetVecIdx()
```

### `GetSubBlockIdx(name="")`

- 作用：返回当前 subblock 的索引，类型为 `Var`。
- 参数：
  - `name`：可选的输出变量名
- 限制：
  - 经常用于 tail-safe 的 vec 写回分块
- 示例：

```python
sb = GetSubBlockIdx()
```

## 2. 标量数学与对齐

### `scalar_sqrt(a, name="")`

- 作用：创建一个等于 `sqrt(a)` 的标量 `Var`。
- 参数：
  - `a`：`Var` 或 `float`
  - `name`：可选输出名
- 限制：
  - 若输入是 `Var`，则必须是 float 类型
- 示例：

```python
inv_scale = scalar_sqrt(scale)
```

### `Align16(a, name="")`

- 作用：把一个整数标量向上补齐到 16 的整数倍。
- 参数：
  - `a`：`Var` 或 `int`
  - `name`：可选输出名
- 限制：
  - 若输入是 `Var`，则必须是整型
- 示例：

```python
aligned = Align16(K)
```

### `Align32(a, name="")`

- 作用：把一个整数标量向上补齐到 32 的整数倍。
- 参数：
  - `a`：`Var` 或 `int`
  - `name`：可选输出名
- 限制：
  - 若输入是 `Var`，则必须是整型
- 示例：

```python
aligned = Align32(K)
```

### `Align64(a, name="")`

- 作用：把一个整数标量向上补齐到 64 的整数倍。
- 参数：
  - `a`：`Var` 或 `int`
  - `name`：可选输出名
- 限制：
  - 若输入是 `Var`，则必须是整型
- 示例：

```python
aligned = Align64(K)
```

### `Align128(a, name="")`

- 作用：把一个整数标量向上补齐到 128 的整数倍。
- 参数：
  - `a`：`Var` 或 `int`
  - `name`：可选输出名
- 限制：
  - 若输入是 `Var`，则必须是整型
- 示例：

```python
aligned = Align128(N)
```

### `Align256(a, name="")`

- 作用：把一个整数标量向上补齐到 256 的整数倍。
- 参数：
  - `a`：`Var` 或 `int`
  - `name`：可选输出名
- 限制：
  - 若输入是 `Var`，则必须是整型
- 示例：

```python
aligned = Align256(M)
```

## 3. 标量算术构造器

### `var_mul(a, b, name="")`

- 作用：构造一个表示乘法的标量 `Var`。
- 参数：
  - `a`、`b`：`Var`、`int` 或 `float`
  - `name`：可选输出名
- 限制：
  - 只接受 `Var`、`int`、`float`
  - 结果 dtype 会根据操作数自动推断
- 示例：

```python
numel = var_mul(M, K)
```

### `var_add(a, b, name="")`

- 作用：构造一个表示加法的标量 `Var`。
- 参数：
  - `a`、`b`：`Var`、`int` 或 `float`
  - `name`：可选输出名
- 限制：
  - 只接受 `Var`、`int`、`float`
- 示例：

```python
end = var_add(start, block)
```

### `var_sub(a, b, name="")`

- 作用：构造一个表示减法的标量 `Var`。
- 参数：
  - `a`、`b`：`Var`、`int` 或 `float`
  - `name`：可选输出名
- 限制：
  - 只接受 `Var`、`int`、`float`
- 示例：

```python
remaining = var_sub(N, n0)
```

### `var_div(a, b, name="")`

- 作用：构造一个表示除法的标量 `Var`。
- 参数：
  - `a`、`b`：`Var`、`int` 或 `float`
  - `name`：可选输出名
- 限制：
  - 只接受 `Var`、`int`、`float`
- 示例：

```python
ratio = var_div(total, parts)
```

### `var_mod(a, b, name="")`

- 作用：构造一个表示取模的标量 `Var`。
- 参数：
  - `a`、`b`：`Var` 或 `int`
  - `name`：可选输出名
- 限制：
  - 只支持整数风格操作数
- 示例：

```python
slot = var_mod(cnt, 2)
```

### `Min(a, b, name="")`

- 作用：构造一个表示两值最小值的标量 `Var`。
- 参数：
  - `a`、`b`：`Var`、`int` 或 `float`
  - `name`：可选输出名
- 限制：
  - 只接受 `Var`、`int`、`float`
- 示例：

```python
valid_m = Min(BLK, m2 - m)
```

### `Max(a, b, name="")`

- 作用：构造一个表示两值最大值的标量 `Var`。
- 参数：
  - `a`、`b`：`Var`、`int` 或 `float`
  - `name`：可选输出名
- 限制：
  - 只接受 `Var`、`int`、`float`
- 示例：

```python
row_max = Max(prev_max, curr_max)
```
