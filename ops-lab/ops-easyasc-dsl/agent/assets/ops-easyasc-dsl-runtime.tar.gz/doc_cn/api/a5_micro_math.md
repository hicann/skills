# A5 Micro 数学

本页文档说明 `easyasc.a5` 直接导出的寄存器级数学辅助能力。

下面的描述依据：

- `easyasc/stub_functions/micro/` 下公开的 stub 接口
- `easyasc/simulator/micro/runtime/ops_vector.py` 中当前的模拟器行为
- `easyasc/simulator/micro/runtime/math_bits.py` 中共享的数学辅助逻辑
- `historical automated tests/` (removed from this skill bundle) 下当前的 micro 测试

本页所有函数都有这些共同点：

- 要求处在激活的 `@vf` 上下文中
- 操作对象是 `Reg` 和 `MaskReg`，而不是 UB `Tensor`
- 除非某个函数被明确说明是规约，否则都按 lane 工作

## 1. 寄存器生成与复制

### `arange(dst, start, increase=True)`

- 作用：用一个等差序列填满寄存器的所有 lane。
- 参数：
  - `dst`：目标 `Reg`
  - `start`：标量起始值
  - `increase`：序列是递增还是递减

行为：

- 这个 API 会覆盖 `dst` 的所有 lane
- 如果 `increase=True`，模拟器计算：
  - `dst[i] = start + i`
- 如果 `increase=False`，模拟器计算：
  - `dst[i] = start - i`
- 目标 dtype 为整数时，使用整数算术
- 目标 dtype 为浮点时，使用浮点算术

公开 stub 当前支持的目标 dtype：

- `DT.int8`
- `DT.int16`
- `DT.int`
- `DT.half`
- `DT.float`

说明：

- 这个 API 没有 mask 参数
- 也没有 `C0` 分组语义
- 但 lane 数仍然由 dtype 决定：
  - `half`：128 lane
  - `float`：64 lane
  - `int8`：256 lane

示例：

```text
arange(dst_half, 0.0, increase=True)
dst = [0.0, 1.0, 2.0, 3.0, ...]
```

```text
arange(dst_int16, 5, increase=False)
dst = [5, 4, 3, 2, 1, 0, ...]
```

示例用法：

```python
idx = Reg(DT.int16)
arange(idx, 0)
```

限制：

- `dst` 必须是 `Reg`
- `start` 必须是 `Var`、`int` 或 `float`
- `increase` 必须是 `bool`

### `dup(dst, src, mask=None)`

- 作用：把一个值广播到寄存器的激活 lane 上。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 `Reg`、`Var`、`int` 或 `float`
  - `mask`：可选的 `MaskReg`

行为：

- 如果 `src` 是标量或 `Var`，这个标量会写入 `dst` 的每个激活 lane
- 如果 `src` 是 `Reg`，模拟器只会读取 `src[0]`，然后把这一个 lane 的值广播到所有激活 lane
- 模拟器会先把 `dst` 清零，再把广播值写到激活 lane
- 因此，未激活 lane 最终都会变成 `0`

Mask 行为：

- mask 是逐 lane 的
- 不会做 `C0` 扩展
- 没有被 mask 选中的 lane 会保持 `0`

示例：

```text
dup(dst, 3.5, mask=VL4)
old dst = [10, 11, 12, 13, 14, 15]
new dst = [3.5, 3.5, 3.5, 3.5, 0, 0]
```

```text
src = [8, 9, 10, 11, ...]
dup(dst, src, mask=VL4)
result in active lanes = [8, 8, 8, 8]
```

常见误区：

- `dup(dst, src_reg)` 不是逐 lane 拷贝
- 它会把 `src_reg` 的第 0 个 lane 广播出去

示例用法：

```python
dup(dst_reg, 1.0)
dup(dst_reg, src_reg, mask=mask)
```

限制：

- `dst` 必须是 `Reg`
- `src` 必须是 `Reg`、`Var`、`int` 或 `float`
- 当 `src` 是 `Reg` 时，`src.dtype` 必须等于 `dst.dtype`

## 2. 二元寄存器操作

这些函数共享同一种模拟器执行模式：

- `vmax`
- `vmin`
- `add`
- `sub`
- `mul`
- `div`
- `vand`
- `vor`
- `vxor`
- `prelu`

共享参数：

- `dst`：目标 `Reg`
- `src1`、`src2`：源 `Reg`
- `mask`：可选的 `MaskReg`

共享的模拟器规则：

- 模拟器会先快照源寄存器，因此 `dst` 可以与 `src1` 和/或 `src2` 别名
- 模拟器会先把 `dst` 清零
- 激活 lane 再写入对应的二元运算结果
- 因此，未激活 lane 最终保持为 `0`

等价的带 mask 形式：

```text
dst[i] = op(src1[i], src2[i])   if mask[i] is active
dst[i] = 0                      otherwise
```

共享限制：

- 三个寄存器的 dtype 都必须一致
- mask 为逐 lane 语义

### `vmax(dst, src1, src2, mask=None)`

- 作用：逐 lane 取最大值。
- 激活 lane 上的公式：
  - `max(src1[i], src2[i])`
- 示例：

```python
vmax(dst, r0, r1)
```

### `vmin(dst, src1, src2, mask=None)`

- 作用：逐 lane 取最小值。
- 激活 lane 上的公式：
  - `min(src1[i], src2[i])`
- 示例：

```python
vmin(dst, r0, r1)
```

### `add(dst, src1, src2, mask=None)`

- 作用：逐 lane 加法。
- 激活 lane 上的公式：
  - `src1[i] + src2[i]`
- 示例：

```python
add(dst, r0, r1)
```

### `sub(dst, src1, src2, mask=None)`

- 作用：逐 lane 减法。
- 激活 lane 上的公式：
  - `src1[i] - src2[i]`
- 示例：

```python
sub(dst, r0, r1)
```

### `mul(dst, src1, src2, mask=None)`

- 作用：逐 lane 乘法。
- 激活 lane 上的公式：
  - `src1[i] * src2[i]`
- 示例：

```python
mul(dst, r0, r1)
```

### `div(dst, src1, src2, mask=None)`

- 作用：逐 lane 除法。
- 激活 lane 上的公式：
  - `src1[i] / src2[i]`
- 示例：

```python
div(dst, r0, r1)
```

### `vand(dst, src1, src2, mask=None)`

- 作用：逐 lane 按位与。
- 模拟器行为：
  - 对整数类 lane，直接做 bitwise `and`
  - 对浮点 lane，会先把底层 bit pattern 解释为同宽整数，做完 bitwise `and` 后再解释回原 dtype
- 示例：

```python
vand(dst, r0, r1)
```

### `vor(dst, src1, src2, mask=None)`

- 作用：逐 lane 按位或。
- 模拟器行为：
  - 采用和 `vand` 相同的 bit pattern 规则
- 示例：

```python
vor(dst, r0, r1)
```

### `vxor(dst, src1, src2, mask=None)`

- 作用：逐 lane 按位异或。
- 模拟器行为：
  - 采用和 `vand` 相同的 bit pattern 规则
- 示例：

```python
vxor(dst, r0, r1)
```

### `prelu(dst, src1, src2, mask=None)`

- 作用：逐 lane 的参数化 ReLU。
- 激活 lane 上的公式：
  - 当 `src1[i] > 0` 时，取 `src1[i]`
  - 否则取 `src1[i] * src2[i]`
- 未激活 lane 保持为 `0`
- 示例：

```python
prelu(dst, xreg, slope_reg)
```

## 3. 单目寄存器操作

这些函数共享同一种模拟器执行模式：

- `exp`
- `abs`
- `relu`
- `sqrt`
- `ln`
- `log`
- `log2`
- `log10`
- `neg`
- `vnot`
- `vcopy`

共享参数：

- `dst`：目标 `Reg`
- `src`：源 `Reg`
- `mask`：可选的 `MaskReg`

共享的模拟器规则：

- 模拟器会先快照源寄存器，因此 `dst` 可以与 `src` 别名
- 模拟器会先把 `dst` 清零
- 激活 lane 再写入单目运算结果
- 因此，未激活 lane 最终保持为 `0`

等价的带 mask 形式：

```text
dst[i] = op(src[i])   if mask[i] is active
dst[i] = 0            otherwise
```

共享限制：

- `dst.dtype` 必须等于 `src.dtype`
- mask 为逐 lane 语义

共同的数学说明：

- 对 `exp`、`sqrt`、`ln`、`log`、`log2`、`log10`，如果源本身不是 `float32` 或 `float64`，模拟器会先按 `float32` 计算，再 cast 回 `dst.dtype`

### `exp(dst, src, mask=None)`

- 作用：逐 lane 指数。
- 激活 lane 上的公式：
  - `exp(src[i])`
- 示例：

```python
exp(dst, src)
```

### `abs(dst, src, mask=None)`

- 作用：逐 lane 绝对值。
- 激活 lane 上的公式：
  - `abs(src[i])`
- 示例：

```python
abs(dst, src)
```

### `relu(dst, src, mask=None)`

- 作用：逐 lane ReLU。
- 激活 lane 上的公式：
  - `max(src[i], 0)`
- 示例：

```python
relu(dst, src)
```

### `sqrt(dst, src, mask=None)`

- 作用：逐 lane 平方根。
- 激活 lane 上的公式：
  - `sqrt(src[i])`
- 示例：

```python
sqrt(dst, src)
```

### `ln(dst, src, mask=None)`

- 作用：逐 lane 自然对数。
- 激活 lane 上的公式：
  - `log(src[i])`
- 示例：

```python
ln(dst, src)
```

### `log(dst, src, mask=None)`

- 作用：micro API 暴露出的 `log` 辅助函数。
- 当前模拟器行为：
  - 它的实现和 `ln` 相同
  - 激活 lane 使用的是自然对数，而不是以 10 为底的对数
- 示例：

```python
log(dst, src)
```

### `log2(dst, src, mask=None)`

- 作用：逐 lane 以 2 为底的对数。
- 激活 lane 上的公式：
  - `log2(src[i])`
- 示例：

```python
log2(dst, src)
```

### `log10(dst, src, mask=None)`

- 作用：逐 lane 以 10 为底的对数。
- 激活 lane 上的公式：
  - `log10(src[i])`
- 示例：

```python
log10(dst, src)
```

### `neg(dst, src, mask=None)`

- 作用：逐 lane 取负。
- 激活 lane 上的公式：
  - `-src[i]`
- 示例：

```python
neg(dst, src)
```

### `vnot(dst, src, mask=None)`

- 作用：逐 lane 按位取反。
- 模拟器行为：
  - 对 `bool` 类型执行逻辑非
  - 对其他 dtype，会先把 bit pattern 解释成同宽整数，做按位取反，再解释回原 dtype
- 示例：

```python
vnot(dst, src)
```

### `vcopy(dst, src, mask=None)`

- 作用：寄存器复制。
- 当前模拟器行为：
  - 激活 lane 复制 `src`
  - 未激活 lane 保持为 `0`
  - 如果 mask 全开，结果就是对 `src` 的完整复制
- 示例：

```python
vcopy(dst, src)
```

## 4. 单目加标量寄存器操作

这些函数都接收：

- `dst`：目标 `Reg`
- `src`：源 `Reg`
- `value`：标量值
- `mask`：可选的 `MaskReg`

这个家族又分成两种执行风格。

### Family A：保留统一模式的 masked unary-scalar 操作

这个家族包括：

- `vmaxs`
- `vmins`
- `adds`
- `muls`
- `lrelu`
- `shiftls`
- `shiftrs`

共享的模拟器规则：

- 模拟器会先快照源寄存器，因此 `dst` 可以与 `src` 别名
- 模拟器会先把 `dst` 清零
- 激活 lane 再写入标量运算结果
- 因此，未激活 lane 最终保持为 `0`

等价的带 mask 形式：

```text
dst[i] = op(src[i], value)   if mask[i] is active
dst[i] = 0                   otherwise
```

### Family B：累加型标量操作

这个家族只有：

- `axpy`

模拟器规则：

- 模拟器会先快照旧的目标值，再把 `dst` 清零
- 激活 lane 计算：
  - `dst[i] = old_dst[i] + src[i] * value`
- 未激活 lane 保持为 `0`

这和本页其他所有 unary-scalar helper 都不同。

### `vmaxs(dst, src, value, mask=None)`

- 作用：逐 lane 钳位到下界。
- 激活 lane 上的公式：
  - `max(src[i], value)`
- 示例：

```python
vmaxs(dst, src, 0.0)
```

### `vmins(dst, src, value, mask=None)`

- 作用：逐 lane 钳位到上界。
- 激活 lane 上的公式：
  - `min(src[i], value)`
- 示例：

```python
vmins(dst, src, 1.0)
```

### `adds(dst, src, value, mask=None)`

- 作用：逐 lane 标量加法。
- 激活 lane 上的公式：
  - `src[i] + value`
- 示例：

```python
adds(dst, src, 1.0)
```

### `muls(dst, src, value, mask=None)`

- 作用：逐 lane 标量乘法。
- 激活 lane 上的公式：
  - `src[i] * value`
- 示例：

```python
muls(dst, src, 2.0)
```

### `lrelu(dst, src, value, mask=None)`

- 作用：逐 lane 的带标量斜率 Leaky ReLU。
- 激活 lane 上的公式：
  - 当 `src[i] > 0` 时，取 `src[i]`
  - 否则取 `src[i] * value`
- 示例：

```python
lrelu(dst, src, 0.1)
```

### `shiftls(dst, src, value, mask=None)`

- 作用：逐 lane 左移。
- 模拟器行为：
  - 先把 lane 通过同宽整数视图重解释
  - 再左移 `value`
  - 然后重解释回原 dtype
  - 如果 `value < 0`，模拟器会反转方向，改做右移
- 限制：
  - `value` 必须是 `int` 或 `Var`
- 示例：

```python
shiftls(dst, src, 1)
```

### `shiftrs(dst, src, value, mask=None)`

- 作用：逐 lane 右移。
- 模拟器行为：
  - 采用和 `shiftls` 相同的 bit pattern 规则
  - 如果 `value < 0`，模拟器会反转方向，改做左移
- 限制：
  - `value` 必须是 `int` 或 `Var`
- 示例：

```python
shiftrs(dst, src, 1)
```

### `axpy(dst, src, value, mask=None)`

- 作用：把按比例缩放后的 `src` 累加到 `dst` 上。
- 激活 lane 上的公式：
  - `dst[i] = old_dst[i] + src[i] * value`
- 未激活 lane 保持为 `0`
- 这是本页唯一一个会把“原目标值”作为输入参与计算的标量操作
- 示例：

```python
axpy(dst, src, 0.5)
```

## 5. 组风格 Micro 辅助

这些辅助函数都会先快照源寄存器，再把目标寄存器清零，然后才写结果。
因此它们在 alias 场景下仍有稳定语义，例如：

```text
cadd(reg, reg, mask)
```

仍然会对“原始寄存器内容”做规约，而不是对“已经被部分覆盖过的目标”做规约。

下面这些函数共享同样的参数形式：

- `cmax`
- `cgmax`
- `cmin`
- `cgmin`
- `cadd`
- `cgadd`
- `cpadd`

共享参数：

- `dst`：目标 `Reg`
- `src`：源 `Reg`
- `mask`：可选的 `MaskReg`

共享限制：

- `dst.dtype` 必须等于 `src.dtype`
- mask 是逐 lane 的

这里一共有三种不同的规约家族。

### Family A：`cadd`、`cmax`、`cmin`

- 对寄存器中所有激活 lane 做一次整体规约
- 结果写入 `dst[0]`
- `dst` 其余所有 lane 都保持 `0`
- 如果没有任何 lane 激活，整个目标都会保持为零

公式：

```text
dst[0] = reduce(src[active_lanes])
dst[1:] = 0
```

示例：

```text
src  = [4, 1, 7, 2, 9, 3]
mask = active lanes [0, 2, 5]

cadd -> dst = [14, 0, 0, 0, 0, 0]
cmax -> dst = [7,  0, 0, 0, 0, 0]
cmin -> dst = [3,  0, 0, 0, 0, 0]
```

### Family B：`cgadd`、`cgmax`、`cgmin`

- 在连续的 8 个 `C0` block 内部分别独立规约
- 设 `c0 = 32 / dtype_size_in_bytes`
- 当前模拟器要求：
  - `lane_count == 8 * c0`
- 第 `b` 个 block 覆盖：
  - `src[b * c0 : (b + 1) * c0]`
- 第 `b` 个 block 的规约结果写入 `dst[b]`
- `dst[8:]` 都保持为 `0`
- 如果某个 block 没有任何激活 lane，它对应的输出槽位保持为 `0`

公式：

```text
for b in range(8):
    dst[b] = reduce(src[active lanes inside block b])
dst[8:] = 0
```

`half` 示例：

```text
dtype = half
c0 = 16

block 0 -> src lanes   0..15 -> dst[0]
block 1 -> src lanes  16..31 -> dst[1]
...
block 7 -> src lanes 112..127 -> dst[7]
```

### Family C：`cpadd`

- 做成对加法规约
- 相邻源 lane 两两成组：
  - pair `0`：lane `(0, 1)`
  - pair `1`：lane `(2, 3)`
  - pair `2`：lane `(4, 5)`
  - 依此类推
- 当前模拟器要求 lane 数为偶数
- 对每一对来说，被 mask 掉的 lane 贡献 `0`
- 每对的结果会写到 `dst` 前半部分的压紧区域
- `dst` 上半部分保持为 `0`

公式：

```text
dst[p] = masked(src[2 * p]) + masked(src[2 * p + 1])
dst[pair_count:] = 0
```

示例：

```text
src  = [10, 20, 30, 40, 50, 60]
mask = active lanes [0, 2, 5]

pair 0 -> 10 + 0  = 10
pair 1 -> 30 + 0  = 30
pair 2 -> 0  + 60 = 60

dst = [10, 30, 60, 0, 0, 0]
```

### `cmax(dst, src, mask=None)`

- 作用：对整个寄存器做最大值规约。
- 结果规则：
  - `dst[0] = max(active src lanes)`
  - `dst[1:] = 0`
- 示例：

```python
cmax(dst, src)
```

### `cgmax(dst, src, mask=None)`

- 作用：按 `C0` block 做最大值规约。
- 结果规则：
  - `dst[0:8]` 保存每个 block 的最大值
  - `dst[8:] = 0`
- 示例：

```python
cgmax(dst, src)
```

### `cmin(dst, src, mask=None)`

- 作用：对整个寄存器做最小值规约。
- 结果规则：
  - `dst[0] = min(active src lanes)`
  - `dst[1:] = 0`
- 示例：

```python
cmin(dst, src)
```

### `cgmin(dst, src, mask=None)`

- 作用：按 `C0` block 做最小值规约。
- 结果规则：
  - `dst[0:8]` 保存每个 block 的最小值
  - `dst[8:] = 0`
- 示例：

```python
cgmin(dst, src)
```

### `cadd(dst, src, mask=None)`

- 作用：对整个寄存器做求和规约。
- 结果规则：
  - `dst[0] = sum(active src lanes)`
  - `dst[1:] = 0`
- 示例：

```python
cadd(dst, src)
```

### `cgadd(dst, src, mask=None)`

- 作用：按 `C0` block 做求和规约。
- 结果规则：
  - `dst[0:8]` 保存每个 block 的和
  - `dst[8:] = 0`
- 示例：

```python
cgadd(dst, src)
```

### `cpadd(dst, src, mask=None)`

- 作用：做成对加法规约。
- 结果规则：
  - `dst[p] = masked(src[2p]) + masked(src[2p+1])`
  - `dst[pair_count:] = 0`
- 说明：
  - 它不是整个寄存器求和
  - 也不是按 `C0` block 的规约
- 示例：

```python
cpadd(dst, src)
```
