# Pipe

本页文档说明贯穿 `easyasc` 各处使用的 pipe 对象。

这里有两个名字需要区分：

- `Pipe`：kernel 作者平时直接使用的公开 pipe 命名空间
- `PipeType`：实际传给 barrier、flag、event 与跨侧同步辅助的具体值对象

在普通 kernel 代码里，你通常会直接写 `Pipe.MTE2`、`Pipe.V`、`Pipe.FIX`、`Pipe.S` 这类名字。

## 1. 概览

`Pipe` 描述的是一个操作属于哪条执行流水，或者属于哪个调度域。

典型例子：

```python
barrier(Pipe.V)
setflag(Pipe.MTE2, Pipe.V, 0)
waitflag(Pipe.MTE2, Pipe.S, 0)
cv = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
evt = SEvent(Pipe.MTE2, Pipe.V)
```

`Pipe` 最常出现的地方包括：

- `barrier(Pipe.V)`、`barrier(Pipe.ALL)` 这类 barrier
- `setflag(src, dst, event_id)` 与 `waitflag(src, dst, event_id)` 这类 flag 辅助
- `cube_ready(..., pipe=...)`、`wait_cube(..., pipe=...)`、`wait_vec(..., pipe=...)` 这类跨侧同步辅助
- `SEvent(src_pipe, dst_pipe)`、`DEvent(src_pipe, dst_pipe)` 这类显式事件对象

和 `Position` 不同，`Pipe` 不是在描述“张量存储在哪里”，而是在描述“一个指令关联到哪条流水”。

## 2. `Pipe`

### 它是什么

- `Pipe` 是由 `easyasc.a2` 和 `easyasc.a5` 导出的公开枚举风格命名空间
- 每个成员都是一个预定义的 `PipeType` 单例

可用成员如下：

| 公开名称 | 含义 | 常见角色 |
| --- | --- | --- |
| `Pipe.MTE2` | 加载 / 输入侧搬运 pipe | GM -> L1 或 GM -> UB 风格的生产者 |
| `Pipe.MTE1` | L1 -> L0 搬运 pipe | cube 侧的 L1 到 L0 staging |
| `Pipe.M` | cube 计算 pipe | `mmad` 和 cube 计算阶段 |
| `Pipe.V` | vec 计算 pipe | vec 操作以及紧邻 micro 的 vec 阶段 |
| `Pipe.FIX` | cube 侧输出 / fix pipe | `l0c_to_ub`、`l0c_to_l1`、`l0c_to_gm_nz2nd` 这类消费者 |
| `Pipe.MTE3` | 存储 / 输出侧搬运 pipe | UB -> GM、UB -> L1 风格的生产者 |
| `Pipe.S` | 主循环调度 pipe | wait 所在的调度域，以及特殊同步目标 |
| `Pipe.ALL` | 全 pipe barrier 域 | 对本地全部 pipe 做 barrier |

### 为什么应优先使用 `Pipe.*`

- 它属于稳定的公开接口
- 它提供了框架所期待的单例对象
- 当前很多内部检查会按对象身份比较 pipe，或者期待确切的 `PipeType` 实例

安全写法是：

```python
pipe = Pipe.V
```

而下面这种写法不推荐：

```python
pipe = PipeType("V")
```

虽然 `PipeType("V") == Pipe.V` 为真，但它不是同一个单例对象，因此那些依赖对象身份或公开成员本身的代码未必会表现一致。

## 3. `PipeType`

### `PipeType(name)`

- 作用：表示一个具体的 pipe 值
- 构造参数：
  - `name`：pipe 名称，例如 `"V"` 或 `"MTE2"`

通常不需要直接实例化这个类。标准实例已经通过 `Pipe` 提供。

### `__str__()` 和 `__repr__()`

- `str(pipe)` 返回纯 pipe 名称
- `repr(pipe)` 返回 `PipeType('...')`

示例：

```python
str(Pipe.MTE2)   # "MTE2"
repr(Pipe.S)     # "PipeType('S')"
```

### 相等性与哈希

- 相等按 pipe 名称比较
- 和非 `PipeType` 对象比较会抛出 `TypeError`
- `PipeType` 可哈希，因此可以作为字典 key 或 set 成员

示例：

```python
Pipe.V == Pipe.V
Pipe.MTE2 == Pipe.MTE2
```

但：

```python
Pipe.V == "V"   # raises TypeError
```

## 4. 每个 pipe 的实际语义

### `Pipe.MTE2`

- 通常表示输入侧搬运 pipe
- 在当前 autosync 分类里，这条 pipe 负责：
  - `gm_to_l1_nd2nz`
  - `set_constant_to_l1`
  - `gm_to_ub_pad`

典型理解：

- 数据正从上游被搬进片上内存

常见例子：

```python
evt = SEvent(Pipe.MTE2, Pipe.V)
setflag(Pipe.MTE2, Pipe.V, 0)
```

### `Pipe.MTE1`

- 通常表示 L1 -> L0 搬运 pipe
- 在当前 autosync 分类里，这条 pipe 负责：
  - `l1_to_l0`

典型理解：

- cube 侧准备好的 L1 tile 正在被送进 L0 输入缓冲

常见例子：

```python
evt = DEvent(Pipe.MTE2, Pipe.MTE1)
barrier(Pipe.MTE1)
```

### `Pipe.M`

- cube 计算 pipe
- 在当前 autosync 分类里，这条 pipe 负责：
  - `mmad`

典型理解：

- matmul 或 cube 计算正在进行

常见例子：

```python
evt = DEvent(Pipe.MTE1, Pipe.M)
barrier(Pipe.M)
```

### `Pipe.V`

- vec 计算 pipe
- 在当前 autosync 分类里，那些不属于 `MTE2`、`MTE1`、`M`、`FIX`、`MTE3` 的 vec 显式操作，都会被视作 `V` pipe 工作

典型理解：

- 逐元素 vec 计算、规约、比较、排序辅助等都发生在这条 pipe 上

常见例子：

```python
barrier(Pipe.V)
evt = SEvent(Pipe.MTE2, Pipe.V)
```

### `Pipe.FIX`

- cube 侧输出 / fix pipe
- 在当前 autosync 分类里，这条 pipe 负责：
  - `l0c_to_gm_nz2nd`
  - `l0c_to_l1`
  - `l0c_to_ub`

典型理解：

- cube 结果正从 `L0C` 向后续阶段发布

常见例子：

```python
cv = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)
barrier(Pipe.FIX)
```

### `Pipe.MTE3`

- 通常表示输出侧搬运 pipe
- 在当前 autosync 分类里，这条 pipe 负责：
  - `ub_to_gm_pad`
  - `ub_to_l1_nd2nz`
  - `ub_to_l1_nz`

典型理解：

- vec 侧产出的结果，或重新打包好的 UB 数据，正在继续向 GM 或 L1 写出

常见例子：

```python
evt = SEvent(Pipe.V, Pipe.MTE3)
vc = VcMutex(1, src_end_pipe=Pipe.MTE3, dst_end_pipe=Pipe.FIX)
```

### `Pipe.S`

- 一个特殊的调度 pipe，用作主循环同步域
- 它不是普通的生产者 pipe，不适合作为 `setflag` / `waitflag` 的源 pipe

当前的重要限制：

- `setflag(src, dst, ...)` 禁止 `src == Pipe.S`
- `waitflag(src, dst, ...)` 禁止 `src == Pipe.S`
- 但 `Pipe.S` 仍然可以作为 flag wait 的目标，也是不少跨侧辅助默认的等待 pipe

典型理解：

- “让主循环等待”，而不是“让某条普通计算 / 搬运 pipe 去等待”

常见例子：

```python
waitflag(Pipe.MTE2, Pipe.S, 0)
wait_cube(flag_id=0, pipe=Pipe.S)
wait_vec(flag_id=0, pipe=Pipe.S)
```

这也是为什么很多同步辅助默认在 wait 侧使用 `Pipe.S`：它们希望阻塞发生在主调度循环上。

### `Pipe.ALL`

- 一个特殊的全 pipe 域，只用于 barrier
- 它不是普通的 flag 事件源或目标

当前的重要限制：

- `setflag` 禁止 `src == Pipe.ALL`
- `setflag` 禁止 `dst == Pipe.ALL`
- `waitflag` 禁止 `src == Pipe.ALL`
- `waitflag` 禁止 `dst == Pipe.ALL`

典型用法：

```python
barrier(Pipe.ALL)
```

它的含义是：

- 在继续执行前，等待所有相关本地 pipe 的排队工作都到达 barrier 点

## 5. Pipe 如何影响框架行为

### autosync 的 pipe 划分

当前 autosync 逻辑围绕这些同侧边界分组：

- vec 侧：
  - `MTE2 -> V`
  - `V -> MTE3`
- cube 侧：
  - `MTE2 -> MTE1`
  - `MTE1 -> M`
  - `M -> FIX`

这也是为什么这些 pipe 名字会在事件对、trace 和生成代码里反复出现。

### flag 与显式事件

`setflag(src, dst, event_id)` 和 `waitflag(src, dst, event_id)` 用 `PipeType` 标识源 pipe 和目标 pipe。

`SEvent(src_pipe, dst_pipe)` 和 `DEvent(src_pipe, dst_pipe)` 在对象层面上做的是同样的事。

因此当你写：

```python
SEvent(Pipe.MTE2, Pipe.V)
```

意思就是：

- 生产方：`MTE2`
- 消费方：`V`

### Barrier

`barrier(pipe)` 同样接收 `PipeType`。

示例：

```python
barrier(Pipe.M)
barrier(Pipe.V)
barrier(Pipe.ALL)
```

这里的 pipe 决定的是：barrier 只约束一条 pipe，还是约束所有本地 pipe。

### 跨侧 wait 与 ready 信号

`cube_ready`、`vec_ready`、`wait_cube`、`wait_vec` 以及 allcore 版本上的 `pipe` 参数，并不会改变逻辑 flag id。它改变的是这条同步指令被安排到哪里执行。

当前 API 中常见的默认值是：

- `cube_ready(..., pipe=Pipe.FIX)`
- `vec_ready(..., pipe=Pipe.MTE3)`
- `wait_cube(..., pipe=Pipe.S)`
- `wait_vec(..., pipe=Pipe.S)`

这和常见的混合流水形态是一致的：

- cube 在自己的输出侧工作之后发布 ready
- vec 在自己的输出侧工作之后发布 ready
- wait 通常发生在主循环

## 6. Codegen 含义

parser 会按名称 lowering `PipeType` 值。

当前 pipe lowering 使用的是类似下面的形式：

```python
PIPE_MTE2
PIPE_V
PIPE_S
PIPE_ALL
```

示例：

- `barrier(Pipe.V)` 会 lowering 成 `PipeBarrier<PIPE_V>();`
- `setflag(Pipe.MTE2, Pipe.V, 0)` 会 lowering 成 `SetFlag<PIPE_MTE2, PIPE_V>(0);`

因此，`Pipe` 值不只是文档标签，它们会变成真正的后端模板参数。

## 7. 实用建议

- 在普通 kernel 代码里使用预定义的 `Pipe.*` 成员。
- 除非你在扩展框架内部，否则不要手工构造 `PipeType(...)`。
- 当某个 API 采用“主循环等待”这一模式时，在 wait 侧使用 `Pipe.S`。
- `Pipe.ALL` 只用于 all-pipe barrier，不要拿它做 flag。
- 可以把 `MTE2` 理解为输入侧搬运、`MTE1` 理解为 L1 -> L0 搬运、`M` 理解为 cube 计算、`V` 理解为 vec 计算、`FIX` 理解为 cube 输出侧发布、`MTE3` 理解为 vec 输出侧搬运。
- 读取 autosync 结果或 trace 时，规范的同侧交接对是 `MTE2 -> V`、`V -> MTE3`、`MTE2 -> MTE1`、`MTE1 -> M`、`M -> FIX`。
