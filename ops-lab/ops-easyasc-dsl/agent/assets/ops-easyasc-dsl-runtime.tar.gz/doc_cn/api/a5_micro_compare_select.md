# A5 Micro 比较与选择

本页文档说明 `a5` micro 侧的 compare/select 辅助能力：

- `CompareMode`
- `CompareModeType`
- `compare`
- `select`

下面的描述依据：

- `easyasc/stub_functions/micro/compare.py` 中公开的 stub 接口
- `easyasc/simulator_v2/ops/micro/runtime.py` 中当前 V2 模拟器的行为
- `easyasc/stub_functions/micro/microutils.py` 中与 mask 相关的辅助逻辑
- `testcases/simulator/micro/` 下当前的 V2 micro 测试

本页所有函数都有这些共同点：

- 要求处在激活的 `@vf` 上下文中
- 按 lane 作用于 `Reg` 和 `MaskReg`
- 使用的是逐个 micro lane 的 mask bit，而不是按 `C0` 展开的 tensor mask

## 1. `CompareModeType` 与 `CompareMode`

`compare(...)` 用 `CompareModeType` 值来描述比较谓词。

这些类型定义在 `easyasc/utils/comparemode.py` 中。

### `CompareModeType`

- 作用：表示一个具体比较谓词，例如 `LT` 或 `GE`
- 存储字段：
  - `name`
- 重要行为：
  - `str(mode)` 会返回 `LT`、`GE` 这样的名字
  - `repr(mode)` 会返回类似 `CompareModeType('GE')` 这样的调试形式
  - 相等比较按模式名进行

当前实现里有一个稍微特别的地方：

- 如果拿 `CompareModeType` 和其他类型对象比较，会抛 `TypeError`
- 它不会静默地返回 `False`

实际写 kernel 时，
这通常只会在内部辅助代码或调试代码中才会遇到，在正常作者代码里并不常见。

### `CompareMode`

`CompareMode` 是一个类似枚举的命名空间，导出了 6 个受支持的谓词：

- `CompareMode.LT`
  - 当 `lhs < rhs` 时，该 lane 为激活
- `CompareMode.LE`
  - 当 `lhs <= rhs` 时，该 lane 为激活
- `CompareMode.GT`
  - 当 `lhs > rhs` 时，该 lane 为激活
- `CompareMode.GE`
  - 当 `lhs >= rhs` 时，该 lane 为激活
- `CompareMode.EQ`
  - 当 `lhs == rhs` 时，该 lane 为激活
- `CompareMode.NE`
  - 当 `lhs != rhs` 时，该 lane 为激活

这些都是单例值，所以普通用户代码应始终传：

```python
CompareMode.GT
```

而不是手动构造 `CompareModeType(...)`。

### 为什么这个类型最适合放在本页

`CompareMode` 只在本页记录的 micro compare 路径里有意义。
把它和 `compare(...)` 放在一起，
能把下面几部分集中到同一页：

- 枚举本身
- compare API
- 模拟器语义

## 2. 如何理解这组 API

在 micro 级别：

- 一个 `Reg` 保存一组向量 lane
- 一个 `MaskReg` 为每个 lane 保存一个布尔位
- 执行 mask 决定哪些 lane 会被这条指令更新

这里有两种不同角色的 mask：

- 目标 mask：
  - 只用于 `compare`
  - 用来接收布尔比较结果
- 执行 mask：
  - 即可选的 `mask=...` 参数
  - 用来决定哪些 lane 参与本条指令

如果省略 `mask`，stub 会通过 `ensure_mask(...)` 调用 `micro.get_mask(dtype)`。
在常见用法下，这通常意味着“使用这个 dtype 当前默认的执行 mask”，除非你在更早的代码里已经改动过它。

## 3. `compare(dst, src1, src2, mode, mask=None)`

- 作用：把一个寄存器和另一个寄存器或标量做比较，并把布尔结果写到 `MaskReg` 中。
- 参数：
  - `dst`：目标 `MaskReg`
  - `src1`：左侧 `Reg`
  - `src2`：右侧 `Reg`、`Var`、`int` 或 `float`
  - `mode`：`CompareMode`
  - `mask`：可选的执行 `MaskReg`

### 支持的比较模式

- `CompareMode.LT`
- `CompareMode.LE`
- `CompareMode.GT`
- `CompareMode.GE`
- `CompareMode.EQ`
- `CompareMode.NE`

### Stub 层 lowering

stub 会发射两种指令形式之一：

- `micro_compare`
  - 当 `src2` 是 `Reg` 时
- `micro_compares`
  - 当 `src2` 是标量类值时

标量形式不会在 Python 侧物化一个临时寄存器。
相反，标量会先被格式化，随后由模拟器解析成数值。

### Dtype 限制

- `dst.dtype` 必须等于 `src1.dtype`
- 如果 `src2` 是 `Reg`，那么 `src2.dtype` 也必须匹配
- 如果 `src2` 是标量类值，那么它必须和 `src1` 保持同一个数值家族
  - float 类 `src1`（`DT.float` / `DT.half` / `DT.bfloat16`）只能配 float 类标量或 `Var`
  - int 类 `src1` 只能配 int 类标量或 `Var`
- `mode` 必须是 `CompareModeType`

这个 dtype 规则不仅关系到元素类型，也关系到 lane 数和寄存器形状：

- 模拟器会按 dtype 来解析 lane 视图
- dtype 不匹配就意味着 lane 形状也不兼容

### 模拟器执行模型

模拟器会执行这些步骤：

1. 把 `dst` 解析成可写的 mask-lane 向量
2. 把 `src1` 解析成寄存器 lane 向量
3. 解析执行 mask bits
4. 计算 `active = execution_mask`
5. 如果没有任何 lane 激活，立即返回
6. 取出 `lhs = src1[active]`
7. 解析 `rhs`：
   - 如果 `src2` 是 `Reg`，取出 `src2[active]`
   - 否则解析出一个标量，并在逻辑上对 `lhs` 做广播比较
8. 只对激活 lane 计算比较结果
9. 把这些布尔结果写回 `dst[active]`

一个关键后果是：

- 被 mask 掉的 `dst` lane 不会被碰到
- 它们会保持原有值

这意味着 `compare` 是“按 mask 的局部更新”，而不是“无条件重建整个目标”。

### 精确 lane 规则

对每个 lane `i`：

```text
dst[i] = compare(src1[i], src2[i or scalar], mode)   if exec_mask[i] is active
dst[i] = old dst[i]                                  otherwise
```

### 标量 compare 行为

如果 `src2` 是标量类值：

- 模拟器会把它解析一次
- 然后让 `src1` 的每个激活 lane 都拿它来比较
- stub 会在 codegen 前拒绝 float/int 混型

所以：

```python
compare(mask_gt, reg, 2.0, CompareMode.GT)
```

表示：

```text
mask_gt[i] = (reg[i] > 2.0)   on active lanes
```

### 寄存器 compare 行为

如果 `src2` 是 `Reg`：

- 两个源寄存器都会用同一个执行 mask 去切片
- 只对激活 lane 做逐 lane 比较

所以：

```python
compare(mask_gt, r0, r1, CompareMode.GT, mask=gate)
```

表示：

```text
mask_gt[i] = (r0[i] > r1[i])  if gate[i] is active
mask_gt[i] = old mask_gt[i]   otherwise
```

### 为什么被 mask 掉的 lane 会保持不变

因为模拟器只会做：

- `dst_view[active] = values`

它不会先把整个目标 mask 清掉，也不会重建整份目标。

这种行为通常很有用，比如：

- 一条指令只更新 mask 的某一部分
- 后续指令还要在现有 mask 基础上累积或细化状态

但这也意味着，如果你需要被 mask 掉的 lane 有确定值，就应该显式初始化 `dst`。

### 示例：和标量阈值比较

```python
compare(mask_reg, r0, 0.0, CompareMode.GE)
```

含义：

- 激活 lane 中，满足 `r0 >= 0` 的位置会变成 `True`
- 激活 lane 中，满足 `r0 < 0` 的位置会变成 `False`
- 被 mask 掉的 lane 保持 `mask_reg` 原值

### 示例：部分 mask compare

```python
compare(mask_reg, r0, r1, CompareMode.LT, mask=gate_mask)
```

含义：

- 只有 `gate_mask` 启用的 lane 会重新计算
- 其余 lane 的 `mask_reg` 保持原样

## 4. `select(dst, src1, src2, mask=None)`

- 作用：按 mask 从 `src1` 或 `src2` 中选择 lane 值。
- 参数：
  - `dst`：目标 `Reg`
  - `src1`：源 `Reg`
  - `src2`：源 `Reg`
  - `mask`：可选的 `MaskReg`

### Dtype 限制

- `dst.dtype`、`src1.dtype` 和 `src2.dtype` 必须一致

### Stub 层 lowering

stub 会发射：

- `Instruction("micro_select", dst=dst, src1=src1, src2=src2, mask=mask)`

如果省略 `mask`，同样会回退到 `micro.get_mask(dtype)`。

### 模拟器执行模型

模拟器会执行这些步骤：

1. 把目标和两个源都解析成 lane 向量
2. 解析执行 mask bits
3. 先对两个源做快照：
   - `src1_snapshot = src1_view.clone()`
   - `src2_snapshot = src2_view.clone()`
4. 先把整个 `src2_snapshot` 复制到 `dst`
5. 再用 `src1_snapshot` 覆盖 `dst` 中激活的 lane

因此它的实际规则是：

```text
dst[i] = src1[i]   if mask[i] is active
dst[i] = src2[i]   otherwise
```

### 为什么这里的 alias 是安全的

因为模拟器会在写目标之前先快照两个源：

- 即使 `dst is src1`，也仍然会表现得像真正的 select
- 即使 `dst is src2`，也仍然会表现得像真正的 select

如果不先做快照，alias 就会污染那些尚未读取的源 lane。
模拟器正是显式避免了这个问题。

### 全 lane 覆盖语义

和 `compare` 不同，`select` 总是会重建整个目标：

- 它先把所有 lane 都从 `src2` 复制进 `dst`
- 再把激活 lane 用 `src1` 覆盖

因此，被 mask 掉的 lane 并不会保留原目标值。
它们总是会变成对应的 `src2` lane。

这正是下面两者最重要的语义差别：

- `compare`
- `select`

### 示例

如果：

```text
src1 = [10, 20, 30, 40]
src2 = [ 1,  2,  3,  4]
mask = [T, F, T, F]
```

那么：

```text
dst = [10, 2, 30, 4]
```

### 示例：无分支 lane 合并

```python
select(dst_reg, positive_path, negative_path, mask_reg)
```

含义：

- mask 激活的 lane 选 `positive_path`
- mask 未激活的 lane 选 `negative_path`

这相当于 micro 层的向量化三元表达式。

## 5. Compare 与 Select 的区别

在这些情况下用 `compare`：

- 你想生成或更新布尔 lane 状态
- 目标是 `MaskReg`

在这些情况下用 `select`：

- 你已经有一个 mask
- 你想把两个数值寄存器合并成一个 `Reg`

关键语义差别：

- `compare` 只更新激活的目标 lane，被 mask 掉的 lane 保持不变
- `select` 会先用 `src2` 重建整个目标，再把激活 lane 改成 `src1`

## 6. 常见坑

- 不要以为 `compare(..., mask=...)` 会清掉被 mask 掉的 lane。它不会。
- 不要以为 `select(..., mask=...)` 会让被 mask 掉的 lane 保持旧的目标值。它不会；这些 lane 来自 `src2`。
- 不要在 `dst`、`src1`、`src2` 之间混用不同 dtype。
- 不要把 `compare` 的执行 mask 和它写入结果的目标 mask 混为一谈，它们是两个不同角色。
