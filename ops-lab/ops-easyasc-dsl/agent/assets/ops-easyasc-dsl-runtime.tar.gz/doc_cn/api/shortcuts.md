# Shortcut

本页文档说明一些在概念上由 `easyasc.a2` 与 `easyasc.a5` 共同使用的公开 shortcut 风格辅助。

这些辅助属于更高层的便利入口，而不是最底层的指令原语。

## 1. Matmul Shortcut

### `matmul(dst, l1a, l1b, splitn=None, splitk=None, m=None, n=None, k=None, is_init=True)`

- 作用：发射仓库中大多数 kernel 使用的标准 matmul 路径，并支持可选的 split-N 或 split-K staging。
- 参数：
  - `dst`：位于 `L0C` 的 `Tensor`
  - `l1a`、`l1b`：位于 `L1` 的输入 `Tensor`
  - `splitn`：可选的 N 向切分大小
  - `splitk`：可选的 K 向切分大小
  - `m`、`n`、`k`：可选的显式逻辑尺寸
  - `is_init`：目标累加是否从零开始
- 限制：
  - 只能在激活的 kernel 中使用
  - `dst` 必须位于 `Position.L0C`
  - `l1a` 与 `l1b` 必须位于 `Position.L1`
  - `splitn` 与 `splitk` 不能同时设置
  - 当前激活的 kernel 必须已经具备框架管理的 `_l0a`、`_l0b`、`_l0acnt`、`_l0bcnt` 缓冲
- 示例：

```python
matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
```

## 2. VecOP 便捷构造器

### `maximum(a, b)`

- 作用：构造一个 `VecOP`，表示“一个 tensor 与另一个 tensor 或标量之间的逐元素最大值”。
- 参数：
  - `a`、`b`：至少其中一个必须是 tensor，另一个可以是另一个 tensor 或标量 / `Var`
- 限制：
  - 至少有一个操作数必须是 `Tensor`
  - 返回对象必须通过 `<<=` 消费
- 示例：

```python
dst <<= maximum(src, 0.0)
```

### `minimum(a, b)`

- 作用：构造一个 `VecOP`，表示“一个 tensor 与另一个 tensor 或标量之间的逐元素最小值”。
- 参数：
  - `a`、`b`：至少其中一个必须是 tensor，另一个可以是另一个 tensor 或标量 / `Var`
- 限制：
  - 至少有一个操作数必须是 `Tensor`
  - 返回对象必须通过 `<<=` 消费
- 示例：

```python
dst <<= minimum(src1, src2)
```
