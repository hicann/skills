# 寄存器与掩码类型

本页文档说明 A5 micro 侧的寄存器对象：

- `Reg`
- `RegList`
- `MaskReg`
- `MaskType`
- `MaskTypeValue`

这些类型主要定义在 `easyasc/utils/reg.py` 与 `easyasc/utils/mask.py` 中。它们属于 A5 micro 编写对象，在 `@vf` 代码里最有用。

一个重要区别是：

- 很多 `Reg` / `RegList` / `MaskReg` 方法返回的是 `RegOP` builder
- 有些方法会立刻发射指令
- 有些运算符看起来像普通 Python 算术，但实际上构造的是 micro IR

关于底层 micro 操作的详细数值行为，请参见：

- [a5_micro_math.md](a5_micro_math.md)
- [a5_micro_data_movement.md](a5_micro_data_movement.md)
- [a5_micro_cast.md](a5_micro_cast.md)
- [a5_micro_compare_select.md](a5_micro_compare_select.md)
- [a5_micro_mask_operations.md](a5_micro_mask_operations.md)

## 1. `Reg`

### `Reg(dtype, name="")`

- 作用：表示一个 A5 micro 寄存器。
- 构造参数：
  - `dtype`：寄存器 dtype
  - `name`：可选的显式寄存器名
- 限制：
  - `dtype` 必须是 `DataTypeValue`
  - 如果 `name=""`，则必须有激活的 `@vf` 上下文，以便运行时自动生成 `_reg_*`
- 行为：
  - 保存 `dtype` 与 `name`
  - 如果在激活的 micro module 内创建，会发射 `create_reg`

示例：

```python
r0 = Reg(DT.float)
r1 = Reg(DT.float)
```

### `__repr__()` 和 `__str__()`

- `repr(reg)` 会同时展示名字和 dtype
- `str(reg)` 只返回寄存器名
- 实际用途：
  - 主要用于调试输出和生成表达式时的可读性

### 算术运算符

这些运算符不会立刻执行，它们返回的是 `RegOP` builder。

#### `a + b`

- 如果 `b` 是 `Reg`，返回 `RegOP("add", a, b)`
- 如果 `b` 是 `int`、`float` 或 `Var`，返回 `RegOP("adds", a, b)`
- 如果 `b` 是另一个 `RegOP`，会先把它物化到一个临时寄存器里

#### `a - b`

- `Reg - Reg` -> `RegOP("sub", a, b)`
- `Reg - scalar` -> `RegOP("adds", a, -scalar)`
- 只有当左侧标量已经是 `Reg` 或 `RegOP` 时，才支持 `scalar - Reg`

#### `a * b`

- `Reg * Reg` -> `RegOP("mul", a, b)`
- `Reg * scalar` -> `RegOP("muls", a, scalar)`

#### `a / b`

- `Reg / Reg` -> `RegOP("div", a, b)`
- `Reg / scalar` -> `RegOP("muls", a, 1 / scalar)`
- 这意味着，标量除法在 builder 层会被表示成“乘倒数”

### 比较运算符

这些运算同样返回 `RegOP`，而不是 Python `bool`。

- `a >= b` -> `RegOP("compare", a, b, CompareMode.GE)`
- `a > b` -> `CompareMode.GT`
- `a <= b` -> `CompareMode.LE`
- `a < b` -> `CompareMode.LT`
- `a == b` -> `CompareMode.EQ`
- `a != b` -> `CompareMode.NE`

实际含义：

- 比较结果应当赋给 `MaskReg`
- 例如：`mask <<= (r0 > r1)`

### `reg <<= other`

`Reg.__ilshift__` 是主要的命令式赋值入口。

#### `Reg <<= RegOP`

- 作用：把一个寄存器表达式执行到当前寄存器中。
- 行为：
  - 先释放临时输入
  - 再把底层操作发射到 `self`

示例：

```python
r2 <<= r0 + r1
```

#### `Reg <<= Tensor`

- 作用：把 UB 数据加载到寄存器里。
- 限制：
  - 面向 micro 侧的 UB load 路径
- 行为：
  - 会检查 `other.vec_copy_mode`
  - 同 dtype 路径：
    - 默认 -> `ub_to_reg`
    - `brcb()` -> `ub_to_reg_brcb`
    - `upsample()` -> `ub_to_reg_upsample`
    - `unpack()` -> `ub_to_reg_unpack`
    - `unpack4()` -> `ub_to_reg_unpack4`
    - `downsample()` -> `ub_to_reg_downsample`
    - `single()` -> `ub_to_reg_single`
  - 跨 dtype 路径：
    - 运行时会先按 tensor 的 dtype 分配一个临时寄存器
    - 先用合适的数据搬运路径加载到该临时寄存器
    - 再发射 `cast(self, tmp_reg)`
    - 最后释放临时寄存器
- 重要限制：
  - mixed dtype 的 tensor-to-reg 赋值要求处在激活的 micro 上下文中

示例：

```python
r0 <<= ub
scalar_reg <<= ub[0:1, col:col + 1].single()
```

#### `Reg <<= Reg`

- 作用：把一个寄存器复制到另一个寄存器。
- 行为：
  - 发射 `vcopy(self, other)`

#### `Reg <<= scalar_or_var`

- 作用：把一个标量广播到目标寄存器中。
- 可接受的来源：
  - `int`
  - `float`
  - `Var`
- 行为：
  - 发射 `dup(self, value)`

示例：

```python
r0 <<= 0.0
r1 <<= count_var
```

### Cast 辅助

#### `cast(cfg=None)`

- 作用：构造一个 cast builder，源 dtype 使用当前寄存器 dtype，而目标 dtype 由最终赋值目标决定。
- 返回：
  - `RegOP("cast", self, cfg)`
- 如果 `cfg is None`，会自动创建默认的 `CastConfig()`

#### `astype(dtype, cfg=None)`

- 作用：构造一个带显式目标 dtype 的 cast builder。
- 返回：
  - `RegOP("cast", self, cfg, dtype)`

实际区别：

- `.cast()` 通常在目标寄存器已经明确时使用
- `.astype(dtype)` 在目标 dtype 本身也是表达式语义一部分时更直观

关于精确的 lane 布局与饱和语义，请参见 [a5_micro_cast.md](a5_micro_cast.md)。

### 单目数学 builder

这些方法返回 `RegOP` builder：

- `exp()`
- `abs()`
- `sqrt()`
- `relu()`
- `ln()`
- `log()`
- `log2()`
- `log10()`
- `neg()`
- `vnot()`
- `vcopy()`

示例：

```python
r1 <<= r0.abs()
r2 <<= r0.log()
```

### 单目标量 builder

这些方法返回 `RegOP` builder：

- `shiftls(value)`
- `shiftrs(value)`
- `axpy(value)`
- `lrelu(value)`
- `vmins(value)`
- `vmaxs(value)`

限制：

- `shiftls` / `shiftrs` 在概念上要求整数风格的 block / shift 计数
- 其他方法接受 `int`、`float` 或 `Var`

### 二元寄存器 builder

这些方法返回 `RegOP` builder：

- `vand(other)`
- `vor(other)`
- `vxor(other)`
- `prelu(other)`
- `vmax(other)`
- `vmin(other)`

### 规约 / group builder

这些方法返回的 `RegOP` 结果仍然是一个 `Reg`：

- `cadd()`
- `cmax()`
- `cmin()`
- `cgadd()`
- `cgmax()`
- `cgmin()`
- `cpadd()`

关于精确的 lane 规约语义，请参见 [a5_micro_math.md](a5_micro_math.md)。

### 复制与序列辅助

#### `dup()`

- 返回：
  - `RegOP("dup", self)`
- 实际含义：
  - 这是 builder 形式；当它物化到另一个寄存器里时，会广播 `self[0]`

示例：

```python
r1 <<= r0.dup()
```

#### `fill(value)`

- 作用：立刻用某个标量填满当前寄存器。
- 行为：
  - 直接发射 `dup(self, value)`
- 与 `dup()` 的区别：
  - `fill()` 是命令式的，会直接修改 `self`
  - `dup()` 是表达式构造形式，会把现有寄存器作为源

示例：

```python
r0.fill(0.0)
```

#### `arange(start, increase=True)`

- 作用：用一个算术递增序列填满寄存器。
- 参数：
  - `start`：`int`、`float` 或 `Var`
  - `increase`：按每个 lane 递增还是递减 1
- 行为：
  - 立即发射 `arange(self, start, increase=...)`
- 这是命令式方法，不是 builder

示例：

```python
idx.arange(0)
```

### UB 写回便捷 builder

这些方法返回 `RegOP`，预期由 `Tensor <<= ...` 消费：

- `downsample()` -> `RegOP("reg_to_ub_downsample", self)`
- `pack4()` -> `RegOP("reg_to_ub_pack4", self)`
- `single_value()` -> `RegOP("reg_to_ub_single", self)`

典型用法：

```python
ub <<= reg.pack4()
```

### Gather 辅助

这些方法是命令式的。它们会直接把结果写到 `self`，并返回 `None`。

#### `ub_gather(src, index, mask=None)`

- 作用：用逐 lane 索引，从 UB tensor 中 gather 到寄存器。
- 行为：
  - 调用 `ub_to_reg_gather(self, src, index, mask=mask)`

#### `gather(src, index)`

- 作用：用逐 lane 索引，从另一个寄存器中 gather。
- 行为：
  - 调用 `gather(self, src, index)`

#### `gather_mask(src, mask=None)`

- 作用：在 mask 控制下，从源寄存器中压紧或 gather 激活 lane。
- 行为：
  - 调用 `gather_mask(self, src, mask=mask)`

这些 gather helper 的精确数据选择规则，见 [a5_micro_data_movement.md](a5_micro_data_movement.md)。

## 2. `RegList`

### `RegList(dtype, length, name="")`

- 作用：表示一个固定长度的逻辑 micro 寄存器列表。
- 构造参数：
  - `dtype`：寄存器 dtype
  - `length`：逻辑元素个数
  - `name`：可选的基础名称
- 限制：
  - `length` 必须是正整数
  - 如果 `name=""`，则要求处在激活的 micro 上下文中，以便自动生成 `_reglist_*`
- 行为：
  - 在激活的 micro 上下文中会发射 `create_reglist`

示例：

```python
rows = RegList(DT.float, 2)
```

### `__repr__()` 和 `__str__()`

- `repr(reglist)` 会显示基础名、dtype 和逻辑长度
- `str(reglist)` 只返回基础名

### `reglist[i]`

- 限制：
  - 索引必须是 `int`
- 行为：
  - 返回一个代理 `Reg`
  - 代理名字格式为 `"{reglist.name}[{i}]"`
  - 不会真正创建容器项或存储对象
- 一个重要后果是：
  - `RegList` 更像是一组寄存器命名约定，而不是一个真的持有子对象的 Python 列表

示例：

```python
r0 = rows[0]
```

### `reglist[i] = value`

- 作用：满足 Python 的增量赋值协议。
- 行为：
  - 故意什么都不做
- 原因：
  - `reglist[i] <<= ...` 在代理寄存器上已经发射了真正有意义的指令
  - Python 在增量赋值之后仍然会调用 `__setitem__`，所以这里必须提供这个钩子

### `reglist <<= tensor`

- 作用：从 UB 中按“整行寄存器列表”的方式加载一整组寄存器。
- 限制：
  - 源必须是 `Tensor`
- 行为：
  - block 大小为 `256 // dtype.size`
  - 对每个逻辑寄存器 `i`，运行时都会从 `tensor[block * i]` 位置加载
  - 每个元素的加载都委托给对应代理寄存器的赋值路径

示例：

```python
rows <<= ub
```

### `reglist <<= regop`

- 作用：把一个逐元素或规约风格的 builder 执行到整个寄存器列表上。
- 支持的 `RegOP` 家族：
  - 二元：`add`、`sub`、`mul`、`div`、`vmax`、`vmin`、`vand`、`vor`、`vxor`、`prelu`
  - 单目：`exp`、`abs`、`sqrt`、`relu`、`ln`、`log`、`log2`、`log10`、`neg`、`vnot`、`vcopy`
  - 单目标量：`shiftls`、`shiftrs`、`axpy`、`lrelu`、`vmaxs`、`vmins`、`adds`、`muls`
- 行为：
  - 如果 `RegOP` 内部的源是另一个 `RegList`，则两边长度必须一致
  - 附着在源 `RegOP` 上的 mask 会复制到每个逐元素操作上
  - 逐元素执行会展开成对每个代理寄存器逐个赋值
- 不支持的操作：
  - 凡是不在上述支持家族里的 `RegOP` 都会抛错

### 二元表达 builder

这些方法返回 `RegOP` builder：

- `__add__(other)`
- `__sub__(other)`
- `__mul__(other)`
- `__truediv__(other)`
- `vmax(other)`
- `vmin(other)`
- `vand(other)`
- `vor(other)`
- `vxor(other)`
- `prelu(other)`

当它们物化到目标 `RegList` 时，支持的 `other` 形式有：

- 另一个长度相同的 `RegList`
- 单个 `Reg`
- 仅对基础算术操作，支持标量

### 单目表达 builder

这些方法返回 `RegOP` builder：

- `exp()`
- `abs()`
- `sqrt()`
- `relu()`
- `ln()`
- `log()`
- `log2()`
- `log10()`
- `neg()`
- `vnot()`
- `vcopy()`
- `shiftls(value)`
- `shiftrs(value)`
- `axpy(value)`
- `lrelu(value)`
- `vmaxs(value)`
- `vmins(value)`

### 规约 builder

这些方法返回 `RegOP`，会把整个 `RegList` 规约成单个 `Reg`：

- `cmax()`
- `cmin()`
- `cadd()`

当前运行时里，这类 `RegOP` 物化到 `Reg` 上时的行为是：

- 先在整个列表元素之间做 pairwise 组合
- 然后再对最终单寄存器结果应用一次单寄存器 group 规约

### `fill(value)`

- 作用：把每个逻辑寄存器元素都填成同一个标量。
- 行为：
  - 遍历所有索引
  - 对每个代理寄存器发射 `self[i] <<= value`
- 这是命令式操作，不是 builder

示例：

```python
rows.fill(0.0)
```

## 3. `MaskReg`

### `MaskReg(dtype, init_mode=None, name="")`

- 作用：表示一个 micro 掩码寄存器。
- 构造参数：
  - `dtype`：这个 mask 所遵循的 lane 几何对应的数据 dtype
  - `init_mode`：可选的 `MaskTypeValue`
  - `name`：可选的显式 mask 寄存器名
- 默认行为：
  - 如果 `init_mode is None`，则默认变成 `MaskType.ALL`
- 限制：
  - `dtype` 必须是 `DataTypeValue`
  - `init_mode` 必须是 `MaskTypeValue`
  - 如果 `name=""`，则要求激活的 micro 上下文，以便自动生成 `_maskreg_*`
- 行为：
  - 在激活的 micro 上下文中会发射 `create_maskreg`

示例：

```python
mask = MaskReg(DT.half)
mask_none = MaskReg(DT.half, init_mode=MaskType.NONE)
```

### `__repr__()` 和 `__str__()`

- `repr(mask)` 会显示名字、dtype 和初始 mask 模式
- `str(mask)` 只返回 mask 寄存器名

### `mask * regop`

- 作用：把一个 mask 附着到 `RegOP` 上。
- 限制：
  - 右侧必须是 `RegOP`
- 行为：
  - 调用 `regop.setmask(mask)`
  - 返回同一个 `RegOP`
- 实际含义：
  - 这是构造带 mask 表达式的便捷语法

示例：

```python
r2 <<= mask * (r0 + r1)
```

### `mask <<= other`

`MaskReg.__ilshift__` 支持两类来源。

#### `mask <<= Var`

- 作用：从一个类似计数器的标量更新 mask bits。
- 限制：
  - 源必须是 `Var`
- 行为：
  - 发射 `update_mask(mask, cnt)`

#### `mask <<= RegOP`

- 作用：把一个产生 mask 的 `RegOP` 执行到当前 mask 寄存器中。
- 行为：
  - 先释放临时输入
  - 再把底层操作发射到 `self`

示例：

```python
mask <<= (r0 > r1)
mask <<= ~other_mask
```

### 按位 mask builder

这些操作返回 `RegOP` builder：

- `~mask` -> `mask_not`
- `mask0 & mask1` -> `mask_and`
- `mask0 | mask1` -> `mask_or`
- `mask0 ^ mask1` -> `mask_xor`

### `mov(src)`

- 作用：构造一个 mask copy 操作。
- 返回：
  - `RegOP("mask_mov", src)`

### `sel(src1, src2)`

- 作用：构造一个 mask-to-mask select 操作。
- 返回：
  - `RegOP("mask_sel", src1, src2)`
- 含义：
  - 在附着到该 `RegOP` 的执行 mask 控制下，在两个 mask 寄存器之间做选择

### `pack(low_part=True)`

- 作用：构造一个 mask pack 操作。
- 返回：
  - `RegOP("mask_pack", self, low_part)`

### `unpack(low_part=True)`

- 作用：构造一个 mask unpack 操作。
- 返回：
  - `RegOP("mask_unpack", self, low_part)`

### `move_to_spr()`

- 作用：构造一个 move-to-mask-SPR 操作。
- 返回：
  - `RegOP("move_mask_spr")`
- 说明：
  - 这是 builder 形式
  - 很多 kernel 更常直接使用 helper `move_mask_spr(mask)`

### `update(cnt)`

- 作用：根据一个计数器 `Var` 更新当前 mask。
- 行为：
  - 直接发射 `update_mask(self, cnt)`
- 这是命令式操作，不像 `pack()` / `unpack()` 那样返回 builder

### `select(src1, src2)`

- 作用：在当前 mask 寄存器控制下，构造一个数据寄存器 select。
- 参数：
  - `src1`、`src2`：`Reg`
- 行为：
  - 创建 `RegOP("select", src1, src2)`
  - 把 `self` 附着为执行 mask
  - 返回该 `RegOP`
- 一个重要区别：
  - `sel()` 是 mask-to-mask 选择
  - `select()` 是在当前 mask 控制下的数据寄存器选择

示例：

```python
r_out <<= mask.select(r_true, r_false)
```

## 4. `MaskTypeValue`

### `MaskTypeValue(name)`

- 作用：表示一个具体的预定义 mask 模式。
- 常见用法：
  - 通常不需要手动构造它
  - 而是使用 `MaskType` 命名空间下的值

### `__repr__()` 和 `__str__()`

- `repr(value)` 返回 `MaskTypeValue('...')`
- `str(value)` 返回原始模式名，例如 `ALL`、`VL8`、`M3`

### 相等性

- 同一对象比较会得到 `True`
- 两个 `MaskTypeValue` 按 `.name` 比较
- 和任何非 `MaskTypeValue` 对象比较都会抛出 `TypeError`

实际含义：

- `MaskTypeValue` 更像是严格的枚举 token，而不是普通字符串

## 5. `MaskType`

`MaskType` 是一个枚举风格命名空间，暴露了一组可复用的 `MaskTypeValue` 预设。

这些预设控制新建 `MaskReg` 时的初始 lane bits。当前模拟器行为如下：

- `MaskType.ALL`
  - 所有 lane 激活
- `MaskType.NONE`
  - 没有任何 lane 激活
- `MaskType.LOWEST1`
  - 最低 1 个 lane 激活
- `MaskType.LOWEST2`
  - 最低 2 个 lane 激活
- `MaskType.LOWEST3`
  - 最低 3 个 lane 激活
- `MaskType.LOWEST4`
  - 最低 4 个 lane 激活
- `MaskType.LOWEST8`
  - 最低 8 个 lane 激活
- `MaskType.LOWEST16`
  - 最低 16 个 lane 激活
- `MaskType.LOWEST32`
  - 最低 32 个 lane 激活
- `MaskType.LOWEST128`
  - 最低 128 个 lane 激活，并按该 dtype 的 lane 数做截断
- `MaskType.LOWHALF`
  - 最低一半 lane 激活
- `MaskType.LOWQUAT`
  - 最低四分之一 lane 激活
- `MaskType.MULTI3`
  - 每隔 3 个 lane 激活一个：`0, 3, 6, ...`
- `MaskType.MULTI4`
  - 每隔 4 个 lane 激活一个：`0, 4, 8, ...`

示例：

```python
mask = MaskReg(DT.half, init_mode=MaskType.LOWEST8)
```

## 6. 实用使用说明

- 当你需要一个向量宽度的 micro 寄存器时，使用 `Reg`。
- 当你的算法天然按多行 / 多寄存器块组织，而且能展开成若干个等宽寄存器时，使用 `RegList`。
- `MaskReg` 既可以作为保存布尔 lane 状态的对象，也可以作为附着在 `RegOP` 上的执行 mask。
- 组合表达式时，优先使用 builder 形式：
  - `r2 <<= r0.abs()`
  - `r2 <<= mask * (r0 + r1)`
- 当你明确要加载、存储或原地修改状态时，优先使用命令式形式：
  - `r0 <<= ub`
  - `rows.fill(0.0)`
  - `mask.update(cnt)`
- 要记住，`RegList[i]` 是一个代理寄存器视图，不是一个单独持有存储的 Python 容器元素。
