# A5 Micro 掩码操作

本页文档说明 `a5` micro 掩码辅助能力中，除 compare/select 之外的部分。

覆盖的 API 包括：

- `mask_not`
- `mask_and`
- `mask_or`
- `mask_xor`
- `mask_mov`
- `mask_sel`
- `mask_interleave`
- `mask_deinterleave`
- `mask_pack`
- `mask_unpack`
- `move_mask_spr`
- `update_mask`

下面的描述依据：

- `easyasc/stub_functions/micro/mask.py` 中公开的 stub 接口
- `easyasc/simulator/micro/runtime/ops_mask.py` 中当前的模拟器行为
- `historical testcases/test_sim_micro_mask_ops.py` (removed from this skill bundle) 中当前的测试

本页所有函数都有这些共同点：

- 要求处在激活的 `@vf` 上下文中
- 操作对象是 `MaskReg`
- 使用的是逐 lane 的布尔 mask

## 1. 一元与二元 Mask 操作

这些辅助函数都作用于 `MaskReg` 中保存的布尔 lane mask。

一个重要区别是：

- `mask_not`、`mask_and`、`mask_or`、`mask_xor`、`mask_mov` 只会更新执行 mask 激活的 lane
- 被 mask 掉的 lane 会保留 `dst` 原有内容
- `mask_sel` 的行为不同，会在下面单独说明

### `mask_not(dst, src, mask=None)`

- 作用：把一个 mask 寄存器逐 lane 取反后写到另一个 mask 寄存器中。
- 参数：
  - `dst`：目标 `MaskReg`
  - `src`：源 `MaskReg`
  - `mask`：可选的执行 mask

行为：

```text
dst[i] = not src[i]   if exec_mask[i] is active
dst[i] = old dst[i]   otherwise
```

示例：

```python
mask_not(dst_mask, src_mask)
```

### `mask_and(dst, src1, src2, mask=None)`

- 作用：对两个 mask 寄存器做逻辑与。
- 参数：
  - `dst`：目标 `MaskReg`
  - `src1`、`src2`：源 `MaskReg`
  - `mask`：可选的执行 mask

行为：

```text
dst[i] = src1[i] and src2[i]   if exec_mask[i] is active
dst[i] = old dst[i]            otherwise
```

示例：

```python
mask_and(dst_mask, m0, m1)
```

### `mask_or(dst, src1, src2, mask=None)`

- 作用：对两个 mask 寄存器做逻辑或。
- 激活 lane 上的行为：
  - `src1[i] or src2[i]`
- 被 mask 掉的 lane 保留旧的目标值。
- 示例：

```python
mask_or(dst_mask, m0, m1)
```

### `mask_xor(dst, src1, src2, mask=None)`

- 作用：对两个 mask 寄存器做逻辑异或。
- 激活 lane 上的行为：
  - `src1[i] xor src2[i]`
- 被 mask 掉的 lane 保留旧的目标值。
- 示例：

```python
mask_xor(dst_mask, m0, m1)
```

### `mask_mov(dst, src, mask=None)`

- 作用：在执行 mask 控制下，把一个 mask 寄存器复制到另一个 mask 寄存器。
- 行为：

```text
dst[i] = src[i]       if exec_mask[i] is active
dst[i] = old dst[i]   otherwise
```

- 示例：

```python
mask_mov(dst_mask, src_mask)
```

### `mask_sel(dst, src1, src2, mask=None)`

- 作用：在两个 mask 寄存器之间做选择。
- 参数：
  - `dst`：目标 `MaskReg`
  - `src1`、`src2`：源 `MaskReg`
  - `mask`：可选的执行 mask

行为：

- 模拟器会先把 `src2` 整体复制到 `dst`
- 然后再用 `src1` 覆盖执行 mask 激活的 lane

等价规则：

```text
dst[i] = src1[i]   if exec_mask[i] is active
dst[i] = src2[i]   otherwise
```

一个重要的 alias 说明：

- 和寄存器版的 `select()` 不同，当前 `mask_sel()` 不会先快照源
- 如果你需要严格的 select 语义，最好避免让 `dst` 与 `src1` 或 `src2` 别名

示例：

```python
mask_sel(dst_mask, left_mask, right_mask, ctrl_mask)
```

本节所有操作的共同限制：

- 所有参与的 mask 寄存器 dtype 都必须一致

## 2. 多寄存器 Mask 路由

### `mask_interleave(dst0, dst1, src0, src1)`

- 作用：把两个源 mask 寄存器交错写入两个目标 mask 寄存器。
- 参数：
  - `dst0`、`dst1`：目标 `MaskReg`
  - `src0`、`src1`：源 `MaskReg`

行为：

- 模拟器会先快照两个源
- 设 `half = lane_count / 2`
- 对 `k in [0, half)`：
  - `dst0[2 * k]     = src0[k]`
  - `dst0[2 * k + 1] = src1[k]`
  - `dst1[2 * k]     = src0[half + k]`
  - `dst1[2 * k + 1] = src1[half + k]`

8 lane 示例：

```text
src0 = [a0, a1, a2, a3, a4, a5, a6, a7]
src1 = [b0, b1, b2, b3, b4, b5, b6, b7]

dst0 = [a0, b0, a1, b1, a2, b2, a3, b3]
dst1 = [a4, b4, a5, b5, a6, b6, a7, b7]
```

限制：

- 四个 mask 的 dtype 必须一致
- lane 数必须为偶数

### `mask_deinterleave(dst0, dst1, src0, src1)`

- 作用：把 `mask_interleave()` 形成的布局反向拆开。
- 参数：
  - `dst0`、`dst1`：目标 `MaskReg`
  - `src0`、`src1`：源 `MaskReg`

行为：

- 模拟器会先快照两个源
- 设 `half = lane_count / 2`
- 对 `k in [0, half)`：
  - `dst0[k]        = src0[2 * k]`
  - `dst1[k]        = src0[2 * k + 1]`
  - `dst0[half + k] = src1[2 * k]`
  - `dst1[half + k] = src1[2 * k + 1]`

示例：

```python
mask_deinterleave(out0, out1, in0, in1)
```

限制：

- 四个 mask 的 dtype 必须一致
- lane 数必须为偶数

## 3. Pack、Unpack 与控制

### `mask_pack(dst, src, low_part=True)`

- 作用：把源 mask 中的偶数 lane 压紧到目标 mask 的低半部分或高半部分。
- 参数：
  - `dst`：目标 `MaskReg`
  - `src`：源 `MaskReg`
  - `low_part`：为 `True` 时写到低半部分，为 `False` 时写到高半部分

行为：

- 模拟器会先快照 `src`
- 设 `half = lane_count / 2`
- 它会抽取 `src[0]`、`src[2]`、`src[4]`、...
- 如果 `low_part=True`，这些值会写到 `dst[0:half]`
- 如果 `low_part=False`，这些值会写到 `dst[half:lane_count]`
- 其余所有目标 lane 都会变成 `False`

8 lane 示例：

```text
src = [a0, a1, a2, a3, a4, a5, a6, a7]

mask_pack(..., low_part=True)  -> [a0, a2, a4, a6, 0,  0,  0,  0]
mask_pack(..., low_part=False) -> [0,  0,  0,  0,  a0, a2, a4, a6]
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- lane 数必须为偶数

### `mask_unpack(dst, src, low_part=True)`

- 作用：把压紧后的 mask 再展开回目标的偶数 lane。
- 参数：
  - `dst`：目标 `MaskReg`
  - `src`：源 `MaskReg`
  - `low_part`：为 `True` 时读取低半部分打包区，为 `False` 时读取高半部分

行为：

- 设 `half = lane_count / 2`
- 如果 `low_part=True`，模拟器读取 `src[0:half]`
- 如果 `low_part=False`，读取 `src[half:lane_count]`
- 这些值会写到 `dst[0]`、`dst[2]`、`dst[4]`、...
- 所有奇数目标 lane 都会变成 `False`

8 lane 示例：

```text
src = [p0, p1, p2, p3, q0, q1, q2, q3]

mask_unpack(..., low_part=True)  -> [p0, 0, p1, 0, p2, 0, p3, 0]
mask_unpack(..., low_part=False) -> [q0, 0, q1, 0, q2, 0, q3, 0]
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- lane 数必须为偶数

### `move_mask_spr(dst)`

- 作用：把 SPR 路径上的 mask 状态搬运到一个 mask 寄存器里。
- 参数：
  - `dst`：目标 `MaskReg`

当前模拟器状态：

- 模拟器尚未实现 `move_mask_spr()`
- 当前会抛出 `NotImplementedError`

示例：

```python
move_mask_spr(mask_reg)
```

### `update_mask(dst, cnt)`

- 作用：根据一个标量 lane 计数构造前缀 mask，并把这个计数更新到下一段。
- 参数：
  - `dst`：目标 `MaskReg`
  - `cnt`：dtype 为 `DT.uint32` 的 `Var`

行为：

- 设 `lane_count` 为 `dst.dtype` 对应的 lane 数
- 模拟器先计算：
  - `active_count = clamp(cnt, 0, lane_count)`
- 然后写：
  - `dst[0:active_count] = True`
  - `dst[active_count:] = False`
- 写完之后，再原地更新 `cnt`：
  - `cnt = max(cnt - lane_count, 0)`

这使得重复调用时，可以按“每次消费一个寄存器宽度的 chunk”的方式处理一个更长的逻辑计数。

`half` 示例：

```text
lane_count = 128
initial cnt = 300

call 1:
  dst = first 128 lanes active
  cnt becomes 172

call 2:
  dst = first 128 lanes active
  cnt becomes 44

call 3:
  dst = first 44 lanes active
  cnt becomes 0
```

示例用法：

```python
update_mask(mask_reg, lane_count_var)
```

限制：

- `dst` 必须是 `MaskReg`
- `cnt` 必须是 `Var`
- `cnt.dtype` 必须是 `DT.uint32`
