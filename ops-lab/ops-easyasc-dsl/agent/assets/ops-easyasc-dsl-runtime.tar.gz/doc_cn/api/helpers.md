# 杂项辅助

本页文档说明四个体量不大、但非常重要的辅助 API：

- `sim_print`
- `dump_tensor`
- `inline`
- `clean_dcache`

它们被归在一起，是因为它们既不是数据搬运原语，也不是同步原语，更不是数学原语；它们主要用于调试、观测，以及作为后端逃生口。

可用性概览：

- `inline`：`easyasc.a2` 和 `easyasc.a5` 都会导出
- `clean_dcache`：`easyasc.a2` 和 `easyasc.a5` 都会导出
- `sim_print`：只在 `easyasc.a5` 中导出
- `dump_tensor`：只在 `easyasc.a5` 中导出

另外，这几个辅助在模拟器模式和 codegen 模式下的行为差异非常大，所以阅读时首先要记住这一点。

## 1. `sim_print(*args, pipe=Pipe.S)`

- 作用：打印附着到某条 pipe 或主循环上的模拟器调试信息。
- 参数：
  - `*args`：任意需要输出的内容
  - `pipe`：`PipeType`，默认值是 `Pipe.S`
- 校验：
  - `pipe` 必须是 `PipeType`
- 指令发射：
  - 会发射 `Instruction("sim_print", payload=list(args), pipe=pipe)`

### 在模拟器模式下做什么

当模拟器执行到这条指令时：

- 传入内容会尽可能先解析成可打印的运行时值
- `Var`、`Expr` 这类 DSL 标量对象也会先被解析
- 最终消息会把所有内容项用空格拼接起来

日志前缀取决于当前执行侧：

- cube：
  - `[cube][core=<core_idx>] ...`
  - 如果 `pipe != Pipe.S`，还会额外带上 `[pipe=<pipe>]`
- vec：
  - `[vec][core=<core_idx>][subblock=<subblock_idx>] ...`
  - 如果 `pipe != Pipe.S`，同样会额外带上 `[pipe=<pipe>]`

因此像下面这样的调用：

```python
sim_print("row_count", row_count, pipe=Pipe.V)
```

概念上可能会输出一行类似：

```text
[vec][core=0][subblock=1][pipe=V] row_count 32
```

### 在 codegen 模式下做什么

`sim_print` 是一个有意设计成“只在模拟器里有效”的 API。

它对应的 parser handler 是 no-op：

- 不会发射任何后端 C++ 代码
- 也不会生成任何运行时打印辅助

这意味着：

- `sim_print` 适合本地模拟器调试
- 不应把它视作生成 kernel 可观察行为的一部分

### pipe 语义

`pipe` 决定打印附着在哪个执行域上：

- `Pipe.S`
  - 打印附着在主循环侧
  - 适合看标量状态、控制流和同步逻辑
- 非 `S` pipe
  - 打印会尽量附着到对应的 pipe 队列上
  - 适合观察某个 producer / consumer pipe 真正到达某一点的时机

一个实用理解是：

- `pipe=Pipe.S` 更适合高层调试
- `pipe=Pipe.MTE2`、`Pipe.V`、`Pipe.M`、`Pipe.FIX` 等更适合看 pipe 局部时序

### 可以打印什么

API 接受任意 Python 对象，但最有用的输出内容通常是：

- 字符串
- `int`、`float`、`bool`
- `Var` 和 `Expr`
- `PipeType`
- 较短的标量风格 tuple / list

如果你想看大张量内容，`sim_print` 并不合适，应该用 `dump_tensor`。

### 常见用途

- 查看循环计数器或推导出来的 tile 大小
- 确认哪条 pipe 先到达某个点
- 调试跨侧或事件顺序
- 查看规约或形状计算后的标量值

### 示例：控制侧调试

```python
sim_print("tile", tile_idx, "valid_m", valid_m, pipe=Pipe.S)
```

当你关心的是标量信息，而且它更属于调度器 / 主循环视角时，这种写法最合适。

### 示例：pipe 局部调试

```python
sim_print("issued gm_to_ub for tile", tile_idx, pipe=Pipe.MTE2)
sim_print("starting vec postprocess", tile_idx, pipe=Pipe.V)
```

如果你想让模拟器日志显式带上 pipe 身份，这种写法会很有帮助。

## 2. `dump_tensor(tensor, filename, pipe)`

- 作用：在模拟执行期间，把某个运行时张量视图导出到磁盘。
- 参数：
  - `tensor`：源 `Tensor`
  - `filename`：输出文件名字符串
  - `pipe`：`PipeType`
- 校验：
  - `tensor` 必须是 `Tensor`
  - `filename` 必须是 `str`
  - `pipe` 必须是 `PipeType`
  - `pipe` 不能是 `Pipe.ALL`
- 指令发射：
  - 会发射 `Instruction("dump_tensor", tensor=tensor, filename=filename, pipe=pipe)`

### 会导出什么

执行时，模拟器会：

- 解析当前运行时张量视图
- 克隆它
- 用 `torch.save(...)` 把它写出去

因此，文件里保存的是已经解析好的运行时张量内容，而不是一个符号 DSL 对象。

这有几个重要含义：

- 切片、reinterpret 视图、转置元数据以及当前 offset，都已经体现在运行时视图中
- 导出的数据对应的是这个程序点可见的那份张量视图
- 后续再修改张量，也不会改变已经写出的文件

### 在 codegen 模式下做什么

和 `sim_print` 一样，`dump_tensor` 在 codegen 期间也是 no-op：

- parser handler 不会发射任何代码
- 生成后的后端代码里也不会包含这条操作

因此 `dump_tensor` 是模拟器调试工具，而不是生成 kernel 的功能。

### pipe 语义

`pipe` 决定这条 dump 指令在哪个执行域上执行：

- `Pipe.S`
  - dump 由主循环执行
- 非 `S` pipe
  - dump 会在支持的情况下被派发到对应的 pipe 队列

如果你想抓住“某条 pipe 真正走到这里时”的张量状态，而不是“主循环走到这里时”的状态，这个区别就很重要。

`Pipe.ALL` 会被拒绝，因为 tensor dump 是一次单独执行动作，而不是一种 all-pipe barrier。

### 模拟器里的具体行为

cube 和 vec 模拟器都支持两条路径：

- 主循环路径：
  - 如果 `pipe == Pipe.S`，模拟器会立即解析运行时张量并调用 `torch.save`
- 派发到 pipe 的路径：
  - 否则，这条指令会先进入目标 pipe 队列
  - 当该 pipe 执行到它时，再执行同样的 `torch.save(tensor.detach().clone(), filename)`

如果所选 pipe 在当前模拟器侧不受支持，会报错，例如：

- `dump_tensor has unsupported pipe on cube simulator: ...`
- `dump_tensor has unsupported pipe on vec simulator: ...`

### 文件名行为

`filename` 会原样传给 `torch.save`。

实用建议：

- 文件名尽量明确且唯一
- 如果会 dump 多个阶段，建议把 tile 或 stage 信息写进文件名
- 注意同一路径重复 dump 会覆盖之前的文件

### 常见用途

- 查看 vec 数学之后的中间 UB 数据
- 在同步边界附近抓取 L1 / UB 交接结果
- 把模拟器状态和 Python 参考实现做离线对比
- 调试 reinterpret 或打包搬运这类对布局很敏感的操作

### 示例：在 vec 处理后导出 UB 张量

```python
dump_tensor(ub_out, "ub_out_tile0.pt", Pipe.V)
```

含义：

- 把 dump 挂到 `V` pipe
- 当 `V` pipe 真正执行到这里时，保存 `ub_out` 当前的运行时视图

### 示例：从主循环导出

```python
dump_tensor(ub_mid, "ub_mid_mainloop.pt", Pipe.S)
```

当你希望 dump 和控制流对齐，而不是和某条 pipe 队列对齐时，用这种写法。

## 3. `inline(code)`

- 作用：把原始后端代码直接注入到生成结果里。
- 参数：
  - `code`：包含一行或多行后端代码的字符串
- 校验：
  - `code` 必须是 `str`
  - `inline` 不允许出现在 `@vf` 上下文中
- 指令发射：
  - 会发射 `Instruction("inline", code=code)`

`inline` 和 `sim_print`、`dump_tensor` 的根本区别在于：

- 它只在 codegen 模式下有意义
- 模拟器会完全忽略它

### 在 codegen 模式下做什么

parser handler 会把这个字符串逐行直接发射到生成后的后端输出中。

具体行为：

- 如果 `code == ""`，会发出一个空行
- 否则，会把 `code.splitlines()` 得到的每一行原样输出
- DSL 这一层不会做语法检查

也就是说，`inline` 真的是一个逃生口：框架会把你给的文本原样插到 lowering 后的位置。

### 在模拟器模式下做什么

cube 和 vec 模拟器都会完全忽略 `inline`：

- 它不会影响运行时状态
- 不会打印任何内容
- 也不会改变调度

因此，绝不要依赖 `inline` 去产生任何模拟器可见行为。

### 为什么 `@vf` 会拒绝它

`inline` 被禁止出现在 `@vf` 中，是因为 micro module 预期应通过框架的结构化 micro API 生成路径去 lowering，而不是在 micro DSL 内部注入任意后端文本。

如果你确实缺一个 micro 能力，通常更合适的修复方式是：

- 增加一个正式的 DSL helper 和 lowering 路径
- 或者只有在没有更好结构化替代方案时，才从 kernel 作用域使用 `inline`

### 常见用途

- 临时性的后端实验
- 在生成代码里插入自定义注释或标记
- 桥接一个目前还没有一等 DSL helper 的后端能力

框架内部自己也会在一些自动插入的声明附近，用 `inline` 打标记。

### 风险与限制

- 你写进去的是后端相关文本
- DSL 层不会帮你校验语义
- 模拟器也帮不了你验证行为
- 如果周围生成结构后续发生变化，注入代码也可能随之过时

这也是为什么 `inline` 应该是最后手段，而不是常规作者工具。

### 示例：插入一条后端注释

```python
inline("// custom marker before manual backend fragment")
```

这是最安全的使用方式，因为它不会改变运行时语义。

### 示例：多行注入

```python
inline(
    "int local_debug_value = 3;\n"
    "(void)local_debug_value;"
)
```

handler 会把这两行原样输出到生成结果中。

## 4. `clean_dcache(dst, entire_type=EntireType.single, dcci_dst=DcciDst.all, mode="all")`

- 作用：为某个 GM tensor 目标发射显式的后端数据缓存 clean-and-invalidate 调用。
- 参数：
  - `dst`：目标 `GMTensor`
  - `entire_type`：`EntireTypeValue`，默认值为 `EntireType.single`
  - `dcci_dst`：`DcciDstType`，默认值为 `DcciDst.all`
  - `mode`：`str`，默认值为 `"all"`，必须是 `"all"`、`"vec"`、`"cube"` 之一
- 校验：
  - `dst` 必须是 `GMTensor`
  - `entire_type` 必须是 `EntireTypeValue`
  - `dcci_dst` 必须是 `DcciDstType`
  - `mode` 必须是 `str`
  - `mode` 必须是 `"all"`、`"vec"`、`"cube"` 之一
- 指令发射：
  - 会发射 `Instruction("clean_dcache", dst=dst, entire_type=entire_type, dcci_dst=dcci_dst, mode=mode)`

### 在 codegen 模式下做什么

parser lowering 会生成如下形式的后端调用：

```text
DataCacheCleanAndInvalid<{dst_dtype}, AscendC::CacheLine::{entire_type}, AscendC::DcciDst::{dcci_dst}>({dst_expr});
```

例如：

```python
clean_dcache(global_out, EntireType.entire, DcciDst.atomic)
```

概念上会 lowering 成：

```text
DataCacheCleanAndInvalid<float, AscendC::CacheLine::ENTIRE_DATA_CACHE, AscendC::DcciDst::CACHELINE_ATOMIC>(global_out);
```

其中 dtype 来自 `dst.dtype`，最后一个实参是 `dst` 对应的 GM tensor lowering 表达式。

`mode` 参数用于控制 backend 调用会生成到哪一侧 split 代码里：

- `mode="all"`：同时生成到 cube 和 vec 两侧
- `mode="vec"`：只生成到 vec 侧
- `mode="cube"`：只生成到 cube 侧

### 在模拟器模式下做什么

模拟器会完全忽略 `clean_dcache`：

- 不会改写 tensor 载荷
- 不会改变调度
- 不会模拟 cache 状态

因此目前 `clean_dcache` 是一个只在 codegen 中生效的 helper。

### 常见用途

- 桥接 DSL 需要显式调用的后端 cache 维护原语
- 用 `EntireType.single` 或 `EntireType.entire` 选择 cache-line 作用范围
- 用 `DcciDst.all`、`DcciDst.ub`、`DcciDst.out`、`DcciDst.atomic` 选择目标策略

## 5. 如何在四者之间选择

在下面这些情况下使用 `sim_print`：

- 你想要轻量级的模拟器日志输出
- 你关心的内容主要是标量或文本

在下面这些情况下使用 `dump_tensor`：

- 你需要真实的运行时张量内容
- 你想用 `torch.load` 离线检查数据

在下面这些情况下使用 `inline`：

- 你在 codegen 时需要一个后端逃生口
- DSL 目前还没有暴露你所需要的操作

在下面这些情况下使用 `clean_dcache`：

- 你需要在生成后的 kernel 里显式发出 cache clean/invalidate 调用
- 你希望这个调用保持结构化，而不是手写成 `inline`

## 6. 常见坑

- 不要期待 `sim_print` 或 `dump_tensor` 出现在生成后的后端代码里；它们在 codegen 中的 handler 都是 no-op。
- 不要期待 `inline` 改变模拟器行为；模拟器会明确忽略它。
- 不要期待 `clean_dcache` 改变模拟器结果；它在 simulation 中会被有意跳过。
- 不要使用 `dump_tensor(..., pipe=Pipe.ALL)`；dump 是单次执行动作，不是 all-pipe barrier。
- 不要把 `inline` 放进 `@vf`；stub 会在发射指令前直接拒绝。
- 不要拿 `sim_print` 去打印大张量；它适合小型调试负载，真正要看张量内容请用 `dump_tensor`。
