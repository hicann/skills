# 流程控制

本页文档说明 `easyasc` 公开接口中共享的流程控制辅助函数。

这些辅助用来表达：

- DSL 循环
- 编写阶段展开
- DSL 条件分支

## 1. `range(*args, name="")`

- 作用：发射一个 DSL 循环变量，以及与之对应的循环指令。
- 参数：
  - `*args`：1 到 3 个位置参数，含义与 Python `range` 一致
  - `name`：可选的循环变量名覆盖
- 限制：
  - 接受的参数类型是 `int` 和 `Var`
  - `step` 不能为零
  - 这不是 Python 内置的 `range`；只能在 kernel 或 micro 编写代码中使用
- 示例：

```python
for m in range(0, M, 128, name="m"):
    ...
```

## 2. `unroll(*args)`

- 作用：返回 Python 内置的 `range`，用于编写阶段展开，而不是发射 DSL 循环。
- 参数：
  - `*args`：含义与 Python `range` 相同
- 限制：
  - 和 `range(...)` 不同，它不会发射循环指令
- 示例：

```python
for i in unroll(4):
    regs[i] <<= 0
```

## 3. `If(cond)`、`Elif(cond)`、`Else()`

- 作用：用上下文管理器形式编码 DSL 控制流。
- 参数：
  - `cond`：`If` 和 `Elif` 的条件表达式
- 限制：
  - 只能在 kernel 或 micro 代码中使用
  - `Elif` 和 `Else` 必须直接跟在某个 `If` 或前一个 `Elif` 之后
- 示例：

```python
with If(valid_m > 0):
    z[:, :] <<= ub
with Else():
    inline("// no-op")
```

原生 Python 语法：

- 在会被框架 AST 改写流程处理的函数里，你也可以直接写普通的 Python `if / elif / else`
- 在被装饰函数的分析阶段，`easyasc.pythonic` 会把这些原生分支改写成基于 `If(...)`、`Elif(...)` 和 `Else()` 的 DSL 形式
- 实际上，这意味着下面两种写法在 kernel 编写时是等价的：

```python
if valid_m > 0:
    z[:, :] <<= ub
else:
    inline("// no-op")
```

以及：

```python
with If(valid_m > 0):
    z[:, :] <<= ub
with Else():
    inline("// no-op")
```

说明：

- 只有当函数体能被框架的 source-to-AST 变换拿到时，这种改写才会发生
- 被改写的是 `if / elif / else` 语法；本页只是在说明这些原生语法最终映射到的那层显式 DSL 接口
