# 流程控制

本页文档说明 `easyasc` 公开接口中共享的流程控制辅助函数。

这些辅助用来表达：

- DSL 循环
- 编写阶段展开
- DSL 循环内部的退出控制
- DSL 条件分支

## 1. `range(*args, name="")`

- 作用：发射一个 DSL 循环变量，以及与之对应的循环指令。
- 参数：
  - `*args`：1 到 3 个位置参数，含义与 Python `range` 一致
  - `name`：可选的循环变量名覆盖
- 限制：
  - 接受的参数类型是 `int` 和 `Var`
  - `step` 不能为零
  - 这不是 Python 内置的 `range`；只能在 kernel 或 micro 编写代码中使用
- 示例：

```python
for m in range(0, M, 128, name="m"):
    ...
```

## 2. `unroll(*args)`

- 作用：返回 Python 内置的 `range`，用于编写阶段展开，而不是发射 DSL 循环。
- 参数：
  - `*args`：含义与 Python `range` 相同
- 限制：
  - 和 `range(...)` 不同，它不会发射循环指令
- 示例：

```python
for i in unroll(4):
    regs[i] <<= 0
```

## 3. `break_()` 与 `continue_()`

- 作用：为当前激活的 DSL `range(...)` 循环发射退出控制指令。
- 限制：
  - 只能在 kernel 或 micro 代码中使用
  - 语义上面向 `easyasc.flowcontrol.range(...)` 创建出来的 DSL 循环
  - 如果你在被改写的 DSL `range(...)` 循环里直接写原生 Python `break` / `continue`，框架会自动把它们改写成这两个 helper
  - 如果在 `unroll(...)` 循环里写原生 Python `break` / `continue`，改写阶段会直接拒绝
- 示例：

```python
for m in range(0, M, 128):
    if valid_m == 0:
        break
    if skip_tile:
        continue
```

这里发射的是 `break_loop` / `continue_loop` 指令，而不是 Python 解释器层面的普通循环控制。

## 4. `If(cond)`、`Elif(cond)`、`Else()`

- 作用：用上下文管理器形式编码 DSL 控制流。
- 参数：
  - `cond`：`If` 和 `Elif` 的条件表达式
- 限制：
  - 只能在 kernel 或 micro 代码中使用
  - `Elif` 和 `Else` 必须直接跟在某个 `If` 或前一个 `Elif` 之后
- 示例：

```python
with If(valid_m > 0):
    z[:, :] <<= ub
with Else():
    inline("// no-op")
```

原生 Python 语法：

- 在会被框架 AST 改写流程处理的函数里，你也可以直接写普通的 Python `if / elif / else`
- 在被装饰函数的分析阶段，`easyasc.pythonic` 会把这些原生分支改写成基于 `If(...)`、`Elif(...)` 和 `Else()` 的 DSL 形式
- 实际上，这意味着下面两种写法在 kernel 编写时是等价的：

```python
if valid_m > 0:
    z[:, :] <<= ub
else:
    inline("// no-op")
```

以及：

```python
with If(valid_m > 0):
    z[:, :] <<= ub
with Else():
    inline("// no-op")
```

对于那些在求值过程中本身会发射 DSL 指令的条件表达式，原生语法同样受支持，例如：

```python
if valid > 0:
    ...
elif GetSubBlockIdx() == 0:
    ...
else:
    ...
```

以及：

```python
if valid > 0:
    ...
else:
    if GetSubBlockIdx() == 0:
        ...
```

如果你写的是真正的嵌套 `else: if ...`，改写会保留嵌套结构；如果你写的是 `elif`，框架会延迟 `elif` 条件的求值时机，以保证最终发射出的 DSL 指令仍然满足 `If -> Elif` 的链式结构。

说明：

- 只有当函数体能被框架的 source-to-AST 变换拿到时，这种改写才会发生
- 被改写的是 `if / elif / else` 语法；本页只是在说明这些原生语法最终映射到的那层显式 DSL 接口
