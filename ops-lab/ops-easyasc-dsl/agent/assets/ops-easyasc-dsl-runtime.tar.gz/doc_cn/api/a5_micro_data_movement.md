# A5 Micro 数据搬运
本页文档说明 `easyasc.a5` 直接导出的 micro 侧数据搬运辅助能力。

下面的描述同时依据以下两部分：

- `easyasc/stub_functions/micro/datamove.py` 中公开的 stub 接口
- `easyasc/simulator/micro/runtime/ops_data.py` 与 `easyasc/simulator/micro/runtime/ops_vector.py` 中当前的模拟器行为

本页所有函数都有这些共同点：
- 要求处在激活的 `@vf` 上下文中
- 操作对象包括 `Reg`、`MaskReg` 和 UB `Tensor`
- 在计算地址时，会把 UB tensor 视为展平后的 1D 视图

## 1. 这些 API 使用的寄存器几何

下面很多行为都依赖 micro 寄存器的 lane 数，
以及硬件上的 `C0` block 大小。

- `lane_count = 256 / dtype_size_in_bytes`
- `c0 = 32 / dtype_size_in_bytes`

常见情况如下：

| dtype | 元素大小 | lane 数 | `C0` 大小 |
| --- | --- | --- | --- |
| `int8` / `uint8` | 1 字节 | 256 lane | 32 lane |
| `half` / `bfloat16` | 2 字节 | 128 lane | 16 lane |
| `float` / `int32` | 4 字节 | 64 lane | 8 lane |

这很重要，因为：

- `ub_to_reg()` 和 `reg_to_ub()` 会把 `blk_stride` 解释为以 `C0` block 为单位的步长
- 这类 block copy API 会把 mask 扩展到整个 `C0` block
- `LoadDist.BRCB` 会把一个标量重复到整个 `C0` block 上

## 2. 分布模式对象

### `LoadDist`

- 作用：为 `ub_to_reg_continuous()` 选择一种行为模式。
- 参数含义：
  - `loaddist`：决定一个展平后的 UB 源流如何被展开或重排到一个寄存器里

可用值如下：

| API 值 | 模拟器模式 | 支持的元素宽度 | 行为 |
| --- | --- | --- | --- |
| `LoadDist.DOWNSAMPLE` | `DIST_DS_B8`, `DIST_DS_B16` | 8 位、16 位 | 每隔一个源元素读一个。 |
| `LoadDist.UPSAMPLE` | `DIST_US_B8`, `DIST_US_B16` | 8 位、16 位 | 每个源元素重复两次。 |
| `LoadDist.SINGLE_VALUE` | `DIST_BRC_B8`, `DIST_BRC_B16`, `DIST_BRC_B32` | 8 位、16 位、32 位 | 把 `src[0]` 广播到所有寄存器 lane。 |
| `LoadDist.BRCB` | `DIST_E2B_B16`, `DIST_E2B_B32` | 16 位、32 位 | 每个源元素广播到一个完整 `C0` block。 |
| `LoadDist.UNPACK` | `DIST_UNPACK_B8`, `DIST_UNPACK_B16`, `DIST_UNPACK_B32` | 8 位、16 位、32 位 | 把源值写到偶数 lane，奇数 lane 补零。 |
| `LoadDist.UNPACK4` | `DIST_UNPACK4_B8` | 仅 8 位 | 把源值写到 `0, 4, 8, ...` 这些 lane，其余 lane 补零。 |

行为细节：

- `DOWNSAMPLE`：
  - 要求源长度为 `lane_count * 2`
  - 公式：`dst[i] = src[2 * i]`
- `UPSAMPLE`：
  - 要求源长度为 `lane_count / 2`
  - 要求 `lane_count` 为偶数
  - 公式：`dst[2 * i] = src[i]`，`dst[2 * i + 1] = src[i]`
- `SINGLE_VALUE`：
  - 要求源长度为 `1`
  - 公式：`dst[i] = src[0]`
- `BRCB`：
  - 要求源长度为 `lane_count / c0`
  - 要求 `lane_count % c0 == 0`
  - 公式：对 block `b`，`dst[b * c0 : (b + 1) * c0] = src[b]`
- `UNPACK`：
  - 要求源长度为 `lane_count / 2`
  - 要求 `lane_count` 为偶数
  - 公式：`dst[2 * i] = src[i]`，`dst[2 * i + 1] = 0`
- `UNPACK4`：
  - 要求源长度为 `lane_count / 4`
  - 要求 `lane_count % 4 == 0`
  - 公式：`dst[4 * i] = src[i]`，其余所有 lane 都为 `0`

简单例子：

```text
LoadDist.DOWNSAMPLE
src = [10, 11, 12, 13, 14, 15, 16, 17, ...]
dst = [10, 12, 14, 16, ...]
```

```text
LoadDist.UPSAMPLE
src = [5, 6, 7, 8]
dst = [5, 5, 6, 6, 7, 7, 8, 8]
```

```text
LoadDist.BRCB with half
lane_count = 128, c0 = 16
src = [1, 2, 3, 4, 5, 6, 7, 8]
dst[0:16]    = 1
dst[16:32]   = 2
dst[32:48]   = 3
...
dst[112:128] = 8
```

示例用法：

```python
reg = Reg(DT.half)
src = Tensor(DT.half, [1, 8], Position.UB)
ub_to_reg_continuous(reg, src, LoadDist.BRCB)
```

### `LoadDistValue`

- 作用：`LoadDist.*` 成员背后真正对应的具体值类型。
- 实际用法：
  - 通常不需要手动构造它
  - 而是传 `LoadDist.DOWNSAMPLE`、`LoadDist.BRCB`、`LoadDist.UNPACK`、`LoadDist.SINGLE_VALUE` 这些预定义值

它存在的原因是：

- 公开 API 通过 `LoadDist` 命名空间暴露易读的名字
- 底层 stub 和模拟器实际接收到的是这些名字背后的 `LoadDistValue`

实践规则：

- 在 kernel 代码里使用 `LoadDist.*`
- 把 `LoadDistValue` 视为实现层的值类型，它主要出现在底层文档、类型检查和调试输出里

示例：

```python
mode = LoadDist.SINGLE_VALUE
ub_to_reg_continuous(dst_reg, src_ub, mode)
```

### `StoreDist`

- 作用：为 `reg_to_ub_continuous()` 选择一种行为模式。
- 参数含义：
  - `storedist`：决定寄存器 lane 如何被压缩或写入展平后的 UB 目标

可用值如下：

| API 值 | 模拟器模式 | 支持的元素宽度 | 行为 |
| --- | --- | --- | --- |
| `StoreDist.DOWNSAMPLE` | `DIST_PACK_B16`, `DIST_PACK_B32`, `DIST_PACK_B64` | 8 位、16 位、32 位 | 把源寄存器中隔一个 lane 取一个，压紧后写入目标。 |
| `StoreDist.PACK4` | `DIST_PACK4_B32` | 仅 8 位 | 每隔 4 个 lane 取一个，压紧后写入目标。 |
| `StoreDist.SINGLE_VALUE` | `DIST_FIRST_ELEMENT_B8`, `DIST_FIRST_ELEMENT_B16`, `DIST_FIRST_ELEMENT_B32` | 8 位、16 位、32 位 | 只存 lane `0`。 |
| `StoreDist.NORMAL` | `DIST_NORM_B8`, `DIST_NORM_B16`, `DIST_NORM_B32` | 8 位、16 位、32 位 | 1:1 存储所有 lane。 |

行为细节：

- `DOWNSAMPLE`：
  - 目标长度至少要有 `lane_count / 2`
  - 要求 `lane_count` 为偶数
  - 公式：`dst[i] = src[2 * i]`
- `PACK4`：
  - 目标长度至少要有 `lane_count / 4`
  - 要求 `lane_count % 4 == 0`
  - 公式：`dst[i] = src[4 * i]`
- `SINGLE_VALUE`：
  - 目标长度至少要有 `1`
  - 公式：`dst[0] = src[0]`
- `NORMAL`：
  - 目标长度至少要有 `lane_count`
  - 公式：`dst[i] = src[i]`

连续写回时的 mask 行为：

- `reg_to_ub_continuous()` 会先解析源 mask
- 然后把 mask 扩展到整个 `C0` block
- 之后所选的模式会从这个扩展后的 mask 上取样
- 目标中没有被选中的位置会保留原有值

示例：

```text
StoreDist.DOWNSAMPLE
src = [10, 11, 12, 13, 14, 15, 16, 17]
dst = [10, 12, 14, 16]
```

```text
StoreDist.PACK4
src = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
dst = [0, 4, 8]
```

示例用法：

```python
reg = Reg(DT.int8)
dst = Tensor(DT.int8, [1, 64], Position.UB)
reg_to_ub_continuous(dst, reg, None, StoreDist.PACK4)
```

### `StoreDistValue`

- 作用：`StoreDist.*` 成员背后真正对应的具体值类型。
- 实际用法：
  - 通常不需要手动构造它
  - 而是传 `StoreDist.NORMAL`、`StoreDist.DOWNSAMPLE`、`StoreDist.PACK4`、`StoreDist.SINGLE_VALUE` 这些预定义值

它存在的原因是：

- 公开 API 通过 `StoreDist` 命名空间提供易读的模式名
- 底层 stub 和模拟器实际接收到的是对应的 `StoreDistValue`

实践规则：

- 在 kernel 代码里使用 `StoreDist.*`
- 把 `StoreDistValue` 看作这些导出名字之下的实现层值类型

示例：

```python
mode = StoreDist.NORMAL
reg_to_ub_continuous(dst_ub, src_reg, None, mode)
```

## 3. 基础 UB / 寄存器传输

### `ub_to_reg(dst, src, blk_stride=1, mask=None)`

- 作用：把一个 UB tensor 读入一个寄存器。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 UB `Tensor`
  - `blk_stride`：展平后源视图中，相邻被拷贝 `C0` block 之间的距离
  - `mask`：可选的 `MaskReg`

寻址方式：

- 当 `blk_stride == 1` 且 mask 为全开时，模拟器会走快速的连续拷贝：
  - `dst[i] = src_flat[i]`
- 否则，地址按 `C0` 大小的 block 计算：
  - `src_index(i) = (i // c0) * (blk_stride * c0) + (i % c0)`

`blk_stride` 的解释：

- `blk_stride = 1`：复制相邻的 `C0` block
- `blk_stride = 2`：复制一个 `C0` block，跳过一个 `C0` block，再复制下一个
- `blk_stride = 3`：复制一个 `C0` block，跳过两个 `C0` block，以此类推

Mask 行为：

- 对 `ub_to_reg()` 来说，mask 会扩展到整个 `C0` block
- 只要某个 `C0` block 里任意一个 lane 被启用，整个 block 都会被复制
- 没有被 mask 选中的 lane，会在 `dst` 中被清零

示例：`half` 上的 `blk_stride`

```text
dtype = half
lane_count = 128
c0 = 16
blk_stride = 2

dst lanes   0..15  <- src lanes   0..15
dst lanes  16..31  <- src lanes  32..47
dst lanes  32..47  <- src lanes  64..79
dst lanes  48..63  <- src lanes  96..111
...
```

等价公式：

```text
src_index(i) = (i // 16) * 32 + (i % 16)
```

示例：`half` 上的 `MaskType.LOWEST1`

```text
lane_count = 128, c0 = 16
LOWEST1 initially enables only lane 0
after C0 expansion, lanes 0..15 become active

result:
dst[0:16]   = src[0:16]
dst[16:128] = 0
```

示例用法：

```python
reg = Reg(DT.half)
src = Tensor(DT.half, [1, 256], Position.UB)
mask = MaskReg(DT.half, init_mode=MaskType.ALL)
ub_to_reg(reg, src, blk_stride=2, mask=mask)
```

限制：

- `src.position` 必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- `blk_stride` 必须为正
- 展平后的源视图必须足够大，能够覆盖计算出的最高地址

### `reg_to_ub(dst, src, blk_stride=1, mask=None)`

- 作用：把一个寄存器写回 UB tensor。
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：源 `Reg`
  - `blk_stride`：展平后目标视图中，相邻被写入 `C0` block 之间的距离
  - `mask`：可选的 `MaskReg`

寻址方式：

- 当 `blk_stride == 1` 且 mask 为全开时，模拟器会走快速连续写：
  - `dst_flat[i] = src[i]`
- 否则，地址采用和 `ub_to_reg()` 相同的 `C0` block 规则：
  - `dst_index(i) = (i // c0) * (blk_stride * c0) + (i % c0)`

Mask 行为：

- mask 会扩展到整个 `C0` block
- 只有激活 lane 会被写入
- 没有被写到的目标位置会保留原有值

示例：`half` 上的 `blk_stride`

```text
dtype = half
lane_count = 128
c0 = 16
blk_stride = 2

dst lanes   0..15   <- src lanes   0..15
dst lanes  32..47   <- src lanes  16..31
dst lanes  64..79   <- src lanes  32..47
dst lanes  96..111  <- src lanes  48..63
...
```

等价公式：

```text
dst_index(i) = (i // 16) * 32 + (i % 16)
```

示例用法：

```python
reg = Reg(DT.half)
dst = Tensor(DT.half, [1, 256], Position.UB)
reg_to_ub(dst, reg, blk_stride=2)
```

限制：

- `dst.position` 必须是 `Position.UB`
- `dst.dtype` 必须等于 `src.dtype`
- `blk_stride` 必须为正
- 展平后的目标视图必须足够大，能够覆盖计算出的最高地址

### `ub_to_reg_continuous(dst, src, loaddist)`

- 作用：按预定义的分布模式，把展平后的 UB 数据流加载到一个寄存器中。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 UB `Tensor`
  - `loaddist`：一个 `LoadDist` 值

行为概述：

- 这个 API 不接收 mask
- 总是从 `src_flat[0]` 开始读
- 所选的 `LoadDist` 决定要消耗多少源元素，以及这些元素如何映射到 `dst` 的 lane 上

示例：

```python
ub_to_reg_continuous(reg, src, LoadDist.DOWNSAMPLE)
ub_to_reg_continuous(reg, src, LoadDist.UNPACK)
ub_to_reg_continuous(reg, src, LoadDist.BRCB)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- 所选模式必须支持该 dtype 宽度
- 展平后的源数据必须提供该模式所需的元素数

### `reg_to_ub_continuous(dst, src, mask, storedist)`

- 作用：按预定义的压缩写回模式，把寄存器写到展平后的 UB 数据流中。
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：源 `Reg`
  - `mask`：可选的 `MaskReg`
  - `storedist`：一个 `StoreDist` 值

行为概述：

- 所选的 `StoreDist` 会先决定哪些源 lane 参与本次写回
- 源 mask 再应用到这些参与的 lane 上
- 被写入的目标位置会从 `dst_flat[0]` 开始按压紧后的顺序排布
- 没有被模式或 mask 选中的目标位置会保留原值

详细示例：带部分 mask 的 `StoreDist.DOWNSAMPLE`

```text
src = [10, 11, 12, 13, 14, 15, 16, 17]
mode samples lanes [0, 2, 4, 6]

if the active sampled lanes are [0, 4, 6]
then dst receives:
dst[0] = 10
dst[1] = 14
dst[2] = 16

the next compact destination position is not written at all
```

示例：

```python
reg_to_ub_continuous(dst, reg, None, StoreDist.NORMAL)
reg_to_ub_continuous(dst, reg, mask, StoreDist.DOWNSAMPLE)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- 所选模式必须支持该 dtype 宽度
- 展平后的目标必须足够大，能容纳最高的压缩写回索引

## 4. 便捷传输包装

这些包装函数只是帮你选好了一个 `LoadDist` 或 `StoreDist`。

| 包装函数 | 等价调用 |
| --- | --- |
| `reg_to_ub_downsample(dst, src, mask)` | `reg_to_ub_continuous(dst, src, mask, StoreDist.DOWNSAMPLE)` |
| `reg_to_ub_pack4(dst, src, mask)` | `reg_to_ub_continuous(dst, src, mask, StoreDist.PACK4)` |
| `reg_to_ub_single(dst, src, mask)` | `reg_to_ub_continuous(dst, src, mask, StoreDist.SINGLE_VALUE)` |
| `ub_to_reg_single(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.SINGLE_VALUE)` |
| `ub_to_reg_upsample(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.UPSAMPLE)` |
| `ub_to_reg_downsample(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.DOWNSAMPLE)` |
| `ub_to_reg_unpack(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.UNPACK)` |
| `ub_to_reg_unpack4(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.UNPACK4)` |
| `ub_to_reg_brcb(dst, src)` | `ub_to_reg_continuous(dst, src, LoadDist.BRCB)` |

示例：

```python
ub_to_reg_unpack(reg, src_ub)
reg_to_ub_single(dst_ub, reg)
```

## 5. Gather 与 Scatter

### `ub_to_reg_gather(dst, src, index, mask=None)`

- 作用：从 UB 中按任意索引 gather 到寄存器。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 UB `Tensor`
  - `index`：索引 `Reg`
  - `mask`：可选的 `MaskReg`

寻址规则：

- 模拟器会先把 `src` 展平
- 对每个激活 lane `i`，读取：
  - `dst[i] = src_flat[index[i]]`

Mask 行为：

- 这里的 mask 是逐 lane 的，不会扩展到 `C0` block
- `dst` 会先被清零，所以未激活 lane 在结果中为 `0`

索引行为：

- `index` 直接参与地址计算
- `index[i]` 已经是最终的展平元素下标
- 不会再额外乘元素大小、行宽或 `C0`

如果 `src` 的逻辑形状是 `[rows, cols]`，那么：

- 展平地址 `0 .. cols - 1` 对应第 `0` 行
- 展平地址 `cols .. 2 * cols - 1` 对应第 `1` 行
- 一般地：`flat_index = row * cols + col`

示例：

```text
src (flattened) = [100, 101, 102, 103, 104, 105]
index           = [4,   1,   1,   0]
mask            = VL3

dst[0] = src[4] = 104
dst[1] = src[1] = 101
dst[2] = src[1] = 101
dst[3] = 0      # masked off
```

示例用法：

```python
data = Tensor(DT.half, [4, 64], Position.UB)
index = Reg(DT.uint16)
dst = Reg(DT.half)
mask = MaskReg(DT.half, init_mode=MaskType.ALL)
ub_to_reg_gather(dst, data, index, mask=mask)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- `index` 的 lane 数必须等于 `dst` 的 lane 数
- 模拟器要求 `index` 是整数类型
- stub 还额外要求：
  - 对 16 位数据使用 `uint16` 索引
  - 对 32 位数据使用 `uint32` 索引
- 每个激活索引都必须落在展平后的源范围内

### `reg_to_ub_scatter(dst, src, index, mask=None)`

- 作用：把寄存器 lane 按任意索引 scatter 到 UB 中。
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：源 `Reg`
  - `index`：索引 `Reg`
  - `mask`：可选的 `MaskReg`

寻址规则：

- 模拟器会先把 `dst` 展平
- 对每个激活 lane `i`，写入：
  - `dst_flat[index[i]] = src[i]`

Mask 行为：

- 这里的 mask 同样是逐 lane 的，不会扩展到 `C0`
- 未激活 lane 不会进行任何写入
- 未触及的目标位置会保留原值

重复索引行为：

- 如果多个激活 lane 指向同一个目标位置，会按 lane 顺序依次写
- 最后一个激活 lane 的值生效

示例：

```text
initial dst = [0, 0, 0, 0, 0]
src         = [10, 20, 30, 40]
index       = [3,  1,  3,  0]

lane 0 writes dst[3] = 10
lane 1 writes dst[1] = 20
lane 2 writes dst[3] = 30   # overwrites lane 0
lane 3 writes dst[0] = 40

final dst = [40, 20, 0, 30, 0]
```

示例用法：

```python
dst = Tensor(DT.half, [4, 64], Position.UB)
src = Reg(DT.half)
index = Reg(DT.uint16)
reg_to_ub_scatter(dst, src, index)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- `index` 的 lane 数必须等于 `src` 的 lane 数
- 模拟器要求 `index` 是整数类型
- stub 还额外要求：
  - 对 16 位数据使用 `uint16` 索引
  - 对 32 位数据使用 `uint32` 索引
- 每个激活索引都必须落在展平后的目标范围内

### `gather(dst, src, index)`

- 作用：在寄存器内部，从一个寄存器按索引 gather 到另一个寄存器。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 `Reg`
  - `index`：索引 `Reg`

规则：

- 对每个 lane `i`：
  - `dst[i] = src[index[i]]`

重要的 alias 行为：

- 模拟器会先对 `src` 做快照，再执行 gather
- 因此 `gather(reg, reg, index)` 的语义是“从原始寄存器内容中 gather”，而不是一边覆盖一边继续读取

示例：

```text
src   = [10, 20, 30, 40]
index = [3, 2, 1, 0]
dst   = [40, 30, 20, 10]
```

重复索引示例：

```text
src   = [10, 20, 30, 40]
index = [1, 1, 1, 1]
dst   = [20, 20, 20, 20]
```

示例用法：

```python
dst = Reg(DT.half)
src = Reg(DT.half)
index = Reg(DT.uint16)
gather(dst, src, index)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- `dst`、`src`、`index` 三者必须有相同的 lane 数
- 每个索引都必须落在源寄存器 lane 范围内

### `gather_mask(dst, src, mask=None)`

- 作用：把源寄存器中被 mask 选中的 lane 压紧到目标寄存器前部。
- 参数：
  - `dst`：目标 `Reg`
  - `src`：源 `Reg`
  - `mask`：可选的 `MaskReg`

规则：

- 被选中的源 lane 会保持原有顺序复制
- 它们会被压到 `dst[0]`、`dst[1]`、`...`
- `dst` 中剩余 lane 全部补零

示例：

```text
src  = [10, 20, 30, 40, 50, 60]
mask = active at lanes [0, 2, 5]
dst  = [10, 30, 60, 0, 0, 0]
```

重要的 alias 行为：

- 模拟器会在压紧前先快照 `src`
- 因此 `gather_mask(src, src, mask)` 会使用原始源内容

示例用法：

```python
dst = Reg(DT.half)
src = Reg(DT.half)
mask = MaskReg(DT.half, init_mode=MaskType.MULTI3)
gather_mask(dst, src, mask)
```

限制：

- `dst.dtype` 必须等于 `src.dtype`
- `dst` 和 `src` 必须有相同的 lane 数

## 6. Interleave 辅助

### `interleave(dst0, dst1, src0, src1)`

- 作用：把两个源寄存器交错写入两个目标寄存器。
- 参数：
  - `dst0`、`dst1`：目标 `Reg`
  - `src0`、`src1`：源 `Reg`

规则：

- 设 `half = lane_count / 2`
- 对 `k in [0, half)`：
  - `dst0[2 * k]     = src0[k]`
  - `dst0[2 * k + 1] = src1[k]`
  - `dst1[2 * k]     = src0[half + k]`
  - `dst1[2 * k + 1] = src1[half + k]`

8 lane 示例：

```text
src0 = [a0, a1, a2, a3, a4, a5, a6, a7]
src1 = [b0, b1, b2, b3, b4, b5, b6, b7]

dst0 = [a0, b0, a1, b1, a2, b2, a3, b3]
dst1 = [a4, b4, a5, b5, a6, b6, a7, b7]
```

Alias 行为：

- 模拟器会先快照两个源
- 因此 `interleave(reg0, reg1, reg0, reg1)` 的语义是稳定的

示例用法：

```python
out0 = Reg(DT.half)
out1 = Reg(DT.half)
interleave(out0, out1, reg0, reg1)
```

限制：

- 四个寄存器的 dtype 必须一致
- 四个寄存器的 lane 数必须一致
- lane 数必须为偶数

### `deinterleave(dst0, dst1, src0, src1)`

- 作用：把 `interleave()` 的布局还原回来。
- 参数：
  - `dst0`、`dst1`：目标 `Reg`
  - `src0`、`src1`：源 `Reg`

规则：

- 设 `half = lane_count / 2`
- 对 `k in [0, half)`：
  - `dst0[k]        = src0[2 * k]`
  - `dst1[k]        = src0[2 * k + 1]`
  - `dst0[half + k] = src1[2 * k]`
  - `dst1[half + k] = src1[2 * k + 1]`

8 lane 示例：

```text
src0 = [a0, b0, a1, b1, a2, b2, a3, b3]
src1 = [a4, b4, a5, b5, a6, b6, a7, b7]

dst0 = [a0, a1, a2, a3, a4, a5, a6, a7]
dst1 = [b0, b1, b2, b3, b4, b5, b6, b7]
```

往返性质：

```text
deinterleave(*, *, *interleave(src0, src1)) == (src0, src1)
```

Alias 行为：

- 和 `interleave()` 一样，模拟器也会先快照源

示例用法：

```python
out0 = Reg(DT.half)
out1 = Reg(DT.half)
deinterleave(out0, out1, tmp0, tmp1)
```

限制：

- 四个寄存器的 dtype 必须一致
- 四个寄存器的 lane 数必须一致
- lane 数必须为偶数

## 7. 相关阅读

与 cast 相关的 API 另见 [a5_micro_cast.md](a5_micro_cast.md)。
