# Barrier

本页文档说明由 `easyasc.a2` 与 `easyasc.a5` 共享的 barrier 辅助。

这些 API 定义在 `easyasc/stub_functions/barrier.py` 中，会向当前激活的 kernel 发射 `Instruction("barrier", pipe=...)`。

## 1. 概览

Barrier 辅助是显式的 pipe 顺序控制工具。

典型例子：

```python
bar_v()
bar_m()
bar_all()
```

从概念上说，barrier 做的事情是：

- 它表示“不要让这条调度路径上、所选 pipe 域里的后续工作，跑到更早的工作前面去”

Barrier 不做的事情包括：

- 它不是像 `CvMutex` 或 `VcMutex` 那样的 cube/vec ownership 原语
- 它不是像 `SEvent` 或 `DEvent` 那样的 ready/valid 事件对象
- 它本身不会搬运数据

当你需要一种比普通 FIFO、`auto_sync()` 或 ownership 交接原语更显式的 pipe 顺序约束时，才应该使用 barrier。

## 2. 核心 API

### `barrier(pipe)`

- 作用：为指定的一个 `PipeType` 发射 barrier 指令。
- 参数：
  - `pipe`：一个 `PipeType`，例如 `Pipe.V`、`Pipe.M` 或 `Pipe.ALL`
- 限制：
  - `pipe` 必须是 `PipeType`
  - 只能在 kernel 上下文中使用

示例：

```python
barrier(Pipe.V)
barrier(Pipe.ALL)
```

当前 lowering 结果：

- parser 会把它 lowering 成 `PipeBarrier<PIPE_...>();`

例如：

- `barrier(Pipe.V)` -> `PipeBarrier<PIPE_V>();`
- `barrier(Pipe.MTE2)` -> `PipeBarrier<PIPE_MTE2>();`
- `barrier(Pipe.ALL)` -> `PipeBarrier<PIPE_ALL>();`

## 3. 便捷辅助

这些辅助本质上都是 `barrier(pipe)` 的固定参数包装。

### `bar_m()`

- 等价于：

```python
barrier(Pipe.M)
```

- 常见用途：
  - 显式串行化 cube 计算工作

### `bar_v()`

- 等价于：

```python
barrier(Pipe.V)
```

- 常见用途：
  - 显式串行化 vec 计算工作

### `bar_mte3()`

- 等价于：

```python
barrier(Pipe.MTE3)
```

- 常见用途：
  - 显式串行化 UB -> GM 或 UB -> L1 这类输出侧搬运工作

### `bar_mte2()`

- 等价于：

```python
barrier(Pipe.MTE2)
```

- 常见用途：
  - 显式串行化 GM -> L1 或 GM -> UB 这类输入侧搬运工作

### `bar_mte1()`

- 等价于：

```python
barrier(Pipe.MTE1)
```

- 常见用途：
  - 显式串行化 L1 -> L0 的 staging 工作

### `bar_fix()`

- 等价于：

```python
barrier(Pipe.FIX)
```

- 常见用途：
  - 显式串行化 cube 输出侧发布工作，例如 `l0c_to_ub` 或 `l0c_to_gm_nz2nd`

### `bar_all()`

- 等价于：

```python
barrier(Pipe.ALL)
```

- 常见用途：
  - 等待所有受支持的本地 pipe 都到达 barrier 点

## 4. 机制与理解方式

这里有两种特别值得理解的情况。

### 情况 1：`barrier(Pipe.X)`，针对单个普通 pipe

例如：

- `Pipe.MTE2`
- `Pipe.MTE1`
- `Pipe.M`
- `Pipe.V`
- `Pipe.FIX`
- `Pipe.MTE3`

从机制上看：

- DSL 会发射一条带该 pipe 标签的 `barrier` 指令
- parser 会把它 lowering 成 `PipeBarrier<PIPE_X>();`
- 在模拟器里，这条指令会被派发到对应的 pipe 队列

从实际含义上看：

- 依赖该 pipe 进度的后续工作，必须等这个 pipe 中更早排队的工作先到达 barrier

它是一个 pipe 局部的顺序原语，不是跨 pipe 的握手。

### 情况 2：`barrier(Pipe.ALL)`

这是一个更强、更特殊的情况。

当前模拟器对它的建模比普通单 pipe barrier 更显式：

- cube 模拟器会把 `barrier(Pipe.ALL)` 展开成等待这些 pipe：
  - `MTE2`
  - `MTE1`
  - `M`
  - `FIX`
- vec 模拟器会把 `barrier(Pipe.ALL)` 展开成等待这些 pipe：
  - `MTE2`
  - `V`
  - `MTE3`

当前模拟器的实现方式是：

1. 在每一条参与的源 pipe 上发出一个合成的 `setflag(src_pipe, Pipe.S, event_id=8)`
2. 让主循环等待每个这样的合成 flag 变得可见
3. 再逐个消费这些 flag

这意味着 `barrier(Pipe.ALL)` 当前的模型更接近：

- “每一条相关的本地 pipe 都必须先向主循环报到，执行才能继续”

这也是为什么它比单 pipe barrier 强得多。

## 5. Barrier 真正解决的问题

Barrier 适合这些场景：

- 你已经明确知道工作发生在哪一个 pipe 域
- 你确实需要在这个 pipe 边界上做显式顺序约束
- 你不想引入事件对象或 mutex ownership

例如：

- 强制 `Pipe.V` 上的 vec 工作在后续阶段读取结果之前完成
- 强制 `Pipe.MTE2` 上的 staging 工作先结束，再把生产侧视为已 drain
- 在主循环里读取标量或写调试输出之前，强制所有本地 pipe 都先 drain 完

## 6. Barrier 不能替代什么

不要把 barrier 当成下面这些机制的替代品：

- `CvMutex` / `VcMutex`
  - 它们解决的是 cube/vec 之间的 ownership 交接
- `SEvent` / `DEvent`
  - 它们解决的是源 pipe 到目标 pipe 的显式 ready/valid 同步
- `auto_sync()`
  - 它会为已知的流水线边界自动合成同侧事件

在这一组工具里，barrier 往往是最直接、也最“硬”的一个。

## 7. 示例

### vec 侧显式 pipe barrier

```python
gm_to_ub_pad(ub, x[m:m + blk, :], ...)
bar_v()
add(ub_out, ub, 1.0)
```

可以这样理解：

- 如果你明确知道后续逻辑绝不能越过 vec pipe 的当前阶段，那么 `Pipe.V` barrier 就是一个显式停顿点

### vec 侧的完整本地 drain

```python
seed.SetValueTo(ub)
ub <<= src
bar_all()
val.GetValueFrom(ub)
val += one
val.SetValueTo(ub)
```

这和当前模拟器里关于 `barrier(Pipe.ALL)` 的回归测试一致：barrier 后面的标量读取和更新，只有在先前排队的 pipe 工作都 drain 完之后才会发生。

### cube 侧显式计算 barrier

```python
mmad(l0c, l0a, l0b, M=M, N=N, K=K, is_init=True)
bar_m()
l0c_to_ub(ub, l0c)
```

可以这样理解：

- 在 cube 计算 pipe 到达 barrier 点之前，不要开始下一段 cube 输出阶段

## 8. 实用建议

- 从真正匹配依赖关系的最窄 barrier 开始用起。
- 如果单个 pipe 就够了，优先使用 `bar_m()`、`bar_v()` 或其他单 pipe barrier，而不是 `bar_all()`。
- 把 `bar_all()` 当作一个强本地 drain 点，而不是随手加的“同步提示”。
- 如果依赖关系本质上是“源 pipe -> 目标 pipe”的顺序约束，更适合用 event 或 `auto_sync()`。
- 如果依赖关系本质上是 cube/vec ownership，更适合用 `CvMutex` 或 `VcMutex`。
