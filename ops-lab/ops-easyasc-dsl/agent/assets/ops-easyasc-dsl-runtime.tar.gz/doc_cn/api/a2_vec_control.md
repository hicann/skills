# A2 Vec 控制与访问辅助

本页文档描述的是由 `easyasc.a2` 导出的、那些不属于数学计算本体的向量辅助函数。

本页覆盖的范围包括：

- UB 向量 cast
- UB compare 与 select 辅助
- vec mask 状态辅助
- UB gather 与 scatter 辅助

本页中的所有函数都只属于 `a2` 接口面。

额外说明：

- 本页中出现的所有张量，都默认应当位于 `UB`
- `compare`、`select`、`gather` 这些名字在 `easyasc.a5` 中也存在，但那边对应的是 micro 寄存器 API，会单独文档化

## 1. Vec Cast

### `cast(dst, src, repeat=None, dst_blk_stride=None, src_blk_stride=None, dst_rep_stride=None, src_rep_stride=None, round_mode=RoundMode.AWAY_FROM_ZERO)`

- 作用：在 UB 向量之间执行 dtype cast
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：来源 UB `Tensor`
  - `repeat`：可选的重复次数
  - `dst_blk_stride`、`src_blk_stride`：block stride
  - `dst_rep_stride`、`src_rep_stride`：repeat stride
  - `round_mode`：vec cast 使用的舍入模式
- 限制：
  - 由 `a2` 导出
  - `dst` 与 `src` 必须都是 UB 张量
  - `round_mode` 必须是 `RoundModeType`
  - 当是宽化转换时，运行时会强制使用 `RoundMode.NONE`
- 当前模拟器说明：
  - cast 会忽略 `dst_blk_stride` / `src_blk_stride`；实际只看 repeat stride
  - 每个 repeat 的 cast 元素数由 `src` / `dst` 里更宽的 dtype 决定
  - 当前 vec mask 也在这个 cast-element 域上解析
  - 被 mask 掉的 cast 元素会保留原来的 `dst` 值
- 示例：

```python
cast(dst_half, src_float)
```

## 2. Vec Compare 与 Select

### `SelectModeType` 与 `SelectMode`

vec `select(...)` 这个 stub 会在内部推导出两种 select 模式之一。
这些 mode 对象定义在 `easyasc/utils/selectmode.py` 中。

在正常 kernel 代码里，你并不会手工传 `mode=`。
公开的 `select(...)` API 会根据 `src2` 的运行时类型自动推导模式，并把它记录到发射出来的指令里。

### `SelectModeType`

- 作用：表示一种具体的 vec select lowering 模式
- 内部保存字段：
  - `name`
- 重要行为：
  - `str(mode)` 返回诸如 `TENSOR_TENSOR` 这样的名字
  - `repr(mode)` 返回诸如 `SelectModeType('TENSOR_SCALAR')` 这样的调试形式
  - 相等性按 mode 名称比较

有一个实现细节在调试 helper 代码时值得知道：

- 把 `SelectModeType` 和其他类型对象做比较时，会抛 `TypeError`
- 它不会安静地返回 `False`

### `SelectMode`

`SelectMode` 是一个枚举风格命名空间，对外暴露了两种 vec 侧 select 形式：

- `SelectMode.TENSOR_TENSOR`
  - 被选中的值来自两个 UB 张量：`src1` 与 `src2`
- `SelectMode.TENSOR_SCALAR`
  - 真分支来自 `src1`，假分支则来自一个按 lane 广播的标量

当前 `easyasc/stub_functions/vec/select.py` 里的 stub 用一条非常简单的规则来决定模式：

- 如果 `src2` 是 UB `Tensor`，那么 mode 是 `SelectMode.TENSOR_TENSOR`
- 否则 `src2` 必须是标量风格值，此时 mode 是 `SelectMode.TENSOR_SCALAR`

也就是说，下面两种写法的 lowering 结果是不同的：

```python
select(dst, selmask, src1, src2_tensor)
select(dst, selmask, src1, 0.0)
```

即使其余 stride 参数完全一样，发射出来的指令里也会携带不同的 `mode`，而后端 / 模拟器会据此解释 `src2`。

### 为什么这个类型应该放在 A2 vec 页面

`SelectMode` 是给 A2 vec `select(...)` stub 用的，不是给 A5 micro `select(...)` 用的。
把它放在这里，能避免把两个仅仅名字相同、但实际完全不相干的 API 混在一起。

### `compare(dst, src1, src2, mode, repeat=None, ...)`

- 作用：比较两个 UB 张量，并把布尔结果写进一个 UB mask 张量
- 参数：
  - `dst`：保存 compare 结果的目标 UB `Tensor`
  - `src1`、`src2`：来源 UB 张量
  - `mode`：`CompareMode`
  - 其余参数：repeat 与 stride 元数据
- 限制：
  - 由 `a2` 导出
  - `dst` 必须是 UB 上的 `int8` 或 `uint8`
  - `src1` 与 `src2` 必须是 dtype 一致的 UB 张量
  - 支持的来源 dtype：`float`、`half`、`int16`、`int`
  - `compare()` 当前会忽略 vec mask 状态
- 示例：

```python
compare(mask_buf, xub, yub, CompareMode.GT)
```

### `compare_scalar(dst, src1, src2, mode, repeat=None, ...)`

- 作用：把一个 UB 张量与一个标量做比较，并把结果写入 UB mask 张量
- 参数：
  - `dst`：保存 compare 结果的目标 UB `Tensor`
  - `src1`：来源 UB 张量
  - `src2`：标量 `int`、`float` 或 `Var`
  - `mode`：`CompareMode`
  - 其余参数：repeat 与 stride 元数据
- 限制：
  - 由 `a2` 导出
  - `dst` 必须是 UB 上的 `int8` 或 `uint8`
  - `src1` 必须是 UB 上的 `float`、`half`、`int16` 或 `int`
  - `compare_scalar()` 当前会忽略 vec mask 状态
- 示例：

```python
compare_scalar(mask_buf, xub, 0.0, CompareMode.GE)
```

### `set_cmpmask(src)`

- 作用：从一个 UB 张量中加载 compare-mask 状态
- 参数：
  - `src`：来源 UB `Tensor`
- 限制：
  - 由 `a2` 导出
  - `src` 必须位于 `Position.UB`
- 示例：

```python
set_cmpmask(mask_buf)
```

### `select(dst, selmask, src1, src2, repeat=None, ...)`

- 作用：根据张量或标量形式的选择掩码，在张量 / 标量来源之间选值
- 参数：
  - `dst`：目标 UB `Tensor`
  - `selmask`：mask `Tensor` 或标量 `Var`
  - `src1`：第一个来源 UB `Tensor`
  - `src2`：第二个来源；可以是 UB 张量，也可以是标量
  - 其余参数：repeat 与 stride 元数据
- 限制：
  - 由 `a2` 导出
  - `dst` 与 `src1` 必须是 UB 张量
  - 支持的数据 dtype：`float`、`half`、`int16`、`int`
  - 如果 `selmask` 是张量，它必须是 `uint8`
  - 如果 `selmask` 是标量，它必须是运行时支持的无符号整型标量 dtype 之一
  - `select()` 当前会忽略 vec mask 状态；选择仅由 `selmask` 决定
- lowering 模式：
  - 如果 `src2` 是 UB `Tensor`，stub 会发射 `mode=SelectMode.TENSOR_TENSOR`
  - 如果 `src2` 是标量 `Var`、`int` 或 `float`，stub 会发射 `mode=SelectMode.TENSOR_SCALAR`
- 示例：

```python
select(dst, mask_var, src1, 0.0)
```

## 3. Vec Mask 状态

### `set_mask(mask_high, mask_low)`

- 作用：设置当前 vec mask 寄存器状态
- 参数：
  - `mask_high`、`mask_low`：`int` 或 `Var`
- 限制：
  - 由 `a2` 导出
  - 如果传的是 `Var`，它的 dtype 必须是 `uint64`
- 当前模拟器说明：
  - `mask_low` 控制 bit `0..63`
  - `mask_high` 控制 bit `64..127`
  - `set_mask()` 不会修改 `mask[128:256]`
  - 常见 active prefix 为：
    - `float` / `int32`：`mask[0:64]`
    - `half` / `int16`：`mask[0:128]`
    - `int8` / `uint8`：`mask[0:256]`
  - 每个 repeat 都会复用同一段 mask prefix，不会随着 repeat 自动前移
- 示例：

```python
set_mask(0, 0xFFFFFFFFFFFFFFFF)
```

### `reset_mask()`

- 作用：把 vec mask 状态恢复到默认状态
- 参数：
  - 无
- 限制：
  - 由 `a2` 导出
  - 在临时 partial-mask 区域之后，应主动调用它，避免后续操作意外继承掩码
- 当前模拟器说明：
  - 会把完整的 `mask[0:256]` 全部恢复成 1
- 示例：

```python
reset_mask()
```

## 4. Gather 与 Scatter

### `gather(dst, src, offset, start_idx=0, repeat=None, dst_rep_stride=None)`

- 作用：使用一个 UB offset 张量，从 UB 来源张量中 gather 元素
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：来源 UB `Tensor`
  - `offset`：保存字节偏移的 UB `Tensor`
  - `start_idx`：基础字节偏移
  - `repeat`：可选重复次数
  - `dst_rep_stride`：目标 repeat stride
- 限制：
  - 由 `a2` 导出
  - `offset` 必须是 UB 上的 `uint32`
  - `dst.dtype` 必须等于 `src.dtype`
  - `offset` 与 `start_idx` 都以字节为单位
  - `gather()` 当前会忽略 vec mask 状态
- 示例：

```python
gather(dst, src, offset)
```

### `scatter(dst, src, offset, repeat=None, src_rep_stride=None)`

- 作用：使用 offset，把 UB 来源张量中的元素散写到 UB 目标张量中
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：来源 UB `Tensor`
  - `offset`：保存字节偏移的 UB `Tensor`
  - `repeat`：可选重复次数
  - `src_rep_stride`：来源 repeat stride
- 限制：
  - 由 `a2` 导出
  - `offset` 必须是 UB 上的 `uint32`
  - `dst.dtype` 必须等于 `src.dtype`
  - `scatter()` 当前会忽略 vec mask 状态
- 示例：

```python
scatter(dst, src, offset)
```
