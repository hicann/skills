# A2 向量数学

本页介绍的是由 `easyasc.a2` 直接导出的 UB 向量数学辅助。

一个重要的范围说明是：

- 这里这些名字，在 `a2` 里都是顶层函数
- 同名函数在 `a5` 中通常表示的是 micro 寄存器操作，而不是这里的 UB 向量操作

## Mask 行为总览

在看各个 API 细节前，先记住当前模拟器里的这套规则：

- Binary / unary / unary-scalar / `dup`
  - 会在 dst 写回阶段消费当前 vec mask
  - 被 mask 掉的 lane 会保留原来的 `dst` 值
- 组规约算子
  - `cadd`、`cgadd`、`cpadd`：被 mask 掉的源元素按 `0` 参与计算
  - `cmax`、`cgmax`：被 mask 掉的源元素按 `-inf` 处理
  - `cmin`、`cgmin`：被 mask 掉的源元素按 `+inf` 处理
  - 如果某个规约域对应的 active 区间全都被 mask 掉，则对应的 `dst` 槽位不会被覆写
- `brcb`
  - 当前会忽略 vec mask 状态
- 相关 control 类算子在 A2 vec control 页说明
  - `compare`、`compare_scalar`、`select`、`gather`、`scatter` 当前都会忽略 vec mask 状态

## 1. 共享的二元 vec 参数

下面这些函数共享同一套参数形状：

- `add`
- `sub`
- `mul`
- `div`
- `vmax`
- `vmin`
- `vand`
- `vor`
- `muladddst`

共享参数包括：

- `dst`：目标 UB `Tensor`
- `src1`、`src2`：来源 UB `Tensor`
- `repeat`：可选的重复次数；如果省略，会从 `dst` 推导
- `*_blk_stride`：可选的 block stride
- `*_rep_stride`：可选的 repeat stride

共享限制包括：

- `dst`、`src1` 和 `src2` 必须全部是位于 `Position.UB` 的 `Tensor`
- 这三个张量的 dtype 必须完全一致
- 所有 stride 或 repeat 参数如果给出，必须是 `int` 或 `Var`
- 这些算子会在 dst 写回阶段消费当前 vec mask；被 mask 掉的 lane 会保留原来的 `dst` 值

### `add(dst, src1, src2, ...)`

- 作用：逐元素向量加法，`dst = src1 + src2`
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
add(dst, src1, src2)
```

### `sub(dst, src1, src2, ...)`

- 作用：逐元素向量减法，`dst = src1 - src2`
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
sub(dst, src1, src2)
```

### `mul(dst, src1, src2, ...)`

- 作用：逐元素向量乘法，`dst = src1 * src2`
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
mul(dst, src1, src2)
```

### `div(dst, src1, src2, ...)`

- 作用：逐元素向量除法，`dst = src1 / src2`
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
div(dst, src1, src2)
```

### `vmax(dst, src1, src2, ...)`

- 作用：在两个张量之间做逐元素最大值
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
vmax(dst, src1, src2)
```

### `vmin(dst, src1, src2, ...)`

- 作用：在两个张量之间做逐元素最小值
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
- 示例：

```python
vmin(dst, src1, src2)
```

### `vand(dst, src1, src2, ...)`

- 作用：对向量张量做逐元素按位与
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`int16_t`、`uint16_t`
  - 如果你要对其他 16-bit 数据做按位视图，建议先显式做 `reinterpret(...)`
- 示例：

```python
vand(dst, src1, src2)
```

### `vor(dst, src1, src2, ...)`

- 作用：对向量张量做逐元素按位或
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
  - 如果你对 `float` / `half` 数据需要严格的按位语义，建议显式先做 `reinterpret(...)`
- 示例：

```python
vor(dst, src1, src2)
```

### `muladddst(dst, src1, src2, ...)`

- 作用：先把 `src1` 与 `src2` 相乘，再累加到 `dst`
- 参数：使用上面共享的二元 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`、`int`
  - 只有在 `dst` 里已经预先放好了要累加进去的值时，才应该使用它
- 示例：

```python
muladddst(dst, src1, src2)
```

## 2. 共享的单目 vec 参数

下面这些函数共享同一套参数模式：

- `exp`
- `ln`
- `abs`
- `rec`
- `sqrt`
- `rsqrt`
- `vnot`
- `relu`

共享参数包括：

- `dst`：目标 UB `Tensor`
- `src`：来源 UB `Tensor`
- `repeat`：可选的重复次数
- `dst_blk_stride`、`src_blk_stride`：可选的 block stride
- `dst_rep_stride`、`src_rep_stride`：可选的 repeat stride

共享限制包括：

- `dst` 与 `src` 必须是 UB 张量
- `dst.dtype` 必须等于 `src.dtype`
- 这些算子会在 dst 写回阶段消费当前 vec mask；被 mask 掉的 lane 会保留原来的 `dst` 值

### `exp(dst, src, ...)`

- 作用：逐元素指数
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
exp(dst, src)
```

### `ln(dst, src, ...)`

- 作用：逐元素自然对数
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
ln(dst, src)
```

### `abs(dst, src, ...)`

- 作用：逐元素绝对值
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
abs(dst, src)
```

### `rec(dst, src, ...)`

- 作用：逐元素倒数
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
rec(dst, src)
```

### `sqrt(dst, src, ...)`

- 作用：逐元素平方根
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
sqrt(dst, src)
```

### `rsqrt(dst, src, ...)`

- 作用：逐元素平方根倒数
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
rsqrt(dst, src)
```

### `vnot(dst, src, ...)`

- 作用：逐元素按位取反
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`int16_t`、`uint16_t`
- 示例：

```python
vnot(dst, src)
```

### `relu(dst, src, ...)`

- 作用：逐元素 ReLU
- 参数：使用上面共享的单目 vec 参数集
- 限制：
  - 支持的 dtype：`float`、`half`
- 示例：

```python
relu(dst, src)
```

## 3. 共享的“单目 + 标量”vec 参数

下面这些函数共享同一套参数模式：

- `adds`
- `muls`
- `vmaxs`
- `vmins`
- `lrelu`
- `axpy`

共享参数包括：

- `dst`：目标 UB `Tensor`
- `src`：来源 UB `Tensor`
- `val`：标量 `int`、`float` 或 `Var`
- `repeat`：可选的重复次数
- stride 参数：可选的 vec stride 元数据

共享限制包括：

- `dst` 与 `src` 必须是 UB 张量
- `dst.dtype` 必须等于 `src.dtype`
- 标量类型必须与张量 dtype 相兼容
- 这些算子会在 dst 写回阶段消费当前 vec mask；被 mask 掉的 lane 会保留原来的 `dst` 值

### `adds(dst, src, val, ...)`

- 作用：给每个元素都加上一个标量
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 当前支持的 dtype 以后端对 vec unary-scalar 的支持范围为准
- 示例：

```python
adds(dst, src, 1.0)
```

### `muls(dst, src, val, ...)`

- 作用：让每个元素都乘上一个标量
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 当前支持的 dtype 以后端对 vec unary-scalar 的支持范围为准
- 示例：

```python
muls(dst, src, 2.0)
```

### `vmaxs(dst, src, val, ...)`

- 作用：把每个元素钳到至少不小于某个标量阈值
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 当前支持的 dtype 以后端对 vec unary-scalar 的支持范围为准
- 示例：

```python
vmaxs(dst, src, 0.0)
```

### `vmins(dst, src, val, ...)`

- 作用：把每个元素钳到至多不大于某个标量阈值
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 当前支持的 dtype 以后端对 vec unary-scalar 的支持范围为准
- 示例：

```python
vmins(dst, src, 1.0)
```

### `lrelu(dst, src, val, ...)`

- 作用：应用 leaky relu，其中标量 `val` 表示负半轴斜率
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 当前支持的 dtype 以后端对 vec unary-scalar 的支持范围为准
- 示例：

```python
lrelu(dst, src, 0.1)
```

### `axpy(dst, src, val, ...)`

- 作用：执行后端支持的 vec 侧 AXPY 风格标量融合操作
- 参数：使用上面共享的单目加标量参数集
- 限制：
  - 标量类型必须与张量 dtype 兼容
- 示例：

```python
axpy(dst, src, 0.5)
```

## 4. 复制与广播辅助

### `dup(dst, value, repeat=None, dst_blk_stride=None, dst_rep_stride=None)`

- 作用：把一个标量值复制到 UB 张量中
- 参数：
  - `dst`：目标 UB `Tensor`
  - `value`：`int`、`float` 或 `Var`
  - `repeat`：可选重复次数
  - `dst_blk_stride`、`dst_rep_stride`：可选 stride 元数据
- 限制：
  - `dst` 必须位于 `Position.UB`
  - 支持的 dtype：`float`、`half`、`int`、`uint32_t`
  - `dup()` 会在 dst 写回阶段消费当前 vec mask；被 mask 掉的 lane 会保留原来的 `dst` 值
- 示例：

```python
dup(dst, 0.0)
```

### `brcb(dst, src, dst_blk_stride=None, dst_rep_stride=None, repeat=None)`

- 作用：执行仓库里 kernel 常用的 vec 侧广播 / 重复辅助
- 参数：
  - `dst`：目标 UB `Tensor`
  - `src`：来源 UB `Tensor`
  - `dst_blk_stride`、`dst_rep_stride`、`repeat`：可选控制参数
- 限制：
  - `dst` 与 `src` 必须都是 UB 张量
  - `dst.dtype` 必须等于 `src.dtype`
  - `brcb()` 当前会忽略 vec mask 状态
- 示例：

```python
brcb(dst, src)
```

## 5. 组规约风格算子

下面这些函数共享同一套参数模式：

- `cmax`
- `cgmax`
- `cmin`
- `cgmin`
- `cadd`
- `cgadd`
- `cpadd`

共享参数包括：

- `dst`：目标 UB `Tensor`
- `src`：来源 UB `Tensor`
- `repeat`：可选重复次数
- `dst_rep_stride`：目标 repeat stride，这个参数是刻意要求显式给出的
- `src_blk_stride`、`src_rep_stride`：可选的来源 stride 元数据

共享限制包括：

- `dst` 与 `src` 必须都是 UB 张量
- 支持的 dtype：`float`、`half`
- `dst_rep_stride` 不能是 `None`
- `vc`、`vcg` 和 `vcp` 三个家族的目标 stride 单位并不相同；当前实现会打印一次性提醒，提示这些单位差异
- 这些算子都会消费 `set_mask()` / `reset_mask()` 设置的当前 vec mask 状态

当前模拟器对这一组算子的 mask 语义如下：

- `cadd`
  - 被 mask 掉的源元素按 `0` 参与求和
  - 如果 active prefix 上所有 mask bit 都是 `0`，则不会覆写目标标量
- `cgadd`
  - 每个 datablock 内，被 mask 掉的源元素按 `0` 参与求和
  - 如果某个 datablock 的 mask 全为 `0`，则不会覆写该 datablock 对应的目标标量
- `cpadd`
  - 在做 pairwise add 之前，被 mask 掉的源元素按 `0` 参与计算
- `cmax`、`cgmax`
  - 被 mask 掉的源元素按 `-inf` 处理
  - 对 `cmax` 来说，如果整个 active prefix 全 0，则不会覆写目标标量
  - 对 `cgmax` 来说，如果某个 datablock 的 mask 全 0，则不会覆写该 datablock 对应的目标标量
- `cmin`、`cgmin`
  - 被 mask 掉的源元素按 `+inf` 处理
  - 对 `cmin` 来说，如果整个 active prefix 全 0，则不会覆写目标标量
  - 对 `cgmin` 来说，如果某个 datablock 的 mask 全 0，则不会覆写该 datablock 对应的目标标量

### `cmax(dst, src, ...)`

- 作用：`vc` 家族里的组最大值规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vc` 家族规则
- 示例：

```python
cmax(dst, src, dst_rep_stride=1)
```

### `cgmax(dst, src, ...)`

- 作用：`vcg` 家族里的组最大值规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vcg` 家族规则
- 示例：

```python
cgmax(dst, src, dst_rep_stride=1)
```

### `cmin(dst, src, ...)`

- 作用：`vc` 家族里的组最小值规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vc` 家族规则
- 示例：

```python
cmin(dst, src, dst_rep_stride=1)
```

### `cgmin(dst, src, ...)`

- 作用：`vcg` 家族里的组最小值规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vcg` 家族规则
- 示例：

```python
cgmin(dst, src, dst_rep_stride=1)
```

### `cadd(dst, src, ...)`

- 作用：`vc` 家族里的组加法规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vc` 家族规则
- 示例：

```python
cadd(dst, src, dst_rep_stride=1)
```

### `cgadd(dst, src, ...)`

- 作用：`vcg` 家族里的组加法规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vcg` 家族规则
- 示例：

```python
cgadd(dst, src, dst_rep_stride=1)
```

### `cpadd(dst, src, ...)`

- 作用：`vcp` 家族里的 packed 加法规约
- 参数：使用上面共享的组参数集
- 限制：
  - 目标 stride 单位遵循 `vcp` 家族规则
- 示例：

```python
cpadd(dst, src, dst_rep_stride=1)
```
