# API 参考

更详细的 API 参考现在位于 [`doc_cn/api/`](api/index.md) 下。

把这一页作为入口即可：

- [详细 API 参考索引](api/index.md)

推荐阅读顺序：

1. [装饰器](api/decorators.md)
2. [流程控制](api/flow_control.md)
3. [OpExec](api/op_exec.md)
4. [快捷接口](api/shortcuts.md)
5. [共享标量辅助函数](api/scalars.md)
6. [数据类型](api/datatype.md)
7. [存储位置](api/position.md)
8. [Pipe](api/pipe.md)
9. [Var](api/var.md)
10. [Tensor 与 Buffer 类型](api/tensor_buffer.md)
11. [寄存器与掩码类型](api/register.md)
12. [同步](api/synchronize.md)
13. [屏障](api/barrier.md)
14. [原子上下文管理器](api/atomic.md)
15. [杂项辅助](api/helpers.md)
16. 选择一组 API：
   - [A2 向量数学](api/a2_vec_math.md)
   - [A2 与共享 Vec 数据搬运](api/vec_data_movement.md)
   - [A2 Vec 控制与访问辅助](api/a2_vec_control.md)
   - [A2 Vec 排序与归并辅助](api/vec_sort.md)
   - [A5 Micro 数学](api/a5_micro_math.md)
   - [A5 Micro 数据搬运](api/a5_micro_data_movement.md)
   - [A5 Micro 类型转换](api/a5_micro_cast.md)
   - [A5 Micro 比较与选择](api/a5_micro_compare_select.md)
   - [A5 Micro 掩码操作](api/a5_micro_mask_operations.md)
17. 当你的 kernel 开始涉及 matmul staging、打包布局转换或 `DualMode` 时，再回到 [Cube 数据搬运与计算](api/cube.md)

这些详细页面会针对每一个公开 API 条目说明：

- 这个函数或对象是做什么的
- 参数各自是什么意思
- 重要限制是什么
- 最小用法示例是什么
