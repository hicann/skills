# 测试与验证

这个仓库的测试风格非常偏向模拟器优先。新的工作最好也沿用同样的节奏。

注意：当前发布的 skill 版本移除了旧的 pytest 目录。下面提到的历史测试路径，只保留为以前回归覆盖的出处说明。

## 1. 主验证循环

在这个仓库里，一条比较好的 kernel 开发循环通常是：

1. 写出精确的 PyTorch 参考实现
2. 在模拟器模式下运行 kernel
3. 与参考结果做比较
4. 如果需要调试，就把 shape 缩小
5. 只有在模拟器对齐之后，才去尝试生成产物

这种顺序能把未知因素控制在最少。

## 2. 测试放在哪里

主要的自动化测试套件位于 `historical automated tests/` (removed from this skill bundle) 下。

当前覆盖的主题包括：

- parser 行为
- 语法转换
- 形状绑定规则
- cube 与 vec 模拟
- micro 运行时行为
- autosync 与事件元数据
- flag、barrier、atomic，以及跨核等待
- 数据搬运辅助函数与布局转换

## 3. 好的可运行 kernel 文件应该长什么样

`agent/example/kernels/` 下的大多数 kernel 文件都带有一个 `__main__` 块，它会：

1. 构造示例输入
2. 在文件里直接计算 PyTorch 参考
3. 调用 `OpExec(..., simulator=True)`
4. 检查结果是否接近
5. 打印简短的误差摘要

这种格式值得保留，因为它让每个 kernel 文件都能自解释。

## 4. 容差建议

当前仓库里典型的容差习惯大致是：

- 以 float 为主的路径：使用更紧的容差，例如 `1e-5`
- half 或归一化路径：往往在 `1e-3` 左右
- fp8 量化输出：容差会宽很多

一定要让容差和公式里的真实精度边界匹配，不要把某个容差值不加思考地复制到所有 kernel 上。

## 5. `shape_bindings` 相关测试

仓库已经在下面这个文件里测试了 shape binding 行为：

- `historical testcases/test_torchplugin_shape_bindings.py` (removed from this skill bundle)

这类测试是理解以下情况的最好参照：

- 严格的歧义失败
- 只提供部分 binding，但其余维度仍然可唯一推断
- 显式 binding 与真实尺寸不匹配时报错

## 6. 同步验证

对于同步比较重的 kernel：

- 先验证数值结果
- 如果行为仍然可疑，就带 `trace=...` 再跑一次
- 把 trace 里看到的高层流水，与预期的 producer / consumer 流对照

很多时候，这比单靠盯着一份很长的 mixed kernel 源码去推理更快。

## 7. 在认为 kernel 已完成前，建议检查

- 参考公式已经写出并复核
- 模拟器输出与参考一致
- tail tile 已经被覆盖到
- 对重复标量维度检查过 `shape_bindings`
- mixed kernel 的同步已经验证过
- 至少有一个聚焦的回归测试或可运行复现文件

## 8. 什么时候要新增测试文件

当出现这些情况时，应新增或扩展测试：

- 这个行为还没有被现有 kernel 的 `__main__` 覆盖
- 这次改动触及了 parser 或 simulator 语义
- bug 是由同步、datamove 或形状推导引起的
- 你增加了一个新的指令家族或 lowering 路径

看现有的 `historical automated tests/` (removed from this skill bundle) 目录就能感受到推荐做法：尽量小、尽量聚焦，并且在可能时采用端到端方式。
