# 编程模型

本文解释的是这个框架的“编写模型”，而不是硬件模型本身。

## 1. 对外入口

仓库当前主要暴露两个面向用户的导入入口。

### `easyasc.a5`

新 kernel 大多应优先使用 `a5`。它导出了：

- 装饰器：`@kernel`、`@func`、`@auto_sync`、`@vf`
- 张量类型：`GMTensor`、`Tensor`、`DBuff`、`TBuff`
- 标量与寄存器类型：`Var`、`Reg`、`RegList`、`MaskReg`
- cube、vec 和 micro 相关的 stub 辅助函数
- 执行入口：`OpExec`
- `matmul` 这类高层 shortcut

### `easyasc.a2`

`a2` 是面向 A2 风格架构与指令序列的一套公开 DSL 接口。不要把它理解成 `a5` 的精简兼容层；`a2` 和 `a5` 是针对不同指令族的并列架构入口。`a2` 仍然提供 `@kernel`、`GMTensor`、`Tensor`、`DBuff`、`Var`、`OpExec`，以及 A2 侧的 cube / vec 操作。

## 2. 编写层次

理解这个框架最容易的方法，是把它看成五层：

1. Python 编写层
   - 你用装饰器和 DSL 对象写函数
2. 指令 IR 层
   - 对象创建、搬运、数学运算、循环、同步等动作会发射 `Instruction` 对象
3. 拆分与 lowering 层
   - parser 会把 IR 分类成 cube 侧和 vec 侧两条流
4. 执行层
   - 要么由模拟器执行这两条流，要么由生成器发出代码
5. 验证层
   - 把输出与 PyTorch 参考结果比较

## 3. 核心数据对象

### `GMTensor`

`GMTensor` 表示 kernel 参数在全局内存中的张量。kernel 的输入和输出，必须在 `@kernel` 函数签名里声明为 `GMTensor` 参数。

典型用途包括：

- kernel 输入张量
- kernel 输出张量
- 通过 `bind_cv_mutex()` 或 `bind_vc_mutex()` 作为同步锚点

### `Tensor`

`Tensor` 表示片上张量。它总是带有：

- 一个数据类型
- 一个 2D 形状
- 一个存储位置，例如 `L1`、`L0A`、`L0B`、`L0C` 或 `UB`

`<<=` 最终发射什么指令，取决于源和目标的存储位置。

例如：

- `l1 <<= gm[:, :]` 会发射 GM 到 L1 的搬运
- `ub <<= l0c` 会走 `l0c_to_ub` 路径
- `l1 <<= ub` 会走 UB 到 L1 的路径

### `DBuff` 和 `TBuff`

它们是带缓冲槽位概念的张量辅助类型，常见于流水化或双缓冲代码。它们的槽位 lineage 会影响同步逻辑。

### `Var`

`Var` 表示标量值，例如：

- 张量维度
- 循环索引
- 符号形状值
- 计数器

当你把 Python 的整数或浮点数传给 `OpExec` 时，它们会在内部被包成 `Var` 对象。

### `Reg`、`RegList`、`MaskReg`

这些是寄存器级对象，主要用于 `a5` 的 micro 与 vector 代码中：

- `Reg`：标量或向量宽度寄存器抽象
- `RegList`：固定长度的寄存器组，常用于按行处理的 vector 工作
- `MaskReg`：micro 侧的掩码寄存器抽象

## 4. 装饰器

### `@kernel`

它会把一个 Python 函数包装成 `KernelBase`。在调用时，它会：

- 绑定参数名
- 为 `GMTensor` 参数发射 `create_gm_tensor` 指令
- 创建 `_l0a`、`_l0b` 这类内部辅助缓冲
- 记录最终输出的 `GMTensor` 集合

### `@vf`

它会构建一个 `MicroModule`。`@vf` 函数只能接收位于 `UB` 的 `Tensor` 输入，以及类似 `Var` 的标量输入。它从 kernel 中被调用时，会发射 `call_micro` 指令，并把生成代码并入最终产物。

### `@func`

它使用与 `@kernel` 相同的 Python 到 DSL 的源代码变换，但不会创建 kernel wrapper。适合用来写辅助例程，在当前 kernel 或 micro 上下文里发射指令。

### `@auto_sync` 与 `with auto_sync():`

它们不会立刻执行同步，而是发射 `start_auto_sync` 与 `end_auto_sync` 标记。之后 parser 会把被标记的区域重写成基于事件的握手，只覆盖支持的同侧 pipe 对。

## 5. 会被重写的 Python 语法

框架在执行前会重写一部分 Python 构造。

典型例子包括：

- 对 `Var`、`Tensor`、`DBuff`、`TBuff`、`Reg`、`RegList` 等对象的赋值和构造，会尽量自动生成名字
- 在被转换函数里出现的 Python `and`、`or`、`not` 会被改写成按位形式
- Python 的 `if / elif / else` 会被改写成 `with If(...):`、`with Elif(...):`、`with Else():`

这也是为什么仓库更偏向在被装饰函数里写控制流，而不是手工构造指令。

## 6. 循环模型

来自 `easyasc.flowcontrol` 的自定义 `range`，并不是 Python 内置的 `range`。它会把循环指令发射到当前激活的 kernel 或 micro 上下文中。

例如：

```python
for m in range(m_begin, m_end, BLK):
    ...
```

这会发射 `start_loop` 和 `end_loop` 指令，而不是按具体整数去执行普通 Python 循环。

`unroll(...)` 则对应普通的 authoring-time 展开语义。

## 7. 存储位置

作者能直接接触到的主要位置包括：

- `Position.L1`
- `Position.L0A`
- `Position.L0B`
- `Position.L0C`
- `Position.UB`

框架会根据这些位置来验证搬运是否合法，并决定应该发射哪个 backend stub。

例如：

- vec 操作只能作用在 UB 上
- `Tensor.T` 只允许用于 L1 张量
- micro module 只接受 UB 张量

## 8. Pipe 与 side

当前实现区分 cube 侧和 vec 侧执行。

从概念上说：

- cube 侧 pipe 家族包括 `MTE2`、`MTE1`、`M`、`FIX`
- vec 侧 pipe 家族包括 `MTE2`、`V`、`MTE3`

这个拆分很重要，因为：

- parser 会生成彼此独立的 cube 和 vec 代码
- `auto_sync()` 只会给硬编码好的同侧 pipe 对插入握手
- 跨侧 ownership 仍然需要显式 mutex

## 9. 形状推导模型

`OpExec` 会根据以下信息来构造 `GMTensor` 的形状：

- 实际传入的 PyTorch 张量形状
- 标量参数列表
- 可选的 `shape_bindings`

如果多个标量参数的值相同，推导就可能变得有歧义。运行时会选择尽早报错，而不是冒险去猜。

## 10. 推荐的理解方式

在这个仓库里写 kernel 时，推荐按这个顺序思考：

1. 精确的数学契约
2. 内存布局
3. 流水拓扑
4. tile ownership
5. 同步边界
6. tail-safe 写回
7. 与 PyTorch 的对齐验证

这个顺序和当前代码库的组织方式，以及大多数样例 kernel 的写法，是一致的。
