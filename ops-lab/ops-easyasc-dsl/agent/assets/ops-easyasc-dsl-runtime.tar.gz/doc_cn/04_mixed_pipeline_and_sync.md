# 混合流水与同步

这个仓库支持跨越 cube 与 vec 执行的 kernel，但同步模型是刻意保持显式的。

## 1. 流水拓扑

仓库里的大多数 kernel，都可以归到下面这些形态之一：

- 纯 cube：`GM -> L1 -> L0C -> GM`
- cube -> vec：`... -> L0C -> UB -> vec -> GM`
- vec -> cube：`GM -> UB -> vec -> L1 -> L0C -> GM`
- vec -> cube -> vec
- cube -> vec -> cube
- cube -> vec -> cube -> vec

要先选拓扑。它会决定：

- 你需要哪些缓冲
- 每个阶段由哪一侧持有 ownership
- `auto_sync()` 是否已经够用
- 显式 mutex 交接应该放在哪里

## 2. `auto_sync()` 实际做了什么

`auto_sync()` 并不是一个通用同步开关。在当前实现里，它会：

- 在编写阶段发射区域标记
- 在 parser lowering 阶段重写支持的同侧 producer / consumer 对
- 为这些 pipe 对插入事件创建以及 `event_wait` / `event_set` 指令

它本身不会在 cube 和 vec 之间转移 ownership。

## 3. `auto_sync()` 支持的同侧 pipe 对

当前硬编码支持的 autosync 范围围绕这些 pipe 对组织：

- vec 侧：
  - `MTE2 -> V`
  - `V -> MTE3`
- cube 侧：
  - `MTE2 -> MTE1`
  - `MTE1 -> M`
  - `M -> FIX`

如果某个操作不在这些已分类的 pipe 对里，那么当前的 `auto_sync()` 就不会为它自动构建握手。

## 4. 什么时候需要显式 mutex

当 ownership 需要跨越 cube 和 vec 边界时，就要使用显式 mutex。

两种主要类型是：

- `CvMutex`：cube 是生产者，vec 是消费者
- `VcMutex`：vec 是生产者，cube 是消费者

这个仓库里常见的模式有：

- 围绕 `l0c_to_ub` 再接 `@vf` 或 vec 阶段的 cube -> vec 交接
- 围绕 `ub_to_l1_nd2nz` 或 `ub_to_l1_nz` 再接 `matmul` 的 vec -> cube 交接

## 5. cube -> vec 示例

`agent/example/kernels/a5/basic_cube_vec_mix.py` 里的紧凑模式大致是这样：

```python
cvmutex = CvMutex(0, src_end_pipe=Pipe.FIX, dst_end_pipe=Pipe.V)

cvmutex.lock()
xbuf[cnt] <<= l0c[cnt]
cvmutex.ready()

cvmutex.wait()
simple_micro(xbuf[cnt], outbuf[cnt], ...)
cvmutex.free()
```

可以把这个生命周期读成：

1. 生产者先占一个槽位
2. 生产者把数据写满这个槽位
3. 生产者把槽位标记为 ready
4. 消费者等待 ready
5. 消费者处理这个槽位
6. 消费者释放槽位

## 6. vec -> cube 示例

反向模式出现在 vec 预处理类 kernel 中：

1. UB 数据在 vec 侧被生产出来
2. 用 `VcMutex` 守住 publish 边界
3. vec 侧把数据写入或重新发布到 L1
4. cube 侧的 matmul 消费这块已发布的数据

理解下列这些文件时，最合适的方式就是这样：

- `agent/example/kernels/a5/vec_cube_abs_sqrt_matmul.py`
- `agent/example/kernels/a5/vec_cube_abs_sqrt_matmul_nz.py`

## 7. tail-safe 写回规则

混合 kernel 往往会在本地算完整 tile，但只把其中有效部分写回。

常见的 vec 侧 subblock 写回模式是：

```python
valid_m = Min(BLK, m2 - m)
half_rows = CeilDiv(valid_m, 2)
sb_idx = GetSubBlockIdx()
row_begin = sb_idx * half_rows
row_end = Min(row_begin + half_rows, valid_m)
row_count = row_end - row_begin
z[m + row_begin:m + row_end, :] <<= outbuf[cnt][0:row_count, :]
```

它之所以重要，是因为：

- GM 边界必须服从逻辑上的 tail
- UB 或 L0C 这样的本地 tile 一般保持固定满尺寸
- 两个 vector subblock 可以安全地把有效行拆开处理

## 8. 缓冲区 ownership 规则

这个仓库里比较稳定的一套模式是：

- GM 边界使用 `valid_m`、`valid_n`、`valid_k`
- 本地缓冲保持固定 tile 大小
- 计数器单调前进，并且常常与 DBuff 奇偶槽位对应
- 生产者和消费者尽量紧贴缓冲交接点出现

除非你非常清楚理由，否则不要把一个缓冲的生命周期拉得比它的生产者 / 消费者配对关系长很多。

## 9. 实战建议

当同步开始变复杂时，可以按下面这张检查表理：

1. 明确谁是生产方
2. 明确谁是消费方
3. 列清楚源缓冲和目标缓冲到底是哪一个
4. 判断边界是同侧还是跨侧
5. 同侧顺序才考虑 `auto_sync()`
6. 跨侧 ownership 则使用 `CvMutex` 或 `VcMutex`

## 10. 值得对照的文件

- `agent/example/kernels/a5/basic_cube_vec_mix.py`
- `agent/example/kernels/a5/vec_cube_vec_scale2_abs_add1_matmul.py`
- `agent/example/kernels/a5/test_mla_entire.py`
