# easyasc 中文文档总览

本文基于 `doc/` 目录中的英文文档整理，目标是提供一份便于快速查阅的中文入口文档。它不是逐段直译，而是按照原文结构重新组织内容，保留核心概念、使用路径、开发建议和 API 地图，方便在阅读源码与英文细节文档之前先建立整体认识。

## 1. 项目定位

`easyasc` 是一个用 Python 描述 Ascend 风格混合内核的 DSL 框架。它提供统一的编写入口，支持以下几件事：

- 从 Python 内核函数生成指令级 IR
- 将程序拆分为 cube / vec 两侧代码
- 在内置模拟器中执行和验证内核
- 生成非模拟器模式下需要的运行时代码与自定义算子产物

整个仓库围绕三条主线展开：

1. 用 `@kernel`、`Tensor`、`GMTensor`、`Var`、`@vf` 等对象描述内核。
2. 由框架完成 IR 构建、同步插入、代码拆分和后端降级。
3. 先在模拟器里验证，再进入生成模式或更接近硬件的执行路径。

## 2. 建议阅读顺序

如果你第一次接触这个仓库，推荐按下面顺序阅读原始文档：

1. `doc/01_quickstart.md`
2. `doc/02_programming_model.md`
3. `doc/03_write_your_first_kernel.md`
4. `doc/04_mixed_pipeline_and_sync.md`
5. `doc/05_simulator_and_trace.md`
6. `doc/06_codegen_and_runtime.md`
7. `doc/07_kernel_patterns.md`
8. `doc/08_testing_and_validation.md`
9. `doc/10_troubleshooting.md`
10. `doc/09_api_reference.md` 与 `doc/api/`
11. `doc/11_architecture_for_contributors.md`
12. `doc/12_stub_to_codegen_name_map.md`

阅读时的经验法则是：

- 新写内核时先看使用文档，再查 API。
- 遇到同步、死锁、写回错误时优先看 `mixed_pipeline_and_sync`、`troubleshooting`、`synchronize`。
- 遇到推导、降级、生成物不一致时优先看 `codegen_and_runtime`、`op_exec`、`architecture_for_contributors`。

## 3. 快速开始

`doc/01_quickstart.md` 的重点是帮助你完成第一次成功运行。

核心信息包括：

- 如果本地有 `torch210npu` conda 环境，可以作为示例环境使用（并非硬性要求）。
- 最小可运行示例通常从 `agent/example/kernels/a5/matmul_float_mmad.py` 开始。
- 一个最小内核一般包含：
  - `@kernel` 定义
  - `GMTensor` 输入输出
  - 片上 `Tensor` 分配
  - 一组数据搬运与计算 API
  - 用 `OpExec(..., simulator=True)` 运行
  - 与 PyTorch 参考结果比较
- `OpExec` 是统一执行入口，既能跑模拟器，也能走代码生成路径。
- 当多个张量维度共用同一个标量参数，且框架无法唯一推断时，需要通过 `shape_bindings` 指定维度绑定关系。

## 4. 编程模型

`doc/02_programming_model.md` 解释了作者在写内核时真正接触到的抽象层。

### 4.1 公开入口

- `easyasc.a5`
  - 当前仓库里大多数新内核与测试都使用它。
  - 覆盖 cube、vec、micro、寄存器、同步、调试等更完整能力。
- `easyasc.a2`
  - 面向 A2 风格架构与指令序列的公开 DSL 接口。
  - 与 `easyasc.a5` 是并列入口，不是它的兼容层。

### 4.2 关键数据对象

- `GMTensor`
  - 对应 kernel 的全局内存输入输出。
  - 用户指定的张量参数最终都应映射到这里。
- `Tensor`
  - 片上张量，可位于 `L1`、`L0A`、`L0B`、`L0C`、`UB` 等位置。
- `DBuff`、`TBuff`
  - 用于表示带槽位概念的缓冲区，适合双缓冲或多槽复用。
- `Var`
  - 标量变量，常用于维度、循环边界、对齐值和符号表达式。
- `Reg`、`RegList`、`MaskReg`
  - 主要服务于 micro 或 vec 级寄存器表达。

### 4.3 装饰器语义

- `@kernel`
  - 定义一个可以由 `OpExec` 调度的内核入口。
- `@vf`
  - 定义 vec 侧辅助函数，常用于对 UB 数据做后处理。
- `@func`
  - 定义普通 DSL 辅助函数，用于重用逻辑。
- `@auto_sync` / `with auto_sync():`
  - 只负责同一侧内部某些 pipe 对之间的自动事件插入，不等价于跨侧 ownership 传递。

### 4.4 Python 语法重写

框架会重写一部分 Python 语法：

- `range(...)`
- `unroll(...)`
- `If(...)`、`Elif(...)`、`Else()`
- 装饰函数中的部分 `if/elif/else`

理解这一点很重要，因为你看到的是 Python 样式代码，但实际执行的是 DSL AST 降级后的结果。

## 5. 第一个内核怎么写

`doc/03_write_your_first_kernel.md` 给出的主线非常清晰：

1. 先写出精确的 PyTorch 参考公式，尤其要保留 cast 顺序。
2. 再声明 kernel 签名，让输入输出都落在 `GMTensor` 上。
3. 根据 pipeline 需求分配片上 `Tensor`。
4. 显式描述数据搬运路径，例如 GM -> L1 -> L0 或 GM -> UB。
5. 用 `OpExec` 执行并对比参考输出。
6. 在确认正确后，再逐步演进到分块、双缓冲、混合流水和更复杂的同步。

第一次写内核最常见的问题包括：

- 只写公式，没有写清楚数据路径
- 混淆 `GMTensor` 与 `Tensor`
- 在尾块处理上直接缩小片上张量尺寸
- 在需要 `shape_bindings` 的地方依赖自动推断

## 6. 混合流水与同步

`doc/04_mixed_pipeline_and_sync.md` 是理解仓库风格的关键文档之一。

### 6.1 常见流水拓扑

- 纯 cube
- cube -> vec
- vec -> cube
- vec -> cube -> vec
- cube -> vec -> cube
- cube -> vec -> cube -> vec

先确定拓扑，再决定缓冲区、mutex 和计数器，通常比先写代码更重要。

### 6.2 `auto_sync()` 的边界

`auto_sync()` 只处理同一侧内部的 pipe 顺序关系，支持的 pipe 对是硬编码的，例如：

- vec 侧：`MTE2 -> V`、`V -> MTE3`
- cube 侧：`MTE2 -> MTE1`、`MTE1 -> M`、`M -> FIX`

它不会自动解决：

- cube 与 vec 之间的 ownership 交接
- 跨侧读写次序
- 用户自定义的任意依赖关系

### 6.3 显式互斥原语

跨侧同步通常使用：

- `CvMutex`
  - cube 生产、vec 消费
- `VcMutex`
  - vec 生产、cube 消费

实践规则是把 `lock / ready / wait / free` 紧贴在真正的生产者和消费者旁边，不要把资源生命周期拉得太长。

### 6.4 尾块写回原则

仓库里反复强调的规则是：

- GM 边界按 `valid_m`、`valid_n`、`valid_k` 控制
- 本地 `Tensor` 仍保持整 tile 尺寸
- vec 写回常按 subblock 拆行，避免奇数尾块或半块场景出错

## 7. 模拟器与 trace

`doc/05_simulator_and_trace.md` 解释了为什么这个仓库默认采用“先跑模拟器”的开发方式。

主要原因是：

- 模拟器能更快验证数值逻辑、搬运边界、同步语义和 tile 划分。
- trace 能帮助你看到更接近执行顺序的行为。
- 很多问题在进入生成模式前就能被定位。

推荐调试循环是：

1. 写最小内核或最小失败样例
2. 用模拟器跑通
3. 必要时打开 trace
4. 对照已有 kernel 和 simulator 实现排查
5. 再进入 codegen 或运行时路径

## 8. 代码生成与运行时

`doc/06_codegen_and_runtime.md` 描述了从 DSL 到产物的核心链路。

重点可概括为：

- 程序会先按 cube / vec 拆分。
- 模拟器路径会走内部解释执行逻辑。
- 生成路径会产出后端代码与相关资源。
- `KernelBase` 提供运行与产物管理的公共能力。
- parser 会把 Python 样式 DSL 逐步降为内部 IR。
- `OpExec` 是统一入口，支持 `simulator`、`trace`、`gen_only`、`skip_compile` 等选项。
- `shape_bindings` 不只是语法糖，而是连接张量维度与标量形状参数的重要运行时约束。

如果遇到“模拟器正确但生成失败”，这里是最先该回看的文档。

## 9. 内核模式库

`doc/07_kernel_patterns.md` 和 `agent/references/examples/kernel-catalog.md` 一起构成了“怎么选实现路径”的经验库。

主要模式包括：

- 最短正确性基线
  - 用最短 cube-only matmul 验证基本路径。
- cube -> vec 后处理
  - 先做 matmul，再在 vec 侧做归一化、加偏置、量化等。
- vec -> cube 预处理
  - 先在 UB 做变换，再把结果发布到 cube 消费路径。
- 多阶段混合流水
  - 例如 vec -> cube -> vec，或 cube -> vec -> cube。
- 流式与 lookahead
  - 典型场景是一个阶段消费前一 tile，而后一阶段已开始处理下一 tile。
- 纯 vec / micro 模式
  - 适合没有 cube matmul 主体的算子。

选择模式时要先回答三个问题：

1. 主计算发生在 cube 还是 vec？
2. 中间结果是否必须跨侧传递？
3. 是否需要分阶段保留状态、延迟消费或双缓冲？

## 10. 测试与验证

`doc/08_testing_and_validation.md` 给出的主张非常明确：不要只看“能跑”，而要看“是否可靠地对”。

推荐验证流程：

1. 明确 PyTorch 参考公式
2. 用 `OpExec(..., simulator=True)` 跑内核
3. 对比数值误差
4. 覆盖关键 shape，尤其是 tail case
5. 针对 `shape_bindings`、同步、边界对齐增加回归测试

一个可维护的 kernel 示例文件通常应同时包含：

- 内核定义
- 参考实现
- 一个可直接运行的 `__main__` 校验入口

## 11. 常见问题排查

`doc/10_troubleshooting.md` 按高频错误给出了解释。下面是中文化后的速查版。

### 11.1 参数顺序错误

报错类似：

```text
Invalid argument order: torch.Tensor must come before int/float
```

含义是 `OpExec` 的参数顺序不符合约定，张量输入必须先于标量参数传入。

### 11.2 标量维度匹配歧义

报错类似：

```text
Ambiguous scalar match for tensor #... dim #...
```

通常表示某个张量维度可以匹配多个标量参数，框架无法自动判断。应补充 `shape_bindings`。

### 11.3 `shape_bindings` 值不匹配

报错类似：

```text
shape_bindings[...] mismatches tensor dim value
```

表示你手工提供的维度绑定与实际输入张量尺寸不一致。

### 11.4 只在模拟器支持 trace

`trace` 只能与 `simulator=True` 配合使用。

### 11.5 vec / micro 位置限制

- `VecOP only supports UB position`
- `MicroModule only accepts Tensor inputs in UB`

这类错误通常意味着你把 API 用在了错误的 memory position 上。

### 11.6 运行不报错但结果不对

优先检查：

- 参考公式里的 cast 顺序
- matmul 输入布局
- `valid_*` 边界
- 中间写回路径
- `auto_sync()` 是否被误当成跨侧同步

### 11.7 死锁或卡住

优先检查：

- `CvMutex` / `VcMutex` 的四个动作是否成对出现
- 生产者与消费者是否使用同一资源槽位
- `ready` 和 `wait` 是否跨 iteration 错位

## 12. 贡献者视角的架构说明

`doc/11_architecture_for_contributors.md` 面向需要改框架的人，而不仅仅是写 kernel 的人。

可以把系统分成几层：

1. 公共 API 层
   - `easyasc.a5`
   - `easyasc.a2`
2. parser 与 lowering
   - 把 DSL 风格 Python 转成内部指令模型
3. stub 接口
   - 负责不同 API 的指令发射
4. simulator
   - 负责各 pipe、数据搬运、同步、micro 语义模拟
5. codegen/runtime
   - 负责生成后端执行需要的代码与资源

如果你要修改框架行为，最重要的建议是：

- 不要只看 kernel 表面代码，要看 stub、parser 和 simulator 的完整链路。
- 新行为应同时考虑模拟器与生成路径是否一致。
- 同步相关改动一定要核对 autosync、event、mutex、pipe 分类是否同时受影响。

## 13. API 参考地图

`doc/09_api_reference.md` 是 API 总入口，真正细节主要在 `doc/api/` 中。下面给出中文导航。

### 13.1 执行入口与装饰器

- `doc/api/op_exec.md`
  - `OpExec(...)`
  - `shape_bindings`
- `doc/api/decorators.md`
  - `kernel`
  - `func`
  - `auto_sync`
  - `vf`
- `doc/api/flow_control.md`
  - `range`
  - `unroll`
  - `If / Elif / Else`

### 13.2 基础类型与共享对象

- `doc/api/datatype.md`
  - `DT`
  - `Datatype`
  - `DataTypeValue`
- `doc/api/position.md`
  - `Position`
  - `PositionType`
- `doc/api/pipe.md`
  - `Pipe`
  - `PipeType`
- `doc/api/var.md`
  - `Var`
- `doc/api/tensor_buffer.md`
  - `Tensor`
  - `GMTensor`
  - `DBuff`
  - `TBuff`
- `doc/api/register.md`
  - `Reg`
  - `RegList`
  - `MaskReg`
  - `MaskType`

### 13.3 标量工具

- `doc/api/scalars.md`
  - worker 查询函数
  - 对齐函数
  - 标量运算构造器

常用函数包括：

- `CeilDiv`
- `GetCubeNum`
- `GetCubeIdx`
- `GetVecNum`
- `GetVecIdx`
- `GetSubBlockIdx`
- `Align16/32/64/128/256`
- `Min`
- `Max`

### 13.4 cube 侧 API

- `doc/api/cube.md`
  - `gm_to_l1_nd2nz`
  - `set_constant_to_l1`
  - `l1_to_l0`
  - `mmad`
  - `l0c_to_gm_nz2nd`
  - `l0c_to_l1`
  - `l0c_to_ub`
  - `DualMode`
- `doc/api/shortcuts.md`
  - `matmul`

这些 API 主要覆盖：

- ND/NZ/ZN 布局转换
- L1/L0A/L0B/L0C 的数据搬运
- matmul 计算
- cube 结果写回到 GM、L1 或 UB

### 13.5 A2 vec 侧 API

- `doc/api/a2_vec_math.md`
  - 二元、单目、单目标量、dup、规约风格 vec 算子
- `doc/api/a2_vec_control.md`
  - `cast`
  - `compare`
  - `compare_scalar`
  - `set_cmpmask`
  - `select`
  - `set_mask`
  - `reset_mask`
  - `gather`
  - `scatter`
- `doc/api/vec_data_movement.md`
  - `gm_to_ub_pad`
  - `ub_to_gm_pad`
  - `ub_to_l1_nd2nz`
  - `ub_to_l1_nz`
  - `ub_to_ub`
- `doc/api/vec_sort.md`
  - `sort32`
  - `mergesort4`
  - `mergesort_2seq`

### 13.6 A5 micro API

- `doc/api/a5_micro_math.md`
  - `arange`
  - `dup`
  - `add/sub/mul/div`
  - `exp/abs/relu/sqrt/ln`
  - `vmaxs/vmins/adds/muls/lrelu/axpy`
  - `cadd/cmax/cmin/cgadd/cgmax/cgmin/cpadd`
- `doc/api/a5_micro_cast.md`
  - `RoundMode`
  - `CastConfig`
  - `RegLayout`
  - `cast`
  - `Reg.cast`
  - `Reg.astype`
  - `Reg.pack4`
- `doc/api/a5_micro_compare_select.md`
  - `CompareMode`
  - `compare`
  - `select`
- `doc/api/a5_micro_data_movement.md`
  - `ub_to_reg`
  - `reg_to_ub`
  - gather/scatter
  - interleave/deinterleave
- `doc/api/a5_micro_mask_operations.md`
  - 各类 mask 逻辑运算
  - pack / unpack
  - `update_mask`

### 13.7 同步、屏障与原子操作

- `doc/api/synchronize.md`
  - `CvMutex`
  - `VcMutex`
  - 跨核 / 全核同步
  - `setflag`
  - `waitflag`
  - `SEvent`
  - `DEvent`
- `doc/api/barrier.md`
  - `barrier(pipe)`
  - `bar_m`
  - `bar_v`
  - `bar_all`
- `doc/api/atomic.md`
  - `atomic_add`
  - `atomic_max`
  - `atomic_min`

### 13.8 调试辅助

- `doc/api/helpers.md`
  - `sim_print`
  - `dump_tensor`
  - `inline`

它们主要用于：

- 模拟器中的日志观察
- 导出中间张量
- 在 codegen 路径中注入后端代码片段

## 14. 几条实用开发原则

综合 `doc/` 和 `agent/references/examples/kernel-catalog.md`，可以提炼出几条最重要的开发原则：

1. 从精确的参考公式开始，不要省略 cast 顺序。
2. 先选 pipeline 拓扑，再写具体内核。
3. 尾块只在 GM 边界收缩，不在片上张量尺寸上做文章。
4. `auto_sync()` 不是跨侧同步方案。
5. 新内核先在模拟器验证，再考虑生成模式。
6. 遇到问题时不要只看 kernel 文件，要沿着 stub、parser、simulator 一路追踪。
7. 现有 kernel 适合学习模式和约束，不适合直接拷贝复用。

## 15. 原始文档对应关系

下面是本中文总览对应的英文原文文件，便于交叉查阅：

- `doc/01_quickstart.md`
- `doc/02_programming_model.md`
- `doc/03_write_your_first_kernel.md`
- `doc/04_mixed_pipeline_and_sync.md`
- `doc/05_simulator_and_trace.md`
- `doc/06_codegen_and_runtime.md`
- `doc/07_kernel_patterns.md`
- `doc/08_testing_and_validation.md`
- `doc/09_api_reference.md`
- `doc/10_troubleshooting.md`
- `doc/11_architecture_for_contributors.md`
- `doc/12_stub_to_codegen_name_map.md`
- `doc/api/index.md`
- `doc/api/op_exec.md`
- `doc/api/decorators.md`
- `doc/api/flow_control.md`
- `doc/api/datatype.md`
- `doc/api/position.md`
- `doc/api/pipe.md`
- `doc/api/var.md`
- `doc/api/tensor_buffer.md`
- `doc/api/register.md`
- `doc/api/scalars.md`
- `doc/api/cube.md`
- `doc/api/shortcuts.md`
- `doc/api/a2_vec_math.md`
- `doc/api/a2_vec_control.md`
- `doc/api/vec_data_movement.md`
- `doc/api/vec_sort.md`
- `doc/api/a5_micro_math.md`
- `doc/api/a5_micro_cast.md`
- `doc/api/a5_micro_compare_select.md`
- `doc/api/a5_micro_data_movement.md`
- `doc/api/a5_micro_mask_operations.md`
- `doc/api/synchronize.md`
- `doc/api/barrier.md`
- `doc/api/atomic.md`
- `doc/api/helpers.md`

## 16. 后续扩展建议

如果你后面希望把 `doc_cn/` 扩展成完整中文版文档集，建议按下面顺序逐步细化：

1. 先把 `01` 到 `11` 这些高层文档逐个扩展为中文独立页。
2. 再补 `doc/api/index.md` 与 `op_exec.md`、`synchronize.md` 这些最常查的 API 页面。
3. 最后再细化 A2 / A5 的长篇 API 手册。

这样成本更可控，也更容易保持与英文原文同步。
