# 快速开始

本指南面向这样一类读者：先想把现成 kernel 跑起来，再慢慢理解框架其余部分。

## 1. 环境

这个仓库目前还不是一个可直接安装的 Python 项目。更常见的工作方式，是直接在仓库根目录下开发和运行。

示例环境（仅作参考，并非必须）：

```bash
# 仅作参考——请根据本地情况调整
conda activate torch210npu
```

如果你的机器上没有这个环境，就使用已经具备所需依赖的默认 Python 环境。在阅读已归档的运行时/文档或运行示例之前，先执行 `bash agent/scripts/init.sh` 还原归档内容。

基于当前源码树，至少应满足这些前提：

- Python 类型标注需要保持与 Python 3.8 兼容
- `OpExec` 依赖 `torch`，因此环境里必须能导入 `torch`
- 运行示例时，当前工作目录应当是仓库根目录

## 2. 第一次成功运行

先运行最小的 matmul 示例：

```bash
python agent/example/kernels/a5/matmul_float_mmad.py
```

这个文件会做这些事：

1. 从 `easyasc.a5` 导入公开 API
2. 定义一个 `@kernel`
3. 构造示例用的 PyTorch 张量
4. 通过 `OpExec(..., simulator=True)` 启动 kernel
5. 把 kernel 输出与 `x @ y.t()` 做比较

如果运行成功，说明你已经验证了：

- Python DSL 能正常构建 kernel
- 模拟器能够执行它
- 输出张量能正确回读到 PyTorch

## 3. 最小 kernel 的结构

仓库里最短的例子是 `agent/example/kernels/a5/matmul_float_mmad.py`：

```python
from easyasc.a5 import *


@kernel()
def matmul_float_mmad_kernel(x: GMTensor, y: GMTensor, z: GMTensor, M: Var, N: Var, K: Var):
    l1x = Tensor(DT.float, [M, K], Position.L1)
    l1y = Tensor(DT.float, [N, K], Position.L1)
    l0c = Tensor(DT.float, [M, N], Position.L0C)

    l1x <<= x[:, :]
    l1y <<= y[:, :]
    matmul(l0c, l1x, l1y, m=M, n=N, k=K, is_init=True)
    z[:, :] <<= l0c
    return z
```

可以把这段代码理解成一张数据流图：

- `x` 和 `y` 位于全局内存
- `l1x` 和 `l1y` 是片上的 L1 张量
- `l0c` 保存的是 float 累加结果 tile
- `<<=` 会根据源和目标的组合，发射对应的数据搬运或写回指令

## 4. 一分钟理解 `OpExec`

`OpExec` 是主要的执行入口：

```python
z_kernel = OpExec(matmul_float_mmad_kernel, simulator=True)(x, y, z, M, N, K)
```

需要记住的规则有：

- 所有 `torch.Tensor` 参数必须放在标量参数前面
- 标量参数会在内部转换成 `Var` 对象
- 当 `simulator=True` 时，输入张量会被拷贝到模拟器可见的 `GMTensor.data` 中
- 返回的 `GMTensor` 输出会再转换回 PyTorch 张量

## 5. 模拟器模式与生成模式

优先使用模拟器模式：

```python
OpExec(kernel_fn, simulator=True)(...)
```

当你需要生成产物时，再使用生成模式：

```python
OpExec(kernel_fn, out_dir="my_kernel", simulator=False, gen_only=True)(...)
```

二者的高层差别是：

- 模拟器模式会通过 `easyasc/simulator_v2/` 下的 V2 运行时执行 kernel
- 生成模式会经由 parser 和模板路径生成 C++ 与包装层产物

## 6. 什么时候需要 `shape_bindings`

运行时会尝试推断每个张量维度对应哪个标量 `Var`。当多个标量参数在运行时恰好有相同的整数值时，这个推断就可能变得有歧义。

例如：

```python
out = OpExec(kernel_fn, simulator=True)(
    x,
    y,
    z,
    m,
    n,
    k,
    shape_bindings={
        0: [0, 2],
        1: [1, 2],
        2: [0, 1],
    },
)
```

其中每个 key 是张量参数的索引，每个 list 表示张量各维度对应的标量参数索引，也可以写成 `None`。

如果你看到类似下面的报错：

```text
Ambiguous scalar match for tensor #... dim #...
```

先补显式的 `shape_bindings`，不要急着改 kernel 主体。

## 7. 接下来该看什么

- [编程模型](02_programming_model.md)
- [编写你的第一个 Kernel](03_write_your_first_kernel.md)
- [模拟器与 Trace](05_simulator_and_trace.md)
