# 代码生成与运行时

本文解释的是：kernel 发射出指令 IR 之后，接下来会发生什么。

## 1. 执行路径分流

当前框架通过 `OpExec` 支持两条主要执行路径：

- 模拟器路径
- 生成路径

两条路径的起点是一样的：

1. 绑定 `torch.Tensor` 和标量输入
2. 把它们转换成 `GMTensor` 和 `Var`
3. 执行 Python kernel 主体，发射指令

之后，两条路径才开始分叉。

## 2. 模拟器路径

当 `simulator=True` 时：

- `GMTensor.data` 会根据输入张量填充
- kernel 通过自己的 simulator 入口执行
- 输出会从 `GMTensor.data` 回读出来

在编写新 kernel 时，这条路径应当作为默认首选。

## 3. 生成路径

当 `simulator=False` 时，`OpExec` 会走生成流程：

- 输入二进制会被写到 `<base>_aclnn_test/input`
- parser lowering 会生成代码产物
- 可选地调用构建与运行脚本
- 除非设置了 `gen_only=True`，否则输出二进制会再被读回 PyTorch 张量

这里的 base 目录是：

- 如果传了 `out_dir`，就用 `out_dir`
- 否则使用 kernel 名称

## 4. `KernelBase` 负责什么

`KernelBase` 就是 `@kernel` 创建出来的包装器。

它的职责包括：

- 保存发射出来的指令
- 跟踪被使用过的 micro module
- 收集输出 `GMTensor`
- 为已注册的 mutex 插入跨侧 ready / wait 支架逻辑
- 输出生成后的 cube / vec 代码

此外，在用户代码开始之前，它还会自动插入一些框架自身需要的指令。

## 5. parser 如何做 lowering

parser 流程从高层看主要做三件事：

1. 把指令流拆成 cube 侧和 vec 侧两条流
2. 为支持的同侧 pipe 对插入 autosync 事件
3. 用按操作分类的 handler，把各侧翻译成生成代码

关键模块包括：

- `easyasc/parser/asc.py`
- `easyasc/parser/asc_autosync.py`
- `easyasc/parser/asc_pruning.py`
- `easyasc/parser/asc_handlers/`

## 6. 生成产物

`KernelBase.dump_kernel()` 会写出：

- `<path>_cube.h`
- `<path>_vec.h`
- `<path>.cpp`

生成出的 C++ 包装层会：

- 包含张量和辅助头文件
- 在需要时包含生成出的 micro 头文件
- 调度 cube 和 vec 入口函数
- 从生成运行时数据中读取标量 tiling 值

## 7. 构建与运行脚本钩子

当生成模式不是 `gen_only` 时，`OpExec` 可以执行：

- `b.sh` 用于构建
- `r.sh` 用于运行

它们的日志会被写到例如：

- `b.sh.log`
- `r.sh.log`

这也是为什么生成模式默认假设你在仓库根目录工作，并且本地工具链已经准备好。

## 8. `shape_bindings`

`shape_bindings` 属于 `OpExec.__call__` 的参数，而不是 kernel 本身的一部分。

当出现这些情况时，需要它：

- 两个或更多标量参数在运行时恰好有相同的整数值
- 运行时无法确定某个张量维度到底对应哪个标量

如果某个 binding 是显式给出的，运行时还会检查：你选中的那个标量值，是否真的等于实际的张量维度；不相等就报错。

## 9. 常用的 `OpExec` 选项

- `out_dir`：输出目录前缀
- `profile`：在生成模式下请求更偏 profiling 的行为
- `gen_only`：只生成产物，不执行生成路径
- `simulator`：走模拟器，而不是生成路径
- `skip_compile`：在生成模式下跳过 `b.sh`
- `trace`：把模拟器 trace 输出到文件

## 10. 推荐使用顺序

对于新 kernel 的开发，推荐这样推进：

1. `simulator=True`
2. 如果需要看同步，再加上 `simulator=True, trace=...`
3. `simulator=False, gen_only=True`
4. 最后再走完整的生成与运行流程

这个顺序和实现结构是对齐的，也能把你同一时间要排查的变量数降到最低。
