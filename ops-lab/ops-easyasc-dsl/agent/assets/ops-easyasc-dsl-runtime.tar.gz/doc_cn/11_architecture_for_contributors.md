# 面向贡献者的架构说明

本文面向那些需要修改框架本身的人，而不只是基于它来写 kernel 的人。

## 1. 仓库结构

主要源码区域包括：

- `easyasc/`
  - 公开 DSL 接口
  - parser 与 lowering
  - simulator V2 运行时
  - 指令发射器与辅助函数
- `agent/example/kernels/`
  - 样例 kernel 与可运行验证脚本（由 `agent/scripts/init.sh` 按需还原）
- `agent/scripts/`
  - 独立工具与维护脚本
- `doc/`
  - 英文项目与 API 文档
- `doc_cn/`
  - 中文文档镜像
- `agent/`
  - router-first 指导、目录索引与实现路径映射
- `agent/example/demo/`
  - 按设备家族组织的手动 runner / 编译集成 demo

高层 owner 文档包括：

- `README.md`、`README_CN.md`
  - 顶层项目入口
- `AGENTS.md`
  - 面向 agent 式贡献者的仓库规则
- `agent/ROUTER.md`
  - router-first 入口：把读者引导到最小够用的 playbook 或参考页，而不是一次性加载所有地图
- `agent/references/repo-map.md`
  - 顶层布局与归属说明
- `agent/references/code-paths.md`
  - 实现路径速查
- `agent/references/simulator-v2.md`
  - 模拟器运行时与 bridge 的聚焦地图

注意：`testcases/` 已从交付的 skill 包中移除。本文档其余位置对它的描述仅作为历史参考。

## 2. 设备家族映射

在阅读任何和硬件分支相关的代码前，先把这层映射记清楚：

- `device_type == "950"` 对应 C310 路径
- `device_type.startswith("b")` 对应 C220 路径
- 在 `easyasc/resources/tensorutils.h` 中，`__DAV_C310__` 就是 `950` 分支
- 在 `easyasc/resources/tensorutils.h` 中，`__DAV_C220_CUBE__` 就是 `b*` 分支

很多支持性判断、helper 选择和生成代码路径都依赖这层映射。
看仓库时不要把它反过来。

## 3. 端到端控制流

典型的内部路径是：

1. 带装饰器的 Python 函数先被 `easyasc/pythonic.py` 转换
2. `@kernel` 把它包成 `KernelBase`
3. DSL 对象把操作发射成 `Instruction`，进入当前激活的 kernel 或 micro 上下文
4. `OpExec` 绑定运行时输入，并触发模拟器或生成流程
5. parser / lowering 路径或 V2 bridge 路径消费这些指令
6. 模拟器运行时或生成出的运行时执行结果
7. 当多个标量值相同导致维度匹配歧义时，由 `shape_bindings` 参与消歧

关键入口模块有：

- `easyasc/decorators.py`
- `easyasc/kernelbase/kernelbase.py`
- `easyasc/torchplugin.py`

## 4. 对外接口模块

- `easyasc/a2.py`
- `easyasc/a5.py`
- `easyasc/flowcontrol.py`
- `easyasc/utils/Tensor.py`
- `easyasc/utils/var.py`

如果你要修改公开 API，应该先从这里入手，并先判断这个行为属于 `a2`、`a5` 还是两者都需要。
不要默认所有公开 API 变更都必须同时落到 `a2` 和 `a5`。

## 5. parser 与 lowering

parser 栈位于 `easyasc/parser/` 下。

关键职责如下：

- `asc.py`
  - 指令拆分
  - side 分类
  - autosync 插入
  - 翻译分发
- `asc_pruning.py`
  - 清理与裁剪 pass
- `asc_autosync.py`
  - 为支持的同侧 pipe 对插入事件
- `asc_handlers/`
  - 按操作分类的 lowering handler

如果你增加了一个新指令家族，通常会碰到这些地方：

1. stub 接口
2. handler 注册或分发
3. 可能还要改 bridge / simulator runtime
4. 如果该指令属于某个已知 pipe 阶段，还可能要补 autosync 分类

## 6. stub 接口

写 kernel 时用到的大多数 API，最终都会通过这些目录下的 stub 发射成指令：

- `easyasc/stub_functions/`
- `easyasc/stub_functions/vec/`
- `easyasc/stub_functions/micro/`

它们定义了 kernel 实际可调用的 DSL 用法边界。
当某条 DSL 语句的行为和你的预期不一致时，最应该先看这里。

## 7. 模拟器内部

当前真正生效的模拟器位于 `easyasc/simulator_v2/`。

最值得先看的文件包括：

- bridge 选择与模拟器入口
  - `easyasc/kernelbase/kernelbase.py`
- 运行时入口与配置
  - `easyasc/simulator_v2/config.py`
  - `easyasc/simulator_v2/base.py`
  - `easyasc/simulator_v2/api.py`
- 程序 bridge
  - `easyasc/simulator_v2/compat/kernel_bridge.py`
  - `easyasc/simulator_v2/compat/control_flow_bridge.py`
  - `easyasc/simulator_v2/compat/op_exec_adapter.py`
- 运行时层次
  - `easyasc/simulator_v2/runtime/global_runtime.py`
  - `easyasc/simulator_v2/runtime/core_process.py`
  - `easyasc/simulator_v2/runtime/core_runtime.py`
  - `easyasc/simulator_v2/runtime/control_actor.py`
  - `easyasc/simulator_v2/runtime/pipe_worker.py`
- 内存与 workspace
  - `easyasc/simulator_v2/memory/`
- 同步
  - `easyasc/simulator_v2/sync/`
- trace 导出
  - `easyasc/simulator_v2/trace/`

当前一个很重要的事实是：

- `KernelBase.run_sim()` 始终走 `_run_sim_v2()`
- `simulator=True`、`simulator="v2"`、`simulator="legacy"` 目前都会落到这套 V2 路径上

## 8. Bridge 模型

模拟器现在不会再“直接执行原始指令列表”，而是先构建一个 V2 `KernelProgram`。

`KernelBase.build_simulator_v2_program()` 的选择顺序是：

1. 显式自定义 program builder
2. 预构建好的 `KernelProgram`
3. 自动 bridge 选择

自动 bridge 的规则：

- 出现循环、条件分支、拓扑查询、`call_micro`、`VarList`、跨 lane 同步时，走 `control_flow_bridge.py`
- 否则走更窄的线性 bridge：`kernel_bridge.py`

因此，当模拟器行为和作者预期不一致时，bridge 层通常是最值得先检查的地方。

## 9. 运行时形状

V2 运行时的结构是：

- 一个父 `GlobalRuntime`
- 每个模拟 core 一个子 `CoreProcess`
- 每个活跃 lane 一个 `ControlActor`
- lane 内每条逻辑 pipe 一个线程化的 `PipeWorker`

规划由这些文件决定：

- `easyasc/simulator_v2/runtime/execution_plan.py`
- `easyasc/simulator_v2/helpers.py`

shared tensor 存储由这些文件负责：

- `easyasc/simulator_v2/memory/shared_tensor.py`
- `easyasc/simulator_v2/memory/shared_tensor_store.py`
- `easyasc/simulator_v2/memory/workspace.py`

## 10. Micro 模块

`@vf` 函数会被 `easyasc/micro/micromodule.py` 包装。

值得注意的点有：

- micro 函数会被缓存成可复用模块
- 临时寄存器声明会被提升到 micro 作用域
- 读写 sync key 会从发射出来的 micro 指令中收集
- kernel 对 micro 的调用会发射 `call_micro` 指令
- 运行时 micro 执行走 `easyasc/simulator_v2/ops/micro/runtime.py`
- 任何通过 `call_micro` 流进 micro 的 float `Var` 表达式，都必须在
  `control_actor.py` 和 `ops/micro/runtime.py` 里保持 float 语义；如果运行时把它们截成 int，
  就会静默破坏 `@vf()` 里使用的标量 scale

任何影响 micro 数据流的改动，都应该同时对照 parser lowering 和 V2 runtime 去检查。

## 11. 测试与 demo

注意：`testcases/` 已从交付的 skill 包中移除，以下对其结构的描述仅作为历史参考。

- 历史上的 `testcases/` 用于自动化回归，包括：
  - `codegen/`：静态生成、工具与非运行时检查
  - `parser/`：split、pruning、autosync 与 lowering 邻近检查
  - `simulator/`：运行时语义、roundtrip、bridge 行为与 V2 不变量
- `agent/example/kernels/` 可以自带完整 kernel 故事的可运行断言
- `agent/example/demo/` 用于手动运行或编译集成示例，不应作为默认 pytest 覆盖的一部分

如果某个根目录脚本变得重要，可以移到 `agent/example/demo/`。

## 12. 同步模型

当前仓库的同步大体分成两层：

1. autosync
   - lowering 阶段插入的同侧握手
2. 显式跨侧 mutex 与 wait / ready 路径
   - ownership 穿过 cube / vec 边界时使用

这部分改动风险很高，因为会同时影响：

- parser lowering
- bridge 行为
- simulator 调度
- trace 输出
- 大量现有测试

所以同步相关改动一定要尽量小，并用聚焦测试验证。

## 13. 生成资源

生成路径仍然依赖 `easyasc/resources/` 下的模板和辅助文件。

如果你改变了生成代码的整体形状，也要检查 host / runtime 模板或辅助头文件是否需要一起调整。

## 14. 高层地图

优先使用最小但足够的 owner 文档：

- playbook / 参考跨层的 router-first 导航 -> `agent/ROUTER.md`
- 顶层布局或归属 -> `agent/references/repo-map.md`
- simulator 实现路径 -> `agent/references/simulator-v2.md`
- 通用实现路径速查 -> `agent/references/code-paths.md`
- kernel 示例与说明 -> `agent/references/examples/kernel-catalog.md`

## 15. 贡献检查表

当你修改框架内部时，建议按这个顺序自查：

1. 明确公开 API 会受到什么影响
2. 同步更新 lowering、bridge 逻辑和 simulator runtime
3. 增加或更新一个聚焦测试
4. 刷新真正描述该区域的 owner 文档
5. 如果在 `agent/example/kernels/` 下新增了 kernel，也要更新 kernel 摘要

只有让 parser、simulator、测试、文档和示例一起演进，这个仓库才会比较容易维护。
