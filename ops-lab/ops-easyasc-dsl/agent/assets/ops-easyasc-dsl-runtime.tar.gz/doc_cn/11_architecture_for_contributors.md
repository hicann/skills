# 面向贡献者的架构说明

本文面向那些需要修改框架本身的人，而不只是基于它来写 kernel 的人。

如果当前 checkout 里还没有 `easyasc/`、`doc/` 或 `doc_cn/`，先执行 `bash agent/scripts/init.sh` 进行恢复。

## 1. 仓库结构

主要源码区域包括：

- `easyasc/`
  - 公开 DSL 接口
  - parser 与 lowering
  - 模拟器运行时
  - 指令发射器与辅助函数
- `agent/example/kernels/`
  - 样例 kernel 与 kernel 说明
- `historical automated tests/` (removed from this skill bundle)
  - 针对 parser、simulator 与 codegen 行为的回归测试

## 2. 设备家族映射

在阅读任何和硬件分支相关的代码前，先把这层映射记清楚：

- `device_type == "950"` 对应 C310 路径
- `device_type.startswith("b")` 对应 C220 路径
- 在 `easyasc/resources/tensorutils.h` 中，`__DAV_C310__` 就是 `950` 分支
- 在 `easyasc/resources/tensorutils.h` 中，`__DAV_C220_CUBE__` 就是 `b*` 分支

很多支持性判断、helper 选择和生成代码路径都依赖这层映射。看仓库时不要把它反过来。

## 3. 端到端控制流

典型的内部路径是：

1. 一个带装饰器的 Python 函数先被 `easyasc/pythonic.py` 转换
2. `@kernel` 把它包成 `KernelBase`
3. DSL 对象把操作发射成 `Instruction` 记录，进入当前激活的 kernel 或 micro 上下文
4. `OpExec` 绑定运行时输入，并触发模拟器或生成流程
5. parser 把指令拆分并 lowering 成 cube 与 vec 代码
6. 模拟器或生成出的运行时去消费这些结果

关键入口模块有：

- `easyasc/decorators.py`
- `easyasc/kernelbase/kernelbase.py`
- `easyasc/torchplugin.py`

## 4. 对外接口模块

- `easyasc/a2.py`
- `easyasc/a5.py`
- `easyasc/flowcontrol.py`
- `easyasc/utils/Tensor.py`
- `easyasc/utils/var.py`

如果你要修改公开 API，应该先从这里入手，并先判断这个行为属于 `a2`、`a5` 还是两者都需要。不要默认所有公开 API 变更都必须同时落到 `a2` 和 `a5`，因为它们面向的是不同的架构风格与指令序列。

## 5. parser 与 lowering

parser 栈位于 `easyasc/parser/` 下。

关键职责如下：

- `asc.py`
  - 指令拆分
  - side 分类
  - autosync 插入
  - 翻译分发
- `asc_pruning.py`
  - 清理与裁剪 pass
- `asc_autosync.py`
  - 为支持的同侧 pipe 对插入事件
- `asc_handlers/`
  - 按操作分类的 lowering handler

如果你增加了一个新指令家族，通常会碰到这些地方：

1. stub 接口
2. handler 注册或分发
3. 可能还要改 simulator
4. 如果该指令属于某个已知 pipe 阶段，还可能要补 autosync 分类

## 6. stub 接口

写 kernel 时用到的大多数 API，最终都会通过这些目录下的 stub 发射成指令：

- `easyasc/stub_functions/`
- `easyasc/stub_functions/vec/`
- `easyasc/stub_functions/micro/`

它们定义了 kernel 实际可调用的 DSL 用法边界。当某条 DSL 语句的行为和你的预期不一致时，最应该先看这里。

## 7. 模拟器内部

模拟器位于 `easyasc/simulator/` 下。

主要区域包括：

- 调度：`base.py`、`core.py`
- cube 运行时：`cube.py`
- vec 运行时：`vec.py`
- 各 pipe 实现
- 共享辅助
- micro 运行时
- trace 导出

当你修改某个指令语义时，一定要确认模拟器语义与 parser 预期仍然一致。

## 8. Micro 模块

`@vf` 函数会被 `easyasc/micro/micromodule.py` 包装。

值得注意的点有：

- micro 函数会被缓存成可复用模块
- 临时寄存器声明会被提升到 micro 作用域
- 读写 sync key 会从发射出来的 micro 指令中收集
- kernel 对 micro 的调用会发射 `call_micro` 指令

任何影响 micro 数据流的改动，都应该同时对照 parser lowering 和 simulator 运行时行为去检查。

## 9. 同步模型

当前仓库的同步大体分成两层：

1. autosync
   - 在 lowering 阶段插入同侧流水握手
2. 显式跨侧 mutex 与 wait / ready 路径
   - 当 ownership 穿过 cube 和 vec 边界时使用

这一部分的改动风险很高，因为会同时影响：

- parser lowering
- simulator 调度
- trace 输出
- 大量现有测试

所以同步相关改动一定要尽量小，并用聚焦测试验证。

## 10. 生成资源

运行时生成路径还依赖于
`easyasc/resources/` 下的模板和辅助文件。

如果你改变了生成代码的整体形状，也要检查
host / runtime 模板或辅助头文件是否需要一起调整。

## 11. 贡献检查表

当你修改框架内部时，建议按这个顺序自查：

1. 明确公开 API 会受到什么影响
2. 同步更新 lowering 与 simulator
3. 增加或更新一个聚焦测试
4. 刷新仓库摘要和相关文档
5. 如果在 `agent/example/kernels/` 下增加了新 kernel，也要更新 kernel 摘要文档

只有让 parser、simulator 和示例一起演进，这个仓库才会比较容易维护。
