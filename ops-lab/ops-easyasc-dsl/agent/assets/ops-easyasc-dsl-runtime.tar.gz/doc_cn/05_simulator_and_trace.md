# 模拟器与 Trace

模拟器仍然是这个仓库里最稳妥的第一执行目标，但它的实现路径已经发生了明显变化。
当前真正生效的运行时是 `easyasc/simulator_v2/` 下的 V2 模拟器。

## 1. 现在的模拟器覆盖了什么

当前模拟器栈覆盖了：

- 从 kernel 发射指令构建可执行程序
- 保留控制流的 lane program
- 跨模拟 core 的父/子运行时调度
- V2 运行时中的 cube、vec、micro 执行
- core 内同步与 collective 同步
- shared tensor / workspace 存储
- 可选的 Chrome / Perfetto 风格 trace 导出

因此它仍然适合：

- 第一轮正确性验证
- 同步问题调试
- 在测试里复现 parser / runtime 行为

## 2. 如何在模拟器模式运行

使用：

```python
out = OpExec(kernel_fn, simulator=True)(...)
```

当前也接受这些写法：

```python
out = OpExec(kernel_fn, simulator=True)(...)
out = OpExec(kernel_fn, simulator="v2")(...)
out = OpExec(kernel_fn, simulator="legacy")(...)
```

但要注意当前真实行为：

- 上面三种写法都会开启现在这套模拟器运行时
- `OpExec` 会把 `simulator` 归一化成布尔标志
- `KernelBase.run_sim()` 始终走 `_run_sim_v2()`
- `simulator="legacy"` 现在只是兼容旧调用形式的字符串，不再选择一套独立的旧模拟器

在模拟器模式下：

- 输入的 PyTorch 张量会先拷贝到 `GMTensor.data`
- kernel 会先构建一个 V2 `KernelProgram`
- V2 运行时再把这些 payload 拷贝进 shared tensor store
- 执行结束后，结果会从运行时张量拷回 `GMTensor.data`，再映射回 PyTorch

## 3. kernel 如何变成 V2 程序

程序构建逻辑位于 `easyasc/kernelbase/kernelbase.py`。

当前选择顺序是：

1. `kernel._simulator_v2_program_builder`
2. `kernel._simulator_v2_program`
3. 自动 bridge 选择

自动 bridge 的规则是：

- 如果指令流里出现循环、条件分支、拓扑查询、`call_micro`、`VarList` 或跨 lane 同步 helper，就走 `easyasc/simulator_v2/compat/control_flow_bridge.py`
- 否则走更窄的线性 bridge：`easyasc/simulator_v2/compat/kernel_bridge.py`

也就是说，现在已经不是“直接执行 lowering 后的旧指令流”这么简单，而是多了一层明确的 bridge。

## 4. 运行时层次结构

V2 运行时大致分成这些层：

- 父调度器：`easyasc/simulator_v2/runtime/global_runtime.py`
- 每个 core 的子进程包装：`easyasc/simulator_v2/runtime/core_process.py`
- 每个 core 的运行时：`easyasc/simulator_v2/runtime/core_runtime.py`
- lane 级控制解释器：`easyasc/simulator_v2/runtime/control_actor.py`
- 每个 pipe 的工作线程：`easyasc/simulator_v2/runtime/pipe_worker.py`
- 具体 pipe 执行器：`easyasc/simulator_v2/ops/`

实用心智模型可以记成：

- 一个父运行时先准备 shared tensor 和 execution plan
- 每个模拟 core 启一个子进程
- 每个活跃 lane 对应一个 `ControlActor`
- lane 内每条逻辑 pipe 由独立线程 `PipeWorker` 驱动

## 5. core 数、lane 激活和内存

这里最关键的文件有：

- `easyasc/simulator_v2/config.py`
- `easyasc/simulator_v2/runtime/execution_plan.py`
- `easyasc/simulator_v2/memory/`

当前行为包括：

- 默认 core 数跟随当前设备家族（`950 -> 32`，`b3 -> 20`）
- 当程序只用到部分 cube / vec lane 时，V2 会跳过不活跃 lane
- 运行时张量和 workspace 会通过 shared tensor store 预先准备
- mixed-lane kernel 依赖 bridge 生成的 metadata，尤其是 lane-local UB 的处理信息

标量语义提醒：

- 带控制流的 kernel 会把 `var_add`、`var_mul`、`var_div` 这类 `Var` 标量表达式保留到运行时
- 在 V2 路径里，如果 DSL 里的 `Var` 是 float，这些标量运算也必须保持 float 语义，不能在运行时偷偷截成 int
- 如果你看到 kernel 的原始 `L0C -> UB` 数据是对的，但后面的 `@vf()` scale 一下子全变成 `0`，应当先检查 `control_actor.py` 和 `ops/micro/runtime.py` 里的 float `Var` 算术，而不是先怀疑 cube/vec 交接

## 6. 为什么这里依然提倡先跑模拟器

`agent/example/kernels/` 目录里的大多数可运行 kernel，依然通过下面这种方式自验证：

```python
OpExec(..., simulator=True)
```

原因没有变：

- 迭代 kernel 逻辑更快
- 可以直接和文件内的 PyTorch 参考对比
- 更容易观察同步和 trace 行为
- 比起生成路径，变量更少、更容易定位问题

## 7. 生成 trace

trace 只支持模拟器模式。

示例：

```python
trace_path = os.path.join(out_dir, "trace.json")
out = OpExec(kernel_fn, out_dir, simulator=True, trace=trace_path)(...)
```

当前 trace 的流转方式是：

- 每个模拟 core 分别记录自己的事件
- 父运行时在执行完成后把各 core 的 trace 合并
- 合并后的结果导出成 Chrome / Perfetto 风格的 JSON

值得参考的测试包括：

- `testcases/simulator/trace/test_trace.py`
- `testcases/simulator/trace/test_simulator_v2_trace.py`
- `testcases/simulator/opexec/test_opexec_simulator_v2_kernel_bridge.py`

## 8. trace 能帮你看什么

当你需要回答下面这些问题时，trace 很有帮助：

- 哪个 lane / pipe 先执行
- producer / consumer 的交接顺序是否符合预期
- wait、event、barrier 是否把流水卡住了
- 实际流水拓扑是否和你的设计一致

它尤其适合这些场景：

- `auto_sync()`
- 跨侧 mutex
- mixed cube / vec kernel
- one-tile lookahead 或 delayed-consumer 流

## 9. 建议的调试循环

当一个 kernel 不工作时：

1. 先把 shape 缩小
2. 用模拟器模式运行
3. 和直接写出来的 PyTorch 参考比较
4. 如果涉及同步，就打开 trace
5. 先检查 bridge / runtime 路径，再决定是否改 kernel
6. 只有在模拟器对齐之后，再去看生成路径或更贴近硬件的执行流

## 10. 值得重点查看的文件

- `easyasc/kernelbase/kernelbase.py`
- `easyasc/torchplugin.py`
- `easyasc/simulator_v2/compat/kernel_bridge.py`
- `easyasc/simulator_v2/compat/control_flow_bridge.py`
- `easyasc/simulator_v2/runtime/global_runtime.py`
- `easyasc/simulator_v2/runtime/control_actor.py`
- `easyasc/simulator_v2/runtime/pipe_worker.py`
- `easyasc/simulator_v2/trace/chrome.py`
- `testcases/simulator/`
