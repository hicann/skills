# 模拟器与 Trace

在这个仓库里，模拟器是最稳妥的第一执行目标。它让你可以先验证 kernel 语义，而不用一开始就依赖生成出的运行时路径。

## 1. 模拟器覆盖了什么

模拟器会执行 kernel 在编写阶段之后发射出来的指令流。当前代码库里已经包含：

- 核心调度
- cube 侧执行
- vec 侧执行
- micro 运行时执行
- 事件与同步行为
- 可选的 trace 导出

因此它天然适合：

- 第一轮正确性验证
- 同步问题调试
- 在测试里复现 parser 和运行时行为

## 2. 如何在模拟器模式运行

使用：

```python
out = OpExec(kernel_fn, simulator=True)(...)
```

也可以显式选择 backend：

```python
out = OpExec(kernel_fn, simulator="legacy")(...)
out = OpExec(kernel_fn, simulator="v2")(...)
```

在这个模式下：

- 输入的 PyTorch 张量会被拷贝到 `GMTensor.data`
- kernel 会通过 `run_sim(...)` 执行
- 输出 `GMTensor` 会再映射回 PyTorch 张量

补充说明：

- `simulator=True` 等价于 `simulator="legacy"`
- `simulator="v2"` 目前还是显式实验路径
- 当前 V2 路径会先尝试一条默认 bridge，把 legacy lowered instructions 转成 `KernelProgram`
- 这条默认 bridge 目前故意收得很窄：只覆盖单核、线性、纯 cube 或纯 vec、连续 GM slice、并且已经接入 V2 的 pipe 语义
- mixed cube/vec kernel 目前仍然更适合显式提供 V2 bridge
- 如果 kernel 超出这个子集，仍然需要提供 `build_simulator_v2_program()` bridge，或者提供等价的注入式 hook

## 3. 为什么这里提倡先跑模拟器

`agent/example/kernels/` 目录下的大多数可运行 kernel 文件，都是通过下面这种方式自验证的：

```python
OpExec(..., simulator=True)
```

它的主要优势包括：

- 迭代 kernel 逻辑更快
- 更容易直接与 PyTorch 参考比较
- 更容易看到同步和 pipe 行为
- 在数学逻辑还没对齐之前，不用先去相信 codegen

## 4. 生成 trace

trace 导出只支持模拟器模式。

例如：

```python
trace_path = os.path.join(out_dir, "trace.json")
out = OpExec(kernel_fn, out_dir, simulator=True, trace=trace_path)(...)
```

生成出的文件面向 Chrome 或 Perfetto 风格的 timeline 查看器。

仓库里的 `historical testcases/test_trace.py` (removed from this skill bundle) 演示了：

- 如何在启用 trace 的情况下运行一个 mixed cube / vec kernel
- 如何检查 trace 文件确实生成了
- 如何验证带时间信息的事件已经被写出

## 5. trace 能帮你看什么

当你需要回答这些问题时，trace 很有用：

- 哪一侧先跑起来了
- producer / consumer 的交接顺序是否符合预期
- event、wait 或 barrier 是否把流水卡住了
- 实际流水形状是否就是你设计的拓扑

它对以下这类 mixed kernel 尤其有帮助：

- 带 `auto_sync()`
- 带跨侧 mutex
- 使用 one-tile lookahead
- 存在 delayed consumer

## 6. 建议的调试循环

当一个新 kernel 不工作时：

1. 先把 shape 缩小
2. 用模拟器模式运行
3. 直接和 PyTorch 参考比较
4. 如果涉及同步，就打开 trace
5. 只有在模拟器结果正确之后，再尝试生成模式或更接近硬件的执行流程

## 7. 面向模拟器的测试

`historical automated tests/` (removed from this skill bundle) 下已经有很多“先跑模拟器”的测试，例如：

- autosync 元数据
- 跨核和全核等待
- micro cast 与 mask 行为
- datamove 辅助函数
- timeout 行为
- 运行时优化行为

很多边角行为，最好的文档其实就是这些测试。

## 8. 重要的运行时检查

有一些很有价值的失败模式，直接来自 `OpExec`：

- `trace is only supported when simulator is enabled`
- 张量参数与标量参数顺序不合法
- 不支持的 PyTorch dtype
- 缺少 `shape_bindings` 时的形状推导歧义

这些通常是用户输入问题，不是 parser bug。

## 9. 值得重点查看的文件

- `historical testcases/test_trace.py` (removed from this skill bundle)
- `easyasc/simulator/base.py`
- `easyasc/simulator/core.py`
- `easyasc/simulator/cube.py`
- `easyasc/simulator/vec.py`
- `easyasc/simulator/trace.py`
- `easyasc/simulator_v2/compat/kernel_bridge.py`
