# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import inspect
import json
import os
import platform
import shutil
import tarfile
from typing import Any, Dict, List, Optional, Set, Union, TYPE_CHECKING

from ..utils.instruction import Instruction
from ..utils.Tensor import GMTensor, DBuff
from ..utils.var import Var
from ..utils.mutex import CvMutex, VcMutex
from ..utils.datatype import Datatype
from ..utils.positions import Position
from .. import globvars

if TYPE_CHECKING:
    from ..micro.micromodule import MicroModule


def _comment_reset_cache_lines_for_codegen(code: str) -> str:
    if not code:
        return code
    marker = "// END: Auto inserted buffers/events/GMTensors"
    out_lines = []
    in_auto_inserted_prefix = True
    for line in code.splitlines():
        stripped = line.strip()
        if in_auto_inserted_prefix and stripped in ("pipe_ptr->Reset();", "OccupyMMTE1Events();"):
            indent = line[: len(line) - len(line.lstrip())]
            out_lines.append(f"{indent}// {stripped}")
        else:
            out_lines.append(line)
        if stripped == marker:
            in_auto_inserted_prefix = False
    out = "\n".join(out_lines)
    if code.endswith("\n"):
        out += "\n"
    return out


class KernelBase:
    """Kernel base class that stores name, function, and emitted instructions."""
    _VALID_VECTOR_MODES = ("repeat", "count")

    def __init__(self, name: str, func, vector_mode: str = "repeat"):
        if vector_mode not in self._VALID_VECTOR_MODES:
            raise ValueError(
                f"vector_mode must be one of {self._VALID_VECTOR_MODES}, got {vector_mode!r}"
            )
        self.name = name
        self.func = func
        self.vector_mode = vector_mode
        self.instructions: List[Instruction] = []
        self.crosscore_mutex: List[Union[CvMutex, VcMutex]] = []
        self.workspace_shapes: List[Dict[str, Any]] = []
        self.used_micros: Set["MicroModule"] = set()
        self._last_bound_args = {}
        self._last_output_gmtensors = set()
        self._last_output_gmtensors_ordered: List[GMTensor] = []

    def __call__(self, *args, **kwargs):
        def _collect_gmtensors(value, out_set, out_ordered):
            if isinstance(value, GMTensor):
                out_set.add(value)
                out_ordered.append(value)
                return
            if isinstance(value, (list, tuple, set)):
                for item in value:
                    _collect_gmtensors(item, out_set, out_ordered)
                return
            if isinstance(value, dict):
                for item in value.values():
                    _collect_gmtensors(item, out_set, out_ordered)
                return

        sig = inspect.signature(self.func)
        bound = sig.bind_partial(*args, **kwargs)
        self._last_bound_args = dict(bound.arguments)
        self._last_output_gmtensors = set()
        self._last_output_gmtensors_ordered = []
        self.workspace_shapes = []
        self.used_micros = set()
        self.crosscore_mutex = []
        self.instructions = []
        self._reinterpret_name_counts = {}
        self.vector_mode = "repeat"
        for param_name, value in bound.arguments.items():
            if isinstance(value, (GMTensor, Var)):
                value.name = param_name
            else:
                raise TypeError(f"kernel arguments must be GMTensor or Var, current {param_name} type: {type(value)}")
        globvars.active_kernel = self
        globvars.tmp_idx = 0
        try:
            for value in bound.arguments.values():
                if isinstance(value, GMTensor):
                    self.instructions.append(
                        Instruction("create_gm_tensor", val=value)
                    )
            self._l0a = DBuff(Datatype.half, [128, 128], position=Position.L0A, name='_l0a')
            self._l0b = DBuff(Datatype.half, [128, 128], position=Position.L0B, name='_l0b')
            self._l0acnt = Var(0, name='_l0acnt')
            self._l0bcnt = Var(0, name='_l0bcnt')
            self.instructions.append(
                Instruction("reset_cache")
            )
            self.instructions.append(
                Instruction("inline", code="// END: Auto inserted buffers/events/GMTensors")
            )
            self.instructions.append(
                Instruction("inline", code="// ----- User's codes start from here -----")
            )
            res = self.func(*args, **kwargs)
            outputs = set()
            outputs_ordered: List[GMTensor] = []
            _collect_gmtensors(res, outputs, outputs_ordered)
            self._last_output_gmtensors = outputs
            self._last_output_gmtensors_ordered = outputs_ordered
            head_instructions = []
            tail_instructions = []
            for mutex in self.crosscore_mutex:
                if not isinstance(mutex, (CvMutex, VcMutex)):
                    raise TypeError(
                        f"crosscore_mutex elements must be CvMutex or VcMutex, got: {type(mutex)}"
                    )
                if isinstance(mutex, CvMutex):
                    for _ in range(mutex.depth):
                        head_instructions.append(
                            Instruction("vec_ready", flag_id=mutex.flag_id, pipe=mutex.dst_end_pipe)
                        )
                        tail_instructions.append(
                            Instruction("wait_vec", flag_id=mutex.flag_id, pipe=mutex.src_start_pipe)
                        )
                else:
                    for _ in range(mutex.depth):
                        head_instructions.append(
                            Instruction("cube_ready", flag_id=mutex.flag_id, pipe=mutex.dst_end_pipe)
                        )
                        tail_instructions.append(
                            Instruction("wait_cube", flag_id=mutex.flag_id, pipe=mutex.src_start_pipe)
                        )
            if head_instructions:
                self.instructions[:0] = head_instructions
            if tail_instructions:
                self.instructions.extend(tail_instructions)
            return res
        finally:
            globvars.tmp_idx = 0
            globvars.active_micro = None
            globvars.active_kernel = None
            

    def print_instructions(self):
        print(f"Kernel {self.name}:")
        if not self.instructions:
            print("  (no instructions)")
            return
        for idx, inst in enumerate(self.instructions):
            print(f"  [{idx}] {inst!r}")

    def dump_asc(self, path: str) -> None:
        from ..parser.asc import translate_split
        cube_code, vec_code = translate_split(self.instructions, self.name)
        cube_code = _comment_reset_cache_lines_for_codegen(cube_code)
        vec_code = _comment_reset_cache_lines_for_codegen(vec_code)
        with open(f"{path}_cube.h", "w") as f:
            f.write(cube_code)
        with open(f"{path}_vec.h", "w") as f:
            f.write(vec_code)

    def dump_kernel(self, path: str, debug_entry: bool = False) -> None:
        from ..parser.asc import translate_split
        from ..parser.asc_utils import dtype_to_cpp

        cube_code, vec_code = translate_split(self.instructions, self.name)
        cube_code = _comment_reset_cache_lines_for_codegen(cube_code)
        vec_code = _comment_reset_cache_lines_for_codegen(vec_code)
        cube_code += '\n// Auto generated code. Readability is not guaranteed.'
        vec_code += '\n// Auto generated code. Readability is not guaranteed.'
        sig = inspect.signature(self.func)
        param_names = list(sig.parameters.keys())

        gmtensors = {}
        vars_by_name = {}

        def _collect_var(value):
            if isinstance(value, Var):
                vars_by_name.setdefault(value.name, value)
                return
            if isinstance(value, (list, tuple)):
                for item in value:
                    _collect_var(item)
                return
            if isinstance(value, dict):
                for item in value.values():
                    _collect_var(item)

        for inst in self.instructions:
            if inst.opname == "create_gm_tensor":
                val = inst.kwargs.get("val", None)
                if isinstance(val, GMTensor):
                    gmtensors[val.name] = val
            for value in inst.kwargs.values():
                _collect_var(value)

        gmtensor_params = []
        gmtensor_args = []
        var_params = []
        var_args = []
        for name in param_names:
            bound_val = self._last_bound_args.get(name, None)
            if isinstance(bound_val, GMTensor) or name in gmtensors:
                gmtensor_params.append(f"GM_ADDR {name}_")
                gmtensor_args.append(name)
            else:
                dtype = None
                if isinstance(bound_val, Var):
                    dtype = bound_val.dtype
                elif name in vars_by_name:
                    dtype = vars_by_name[name].dtype
                var_params.append(f"{dtype_to_cpp(dtype)} {name}")
                var_args.append(name)

        params = gmtensor_params + ["GM_ADDR workspace"] + var_params
        param_list = ", ".join(params)
        arg_list = ", ".join(gmtensor_args + ["workspace"] + var_args)

        def _wrap(code: str, suffix: str) -> str:
            header = '#pragma once\n#include "tensorutils.h"\n'
            for i in self.used_micros:
                header += f'#include "{i.name}.h"\n'
            header += '\n'
            fn_name = f"{self.name}_{suffix}"
            body = code.strip("\n")
            if body:
                body = "\n".join(f"    {line}" if line else "" for line in body.splitlines())
                return (
                    f"{header}__aicore__ inline void {fn_name}({param_list}) {{\n"
                    f"    TPipe pipe;\n"
                    f"    TPipe* pipe_ptr = GetTPipePtr();\n"
                    f"    int _offset = 0;\n"
                    f"{body}\n"
                    f"}}\n"
                )
            return (
                f"{header}__aicore__ inline void {fn_name}({param_list}) {{\n"
                f"    TPipe pipe;\n"
                f"    TPipe* pipe_ptr = GetTPipePtr();\n"
                f"    int _offset = 0;\n"
                f"}}\n"
            )

        with open(f"{path}_cube.h", "w") as f:
            f.write(_wrap(cube_code, "cube"))
        with open(f"{path}_vec.h", "w") as f:
            f.write(_wrap(vec_code, "vec"))
        cpp_params = [f"GM_ADDR {name}" for name in param_names
                      if isinstance(self._last_bound_args.get(name, None), GMTensor) or name in gmtensors]
        cpp_params.append("GM_ADDR workspace")
        if debug_entry:
            cpp_params.extend(var_params)
        else:
            cpp_params.append("GM_ADDR tiling")
        cpp_param_list = ", ".join(cpp_params)
        tiling_vars = []
        if not debug_entry:
            for name in param_names:
                bound_val = self._last_bound_args.get(name, None)
                if isinstance(bound_val, GMTensor) or name in gmtensors:
                    continue
                dtype = None
                if isinstance(bound_val, Var):
                    dtype = bound_val.dtype
                elif name in vars_by_name:
                    dtype = vars_by_name[name].dtype
                tiling_vars.append(f"    {dtype_to_cpp(dtype)} {name} = tiling_data.{name};\n")
        cpp_body = (
            '#include "kernel_operator.h"\n'
            '#include "lib/matmul_intf.h"\n'
            '#include "tensorutils.h"\n'
            f'#include "{path}_cube.h"\n'
            f'#include "{path}_vec.h"\n'
            "\n\n"
            f'extern "C" __global__ __aicore__ void {path}({cpp_param_list}) {{\n'
            "    KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);\n"
        )
        if not debug_entry:
            cpp_body += "    GET_TILING_DATA(tiling_data, tiling);\n"
        cpp_body += "    PipeBarrier<PIPE_ALL>();\n"
        cpp_body += "".join(tiling_vars)
        cpp_body += (
            f"    if ASCEND_IS_AIC{{\n"
            f"        {self.name}_cube({arg_list});\n"
            f"    }}\n"
            f"    if ASCEND_IS_AIV{{\n"
            f"        {self.name}_vec({arg_list});\n"
            f"    }}\n"
            "\n}\n"
        )
        with open(f"{path}.cpp", "w") as f:
            f.write(cpp_body)

    @staticmethod
    def _resolve_op_host_block_dim(device_type: object) -> int:
        lowered = str(device_type).lower()
        if lowered in ("b3", "b4"):
            return 20
        if lowered in ("b1", "b2"):
            return 24
        if lowered == "950":
            return 32
        raise ValueError("Unsupported device_type for op_host block dim: " + lowered)

    @staticmethod
    def _resolve_debug_chipset(device_type: object) -> str:
        lowered = str(device_type).lower()
        mapping = {
            "950": "Ascend950",
            "b1": "Ascend910B1",
            "b2": "Ascend910B2",
            "b3": "Ascend910B3",
            "b4": "Ascend910B4",
        }
        if lowered not in mapping:
            raise ValueError("Unsupported device_type for debug scripts: " + lowered)
        return mapping[lowered]

    def generate_op_host(self) -> None:
        sig = inspect.signature(self.func)
        if not self._last_bound_args:
            raise RuntimeError("generate_op_host requires calling kernel first to bind arguments")

        def _to_camel(name: str) -> str:
            parts = [p for p in name.split("_") if p]
            if not parts:
                return name
            return "".join(p[:1].upper() + p[1:] for p in parts)

        def _dtype_to_ge(dtype) -> str:
            name = getattr(dtype, "name", None)
            mapping = {
                "half": "ge::DT_FLOAT16",
                "float": "ge::DT_FLOAT",
                "float8_e4m3_t": "ge::DT_FLOAT8_E4M3FN",
                "float8_e5m2_t": "ge::DT_FLOAT8_E5M2",
                "bfloat16_t": "ge::DT_BF16",
                "int": "ge::DT_INT32",
                "int32_t": "ge::DT_INT32",
                "int64_t": "ge::DT_INT64",
                "uint32_t": "ge::DT_UINT32",
                "uint64_t": "ge::DT_UINT64",
                "int8_t": "ge::DT_INT8",
                "uint8_t": "ge::DT_UINT8",
                "int16_t": "ge::DT_INT16",
                "uint16_t": "ge::DT_UINT16",
            }
            return mapping.get(name, "ge::DT_FLOAT16")   # type: ignore

        def _attr_method(dtype) -> str:
            if dtype is Datatype.int:
                return "Int(0)"
            return "Float(0)"

        def _tiling_scalar_cpp_type(dtype) -> str:
            if dtype is Datatype.int:
                return "int32_t"
            return "float"

        param_names = list(sig.parameters.keys())
        var_names = []
        for name in param_names:
            bound_val = self._last_bound_args.get(name, None)
            if isinstance(bound_val, Var):
                var_names.append(name)

        def _workspace_size_expr() -> str:
            if not self.workspace_shapes:
                return "0"

            def _storage_cpp_type(dtype) -> str:
                name = getattr(dtype, "name", None)
                mapping = {
                    "half": "uint16_t",
                    "float": "float",
                    "int": "int32_t",
                    "int8_t": "int8_t",
                    "uint8_t": "uint8_t",
                    "int16_t": "int16_t",
                    "uint16_t": "uint16_t",
                    "uint32_t": "uint32_t",
                    "uint64_t": "uint64_t",
                    "int64_t": "int64_t",
                    "float8_e4m3_t": "uint8_t",
                    "float8_e5m2_t": "uint8_t",
                    "hifloat8_t": "uint8_t",
                    "bfloat16_t": "uint16_t",
                }
                if name not in mapping:
                    raise ValueError(f"Unsupported dtype for workspace size expression: {name}")
                return mapping[name]

            def _dim_expr(dim) -> str:
                if isinstance(dim, int):
                    return str(dim)
                if isinstance(dim, Var):
                    if dim.name in var_names:
                        return dim.name
                    if dim.value is not None:
                        return str(dim.value)
                    raise ValueError(f"workspace_shape contains an unbound Var: {dim.name!r}")
                raise TypeError(f"workspace_shape elements must be int or Var, got: {type(dim)}")

            def _shape_expr(shape) -> str:
                if not isinstance(shape, (list, tuple)):
                    raise TypeError(f"workspace_shape must be list or tuple, got: {type(shape)}")
                factors = []
                for dim in shape:
                    if isinstance(dim, int) and dim == 1:
                        continue
                    factors.append(_dim_expr(dim))
                if not factors:
                    return "1"
                if len(factors) == 1:
                    return factors[0]
                return "(" + " * ".join(factors) + ")"

            terms = []
            for entry in self.workspace_shapes:
                if not isinstance(entry, dict):
                    raise TypeError(f"workspace entry must be dict, got: {type(entry)}")
                shape = entry.get("shape", None)
                dtype = entry.get("dtype", None)
                if shape is None:
                    raise ValueError("workspace entry missing shape")
                if dtype is None:
                    raise ValueError("workspace entry missing dtype")
                shape_expr = _shape_expr(shape)
                storage_cpp_type = _storage_cpp_type(dtype)
                terms.append(f"{shape_expr} * sizeof({storage_cpp_type})")
            if len(terms) == 1:
                return terms[0]
            return " + ".join(terms)

        workspace_size_expr = _workspace_size_expr()

        op_name = _to_camel(self.name)
        tiling_name = f"{op_name}TilingData"
        block_dim = self._resolve_op_host_block_dim(getattr(globvars, "device_type", ""))
        lines = [
            '#include "register/tilingdata_base.h"',
            "",
            "namespace optiling {",
            f"BEGIN_TILING_DATA_DEF({tiling_name})",
        ]
        for var_name in var_names:
            bound_val = self._last_bound_args.get(var_name, None)
            dtype = bound_val.dtype if isinstance(bound_val, Var) else None
            lines.append(f"  TILING_DATA_FIELD_DEF({_tiling_scalar_cpp_type(dtype)}, {var_name});")
        lines.append("END_TILING_DATA_DEF;")
        lines.append("")
        lines.append(f"REGISTER_TILING_DATA_CLASS({op_name}, {tiling_name})")
        lines.append("}")
        content = "\n".join(lines) + "\n"

        with open(f"{self.name}_tiling.h", "w") as f:
            f.write(content)

        output_gmtensors = set()
        if isinstance(getattr(self, "_last_output_gmtensors", None), set):
            output_gmtensors = self._last_output_gmtensors

        cpp_lines = [
            f'#include "{self.name}_tiling.h"',
            '#include "register/op_def_registry.h"',
            '#include "tiling/tiling_api.h"',
            "",
            "#define SET_ATTR_TO_TILING(name, dtype, idx) \\",
            "    const auto* name##_ptr = attrs->GetAttrPointer<dtype>(idx); \\",
            "    dtype name = *name##_ptr; \\",
            "    tiling.set_##name(name);",
            "#define GET_ATTR_BY_IDX(name, dtype, idx) \\",
            "    const auto* name##_ptr = attrs->GetAttrPointer<dtype>(idx); \\",
            "    dtype name = *name##_ptr;",
            "",
            "namespace optiling {",
            "static ge::graphStatus TilingFunc(gert::TilingContext* context)",
            "{",
            "    // set block size",
            "    auto ascendcPlatform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());",
            f"    context->SetBlockDim({block_dim});",
            "",
            f"    {tiling_name} tiling;",
            "    auto attrs = context->GetAttrs();",
        ]
        for idx, name in enumerate(var_names):
            bound_val = self._last_bound_args.get(name, None)
            dtype = bound_val.dtype if isinstance(bound_val, Var) else None
            cpp_lines.append(f"    SET_ATTR_TO_TILING({name}, {_tiling_scalar_cpp_type(dtype)}, {idx});")
        cpp_lines.extend(
            [
                "    tiling.SaveToBuffer(context->GetRawTilingData()->GetData(), context->GetRawTilingData()->GetCapacity());",
                "    context->GetRawTilingData()->SetDataSize(tiling.GetDataSize());",
                "",
                f"    size_t userWorkspaceSize = {workspace_size_expr};",
                "    size_t sysWorkspaceSize = static_cast<size_t>(ascendcPlatform.GetLibApiWorkSpaceSize());",
                "    size_t *currentWorkspace = context->GetWorkspaceSizes(1);",
                "    currentWorkspace[0] = userWorkspaceSize + sysWorkspaceSize;",
                "    return ge::GRAPH_SUCCESS;",
                "}",
                "}",
                "",
                "namespace ge {",
                "static ge::graphStatus InferShape(gert::InferShapeContext* context)",
                "{",
                "    (void)context;",
                "    return GRAPH_SUCCESS;",
                "}",
                "",
                "static ge::graphStatus InferDataType(gert::InferDataTypeContext* context)",
                "{",
                "    (void)context;",
                "    return GRAPH_SUCCESS;",
                "}",
                "}",
                "",
                "namespace ops {",
                f"class {op_name} : public OpDef {{",
                "public:",
                f"    explicit {op_name}(const char* name) : OpDef(name)",
                "    {",
            ]
        )

        for name in param_names:
            bound_val = self._last_bound_args.get(name, None)
            if not isinstance(bound_val, GMTensor):
                continue
            ge_dt = _dtype_to_ge(bound_val.dtype)
            if bound_val in output_gmtensors:
                cpp_lines.extend(
                    [
                        f'        this->Output("{name}")',
                        "            .ParamType(REQUIRED)",
                        f"            .DataType({{{ge_dt}}})",
                        "            .Format({ge::FORMAT_ND})",
                        "            .UnknownShapeFormat({ge::FORMAT_ND});",
                    ]
                )
            else:
                cpp_lines.extend(
                    [
                        f'        this->Input("{name}")',
                        "            .ParamType(REQUIRED)",
                        f"            .DataType({{{ge_dt}}})",
                        "            .Format({ge::FORMAT_ND})",
                        "            .UnknownShapeFormat({ge::FORMAT_ND});",
                    ]
                )

        for name in var_names:
            bound_val = self._last_bound_args.get(name, None)
            dtype = bound_val.dtype if isinstance(bound_val, Var) else None
            attr_method = _attr_method(dtype)
            cpp_lines.extend(
                [
                    f'        this->Attr("{name}")',
                    "            .AttrType(REQUIRED)",
                    f"            .{attr_method};",
                ]
            )

        cpp_lines.extend(
            [
                "        this->SetInferShape(ge::InferShape).SetInferDataType(ge::InferDataType);",
                "",
                "        this->AICore().SetTiling(optiling::TilingFunc);",
                '        this->AICore().AddConfig("ascend910b");',
            ]
        )
        if globvars.device_type=='950':
            cpp_lines.append('        this->AICore().AddConfig("ascend950");')
        cpp_lines.extend(
            [
                "    }",
                "};",
                "",
                f"OP_ADD({op_name});",
                "}",
                "",
            ]
        )
        with open(f"{self.name}.cpp", "w") as f:
            f.write("\n".join(cpp_lines))

    def generate_op_project(self, path: str, cann_path: str) -> None:
        if not isinstance(path, str):
            raise TypeError(f"path must be str, got: {type(path)}")
        if not isinstance(cann_path, str):
            raise TypeError(f"cann_path must be str, got: {type(cann_path)}")
        resources_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "resources"))
        device_type = getattr(globvars, "device_type", "")
        tar_name = "CustomOp.tar.gz"
        if isinstance(device_type, str) and device_type.lower().startswith("b"):
            tar_name = "CustomOp_a2.tar.gz"
        tar_path = os.path.join(resources_dir, tar_name)
        if not os.path.isfile(tar_path):
            raise FileNotFoundError(f"CustomOp archive not found: {tar_path}")
        preset_template = os.path.join(resources_dir, "CMakePresets.json")
        if not os.path.isfile(preset_template):
            raise FileNotFoundError(f"CMakePresets.json template not found: {preset_template}")
        dst = os.path.abspath(path)
        build_sh = os.path.join(dst, "build.sh")
        if os.path.exists(dst):
            if not os.path.isdir(dst):
                raise FileExistsError(f"Target path already exists and is not a directory: {dst}")
            # Non-empty but missing template files (e.g. partial delete): re-extract from archive.
            if os.path.isfile(build_sh):
                return
            if os.listdir(dst):
                shutil.rmtree(dst)
        os.makedirs(dst, exist_ok=True)
        with tarfile.open(tar_path, "r:gz") as tar:
            tar.extractall(dst)
        with open(preset_template, "r", encoding="utf-8") as f:
            preset_data = json.load(f)
        updated = False
        device_type = getattr(globvars, "device_type", "")
        compute_unit = None
        if isinstance(device_type, str):
            device_type = device_type.lower()
            if device_type.startswith("b"):
                compute_unit = "ascend910b"
            elif device_type.startswith("950"):
                compute_unit = "ascend950"
        for preset in preset_data.get("configurePresets", []):
            cache_vars = preset.get("cacheVariables", {})
            asc_var = cache_vars.get("ASCEND_CANN_PACKAGE_PATH", None)
            if isinstance(asc_var, dict):
                asc_var["value"] = cann_path
                updated = True
            if compute_unit is not None:
                compute_var = cache_vars.get("ASCEND_COMPUTE_UNIT", None)
                if isinstance(compute_var, dict):
                    compute_var["value"] = compute_unit
        if not updated:
            raise ValueError("ASCEND_CANN_PACKAGE_PATH config not found")
        preset_out = os.path.join(dst, "CMakePresets.json")
        with open(preset_out, "w", encoding="utf-8") as f:
            json.dump(preset_data, f, indent=4)
            f.write("\n")

    @staticmethod
    def _resolve_custom_opp_path(custom_op_path: str) -> str:
        # normalized_path = custom_op_path.rstrip("/")
        # if normalized_path.endswith("/opp"):
        #     return normalized_path
        # if normalized_path == "":
        #     return "/opp"
        # return f"{normalized_path}/opp"
        return custom_op_path

    def run_sim(self, trace: Optional[str] = None) -> None:
        self._run_sim_v2(trace=trace)

    def _analyze_usage_for_simulator_v2(self) -> None:
        from ..parser.asc import analyze_usage, eliminate_duplicated_event_creation, split_instructions
        from ..parser.asc_autosync import insert_auto_sync

        instructions = getattr(self, "instructions", None)
        if not instructions:
            return

        cube_insts, vec_insts = split_instructions(instructions)
        cube_insts = eliminate_duplicated_event_creation(insert_auto_sync(cube_insts, mode="cube"))
        analyze_usage(cube_insts, f"{self.name}_cube" if self.name else None)
        vec_insts = eliminate_duplicated_event_creation(insert_auto_sync(vec_insts, mode="vec"))
        analyze_usage(vec_insts, f"{self.name}_vec" if self.name else None)

    def build_simulator_v2_program(self):
        from ..simulator_v2.program.kernel_program import KernelProgram
        from ..simulator_v2.compat import build_kernel_program_from_legacy_instructions

        builder = getattr(self, "_simulator_v2_program_builder", None)
        if callable(builder):
            program = builder()
            if isinstance(program, KernelProgram):
                return program
        program = getattr(self, "_simulator_v2_program", None)
        if isinstance(program, KernelProgram):
            return program
        self._analyze_usage_for_simulator_v2()
        # Auto-detect control flow: use ControlFlowKernelBridge when the
        # instruction stream contains loops, conditionals, or topology queries.
        if self._has_control_flow_instructions():
            from ..simulator_v2.compat.control_flow_bridge import build_control_flow_program
            return build_control_flow_program(self)
        return build_kernel_program_from_legacy_instructions(self)

    def _has_control_flow_instructions(self) -> bool:
        _CF_OPNAMES = frozenset([
            "start_loop", "start_micro_loop", "end_loop", "break_loop", "continue_loop",
            "start_if", "start_elif", "start_else", "end_if",
            "enter_vec_scope", "end_vec_scope", "enter_cube_scope", "end_cube_scope",
            "GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx",
            "create_varlist", "GetValueFrom", "SetValueTo",
            "call_micro",
            "cube_ready", "vec_ready", "wait_cube", "wait_vec",
            "allcube_ready", "allcube_wait", "allvec_ready", "allvec_wait",
        ])
        instructions = getattr(self, "instructions", None)
        if not instructions:
            return False
        for inst in instructions:
            opname = getattr(inst, "opname", "")
            if opname in _CF_OPNAMES:
                return True
        return False

    def resolve_simulator_v2_config(self):
        from ..simulator_v2.config import SimulatorV2Config

        builder = getattr(self, "_simulator_v2_config_builder", None)
        if callable(builder):
            config = builder()
            if config is None or isinstance(config, SimulatorV2Config):
                return config
            raise TypeError(
                "kernel._simulator_v2_config_builder must return SimulatorV2Config or None"
            )
        config = getattr(self, "_simulator_v2_config", None)
        if config is None or isinstance(config, SimulatorV2Config):
            return config
        raise TypeError("kernel._simulator_v2_config must be SimulatorV2Config or None")

    def _iter_bound_gmtensors(self) -> List[GMTensor]:
        out: List[GMTensor] = []
        for value in self._last_bound_args.values():
            if isinstance(value, GMTensor):
                out.append(value)
        return out

    @staticmethod
    def _copy_gmtensor_data_into_v2_runtime(gm_tensor: GMTensor, runtime) -> None:
        import torch

        if gm_tensor.data is None:
            return
        name = getattr(gm_tensor, "name", None)
        if not isinstance(name, str) or name == "":
            return
        if not runtime.tensor_store.contains(name):
            return
        runtime_tensor = runtime.tensor_store.tensor(name)
        if not isinstance(runtime_tensor, torch.Tensor):
            raise TypeError("simulator_v2 runtime tensor must be torch.Tensor")
        src = gm_tensor.data.detach().clone().contiguous().view(-1)
        dst = runtime_tensor.reshape(-1)
        if int(src.numel()) != int(dst.numel()):
            raise ValueError(
                "simulator_v2 tensor spec numel mismatch for "
                + name
                + ": runtime="
                + str(int(dst.numel()))
                + ", bound="
                + str(int(src.numel()))
            )
        dst.copy_(src.to(dtype=runtime_tensor.dtype, device=runtime_tensor.device))

    @staticmethod
    def _copy_v2_runtime_tensor_back(gm_tensor: GMTensor, runtime) -> None:
        import torch

        name = getattr(gm_tensor, "name", None)
        if not isinstance(name, str) or name == "":
            return
        if not runtime.tensor_store.contains(name):
            return
        runtime_tensor = runtime.tensor_store.tensor(name)
        if not isinstance(runtime_tensor, torch.Tensor):
            raise TypeError("simulator_v2 runtime tensor must be torch.Tensor")
        gm_tensor.data = runtime_tensor.detach().clone().contiguous().view(-1)

    def _run_sim_v2(self, trace: Optional[str] = None) -> None:
        from dataclasses import replace

        from ..simulator_v2.compat import SimulatorV2OpExecAdapter
        from ..simulator_v2.config import SimulatorV2Config

        program = self.build_simulator_v2_program()
        config = self.resolve_simulator_v2_config()
        if config is None:
            config = SimulatorV2Config(trace_enabled=trace is not None)
        if trace is not None and not config.trace_enabled:
            config = replace(config, trace_enabled=True)
        adapter = SimulatorV2OpExecAdapter(config=config)
        runtime = adapter.build(program)
        self.global_runtime = runtime
        try:
            runtime.prepare()
            for gm_tensor in self._iter_bound_gmtensors():
                self._copy_gmtensor_data_into_v2_runtime(gm_tensor, runtime)
            runtime.run()
            if trace is not None:
                runtime.dump_chrome_trace(trace)
            for gm_tensor in self._iter_bound_gmtensors():
                self._copy_v2_runtime_tensor_back(gm_tensor, runtime)
        finally:
            runtime.shutdown()

    def _emit_kernel_sources(self, output_dir: str, debug_entry: bool = False) -> None:
        if not isinstance(output_dir, str):
            raise TypeError(f"output_dir must be str, got: {type(output_dir)}")
        abs_output_dir = os.path.abspath(output_dir)
        os.makedirs(abs_output_dir, exist_ok=True)

        cwd = os.getcwd()
        try:
            os.chdir(abs_output_dir)
            for micro in self.used_micros:
                micro.gen_code(f"{micro.name}.h")
            self.dump_kernel(self.name, debug_entry=debug_entry)
        finally:
            os.chdir(cwd)

    def _generate_debug_main(self, output_dir: str, profile: bool = False) -> None:
        if not isinstance(output_dir, str):
            raise TypeError(f"output_dir must be str, got: {type(output_dir)}")
        if not isinstance(profile, bool):
            raise TypeError(f"profile must be bool, got: {type(profile)}")
        if not self._last_bound_args:
            raise RuntimeError("generate_debug requires calling kernel first to bind arguments")

        sig = inspect.signature(self.func)
        param_names = list(sig.parameters.keys())
        output_gmtensors = set()
        if isinstance(getattr(self, "_last_output_gmtensors", None), set):
            output_gmtensors = self._last_output_gmtensors

        var_params = []
        gmtensor_params = []
        for name in param_names:
            bound_val = self._last_bound_args.get(name, None)
            if isinstance(bound_val, Var):
                var_params.append((name, bound_val))
            elif isinstance(bound_val, GMTensor):
                gmtensor_params.append((name, bound_val))
            else:
                raise TypeError(f"kernel arguments must be GMTensor or Var, current {name} type: {type(bound_val)}")

        var_name_set = {name for name, _ in var_params}
        output_names = {name for name, val in gmtensor_params if val in output_gmtensors}
        input_params = [(name, val) for name, val in gmtensor_params if name not in output_names]
        output_params = [(name, val) for name, val in gmtensor_params if name in output_names]

        def _var_cpp_type(var: Var) -> str:
            if var.dtype is Datatype.int:
                return "int"
            if var.dtype is Datatype.float:
                return "float"
            raise ValueError(f"Var only supports int or float dtype, current: {var.dtype}")

        def _storage_cpp_type(dtype) -> str:
            name = getattr(dtype, "name", None)
            mapping = {
                "half": "uint16_t",
                "float": "float",
                "int": "int32_t",
                "int8_t": "int8_t",
                "uint8_t": "uint8_t",
                "int16_t": "int16_t",
                "uint16_t": "uint16_t",
                "uint32_t": "uint32_t",
                "uint64_t": "uint64_t",
                "int64_t": "int64_t",
                "float8_e4m3_t": "uint8_t",
                "float8_e5m2_t": "uint8_t",
                "hifloat8_t": "uint8_t",
                "bfloat16_t": "uint16_t",
            }
            if name not in mapping:
                raise ValueError(f"Unsupported dtype for debug main.cpp: {name}")
            return mapping[name]

        def _dim_expr(dim) -> str:
            if isinstance(dim, bool):
                return str(int(dim))
            if isinstance(dim, int):
                return str(dim)
            if isinstance(dim, Var):
                if dim.name in var_name_set:
                    if dim.dtype is not Datatype.int:
                        raise ValueError(f"shape contains a non-int Var: {dim.name}")
                    return dim.name
                if isinstance(dim.value, bool):
                    return str(int(dim.value))
                if isinstance(dim.value, int):
                    return str(dim.value)
                raise ValueError(f"shape contains an unbound Var: {dim.name!r}")
            raise TypeError(f"shape elements must be int/bool/Var, got: {type(dim)}")

        def _product_expr(parts: List[str]) -> str:
            filtered = [part for part in parts if part != "1"]
            if not filtered:
                return "1"
            if len(filtered) == 1:
                return filtered[0]
            return "*".join(filtered)

        def _tensor_size_expr(gm_tensor: GMTensor) -> str:
            if not isinstance(gm_tensor.shape, (list, tuple)):
                raise TypeError(f"{gm_tensor.name} shape must be list/tuple, got: {type(gm_tensor.shape)}")
            elem_expr = _product_expr([_dim_expr(dim) for dim in gm_tensor.shape])
            storage_cpp_type = _storage_cpp_type(gm_tensor.dtype)
            if elem_expr == "1":
                return f"sizeof({storage_cpp_type})"
            return f"{elem_expr}*sizeof({storage_cpp_type})"

        def _workspace_size_expr() -> str:
            if not self.workspace_shapes:
                return "0"

            terms = []
            for entry in self.workspace_shapes:
                if not isinstance(entry, dict):
                    raise TypeError(f"workspace entry must be dict, got: {type(entry)}")
                shape = entry.get("shape", None)
                dtype = entry.get("dtype", None)
                if not isinstance(shape, (list, tuple)):
                    raise TypeError(f"workspace_shape must be list or tuple, got: {type(shape)}")
                if dtype is None:
                    raise ValueError("workspace entry missing dtype")
                elem_expr = _product_expr([_dim_expr(dim) for dim in shape])
                storage_cpp_type = _storage_cpp_type(dtype)
                if elem_expr == "1":
                    terms.append(f"sizeof({storage_cpp_type})")
                else:
                    terms.append(f"{elem_expr}*sizeof({storage_cpp_type})")
            if len(terms) == 1:
                return terms[0]
            return " + ".join(terms)

        workspace_size_expr = _workspace_size_expr()
        workspace_alloc_expr = workspace_size_expr if workspace_size_expr != "0" else "16 * 1024 * 1024"
        block_dim = self._resolve_op_host_block_dim(getattr(globvars, "device_type", ""))
        exec_args = [name for name, _ in gmtensor_params] + ["workspace"] + [name for name, _ in var_params]

        lines = [
            '#include "testmacros.h"',
            f'#include "aclrtlaunch_{self.name}.h"',
            "",
            "",
            "int32_t main(int32_t argc, char *argv[])",
            "{",
            f"    uint32_t blockDim = {block_dim};",
            "    ",
            "    // constants",
        ]

        for name, var in var_params:
            if var.value is None or not isinstance(var.value, (int, float)):
                raise ValueError(f"Var {name} value must be int or float, current: {type(var.value)}")
            lines.append(f"    {_var_cpp_type(var)} {name} = {var.value};")
        lines.extend(
            [
                "    ",
                "    INIT_ACL();",
                "    ",
                "    // Define Tensors",
            ]
        )

        for name, val in gmtensor_params:
            lines.append(f"    DEFINE_VARIABLE({name}, {_tensor_size_expr(val)});")
        lines.append(f"    DEFINE_VARIABLE(workspace, {workspace_alloc_expr});")
        lines.extend(
            [
                "    ",
                "    // Copy input tensors",
            ]
        )

        for name, _ in input_params:
            lines.append(f"    COPY_VARIABLE({name});")

        run_args = ", ".join(exec_args)
        lines.extend(
            [
                "    ",
                "    // Run",
                f"    RUN_KERNEL({self.name}, {run_args});",
            ]
        )
        if profile:
            lines.extend(
                [
                    "    ",
                    "#ifndef NOSPEEDTEST",
                    f"    SPEED_TEST({self.name}, {run_args});",
                    "#endif",
                ]
            )

        lines.extend(
            [
                "    ",
                "    // Write Tensors",
                "    SYNC_STREAM();",
            ]
        )
        for name, _ in output_params:
            lines.append(f"    WRITE_VARIABLE({name});")
        if workspace_size_expr != "0":
            lines.append("    WRITE_VARIABLE(workspace);")

        lines.extend(
            [
                "    ",
                "    // End",
                "    END_ACL();",
                "    ",
                "    return 0;",
                "}",
                "// Auto-generated code. Readability is not guaranteed",
            ]
        )

        abs_output_dir = os.path.abspath(output_dir)
        os.makedirs(abs_output_dir, exist_ok=True)
        with open(os.path.join(abs_output_dir, "main.cpp"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

    def _generate_debug_bashfiles(self, path: str) -> None:
        if not isinstance(path, str):
            raise TypeError(f"path must be str, got: {type(path)}")
        debug_workspace_path = os.path.join(path, "debug_workspace")
        chipset = self._resolve_debug_chipset(getattr(globvars, "device_type", ""))

        build_lines = [
            "#!/bin/bash",
            f"bash {debug_workspace_path}/build.sh -r npu -v {chipset}",
            "",
        ]
        with open("b.sh", "w", encoding="utf-8") as f:
            f.write("\n".join(build_lines))

        run_lines = [
            "#!/bin/bash",
            f"bash {debug_workspace_path}/run.sh -r npu -v {chipset}",
            "",
        ]
        with open("r.sh", "w", encoding="utf-8") as f:
            f.write("\n".join(run_lines))

    def generate(
        self,
        out_dir: str = "",
        cann_path: Optional[str] = None,
        custom_op_path: Optional[str] = None,
        profile: bool = False,
    ) -> None:
        if not isinstance(out_dir, str):
            raise TypeError(f"out_dir must be str, got: {type(out_dir)}")
        if out_dir == "":
            out_dir = self.name
        if not isinstance(profile, bool):
            raise TypeError(f"profile must be bool, got: {type(profile)}")
        if cann_path is None:
            cann_path = os.getenv("ASCEND_HOME_PATH")
            if not cann_path:
                raise ValueError("cann_path is None and ASCEND_HOME_PATH is not set; please specify cann_path manually")
        if not isinstance(cann_path, str):
            raise TypeError(f"cann_path must be str, got: {type(cann_path)}")
        if custom_op_path is None:
            custom_op_path = cann_path
        if not isinstance(custom_op_path, str):
            raise TypeError(f"custom_op_path must be str, got: {type(custom_op_path)}")

        self.generate_op_project(out_dir, cann_path)

        abs_out_dir = os.path.abspath(out_dir)
        op_host_dir = os.path.join(abs_out_dir, "op_host")
        op_kernel_dir = os.path.join(abs_out_dir, "op_kernel")
        os.makedirs(op_host_dir, exist_ok=True)
        os.makedirs(op_kernel_dir, exist_ok=True)

        cwd = os.getcwd()
        try:
            os.chdir(op_host_dir)
            self.generate_op_host()
        finally:
            os.chdir(cwd)
        self._emit_kernel_sources(op_kernel_dir, debug_entry=False)

        resources_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "resources"))
        tensorutils_src = os.path.join(resources_dir, "tensorutils.h")
        if not os.path.isfile(tensorutils_src):
            raise FileNotFoundError(f"tensorutils.h not found: {tensorutils_src}")
        shutil.copy2(tensorutils_src, os.path.join(op_kernel_dir, "tensorutils.h"))
        self.generate_aclnn_test(
            f"{out_dir}_aclnn_test",
            cann_path=cann_path,
            custom_op_path=custom_op_path,
            profile=profile,
        )
        self.generate_bashfiles(
            out_dir,
            cann_path,
            custom_op_path=custom_op_path,
            profile=profile,
        )

    def generate_debug(
        self,
        out_dir: str = "",
        cann_path: Optional[str] = None,
        custom_op_path: Optional[str] = None,
        profile: bool = False,
    ) -> None:
        if not isinstance(out_dir, str):
            raise TypeError(f"out_dir must be str, got: {type(out_dir)}")
        if out_dir == "":
            out_dir = self.name
        if cann_path is not None and not isinstance(cann_path, str):
            raise TypeError(f"cann_path must be str or None, got: {type(cann_path)}")
        if custom_op_path is not None and not isinstance(custom_op_path, str):
            raise TypeError(f"custom_op_path must be str or None, got: {type(custom_op_path)}")
        if not isinstance(profile, bool):
            raise TypeError(f"profile must be bool, got: {type(profile)}")

        abs_out_dir = os.path.abspath(out_dir)
        os.makedirs(abs_out_dir, exist_ok=True)
        debug_workspace = os.path.join(abs_out_dir, "debug_workspace")
        if os.path.exists(debug_workspace) and not os.path.isdir(debug_workspace):
            raise FileExistsError(f"debug workspace exists and is not a directory: {debug_workspace}")
        os.makedirs(debug_workspace, exist_ok=True)

        resources_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "resources"))
        debug_resources_dir = os.path.join(resources_dir, "debug")
        if not os.path.isdir(debug_resources_dir):
            raise FileNotFoundError(f"debug resources directory not found: {debug_resources_dir}")

        for filename in ("CMakeLists.txt", "build.sh", "run.sh", "data_utils.h", "testmacros.h"):
            src_path = os.path.join(debug_resources_dir, filename)
            if not os.path.isfile(src_path):
                raise FileNotFoundError(f"debug resource file not found: {src_path}")
            shutil.copy2(src_path, os.path.join(debug_workspace, filename))

        cmake_src = os.path.join(debug_resources_dir, "cmake")
        if not os.path.isdir(cmake_src):
            raise FileNotFoundError(f"debug cmake directory not found: {cmake_src}")
        shutil.copytree(cmake_src, os.path.join(debug_workspace, "cmake"), dirs_exist_ok=True)

        cmake_lists_path = os.path.join(debug_workspace, "CMakeLists.txt")
        with open(cmake_lists_path, "r", encoding="utf-8") as f:
            cmake_lists = f.read()
        cmake_lists = cmake_lists.replace("__KERNEL_NAME__", self.name)
        with open(cmake_lists_path, "w", encoding="utf-8") as f:
            f.write(cmake_lists)

        tensorutils_src = os.path.join(resources_dir, "tensorutils.h")
        if not os.path.isfile(tensorutils_src):
            raise FileNotFoundError(f"tensorutils.h not found: {tensorutils_src}")
        shutil.copy2(tensorutils_src, os.path.join(debug_workspace, "tensorutils.h"))

        self._emit_kernel_sources(debug_workspace, debug_entry=True)
        self._generate_debug_main(debug_workspace, profile=profile)
        self._generate_debug_bashfiles(out_dir)

    def generate_aclnn_test(
        self,
        path: str,
        cann_path: Optional[str] = None,
        custom_op_path: Optional[str] = None,
        profile: bool = False,
    ) -> None:
        if not isinstance(path, str):
            raise TypeError(f"path must be str, got: {type(path)}")
        if cann_path is None:
            cann_path = os.getenv("ASCEND_HOME_PATH")
            if not cann_path:
                raise ValueError("cann_path is None and ASCEND_HOME_PATH is not set; please specify cann_path manually")
        if not isinstance(cann_path, str):
            raise TypeError(f"cann_path must be str, got: {type(cann_path)}")
        if custom_op_path is None:
            custom_op_path = cann_path
        if not isinstance(custom_op_path, str):
            raise TypeError(f"custom_op_path must be str, got: {type(custom_op_path)}")
        if not isinstance(profile, bool):
            raise TypeError(f"profile must be bool, got: {type(profile)}")
        resolved_custom_op_path = self._resolve_custom_opp_path(custom_op_path)

        abs_path = os.path.abspath(path)
        os.makedirs(abs_path, exist_ok=True)
        os.makedirs(os.path.join(abs_path, "input"), exist_ok=True)
        os.makedirs(os.path.join(abs_path, "output"), exist_ok=True)
        resources_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "resources"))
        macros_src = os.path.join(resources_dir, "macros.h")
        if not os.path.isfile(macros_src):
            raise FileNotFoundError(f"macros.h not found: {macros_src}")
        shutil.copy2(macros_src, os.path.join(abs_path, "macros.h"))
        parse_prof_src = os.path.join(resources_dir, "parse_prof.py")
        if not os.path.isfile(parse_prof_src):
            raise FileNotFoundError(f"parse_prof.py not found: {parse_prof_src}")
        shutil.copy2(parse_prof_src, os.path.join(abs_path, "parse_prof.py"))
        setup_aclnn_src = os.path.join(resources_dir, "setup_aclnn.py")
        if not os.path.isfile(setup_aclnn_src):
            raise FileNotFoundError(f"setup_aclnn.py not found: {setup_aclnn_src}")
        with open(setup_aclnn_src, "r", encoding="utf-8") as f:
            setup_lines = f.readlines()
        cann_path_literal = repr(cann_path)
        custom_op_path_literal = repr(resolved_custom_op_path)
        replaced_cann_path = False
        replaced_custom_op_path = False
        for idx, line in enumerate(setup_lines):
            stripped = line.lstrip()
            if stripped.startswith("ascend_toolkit_install_path="):
                setup_lines[idx] = f"ascend_toolkit_install_path={cann_path_literal}\n"
                replaced_cann_path = True
                continue
            if stripped.startswith("custom_op_path=") or stripped.startswith("custom_op_path ="):
                setup_lines[idx] = f"custom_op_path = {custom_op_path_literal}\n"
                replaced_custom_op_path = True
        if not replaced_cann_path:
            raise ValueError("ascend_toolkit_install_path config not found in setup_aclnn.py")
        if not replaced_custom_op_path:
            raise ValueError("custom_op_path config not found in setup_aclnn.py")
        machine = platform.machine().lower()
        if machine in ("x86_64", "amd64"):
            arch_tag = "x86_64"
        elif machine in ("aarch64", "arm64"):
            arch_tag = "aarch64"
        else:
            raise ValueError(f"Unknown system architecture: {machine}")
        arch_token = f"{arch_tag}-linux"
        setup_lines = [
            line.replace("aarch64-linux", arch_token).replace("x86_64-linux", arch_token)
            for line in setup_lines
        ]
        with open(os.path.join(abs_path, "setup_aclnn.py"), "w", encoding="utf-8") as f:
            f.writelines(setup_lines)
        tensorx_src = os.path.join(resources_dir, "tensorx.h")
        if not os.path.isfile(tensorx_src):
            raise FileNotFoundError(f"tensorx.h not found: {tensorx_src}")
        with open(tensorx_src, "r", encoding="utf-8") as f:
            tensorx_lines = f.readlines()
        include_replaced = False
        for idx, line in enumerate(tensorx_lines):
            if line.lstrip().startswith('#include "cust_op_list.h"'):
                tensorx_lines[idx] = f'#include "aclnn_{self.name}.h"\n'
                include_replaced = True
                break
        if not include_replaced:
            raise ValueError('Missing #include "cust_op_list.h" in tensorx.h')
        with open(os.path.join(abs_path, "tensorx.h"), "w", encoding="utf-8") as f:
            f.writelines(tensorx_lines)
        if not self._last_bound_args:
            raise RuntimeError("generate_aclnn_test requires calling kernel first to bind arguments")
        sig = inspect.signature(self.func)
        param_names = list(sig.parameters.keys())
        output_gmtensors = set()
        if isinstance(getattr(self, "_last_output_gmtensors", None), set):
            output_gmtensors = self._last_output_gmtensors

        var_params = []
        gmtensor_params = []
        for name in param_names:
            bound_val = self._last_bound_args.get(name, None)
            if isinstance(bound_val, Var):
                var_params.append((name, bound_val))
            elif isinstance(bound_val, GMTensor):
                gmtensor_params.append((name, bound_val))
            else:
                raise TypeError(f"kernel arguments must be GMTensor or Var, current {name} type: {type(bound_val)}")

        gmtensor_values = {val for _, val in gmtensor_params}
        for out in output_gmtensors:
            if out not in gmtensor_values:
                raise ValueError("Output GMTensor must come from kernel arguments")

        var_name_set = {name for name, _ in var_params}

        def _to_camel(name: str) -> str:
            parts = [p for p in name.split("_") if p]
            if not parts:
                return name
            return "".join(p[:1].upper() + p[1:] for p in parts)

        def _var_decl(name: str, var: Var) -> str:
            if var.dtype is None or var.value is None:
                raise ValueError(f"Var {name} has no valid dtype or value")
            if var.dtype is Datatype.int:
                ctype = "int"
            elif var.dtype is Datatype.float:
                ctype = "float"
            else:
                raise ValueError(f"Var {name} only supports int or float dtype, current: {var.dtype}")
            if not isinstance(var.value, (int, float)):
                raise ValueError(f"Var {name} value must be int or float, current: {type(var.value)}")
            return f"    {ctype} {name} = {var.value};"

        def _tensorx_type(dtype) -> str:
            name = getattr(dtype, "name", None)
            mapping = {
                "half": "FP16",
                "float": "FP32",
                "float8_e4m3_t": "E4M3",
                "float8_e5m2_t": "E5M2",
                "bfloat16_t": "BF16",
                "int": "INT32",
                "int8_t": "INT8",
                "int16_t": "INT16",
                "int64_t": "INT64",
                "uint8_t": "UINT8",
                "uint16_t": "UINT16",
                "uint32_t": "UINT32",
                "uint64_t": "UINT64",
            }
            if name in ("int4", "hif8", "bool"):
                raise ValueError(f"Unsupported dtype: {name}")
            if name not in mapping:
                raise ValueError(f"dtype mapping not found: {name}")
            return mapping[name]

        def _dim_expr(dim) -> str:
            if isinstance(dim, int):
                return str(dim)
            if isinstance(dim, Var):
                if dim.name in var_name_set:
                    if dim.dtype is not Datatype.int:
                        raise ValueError(f"shape contains a non-int Var: {dim.name}")
                    return dim.name
                if isinstance(dim.value, int):
                    return str(dim.value)
                raise ValueError(f"shape contains an unbound Var: {dim.name!r}")
            raise TypeError(f"shape elements must be int or Var, got: {type(dim)}")

        def _shape_expr(shape) -> str:
            if not isinstance(shape, (list, tuple)):
                raise TypeError(f"shape must be list or tuple, got: {type(shape)}")
            return ", ".join(_dim_expr(dim) for dim in shape)

        output_names = {name for name, val in gmtensor_params if val in output_gmtensors}
        input_params = [(name, val) for name, val in gmtensor_params if name not in output_names]
        output_params = [(name, val) for name, val in gmtensor_params if name in output_names]

        profile_pre_lines = []
        profile_post_lines = []
        if profile:
            template_src = os.path.join(resources_dir, "test.cpp")
            if not os.path.isfile(template_src):
                raise FileNotFoundError(f"test.cpp template not found: {template_src}")
            with open(template_src, "r", encoding="utf-8") as f:
                legacy_lines = f.readlines()

            def _extract_comment_block(anchor: str) -> list:
                for i, line in enumerate(legacy_lines):
                    if anchor in line:
                        start = i
                        while start - 1 >= 0 and legacy_lines[start - 1].lstrip().startswith("//"):
                            start -= 1
                        end = i
                        while end + 1 < len(legacy_lines) and legacy_lines[end + 1].lstrip().startswith("//"):
                            end += 1
                        return [ln.rstrip("\n") for ln in legacy_lines[start : end + 1]]
                return []

            profile_pre_lines = _extract_comment_block("aclprofInit")
            profile_post_lines = _extract_comment_block("aclprofStop")
            if not profile_pre_lines or not profile_post_lines:
                raise ValueError("Profiling commented block not found in legacy/test.cpp")
            def _uncomment_line(line: str) -> str:
                prefix, sep, rest = line.partition("//")
                if sep == "":
                    return line
                return f"{prefix}{rest.lstrip()}"
            profile_pre_lines = [_uncomment_line(line) for line in profile_pre_lines]
            profile_post_lines = [_uncomment_line(line) for line in profile_post_lines]

        lines = [
            "#include <iostream>",
            "#include <cstdio>",
            "#include <cstring>",
            "#include <vector>",
            "#include <fstream>",
            "#include <sys/stat.h>",
            '#include "tensorx.h"',
            '#include "acl/acl.h"',
        ]
        if profile:
            lines.append('#include "acl/acl_prof.h"')
        lines.extend(
            [
                '#include "macros.h"',
                "",
                "",
                "int main(int argc, char **argv)",
                "{",
                "    int32_t deviceId = 0;",
                "    aclrtStream stream = nullptr;",
                "    auto ret = aclInit(nullptr);",
                "    ret = aclrtSetDevice(deviceId);",
                "    ret = aclrtCreateStream(&stream);",
            ]
        )
        if profile and profile_pre_lines:
            lines.extend(profile_pre_lines)
        lines.extend(
            [
                "    ",
            "    printf(\"--> Initializing tensors...\\n\");",
            ]
        )

        for name, var in var_params:
            lines.append(_var_decl(name, var))
        if var_params:
            lines.append("    ")

        for name, val in input_params:
            tensorx_type = _tensorx_type(val.dtype)
            shape_expr = _shape_expr(val.shape)
            lines.append(f"    TensorX<{tensorx_type}> {name}({{{shape_expr}}});")
            lines.append(f"    {name}.initAll();")
            lines.append(f"    {name}.fillHostWithBinFile(\"./input/input_{name}.bin\");")
            lines.append(f"    {name}.copyToDevice();")
        if input_params:
            lines.append("    ")

        for name, val in output_params:
            tensorx_type = _tensorx_type(val.dtype)
            shape_expr = _shape_expr(val.shape)
            lines.append(f"    TensorX<{tensorx_type}> {name}({{{shape_expr}}});")
            lines.append(f"    {name}.initAll();")
        if output_params:
            lines.append("    ")

        for name, _ in gmtensor_params:
            lines.append(f"    aclTensor* {name}_acl = {name}.toAclTensor();")
        if gmtensor_params:
            lines.append("    ")

        op_name = _to_camel(self.name)
        lines.append("    printf(\"--> Running OP...\\n\");")
        lines.append("    PREPARE_OP();")
        exec_args = []
        for name in param_names:
            bound_val = self._last_bound_args.get(name, None)
            if isinstance(bound_val, GMTensor) and bound_val not in output_gmtensors:
                exec_args.append(f"{name}_acl")
        for name in param_names:
            bound_val = self._last_bound_args.get(name, None)
            if isinstance(bound_val, Var):
                exec_args.append(name)
        for name in param_names:
            bound_val = self._last_bound_args.get(name, None)
            if isinstance(bound_val, GMTensor) and bound_val in output_gmtensors:
                exec_args.append(f"{name}_acl")
        args_str = ", ".join(exec_args)
        if profile:
            lines.append("    for (int i=0; i<100; ++i){")
            lines.append(f"        EXECOP(aclnn{op_name}, stream, {args_str});")
            lines.append("    }")
        lines.append(f"    EXECOP(aclnn{op_name}, stream, {args_str});")
        lines.append("    CHECK_RET(aclrtSynchronizeStream(stream));")
        lines.append("    ")
        lines.append("    printf(\"--> Saving output tensors...\\n\");")
        for name, _ in output_params:
            lines.append(f"    {name}.copyToHost();")
            lines.append(f"    {name}.saveHostToBinFile(\"output/output_{name}.bin\");")
        if profile and profile_post_lines:
            lines.append("    ")
            lines.extend(profile_post_lines)
        lines.append("    ")
        lines.append("    aclrtDestroyStream(stream);")
        lines.append("    aclrtResetDevice(deviceId);")
        lines.append("    aclFinalize();")
        lines.append("}")

        with open(os.path.join(abs_path, "test.cpp"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def generate_bashfiles(
        self,
        path: str,
        cann_path: str,
        custom_op_path: Optional[str] = None,
        profile: bool = False,
    ) -> None:
        if not isinstance(path, str):
            raise TypeError(f"path must be str, got: {type(path)}")
        if not isinstance(cann_path, str):
            raise TypeError(f"cann_path must be str, got: {type(cann_path)}")
        if custom_op_path is None:
            custom_op_path = cann_path
        if not isinstance(custom_op_path, str):
            raise TypeError(f"custom_op_path must be str, got: {type(custom_op_path)}")
        if not isinstance(profile, bool):
            raise TypeError(f"profile must be bool, got: {type(profile)}")
        abs_path = os.path.abspath(path)
        abs_test_path = os.path.abspath(f"{path}_aclnn_test")
        abs_custom_op_path = os.path.abspath(custom_op_path)
        resolved_custom_op_path = os.path.abspath(self._resolve_custom_opp_path(custom_op_path))
        repo_root = os.path.abspath(os.getcwd())
        vendor_lib_abs = os.path.join(resolved_custom_op_path, "vendors", "customize", "op_api", "lib")

        def _rel_to_repo(abs_target: str) -> str:
            ap = os.path.abspath(abs_target)
            try:
                rel = os.path.relpath(ap, repo_root)
            except ValueError:
                return ap
            rel = rel.replace("\\", "/")
            if rel.startswith("../") or rel == "..":
                return ap
            return rel

        def _bash_dir_ref(abs_target: str) -> str:
            seg = _rel_to_repo(abs_target)
            if isinstance(seg, str) and len(seg) > 0 and seg.startswith("/"):
                return '"' + seg + '"'
            if seg == ".":
                return '"${EASYASC_ROOT}"'
            return '"${EASYASC_ROOT}/' + seg + '"'

        def _export_ld_library_path_with_vendor(abs_target: str) -> str:
            seg = _rel_to_repo(abs_target)
            if isinstance(seg, str) and len(seg) > 0 and seg.startswith("/"):
                return f'export LD_LIBRARY_PATH="{seg}:${{LD_LIBRARY_PATH:-}}"'
            if seg == ".":
                return 'export LD_LIBRARY_PATH="${EASYASC_ROOT}:${LD_LIBRARY_PATH:-}"'
            return f'export LD_LIBRARY_PATH="${{EASYASC_ROOT}}/{seg}:${{LD_LIBRARY_PATH:-}}"'

        def _to_camel(name: str) -> str:
            parts = [part for part in name.split("_") if part]
            if not parts:
                return name
            return "".join(part[:1].upper() + part[1:] for part in parts)

        camel_name = _to_camel(self.name)
        chipset = self._resolve_debug_chipset(getattr(globvars, "device_type", ""))
        kernel_proj_dir = _bash_dir_ref(abs_path)
        aclnn_test_dir = _bash_dir_ref(abs_test_path)
        install_root_dir = _bash_dir_ref(abs_custom_op_path)
        ld_library_export = _export_ld_library_path_with_vendor(vendor_lib_abs)
        customize_bin_abs = os.path.join(abs_custom_op_path, "vendors", "customize", "bin")
        customize_bin_dir = _bash_dir_ref(customize_bin_abs)

        env_header = [
            "#!/bin/bash",
            'EASYASC_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"',
            'if [ -z "${ASCEND_HOME_PATH:-}" ]; then',
            '  echo "ERROR: ASCEND_HOME_PATH is not set. Point it at your CANN install root." >&2',
            "  exit 1",
            "fi",
            ': "${ASCEND_CUSTOM_OPP_PATH:=}"',
            "export ASCEND_CUSTOM_OPP_PATH",
            'if [ -n "${EASYASC_PYTHON_BIN:-}" ]; then',
            '  export PATH="${EASYASC_PYTHON_BIN}:${PATH}"',
            "fi",
            'if [ -f "${ASCEND_HOME_PATH}/bin/setenv.bash" ]; then',
            "  # shellcheck source=/dev/null",
            '  source "${ASCEND_HOME_PATH}/bin/setenv.bash"',
            "fi",
        ]

        script_lines = env_header + [
            f"cd {kernel_proj_dir}",
            "bash build.sh",
            "cd build_out",
            f"for f in custom_*.run; do bash ./$f --install-path={install_root_dir}; done",
            "",
        ]
        with open("b.sh", "w", encoding="utf-8") as f:
            f.write("\n".join(script_lines))
        run_lines = env_header + [
            f"CUSTOMIZE_BIN={customize_bin_dir}",
            'if [ -f "${CUSTOMIZE_BIN}/setenv.bash" ]; then',
            "  # shellcheck source=/dev/null",
            '  source "${CUSTOMIZE_BIN}/setenv.bash"',
            "fi",
            'if [ -f "${CUSTOMIZE_BIN}/set_env.bash" ]; then',
            "  # shellcheck source=/dev/null",
            '  source "${CUSTOMIZE_BIN}/set_env.bash"',
            "fi",
            ld_library_export,
            f"cd {aclnn_test_dir}",
            "python setup_aclnn.py",
            f"./test_aclnnop",
        ]
        if profile:
            run_lines.append(f"python parse_prof.py {camel_name}")
        run_lines.append("")
        with open("r.sh", "w", encoding="utf-8") as f:
            f.write("\n".join(run_lines))
