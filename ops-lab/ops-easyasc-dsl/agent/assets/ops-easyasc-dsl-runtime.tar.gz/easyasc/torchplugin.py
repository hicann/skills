# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import inspect
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Sequence, Union

if TYPE_CHECKING:
    from .kernelbase.kernelbase import KernelBase


def _tail_log_lines(log_path: str, max_lines: int = 40) -> str:
    with open(log_path, "r", encoding="utf-8", errors="replace") as log_file:
        lines = log_file.readlines()
    tail = lines[-max_lines:]
    return "".join(tail).rstrip()


def _to_simulator_flag(simulator: Union[bool, str]) -> bool:
    if isinstance(simulator, bool):
        return simulator
    if not isinstance(simulator, str):
        raise TypeError("simulator must be bool or str, got: " + str(type(simulator)))
    lowered = simulator.strip().lower()
    if lowered in ("off", "none", "false"):
        return False
    if lowered in ("true", "v2", "sim", "simulator", "simulator_v2", "legacy"):
        return True
    raise ValueError("simulator must be bool or one of: off, v2; got: " + repr(simulator))



def _run_bash_with_progress(script_path: str, log_path: str) -> None:
    import os
    import subprocess
    import sys
    import time

    if not os.path.exists(script_path) or not os.path.isfile(script_path):
        raise FileNotFoundError(f"{script_path} does not exist or is not a file, cannot execute")

    with open(log_path, "w", encoding="utf-8") as log_file:
        proc = subprocess.Popen(
            ["bash", script_path],
            stdout=log_file,
            stderr=log_file,
        )
        start_ts = time.time()
        bar_width = 24
        while True:
            ret = proc.poll()
            elapsed = time.time() - start_ts
            pos = int(elapsed * 8) % (2 * bar_width)
            if pos >= bar_width:
                pos = 2 * bar_width - pos - 1
            bar = [" "] * bar_width
            bar[pos] = "#"
            msg = f"\r[{''.join(bar)}] bash {script_path} running... {elapsed:6.1f}s"
            print(msg, end="", file=sys.stderr, flush=True)
            if ret is not None:
                break
            time.sleep(0.2)
        print("\r" + " " * (bar_width + 40) + "\r", end="", file=sys.stderr, flush=True)
        if ret != 0:
            tail = _tail_log_lines(log_path)
            detail = f"\nLast log lines:\n{tail}" if tail else "\nLog was empty."
            raise RuntimeError(
                f"bash {script_path} failed with return code {ret}. Log: {log_path}{detail}"
            )

    # Print out the profiled elapsed time
    for line in open(log_path, "r", encoding="utf-8", errors="replace"):
        if line.startswith('---- N_TESTS'):
            print(line)


def _run_cmd_with_progress(*args: str, log_path: str, cwd: Optional[str]=None) -> None:
    import os
    import subprocess
    import sys
    import time

    with open(log_path, "w", encoding="utf-8") as log_file:
        proc = subprocess.Popen(
            args,
            stdout=log_file,
            stderr=log_file,
            cwd=cwd,
        )
        start_ts = time.time()
        bar_width = 24
        while True:
            ret = proc.poll()
            elapsed = time.time() - start_ts
            pos = int(elapsed * 8) % (2 * bar_width)
            if pos >= bar_width:
                pos = 2 * bar_width - pos - 1
            bar = [" "] * bar_width
            bar[pos] = "#"
            msg = f"\r[{''.join(bar)}] [{' '.join(args)}] running... {elapsed:6.1f}s"
            print(msg, end="", file=sys.stderr, flush=True)
            if ret is not None:
                break
            time.sleep(0.2)
        print("\r" + " " * (bar_width + 40) + "\r", end="", file=sys.stderr, flush=True)
        if ret != 0:
            tail = _tail_log_lines(log_path)
            detail = f"\nLast log lines:\n{tail}" if tail else "\nLog was empty."
            raise RuntimeError(
                f"[{' '.join(args)}] failed with return code {ret}. Log: {log_path}{detail}"
            )
    print()


class TorchApiManager:
    def __init__(
        self,
        out_dir: str = "",
        cann_path: Optional[str] = None,
        custom_op_path: Optional[str] = None,
    ) -> None:
        import os

        self._ops: Dict[str, "OpExec"] = {}
        self.out_dir = out_dir
        self.cann_path = cann_path
        if custom_op_path is None:
            custom_op_path = "./"
        if not isinstance(custom_op_path, str):
            raise TypeError(f"custom_op_path must be str, got: {type(custom_op_path)}")
        self.custom_op_path = os.path.abspath(custom_op_path)
        self.compiled = False
        self.mod = None 
        self.initialize()

    def initialize(self) -> None:
        pass

    def load_lib(self):
        import os 
        import glob 
        import subprocess
        import importlib

        if self.mod is not None:
            print('Module is already loaded. Will skip compilation')
            return 

        f = os.path.abspath(self.out_dir)
        try:
            f = glob.glob(os.path.join(f, 'custop_torchapi.cpy*'))[0]
        except:
            print('No pybind library found. Need to re-compile')
            return 
        res = subprocess.run(['nm', '-D', '--defined-only', '-C', f], capture_output=True, text=True)
        res = res.stdout 
        res = res.split('\n')

        defined_fns = []
        for line in res:
            if ' T ' in line:
                name = line.split(' T ')[-1].split('(')[0]
                defined_fns.append(name)
        
        for name in self._ops:
            if name not in defined_fns:
                print('Module not in existing op. Need to re-compile')
                return 

        os.environ['ASCEND_CUSTOM_OPP_PATH'] = os.path.join(self.custom_op_path, 'vendors', 'customize')
        subprocess.check_call(f'cp -r {os.path.join(self.out_dir, "custop_torchapi.*.so")} ./', shell=True)
        self.mod = importlib.import_module('custop_torchapi')
        self.compiled = True 
        for _,op in self._ops.items():
            op.api_manager = self
        print('Custom OP torchapi loaded.')

    def compile(self) -> str:
        import os
        import subprocess
        import importlib
        from .utils.Tensor import GMTensor
        from .utils.var import Var

        if self.mod is not None:
            print('Module is already compiled. Will skip compilation')
            return ''

        if not self._ops:
            raise ValueError("TorchApiManager has no registered ops")

        resources_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "resources"))
        template_path = os.path.join(resources_dir, "torchbind_template.cpp")
        if not os.path.isfile(template_path):
            raise FileNotFoundError(f"torchbind_template.cpp not found: {template_path}")
        setup_template_path = os.path.join(resources_dir, "torchsetup.py")
        if not os.path.isfile(setup_template_path):
            raise FileNotFoundError(f"torchsetup.py not found: {setup_template_path}")

        with open(template_path, "r", encoding="utf-8") as f:
            template_lines = f.readlines()

        include_idx: Optional[int] = None
        module_idx: Optional[int] = None
        binding_idx: Optional[int] = None
        for idx, line in enumerate(template_lines):
            if "aclnn_test_xxx.h" in line:
                include_idx = idx
            if "PYBIND11_MODULE" in line:
                module_idx = idx
            if 'm.def("test_xxx", &test_xxx, "test_xxx");' in line:
                binding_idx = idx

        if include_idx is None:
            raise ValueError('Missing "aclnn_test_xxx.h" placeholder in torchbind_template.cpp')
        if module_idx is None:
            raise ValueError("Missing PYBIND11_MODULE block in torchbind_template.cpp")
        if binding_idx is None:
            raise ValueError('Missing test_xxx binding placeholder in torchbind_template.cpp')

        include_lines = []
        wrapper_lines = []
        binding_lines = []

        def _to_camel(name: str) -> str:
            parts = [part for part in name.split("_") if part]
            if not parts:
                return name
            return "".join(part[:1].upper() + part[1:] for part in parts)

        def _acl_dtype_literal(dtype: Any) -> str:
            dtype_name = getattr(dtype, "name", None)
            mapping = {
                "half": "aclDataType::ACL_FLOAT16",
                "float": "aclDataType::ACL_FLOAT",
                "int": "aclDataType::ACL_INT32",
                "int64_t": "aclDataType::ACL_INT64",
                "int8_t": "aclDataType::ACL_INT8",
                "uint8_t": "aclDataType::ACL_UINT8",
                "int16_t": "aclDataType::ACL_INT16",
                "uint16_t": "aclDataType::ACL_UINT16",
                "uint32_t": "aclDataType::ACL_UINT32",
                "uint64_t": "aclDataType::ACL_UINT64",
                "bfloat16_t": "aclDataType::ACL_BF16",
                "bool": "aclDataType::ACL_BOOL",
                "float8_e5m2_t": "aclDataType::ACL_FLOAT8_E5M2",
                "float8_e4m3_t": "aclDataType::ACL_FLOAT8_E4M3FN",
                "hif8": "aclDataType::ACL_HIFLOAT8",
            }
            if dtype_name not in mapping:
                raise TypeError(f"Unsupported GMTensor dtype for torch API binding: {dtype_name}")
            return mapping[dtype_name]

        for op_name, op_exec in self._ops.items():
            include_lines.append(
                template_lines[include_idx].replace("aclnn_test_xxx", f"aclnn_{op_name}")
            )
            bound_args = getattr(op_exec.op_func, "_last_bound_args", None)
            if not isinstance(bound_args, dict) or not bound_args:
                raise RuntimeError(
                    f"OpExec {op_name} has no bound arguments; call it once before TorchApiManager.compile()"
                )
            output_gmtensors = getattr(op_exec.op_func, "_last_output_gmtensors", None)
            if not isinstance(output_gmtensors, set):
                output_gmtensors = set()

            arg_decls = []
            tensor_arg_infos = []
            scalar_arg_names = []
            for arg_name, arg_value in bound_args.items():
                if isinstance(arg_value, GMTensor):
                    arg_decls.append(f"at::Tensor {arg_name}")
                    tensor_arg_infos.append(
                        (arg_name, _acl_dtype_literal(arg_value.dtype), arg_value in output_gmtensors)
                    )
                    continue
                if isinstance(arg_value, Var):
                    scalar_value = arg_value.value
                    if isinstance(scalar_value, float):
                        scalar_ctype = "float"
                    elif isinstance(scalar_value, (int, bool)):
                        scalar_ctype = "int"
                    else:
                        raise TypeError(
                            f"Unsupported scalar type for {op_name}.{arg_name}: {type(scalar_value)}"
                        )
                    arg_decls.append(f"{scalar_ctype} {arg_name}")
                    scalar_arg_names.append(arg_name)
                    continue
                raise TypeError(
                    f"Unsupported bound argument type for {op_name}.{arg_name}: {type(arg_value)}"
                )

            if not tensor_arg_infos:
                raise ValueError(f"OpExec {op_name} requires at least one GMTensor argument")
            first_tensor_name = tensor_arg_infos[0][0]
            input_tensor_acl_names = [
                f"{tensor_arg_name}_acl"
                for tensor_arg_name, _, is_output in tensor_arg_infos
                if not is_output
            ]
            output_tensor_acl_names = [
                f"{tensor_arg_name}_acl"
                for tensor_arg_name, _, is_output in tensor_arg_infos
                if is_output
            ]
            exec_args = input_tensor_acl_names + scalar_arg_names + output_tensor_acl_names
            camel_name = _to_camel(op_name)
            wrapper_lines.extend(
                [
                    f"void {op_name}({', '.join(arg_decls)}) {{\n",
                    "    PREPARE_OP();\n",
                    f"    int devidx = {first_tensor_name}.device().index();\n",
                    "    c10_npu::NPUStream stream = c10_npu::getCurrentNPUStream(devidx);\n",
                ]
            )
            for tensor_arg_name, acl_dtype_literal, _ in tensor_arg_infos:
                wrapper_lines.append(
                    f"    aclTensor* {tensor_arg_name}_acl = toAclTensor({tensor_arg_name}, {acl_dtype_literal});\n"
                )
            wrapper_lines.extend(
                [
                    f"    EXECOP(aclnn{camel_name}, stream, {', '.join(exec_args)});\n",
                ]
            )
            for tensor_arg_name, _, _ in tensor_arg_infos:
                wrapper_lines.append(
                    f"    aclDestroyTensor({tensor_arg_name}_acl);\n"
                )
            wrapper_lines.extend(
                [
                    "}\n",
                    "\n",
                ]
            )
            binding_lines.append(
                template_lines[binding_idx].replace("test_xxx", op_name)
            )

        output_lines = list(template_lines)
        output_lines[include_idx : include_idx + 1] = include_lines
        wrapper_insert_idx = module_idx + (len(include_lines) - 1)
        output_lines[wrapper_insert_idx:wrapper_insert_idx] = wrapper_lines
        binding_insert_idx = binding_idx + (len(include_lines) - 1)
        binding_insert_idx += len(wrapper_lines)
        output_lines[binding_insert_idx : binding_insert_idx + 1] = binding_lines

        output_dir = os.path.abspath(self.out_dir or ".")
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, "custop_torchapi.cpp")
        with open(output_path, "w", encoding="utf-8") as f:
            f.writelines(output_lines)
        with open(setup_template_path, "r", encoding="utf-8") as f:
            setup_lines = f.readlines()
        custom_op_path_literal = repr(self.custom_op_path)
        replaced_custom_op_path = False
        for idx, line in enumerate(setup_lines):
            stripped = line.lstrip()
            if stripped.startswith("custom_op_path=") or stripped.startswith("custom_op_path ="):
                setup_lines[idx] = f"custom_op_path = {custom_op_path_literal}\n"
                replaced_custom_op_path = True
                break
        if not replaced_custom_op_path:
            raise ValueError("custom_op_path config not found in torchsetup.py")
        setup_output_path = os.path.join(output_dir, "setup.py")
        with open(setup_output_path, "w", encoding="utf-8") as f:
            f.writelines(setup_lines)
        
        _run_bash_with_progress('b.sh', 'b.sh.log')
        _run_cmd_with_progress('python', 'setup.py', 'build_ext', '--inplace', log_path='torchplugin.log', cwd=self.out_dir)
        subprocess.check_call(f'cp -r {os.path.join(self.out_dir, "custop_torchapi.*.so")} ./', shell=True)
        self.compiled = True
        os.environ['ASCEND_CUSTOM_OPP_PATH'] = os.path.join(self.custom_op_path, 'vendors', 'customize')
        self.mod = importlib.import_module('custop_torchapi')
        for _,op in self._ops.items():
            op.api_manager = self
        return output_path

    def __setattr__(self, key: str, value: object) -> None:
        if key in {"_ops", "out_dir", "cann_path", "custom_op_path", "compiled", "mod"} or key.startswith("_"):
            if isinstance(value, OpExec):
                raise TypeError(f'(setattr) Variable name {key} cannot be OpExec. Please change a name')
            super().__setattr__(key, value)
            return

        if not isinstance(value, OpExec):
            raise TypeError(f"value must be OpExec, got: {type(value)}")

        value.out_dir = self.out_dir
        value.cann_path = self.cann_path
        value.custom_op_path = self.custom_op_path
        value.gen_only = True
        value.simulator = False
        value.skip_compile = False

        opname = getattr(value.op_func, "name", None)
        if not isinstance(opname, str):
            raise TypeError(f"OpExec.op_func.name must be str, got: {type(opname)}")
        self._ops[opname] = value
        super().__setattr__(key, value)

    def call_kernel(self, op: 'OpExec', args):
        if self.mod is None:
            raise ValueError('Pybind module is not compiled. Please run compile or load_lib first')
        eval(f'self.mod.{op.op_func.name}(*args)')


class OpExec:
    def __init__(
        self,
        op_func: Union["KernelBase", Callable[..., Any]],
        out_dir: str = "",
        cann_path: Optional[str] = None,
        custom_op_path: Optional[str] = None,
        profile: bool = False,
        gen_only: bool = False,
        simulator: Union[bool, str] = False,
        skip_compile: bool = False,
        trace: Optional[str] = None,
        debug: bool = False,
    ) -> None:
        import os

        self.op_func = op_func
        self.out_dir = out_dir
        self.cann_path = cann_path
        if custom_op_path is None:
            custom_op_path = "./"
        if not isinstance(custom_op_path, str):
            raise TypeError(f"custom_op_path must be str, got: {type(custom_op_path)}")
        self.custom_op_path = os.path.abspath(custom_op_path)
        self.profile = profile
        self.gen_only = gen_only
        self.simulator = _to_simulator_flag(simulator)
        if not isinstance(skip_compile, bool):
            raise TypeError(f"skip_compile must be bool, got: {type(skip_compile)}")
        self.skip_compile = skip_compile
        if trace is not None and not isinstance(trace, str):
            raise TypeError(f"trace must be str or None, got: {type(trace)}")
        if isinstance(trace, str) and trace == "":
            raise ValueError("trace must be a non-empty file path when provided")
        if trace is not None and not self.simulator:
            raise ValueError("trace is only supported when simulator is enabled")
        self.trace = trace
        if not isinstance(debug, bool):
            raise TypeError(f"debug must be bool, got: {type(debug)}")
        self.debug = debug
        self.api_manager: Optional['TorchApiManager'] = None
        self._built = False

    def _validate_kernel_tensor_var_partition(self) -> None:
        from .kernelbase.kernelbase import KernelBase
        from .utils.Tensor import GMTensor
        from .utils.var import Var

        if not isinstance(self.op_func, KernelBase):
            raise TypeError("op_func must be a KernelBase instance")

        sig = inspect.signature(self.op_func.func)
        seen_var = False
        for name, param in sig.parameters.items():
            annotation = param.annotation
            is_tensor_param = annotation is GMTensor or annotation == "GMTensor"
            is_var_param = annotation is Var or annotation == "Var"
            if is_var_param:
                seen_var = True
                continue
            if is_tensor_param and seen_var:
                raise ValueError(
                    "Invalid kernel argument order for OpExec: expected "
                    "`input GMTensor* -> output GMTensor* -> Var*`, but found a GMTensor "
                    f"parameter after Var parameters. Offending parameter: `{name}`."
                )

    def _validate_bound_kernel_signature(self) -> None:
        from .kernelbase.kernelbase import KernelBase
        from .utils.Tensor import GMTensor
        from .utils.var import Var

        if not isinstance(self.op_func, KernelBase):
            raise TypeError("op_func must be a KernelBase instance")
        if not self.op_func._last_bound_args:
            raise ValueError("op_func has not been executed; cannot validate KernelBase arguments")

        output_gmtensors = getattr(self.op_func, "_last_output_gmtensors", None)
        if not isinstance(output_gmtensors, set):
            output_gmtensors = set()
        output_gmtensors_ordered = getattr(self.op_func, "_last_output_gmtensors_ordered", None)
        if not isinstance(output_gmtensors_ordered, list):
            output_gmtensors_ordered = []

        category_items: List[str] = []
        output_param_names: List[str] = []
        output_name_by_id: Dict[int, str] = {}
        seen_output = False
        seen_var = False

        for name, bound_val in self.op_func._last_bound_args.items():
            if isinstance(bound_val, GMTensor):
                is_output = bound_val in output_gmtensors
                if is_output:
                    seen_output = True
                    output_param_names.append(name)
                    output_name_by_id[id(bound_val)] = name
                    category_items.append(f"{name}=output")
                    if seen_var:
                        raise ValueError(
                            "Invalid kernel argument order for OpExec: expected "
                            "`input GMTensor* -> output GMTensor* -> Var*`, but found an "
                            f"output GMTensor after Var parameters. Offending parameter: `{name}`. "
                            f"Current order: {', '.join(category_items)}"
                        )
                    continue

                category_items.append(f"{name}=input")
                if seen_output or seen_var:
                    raise ValueError(
                        "Invalid kernel argument order for OpExec: expected "
                        "`input GMTensor* -> output GMTensor* -> Var*`, but found an "
                        f"input GMTensor after output/Var parameters. Offending parameter: `{name}`. "
                        f"Current order: {', '.join(category_items)}"
                    )
                continue

            if isinstance(bound_val, Var):
                seen_var = True
                category_items.append(f"{name}=var")
                continue

            raise TypeError(
                f"kernel arguments must be GMTensor or Var, current {name} type: {type(bound_val)}"
            )

        output_return_names: List[str] = []
        for out in output_gmtensors_ordered:
            if not isinstance(out, GMTensor):
                continue
            output_name = output_name_by_id.get(id(out))
            if output_name is None:
                raise ValueError("Output GMTensor must come from kernel arguments")
            output_return_names.append(output_name)

        if output_param_names != output_return_names:
            raise ValueError(
                "Output GMTensor order in function signature does not match return order: "
                f"signature outputs={output_param_names}, return outputs={output_return_names}"
            )

    def __call__(
        self,
        *args: Any,
        shape_bindings: Optional[Dict[int, Sequence[Optional[int]]]] = None,
    ) -> Any:
        from .kernelbase.kernelbase import KernelBase
        from .utils.Tensor import GMTensor
        from .utils.datatype import Datatype
        from .utils.var import Var
        import os
        import time

        if self.api_manager is not None:
            self.api_manager.call_kernel(self, args)
            return 

        if not isinstance(self.op_func, KernelBase):
            raise TypeError("op_func must be a KernelBase instance")

        try:
            import torch
        except Exception as exc:
            raise ImportError("OpExec.__call__ requires torch") from exc

        tensor_args: List[Any] = []
        scalar_vars: List[Var] = []
        seen_scalar = False
        for idx, arg in enumerate(args):
            if isinstance(arg, torch.Tensor):
                if seen_scalar:
                    raise TypeError("Invalid argument order: torch.Tensor must come before int/float")
                tensor_args.append(arg)
                continue
            if isinstance(arg, (int, float)):
                seen_scalar = True
                scalar_vars.append(Var(arg))
                continue
            raise TypeError(f"Invalid argument type: arg #{idx} has type {type(arg)}")

        if shape_bindings is not None and not isinstance(shape_bindings, dict):
            raise TypeError(f"shape_bindings must be dict or None, got: {type(shape_bindings)}")

        if shape_bindings is None:
            shape_bindings = {}

        self._validate_kernel_tensor_var_partition()

        dtype_map = {
            torch.float16: Datatype.half,
            torch.float32: Datatype.float,
            torch.int32: Datatype.int,
            torch.int64: Datatype.int64,
            torch.int8: Datatype.int8,
            torch.uint8: Datatype.uint8,
            torch.int16: Datatype.int16,
            torch.bfloat16: Datatype.bfloat16,
        }
        if hasattr(torch, "float8_e4m3fn"):
            dtype_map[torch.float8_e4m3fn] = Datatype.e4m3  # type: ignore[attr-defined]
        if hasattr(torch, "float8_e5m2"):
            dtype_map[torch.float8_e5m2] = Datatype.e5m2  # type: ignore[attr-defined]
        if hasattr(torch, "uint16"):
            dtype_map[torch.uint16] = Datatype.uint16  # type: ignore
        if hasattr(torch, "uint32"):
            dtype_map[torch.uint32] = Datatype.uint32  # type: ignore
        if hasattr(torch, "uint64"):
            dtype_map[torch.uint64] = Datatype.uint64  # type: ignore

        gm_tensors: List[GMTensor] = []
        for tensor_idx, tensor in enumerate(tensor_args):
            binding = shape_bindings.get(tensor_idx)
            if binding is not None:
                if not isinstance(binding, (list, tuple)):
                    raise TypeError(
                        f"shape_bindings[{tensor_idx}] must be list/tuple, got: {type(binding)}"
                    )
                if len(binding) != len(tensor.shape):
                    raise ValueError(
                        f"shape_bindings[{tensor_idx}] rank must match tensor rank, "
                        f"got: {len(binding)} vs {len(tensor.shape)}"
                    )

            inferred_shape: List[Any] = []
            for dim_idx, dim in enumerate(tensor.shape):
                explicit_scalar_idx: Optional[int] = None
                if binding is not None:
                    chosen_idx = binding[dim_idx]
                    if chosen_idx is not None:
                        if not isinstance(chosen_idx, int):
                            raise TypeError(
                                f"shape_bindings[{tensor_idx}][{dim_idx}] must be int or None, "
                                f"got: {type(chosen_idx)}"
                            )
                        if chosen_idx < 0 or chosen_idx >= len(scalar_vars):
                            raise ValueError(
                                f"shape_bindings[{tensor_idx}][{dim_idx}] out of range: "
                                f"{chosen_idx}, scalar count={len(scalar_vars)}"
                            )
                        explicit_scalar_idx = chosen_idx

                if explicit_scalar_idx is not None:
                    bound_var = scalar_vars[explicit_scalar_idx]
                    if bound_var.value != dim:
                        raise ValueError(
                            f"shape_bindings[{tensor_idx}][{dim_idx}] mismatches tensor dim value: "
                            f"tensor dim={int(dim)}, scalar[{explicit_scalar_idx}]={bound_var.value}"
                        )
                    inferred_shape.append(bound_var)
                    continue

                matched_indices: List[int] = []
                for scalar_idx, scalar_var in enumerate(scalar_vars):
                    if scalar_var.value == dim:
                        matched_indices.append(scalar_idx)
                if len(matched_indices) == 0:
                    inferred_shape.append(int(dim))
                    continue
                if len(matched_indices) == 1:
                    inferred_shape.append(scalar_vars[matched_indices[0]])
                    continue
                raise ValueError(
                    f"Ambiguous scalar match for tensor #{tensor_idx} dim #{dim_idx} "
                    f"(value={int(dim)}): matches scalar indices {matched_indices}. "
                    "Please provide shape_bindings for this tensor dimension."
                )

            dtype = dtype_map.get(tensor.dtype)
            if dtype is None:
                raise TypeError(f"Unsupported torch dtype: {tensor.dtype}")
            gm_tensor = GMTensor(dtype, inferred_shape)
            if self.simulator:
                gm_tensor.data = tensor.detach().clone().contiguous().view(-1)
            gm_tensors.append(gm_tensor)

        kernel_ret = self.op_func(*(gm_tensors + scalar_vars))
        self._validate_bound_kernel_signature()
        if self.simulator:
            print("Starting simulation run")
            sim_start_ts = time.perf_counter()
            try:
                self.op_func.run_sim(trace=self.trace)
            finally:
                elapsed = time.perf_counter() - sim_start_ts
                print(f"Simulation run elapsed: {elapsed:.3f}s")
        else:
            if self.debug:
                self.op_func.generate_debug(
                    self.out_dir,
                    cann_path=self.cann_path,
                    custom_op_path=self.custom_op_path,
                    profile=self.profile,
                )
            else:
                self.op_func.generate(
                    self.out_dir,
                    cann_path=self.cann_path,
                    custom_op_path=self.custom_op_path,
                    profile=self.profile,
                )

        if not self.op_func._last_bound_args:
            raise ValueError("op_func has not been executed; cannot extract IO info from KernelBase")

        output_gmtensors = self.op_func._last_output_gmtensors
        param_names = list(self.op_func._last_bound_args.keys())
        gmtensor_param_names: List[str] = []
        for name in param_names:
            bound_val = self.op_func._last_bound_args.get(name)
            if isinstance(bound_val, GMTensor):
                gmtensor_param_names.append(name)

        input_param_names = []
        for name in gmtensor_param_names:
            bound_val = self.op_func._last_bound_args.get(name)
            if bound_val not in output_gmtensors:
                input_param_names.append(name)

        if len(tensor_args) == len(gmtensor_param_names):
            tensor_by_name = {
                name: tensor_args[idx] for idx, name in enumerate(gmtensor_param_names)
            }
        elif len(tensor_args) == len(input_param_names):
            tensor_by_name = {
                name: tensor_args[idx] for idx, name in enumerate(input_param_names)
            }
        else:
            raise ValueError(
                "Number of torch.Tensor inputs does not match KernelBase GMTensor parameters"
            )

        def _resolve_dim(value: Any, label: str) -> int:
            if isinstance(value, bool):
                return int(value)
            if isinstance(value, int):
                return value
            if isinstance(value, Var):
                raw = value.value
                if not isinstance(raw, (int, float, bool)):
                    raise TypeError(
                        f"{label} must resolve to int/float/bool from Var, got: {type(raw)}"
                    )
                return int(raw)
            if isinstance(value, float):
                return int(value)
            raise TypeError(f"{label} must resolve to int, got: {type(value)}")

        def _resolve_shape_dims(gm_tensor: GMTensor) -> List[int]:
            shape = gm_tensor.shape
            if not isinstance(shape, (list, tuple)):
                raise TypeError(
                    f"{gm_tensor.name} shape must be list/tuple, got: {type(shape)}"
                )
            shape_dims: List[int] = []
            for idx, dim in enumerate(shape):
                resolved = _resolve_dim(dim, f"{gm_tensor.name}.shape[{idx}]")
                if resolved < 0:
                    raise ValueError(
                        f"{gm_tensor.name} shape must be non-negative, got: {shape}"
                    )
                shape_dims.append(resolved)
            return shape_dims

        if not self.simulator:
            base_dir = self.out_dir if self.out_dir else self.op_func.name
            if self.debug:
                runtime_dir = os.path.abspath(os.path.join(base_dir, "debug_workspace"))
            else:
                runtime_dir = os.path.abspath(f"{base_dir}_aclnn_test")
            input_dir = os.path.join(runtime_dir, "input")
            output_dir = os.path.join(runtime_dir, "output")
            os.makedirs(input_dir, exist_ok=True)
            os.makedirs(output_dir, exist_ok=True)

            for name in input_param_names:
                tensor = tensor_by_name[name]
                tensor_cpu = tensor.detach().cpu()
                tensor_bytes = tensor_cpu.contiguous().view(torch.uint8)
                tensor_bytes.numpy().tofile(os.path.join(input_dir, f"input_{name}.bin"))

            if self.gen_only:
                return kernel_ret

            if not self.skip_compile and not self._built:
                build_script = "b.sh"
                build_log_path = os.path.abspath("b.sh.log")
                _run_bash_with_progress(build_script, build_log_path)
                self._built = True
            run_script = "r.sh"
            run_log_path = os.path.abspath("r.sh.log")
            _run_bash_with_progress(run_script, run_log_path)

            def _dtype_to_torch(gm_dtype: Any) -> "torch.dtype":
                name = getattr(gm_dtype, "name", None)
                mapping = {
                    "half": torch.float16,
                    "float": torch.float32,
                    "int": torch.int32,
                    "int64_t": torch.int64,
                    "int8_t": torch.int8,
                    "uint8_t": torch.uint8,
                    "int16_t": torch.int16,
                    "bfloat16_t": torch.bfloat16,
                }
                if name in mapping:
                    return mapping[name]
                if name == "uint16_t" and hasattr(torch, "uint16"):
                    return torch.uint16  # type: ignore[attr-defined]
                if name == "uint32_t" and hasattr(torch, "uint32"):
                    return torch.uint32  # type: ignore[attr-defined]
                if name == "uint64_t" and hasattr(torch, "uint64"):
                    return torch.uint64  # type: ignore[attr-defined]
                if name == "float8_e4m3_t" and hasattr(torch, "float8_e4m3fn"):
                    return torch.float8_e4m3fn  # type: ignore[attr-defined]
                if name == "float8_e5m2_t" and hasattr(torch, "float8_e5m2"):
                    return torch.float8_e5m2  # type: ignore[attr-defined]
                raise TypeError(f"Unsupported GMTensor dtype for runtime output load: {name}")

            def _dtype_byte_size(gm_dtype: Any) -> int:
                name = getattr(gm_dtype, "name", None)
                size_map = {
                    "half": 2,
                    "float": 4,
                    "int": 4,
                    "int64_t": 8,
                    "int8_t": 1,
                    "uint8_t": 1,
                    "int16_t": 2,
                    "uint16_t": 2,
                    "uint32_t": 4,
                    "uint64_t": 8,
                    "bfloat16_t": 2,
                    "float8_e4m3_t": 1,
                    "float8_e5m2_t": 1,
                }
                if name not in size_map:
                    raise TypeError(f"Unsupported GMTensor dtype size for output load: {name}")
                return size_map[name]

            def _load_output_from_bin(gm_tensor: GMTensor) -> "torch.Tensor":
                shape_dims = _resolve_shape_dims(gm_tensor)
                target_numel = 1
                for dim in shape_dims:
                    target_numel *= dim
                output_path = os.path.join(output_dir, f"output_{gm_tensor.name}.bin")
                if not os.path.isfile(output_path):
                    raise FileNotFoundError(f"Missing output bin file: {output_path}")
                expected_bytes = target_numel * _dtype_byte_size(gm_tensor.dtype)
                actual_bytes = os.path.getsize(output_path)
                if actual_bytes < expected_bytes:
                    raise ValueError(
                        f"Output bin too small for {gm_tensor.name}: "
                        f"required_bytes={expected_bytes}, actual_bytes={actual_bytes}"
                    )
                dtype_name = getattr(gm_tensor.dtype, "name", None)
                if dtype_name == "bfloat16_t":
                    raw = torch.from_file(
                        output_path,
                        shared=False,
                        size=target_numel,
                        dtype=torch.int16,
                    )
                    out = raw.view(torch.bfloat16).clone()
                elif dtype_name == "float8_e4m3_t":
                    if not hasattr(torch, "float8_e4m3fn"):
                        raise TypeError("torch.float8_e4m3fn is not available in current torch")
                    raw = torch.from_file(
                        output_path,
                        shared=False,
                        size=target_numel,
                        dtype=torch.uint8,
                    )
                    out = raw.view(torch.float8_e4m3fn).clone()  # type: ignore[attr-defined]
                elif dtype_name == "float8_e5m2_t":
                    if not hasattr(torch, "float8_e5m2"):
                        raise TypeError("torch.float8_e5m2 is not available in current torch")
                    raw = torch.from_file(
                        output_path,
                        shared=False,
                        size=target_numel,
                        dtype=torch.uint8,
                    )
                    out = raw.view(torch.float8_e5m2).clone()  # type: ignore[attr-defined]
                else:
                    out = torch.from_file(
                        output_path,
                        shared=False,
                        size=target_numel,
                        dtype=_dtype_to_torch(gm_tensor.dtype),
                    ).clone()
                if len(shape_dims) == 0:
                    return out.view(())
                return out.contiguous().view(*shape_dims)

            def _map_outputs(value: Any) -> Any:
                if isinstance(value, GMTensor):
                    if value in output_gmtensors:
                        return _load_output_from_bin(value)
                    return value
                if isinstance(value, list):
                    return [_map_outputs(item) for item in value]
                if isinstance(value, tuple):
                    return tuple(_map_outputs(item) for item in value)
                if isinstance(value, dict):
                    return {key: _map_outputs(item) for key, item in value.items()}
                return value

            return _map_outputs(kernel_ret)
        else:
            def _clone_gm_tensor_view(gm_tensor: GMTensor) -> "torch.Tensor":
                if gm_tensor.data is None:
                    raise ValueError(
                        f"Simulator output GMTensor {gm_tensor.name} has no data bound"
                    )
                shape_dims = _resolve_shape_dims(gm_tensor)
                target_numel = 1
                for dim in shape_dims:
                    target_numel *= dim
                gm_flat = gm_tensor.data.contiguous().view(-1)
                if int(gm_flat.numel()) < target_numel:
                    raise ValueError(
                        f"{gm_tensor.name} output numel is smaller than shape product: "
                        f"required={target_numel}, actual={int(gm_flat.numel())}"
                    )
                out = gm_flat[:target_numel].detach().clone()
                if len(shape_dims) == 0:
                    return out.view(())
                return out.contiguous().view(*shape_dims)

            def _map_outputs(value: Any) -> Any:
                if isinstance(value, GMTensor):
                    return _clone_gm_tensor_view(value)
                if isinstance(value, list):
                    return [_map_outputs(item) for item in value]
                if isinstance(value, tuple):
                    return tuple(_map_outputs(item) for item in value)
                if isinstance(value, dict):
                    return {key: _map_outputs(item) for key, item in value.items()}
                return value

            return _map_outputs(kernel_ret)
