# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Optional

from ..utils.instruction import Instruction
from ..utils.var import Var
from ..utils.datatype import Datatype, DataTypeValue
from .. import globvars


class atomic_add:
    def __init__(self, cond: Optional[Var] = None, dtype: DataTypeValue = Datatype.float):
        if cond is not None:
            raise NotImplementedError("current frameworkdoes not support conditional atomic_add")
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
        if dtype is not Datatype.float:
            raise NotImplementedError("current framework only supports floatatomictype")
        self.dtype = dtype

    def __enter__(self):
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_add can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_add"))
        globvars.atomic_enabled = True
        globvars.atomic_type = self.dtype

    def __exit__(self, exec_type, exec_val, exec_traceback):
        if exec_type:
            return False
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_add can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_end"))
        globvars.atomic_enabled = False
        globvars.atomic_type = None
        return True


class atomic_max:
    def __init__(self, dtype: DataTypeValue = Datatype.float):
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
        if dtype is not Datatype.float:
            raise NotImplementedError("current framework only supports floatatomictype")
        self.dtype = dtype

    def __enter__(self):
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_max can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_max"))
        globvars.atomic_enabled = True
        globvars.atomic_type = self.dtype

    def __exit__(self, exec_type, exec_val, exec_traceback):
        if exec_type:
            return False
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_max can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_end"))
        globvars.atomic_enabled = False
        globvars.atomic_type = None
        return True


class atomic_min:
    def __init__(self, dtype: DataTypeValue = Datatype.float):
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
        if dtype is not Datatype.float:
            raise NotImplementedError("current framework only supports floatatomictype")
        self.dtype = dtype

    def __enter__(self):
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_min can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_min"))
        globvars.atomic_enabled = True
        globvars.atomic_type = self.dtype

    def __exit__(self, exec_type, exec_val, exec_traceback):
        if exec_type:
            return False
        if globvars.active_kernel is None:
            raise RuntimeError("atomic_min can only be used in kernel context")
        globvars.active_kernel.instructions.append(Instruction("atomic_end"))
        globvars.atomic_enabled = False
        globvars.atomic_type = None
        return True
