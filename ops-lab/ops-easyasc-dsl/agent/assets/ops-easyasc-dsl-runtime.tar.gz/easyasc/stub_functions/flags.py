from typing import Union

from ..utils.pipe import Pipe, PipeType
from ..utils.var import Var
from ..utils.instruction import Instruction
from .. import globvars


def _validate_event_id_range(event_id: Union[int, Var], opname: str) -> None:
    if isinstance(event_id, int):
        if event_id < 0 or event_id > 7:
            raise ValueError(f"{opname} event_id must be in range [0, 7], current value: {event_id}")
        return
    if isinstance(event_id, Var):
        value = getattr(event_id, "value", None)
        if isinstance(value, int) and (value < 0 or value > 7):
            raise ValueError(f"{opname} event_id must be in range [0, 7], current value: {value}")
        return
    raise TypeError(f"event_id must be Var or int type, current type: {type(event_id)}")


def setflag(src: PipeType, dst: PipeType, event_id: Union[int, Var]) -> None:
    if not isinstance(src, PipeType):
        raise TypeError(f"src must be PipeType type, current type: {type(src)}")
    if not isinstance(dst, PipeType):
        raise TypeError(f"dst must be PipeType type, current type: {type(dst)}")
    if src == Pipe.ALL:
        raise ValueError("setflag source pipe cannot be Pipe.ALL")
    if dst == Pipe.ALL:
        raise ValueError("setflag destination pipe cannot be Pipe.ALL")
    if src == Pipe.S:
        raise ValueError("setflag source pipe cannot be Pipe.S")
    _validate_event_id_range(event_id, "setflag")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("setflag", src=src, dst=dst, event_id=event_id)
        )


def waitflag(src: PipeType, dst: PipeType, event_id: Union[int, Var]) -> None:
    if not isinstance(src, PipeType):
        raise TypeError(f"src must be PipeType type, current type: {type(src)}")
    if not isinstance(dst, PipeType):
        raise TypeError(f"dst must be PipeType type, current type: {type(dst)}")
    if src == Pipe.ALL:
        raise ValueError("waitflag source pipe cannot be Pipe.ALL")
    if dst == Pipe.ALL:
        raise ValueError("waitflag destination pipe cannot be Pipe.ALL")
    if src == Pipe.S:
        raise ValueError("waitflag source pipe cannot be Pipe.S")
    _validate_event_id_range(event_id, "waitflag")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("waitflag", src=src, dst=dst, event_id=event_id)
        )
