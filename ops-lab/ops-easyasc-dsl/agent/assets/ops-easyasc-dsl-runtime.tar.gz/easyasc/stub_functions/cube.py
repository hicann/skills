from typing import Union

from ..utils.datatype import DataTypeValue, Datatype
from ..utils.Tensor import Tensor, GMTensor
from ..utils.dualmode import DualMode, DualModeType
from ..utils.var import Var
from ..utils.instruction import Instruction
from ..utils.positions import Position
from .. import globvars


def _validate_var_or_int(value: object, label: str) -> None:
    if not isinstance(value, (Var, int)):
        raise TypeError(f"{label} must be Var or int type, current type: {type(value)}") 


def _validate_tensor_offset_zero(tensor: Tensor, label: str) -> None:
    offset = getattr(tensor, "offset", None)
    if not isinstance(offset, (list, tuple)):
        raise TypeError(f"{label}.offset must be list/tuple, current type: {type(offset)}")
    for value in offset:
        if isinstance(value, Var):
            raise ValueError(f"{label}.offset must be 0, current offset: {offset}")
        if isinstance(value, bool):
            resolved = int(value)
        elif isinstance(value, (int, float)):
            resolved = int(value)
        else:
            raise TypeError(
                f"{label}.offset values must be int/float type, current type: {type(value)}"
            )
        if resolved != 0:
            raise ValueError(f"{label}.offset must be 0, current offset: {offset}")


def _validate_scalar_matches_dtype(value: object, dtype: DataTypeValue) -> None:
    if isinstance(value, bool):
        raise TypeError(f"val must be Var or numeric scalar type, current type: {type(value)}")
    if isinstance(value, Var):
        if not isinstance(value.dtype, DataTypeValue):
            raise TypeError(f"val Var must include dtype, current dtype: {value.dtype}")
        if str(value.dtype) != str(dtype):
            raise TypeError(
                f"val dtype must match tensor dtype, current {value.dtype} and {dtype}"
            )
        return
    dtype_name = str(dtype)
    float_dtypes = {"half", "float", "bfloat16", "bfloat16_t", "float16_t", "float_t"}
    int_dtypes = {
        "int",
        "int8_t",
        "uint8_t",
        "int16_t",
        "uint16_t",
        "uint32_t",
        "uint64_t",
        "int32_t",
        "int64_t",
    }
    if dtype_name in float_dtypes:
        if not isinstance(value, float):
            raise TypeError(
                f"val must be float scalar for tensor dtype {dtype}, current type: {type(value)}"
            )
        return
    if dtype_name in int_dtypes:
        if not isinstance(value, int):
            raise TypeError(
                f"val must be int scalar for tensor dtype {dtype}, current type: {type(value)}"
            )
        return
    raise TypeError(f"set_constant_to_l1 does not support tensor dtype: {dtype}")


def _resolve_dual_mode_value(dual_mode: object) -> int:
    if isinstance(dual_mode, DualModeType):
        value = dual_mode.value
    elif isinstance(dual_mode, bool):
        value = int(dual_mode)
    elif isinstance(dual_mode, int):
        value = dual_mode
    else:
        raise TypeError(f"dual_mode must be DualModeType or int type, current type: {type(dual_mode)}")
    if value not in (DualMode.SINGLE.value, DualMode.SPLITM.value, DualMode.SPLITN.value):
        raise ValueError(f"dual_mode must be 0(SINGLE), 1(SPLITM), or 2(SPLITN), got: {value}")
    return value

def gm_to_l1_nd2nz(
    dst: Tensor,
    src: GMTensor,
    M: Union[int, Var, None]=None,
    N: Union[int, Var, None]=None,
    N_src: Union[int, Var, None]=None,
    M_dst: Union[int, Var, None]=None,
):
    """
    Stub function for GM to L1 copy for 2D tensors with non-zero strides.
    """
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}") 
    if M is None or N is None or N_src is None:
        if not (M is None and N is None and N_src is None):
            raise ValueError("M, N, N_src must all be None")
        slice_mask = getattr(src, "slice_mask", None)
        slice_dims = [idx for idx, flag in enumerate(slice_mask or []) if flag]
        if len(slice_dims) == 2:
            first, second = slice_dims[0], slice_dims[1]
            M = src.span[first]
            N = src.span[second]
            N_src = src.shape[second]
        elif len(slice_dims) == 1:
            dim = slice_dims[0]
            M = 1
            N = src.span[dim]
            N_src = src.shape[dim]
        else:
            raise ValueError("src must include 1 or 2 slicedimensionsto inferM/N/N_src") 
    if M_dst is None:
        M_dst = dst.shape[0]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(N_src, "N_src")
    _validate_var_or_int(M_dst, "M_dst")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gm_to_l1_nd2nz",
                dst=dst,
                src=src,
                M=M,
                N=N,
                N_src=N_src,
                M_dst=M_dst,
            )
        )


def set_constant_to_l1(
    tensor: Tensor,
    val: Union[Var, int, float],
    n_blocks: Union[int, Var, None] = None,
) -> None:
    if not isinstance(tensor, Tensor):
        raise TypeError(f"tensor must be Tensor type, current type: {type(tensor)}")
    if tensor.position is not Position.L1:
        raise ValueError(f"tensor must be at L1 position, current position: {tensor.position}")
    _validate_tensor_offset_zero(tensor, "tensor")
    if not isinstance(val, (Var, int, float)) or isinstance(val, bool):
        raise TypeError(f"val must be Var or numeric scalar type, current type: {type(val)}")
    _validate_scalar_matches_dtype(val, tensor.dtype)
    if n_blocks is None:
        n_blocks = tensor.shape[0] * tensor.shape[1] // tensor.dtype.C0
    _validate_var_or_int(n_blocks, "n_blocks")
    if isinstance(n_blocks, int) and n_blocks < 0:
        raise ValueError(f"n_blocks must be non-negative, current value: {n_blocks}")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "set_constant_to_l1",
                tensor=tensor,
                val=val,
                n_blocks=n_blocks,
            )
        )


def l1_to_l0(dst: Tensor, src: Tensor, m_dst: Union[int, Var, None]=None, n_dst: Union[int, Var, None]=None, m_src: Union[int, Var, None]=None, n_src: Union[int, Var, None]=None):
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position not in (Position.L0A, Position.L0B):
        raise ValueError(f"dst must be at L0A or L0B position, current position: {dst.position}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L1:
        raise ValueError(f"src must be at L1 position, current position: {src.position}") 
    if m_dst is None:
        m_dst = src.span[0] if hasattr(src, "span") else src.shape[0]
    if n_dst is None:
        n_dst = src.span[1] if hasattr(src, "span") else src.shape[1]
    if m_src is None:
        m_src = src.shape[0]
    if n_src is None:
        n_src = src.shape[1]

    _validate_var_or_int(m_dst, "m_dst")
    _validate_var_or_int(n_dst, "n_dst")
    _validate_var_or_int(m_src, "m_src")
    _validate_var_or_int(n_src, "n_src")
    dst.is_transpose = src.is_transpose
    if globvars.device_type.startswith("b"):
        if dst.position is Position.L0A:
            # Canonicalize the left operand during L1->L0A transfer so mmad can
            # always decode L0A with a single logical model on B-series devices.
            dst._sim_layout = "ZZ"
        else:
            dst._sim_layout = "ZN" if src.is_transpose else "NZ"
    else:
        dst._sim_layout = "ZN" if src.is_transpose else "NZ"

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "l1_to_l0",
                dst=dst,
                src=src,
                m_dst=m_dst,
                n_dst=n_dst,
                m_src=m_src,
                n_src=n_src,
            )
        )


def mmad(dst: Tensor, src_a: Tensor, src_b: Tensor, M: Union[int, Var, None]=None, N: Union[int, Var, None]=None, K: Union[int, Var, None]=None, is_init: bool = True):
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.L0C:
        raise ValueError(f"dst must be at L0C position, current position: {dst.position}")
    if not isinstance(src_a, Tensor):
        raise TypeError(f"src_a must be Tensor type, current type: {type(src_a)}")
    if src_a.position is not Position.L0A:
        raise ValueError(f"src_a must be at L0A position, current position: {src_a.position}")
    if not isinstance(src_b, Tensor):
        raise TypeError(f"src_b must be Tensor type, current type: {type(src_b)}")
    if src_b.position is not Position.L0B:
        raise ValueError(f"src_b must be at L0B position, current position: {src_b.position}") 
    if src_a.dtype != src_b.dtype:
        raise ValueError(
            f"mmad requires src_a/src_b data types to match, got: {src_a.dtype} vs {src_b.dtype}"
        )
    if M is None:
        M = src_a.shape[1] if src_a.is_transpose else src_a.shape[0]
    if N is None:
        N = src_b.shape[1] if src_b.is_transpose else src_b.shape[0]
    if K is None:
        K = src_a.shape[0] if src_a.is_transpose else src_a.shape[1]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(K, "K")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "mmad",
                dst=dst,
                src_a=src_a,
                src_b=src_b,
                M=M,
                N=N,
                K=K,
                is_init=is_init,
            )
        )


def l0c_to_gm_nz2nd(
    dst: GMTensor,
    src: Tensor,
    M: Union[int, Var, None] = None,
    N: Union[int, Var, None] = None,
    N_dst: Union[int, Var, None] = None,
    M_src: Union[int, Var, None] = None,
    relu: bool = False,
):
    if not isinstance(dst, GMTensor):
        raise TypeError(f"dst must be GMTensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L0C:
        raise ValueError(f"src must be at L0C position, current position: {src.position}") 
    if not isinstance(relu, bool):
        raise TypeError(f"relu must be bool type, current type: {type(relu)}")
    if M is None or N is None or N_dst is None:
        if not (M is None and N is None and N_dst is None):
            raise ValueError("M, N, N_dst must all be None")
        slice_mask = getattr(dst, "slice_mask", None)
        slice_dims = [idx for idx, flag in enumerate(slice_mask or []) if flag]
        if len(slice_dims) == 2:
            first, second = slice_dims[0], slice_dims[1]
            M = dst.span[first]
            N = dst.span[second]
            N_dst = dst.shape[second]
        elif len(slice_dims) == 1:
            dim = slice_dims[0]
            M = 1
            N = dst.span[dim]
            N_dst = dst.shape[dim]
        else:
            raise ValueError("src must include 1 or 2 slicedimensionsto inferM/N/N_src")
        
    if M_src is None:
        M_src = src.shape[0]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(M_src, "M_src")

    if globvars.active_kernel is not None:
        if globvars.atomic_enabled and globvars.atomic_type is not dst.dtype:
            globvars.active_kernel.instructions.append(
                Instruction("set_atomic_type", dtype=dst.dtype)
            )
            globvars.atomic_type = dst.dtype
        globvars.active_kernel.instructions.append(
            Instruction(
                "l0c_to_gm_nz2nd",
                dst=dst,
                src=src,
                M=M,
                N=N,
                N_dst=N_dst,
                M_src=M_src,
                relu=relu,
            )
        )


def l0c_to_l1(
    dst: Tensor,
    src: Tensor,
    M: Union[int, Var, None] = None,
    N: Union[int, Var, None] = None,
    M_dst: Union[int, Var, None] = None,
    M_src: Union[int, Var, None] = None,
    relu: bool = False,
):
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L0C:
        raise ValueError(f"src must be at L0C position, current position: {src.position}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}") 
    if globvars.device_type.startswith("b") and dst.dtype is Datatype.float:
        raise ValueError(
            "l0c_to_l1 does not support float destination on b* devices, "
            f"current device_type: {globvars.device_type}"
        )
    if M is None:
        M = dst.span[0] if hasattr(dst, "span") else dst.shape[0]
    if N is None:
        N = dst.span[1] if hasattr(dst, "span") else dst.shape[1]
    if M_dst is None:
        M_dst = dst.shape[0]
    if M_src is None:
        M_src = src.shape[0]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(M_dst, "M_dst")
    _validate_var_or_int(M_src, "M_src")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "l0c_to_l1",
                dst=dst,
                src=src,
                M=M,
                N=N,
                M_dst=M_dst,
                M_src=M_src,
                relu=relu,
            )
        )


def l0c_to_ub(
    dst: Tensor,
    src: Tensor,
    M: Union[int, Var, None] = None,
    N: Union[int, Var, None] = None,
    N_dst: Union[int, Var, None] = None,
    M_src: Union[int, Var, None] = None,
    dual_mode: Union[int, DualModeType] = DualMode.SPLITM,
    sub_block_id: Union[int, Var] = 0,
    relu: bool = False,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.L0C:
        raise ValueError(f"src must be at L0C position, current position: {src.position}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")

    mode_value = _resolve_dual_mode_value(dual_mode)
    if not isinstance(sub_block_id, (Var, int)):
        raise TypeError(f"sub_block_id must be Var or int type, current type: {type(sub_block_id)}")
    if isinstance(sub_block_id, int) and sub_block_id not in (0, 1):
        raise ValueError(f"sub_block_id must be 0 or 1, got: {sub_block_id}")
    if not isinstance(relu, bool):
        raise TypeError(f"relu must be bool type, current type: {type(relu)}")

    if M is None or N is None or N_dst is None:
        if not (M is None and N is None and N_dst is None):
            raise ValueError("M, N, N_dst must all be None")
        if mode_value == DualMode.SINGLE.value:
            M = dst.span[0]
            N = dst.span[1]
        elif mode_value == DualMode.SPLITM.value:
            M = dst.span[0] * 2
            N = dst.span[1]
        else:
            M = dst.span[0]
            N = dst.span[1] * 2
        N_dst = dst.shape[1]

    if M_src is None:
        M_src = src.shape[0]

    _validate_var_or_int(M, "M")
    _validate_var_or_int(N, "N")
    _validate_var_or_int(N_dst, "N_dst")
    _validate_var_or_int(M_src, "M_src")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "l0c_to_ub",
                dst=dst,
                src=src,
                M=M,
                N=N,
                N_dst=N_dst,
                M_src=M_src,
                dual_mode=mode_value,
                sub_block_id=sub_block_id,
                relu=relu,
            )
        )
