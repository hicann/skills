# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from ..utils.instruction import Instruction
from ..utils.pipe import PipeType, Pipe
from .. import globvars


def barrier(pipe: PipeType) -> None:
    if not isinstance(pipe, PipeType):
        raise TypeError(f"pipe must be PipeType type, current type: {type(pipe)}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("barrier", pipe=pipe)
        )


def bar_m() -> None:
    barrier(Pipe.M)


def bar_v() -> None:
    barrier(Pipe.V)


def bar_mte3() -> None:
    barrier(Pipe.MTE3)


def bar_mte2() -> None:
    barrier(Pipe.MTE2)


def bar_mte1() -> None:
    barrier(Pipe.MTE1)


def bar_fix() -> None:
    barrier(Pipe.FIX)


def bar_all() -> None:
    barrier(Pipe.ALL)
