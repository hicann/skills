# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from ...utils.reg import Reg, MaskReg
from ...utils.instruction import Instruction
from ...utils.castconfig import CastConfig
from .microutils import require_micro, ensure_mask
from typing import Optional


def cast(dst: Reg, src: Reg, config: Optional[CastConfig] = None, mask: Optional[MaskReg] = None) -> None:
    micro = require_micro()
    mask = ensure_mask(mask, dst.dtype, micro)
    if config is None:
        config = micro.get_default_cast_cfg(dst.dtype)
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if not isinstance(config, CastConfig):
        raise TypeError(f"config must be CastConfig type, current type: {type(config)}")
    if not isinstance(mask, MaskReg):
        raise TypeError(f"mask must be MaskReg type, current type: {type(mask)}")
    if config.name == "":
        raise ValueError("cast config must set name")

    micro.instructions.append(
        Instruction(
            "micro_cast",
            dst=dst,
            src=src,
            config=config,
            mask=mask,
            ddst=dst.dtype,
            dsrc=src.dtype,
        )
    )
