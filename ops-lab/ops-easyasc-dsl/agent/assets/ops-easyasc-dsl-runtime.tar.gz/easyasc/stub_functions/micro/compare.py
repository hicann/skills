# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Optional, Union

from ...utils.comparemode import CompareModeType
from ...utils.reg import Reg, MaskReg
from ...utils.var import Var
from ...utils.instruction import Instruction
from .microutils import (
    dtype_scalar_family,
    ensure_mask,
    format_scalar,
    require_micro,
    scalar_value_family,
)


def compare(
    dst: MaskReg,
    src1: Reg,
    src2: Union[Var, int, float, Reg],
    mode: CompareModeType,
    mask: Optional[MaskReg] = None,
) -> None:
    micro = require_micro()
    if not isinstance(dst, MaskReg):
        raise TypeError(f"dst must be MaskReg type, current type: {type(dst)}")
    if not isinstance(src1, Reg):
        raise TypeError(f"src1 must be Reg type, current type: {type(src1)}")
    if not isinstance(src2, (Var, int, float, Reg)):
        raise TypeError(f"src2 must be Reg or numeric value/Var type, current type: {type(src2)}")
    if not isinstance(mode, CompareModeType):
        raise TypeError(f"mode must be CompareModeType type, current type: {type(mode)}")
    if dst.dtype != src1.dtype:
        raise ValueError("dst/src1 data types must match") 
    mask = ensure_mask(mask, dst.dtype, micro)

    if isinstance(src2, Reg):
        if src1.dtype != src2.dtype:
            raise ValueError("src1/src2 data types must match")
        micro.instructions.append(
            Instruction(
                "micro_compare",
                dst=dst,
                src1=src1,
                src2=src2,
                dtype=dst.dtype,
                mode=mode,
                mask=mask,
            )
        )
    else:
        src1_family = dtype_scalar_family(src1.dtype)
        if src1_family is None:
            raise TypeError(
                "compare scalar only supports float/int register families, "
                f"current dtype: {src1.dtype}"
            )
        src2_family = scalar_value_family(src2)
        if src2_family != src1_family:
            raise TypeError(
                "compare scalar requires matching float/int families, "
                f"src1 dtype: {src1.dtype}, scalar: {src2!r}"
            )
        v = format_scalar(src2, src1.dtype)
        micro.instructions.append(
            Instruction(
                "micro_compares",
                dst=dst,
                src1=src1,
                src2=v,
                dtype=dst.dtype,
                mode=mode,
                mask=mask,
            )
        )


def select(dst: Reg, src1: Reg, src2: Reg, mask: Optional[MaskReg] = None) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src1, Reg):
        raise TypeError(f"src1 must be Reg type, current type: {type(src1)}")
    if not isinstance(src2, Reg):
        raise TypeError(f"src2 must be Reg type, current type: {type(src2)}")
    if src1.dtype != src2.dtype or dst.dtype != src1.dtype:
        raise ValueError("dst/src1/src2 data types must match") 
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(
        Instruction("micro_select", dst=dst, src1=src1, src2=src2, mask=mask)
    )
