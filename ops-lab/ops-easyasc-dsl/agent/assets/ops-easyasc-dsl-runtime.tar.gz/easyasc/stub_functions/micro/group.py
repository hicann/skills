# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Optional

from ...utils.reg import Reg, MaskReg
from ...utils.instruction import Instruction
from .microutils import ensure_mask, require_micro


def _group_op(opname: str, dst: Reg, src: Reg, mask: Optional[MaskReg]) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(Instruction(opname, dst=dst, src=src, mask=mask))


def cmax(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _group_op("micro_vcmax", dst, src, mask)


def cgmax(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _group_op("micro_vcgmax", dst, src, mask)


def cmin(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _group_op("micro_vcmin", dst, src, mask)


def cgmin(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _group_op("micro_vcgmin", dst, src, mask)


def cadd(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _group_op("micro_vcadd", dst, src, mask)


def cgadd(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _group_op("micro_vcgadd", dst, src, mask)


def cpadd(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _group_op("micro_vcpadd", dst, src, mask)
