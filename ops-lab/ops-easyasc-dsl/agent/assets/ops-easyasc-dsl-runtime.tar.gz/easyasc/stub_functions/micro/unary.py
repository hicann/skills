# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Optional

from ...utils.reg import Reg, MaskReg
from ...utils.instruction import Instruction
from .microutils import ensure_mask, require_micro


def _unary_op(opname: str, dst: Reg, src: Reg, mask: Optional[MaskReg]) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    mask = ensure_mask(mask, dst.dtype, micro)
    micro.instructions.append(Instruction(opname, dst=dst, src=src, mask=mask))


def exp(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vexp", dst, src, mask)


def abs(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vabs", dst, src, mask)


def relu(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vrelu", dst, src, mask)


def sqrt(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vsqrt", dst, src, mask)


def ln(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vln", dst, src, mask)


def log(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vlog", dst, src, mask)


def log2(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vlog2", dst, src, mask)


def log10(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vlog10", dst, src, mask)


def neg(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vneg", dst, src, mask)


def vnot(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vnot", dst, src, mask)


def vcopy(dst: Reg, src: Reg, mask: Optional[MaskReg] = None) -> None:
    _unary_op("micro_vcopy", dst, src, mask)
