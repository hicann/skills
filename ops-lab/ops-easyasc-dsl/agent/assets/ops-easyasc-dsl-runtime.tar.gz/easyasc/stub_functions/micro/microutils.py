# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Optional, Union

from ... import globvars
from ...utils.datatype import DataTypeValue, Datatype
from ...utils.reg import MaskReg
from ...utils.var import Var


def require_micro():
    micro = globvars.active_micro
    if micro is None:
        raise RuntimeError("micro function can only be used in MicroModule")
    return micro


def ensure_mask(mask: Optional[MaskReg], dtype: DataTypeValue, micro) -> MaskReg:
    if mask is None:
        mask = micro.get_mask(dtype)
    if not isinstance(mask, MaskReg):
        raise TypeError(f"mask must be MaskReg type, current type: {type(mask)}")
    return mask


def dtype_scalar_family(dtype: DataTypeValue) -> Optional[str]:
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
    if dtype in (Datatype.float, Datatype.half, Datatype.bfloat16):
        return "float"
    if dtype in (
        Datatype.int,
        Datatype.int8,
        Datatype.uint8,
        Datatype.int16,
        Datatype.uint16,
        Datatype.uint32,
        Datatype.uint64,
        Datatype.int64,
    ):
        return "int"
    return None


def scalar_value_family(value: Union[Var, int, float]) -> Optional[str]:
    if isinstance(value, Var):
        if value.dtype is None:
            raise TypeError("Var scalar must have dtype inside vf scalar helpers")
        return dtype_scalar_family(value.dtype)
    if isinstance(value, bool):
        return "int"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "float"
    raise TypeError(f"value must be Var or numeric value type, current type: {type(value)}")


def format_scalar(value: Union[Var, int, float], dtype: DataTypeValue) -> Union[Var, str]:
    target_family = dtype_scalar_family(dtype)
    if target_family is None:
        raise TypeError(
            "vf scalar helpers only support float/int scalar families, "
            f"current dtype: {dtype}"
        )

    value_family = scalar_value_family(value)
    if target_family == "float" and value_family == "int":
        raise TypeError(
            "vf scalar helpers do not support implicit int-to-float conversion, "
            f"target dtype: {dtype}, value: {value!r}"
        )

    if isinstance(value, Var):
        return value
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
    dtype_name = getattr(dtype, "name", None)
    if dtype_name == "float":
        return f"{float(value)}f"
    if dtype_name == "half":
        return f"(half){float(value)}f"
    if dtype_name == "bfloat16_t":
        return f"(bfloat16_t){float(value)}f"
    if isinstance(value, float):
        value = int(value)
    return f"{int(value)}"


def dtype_size(dtype: DataTypeValue) -> int:
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"dtype must be DataTypeValue type, current type: {type(dtype)}")
    return dtype.size
