# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Optional, Union

from ...utils.reg import Reg, MaskReg
from ...utils.var import Var
from ...utils.instruction import Instruction
from .microutils import ensure_mask, format_scalar, require_micro


def _unary_scalar_op(
    opname: str,
    dst: Reg,
    src: Reg,
    value: Union[Var, int, float],
    mask: Optional[MaskReg],
) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if not isinstance(src, Reg):
        raise TypeError(f"src must be Reg type, current type: {type(src)}")
    if not isinstance(value, (Var, int, float)):
        raise TypeError(f"value must be Var or numeric value type, current type: {type(value)}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    mask = ensure_mask(mask, dst.dtype, micro)
    v = format_scalar(value, src.dtype)
    micro.instructions.append(Instruction(opname, dst=dst, src=src, v=v, mask=mask))


def vmaxs(dst: Reg, src: Reg, value: Union[Var, int, float], mask: Optional[MaskReg] = None) -> None:
    _unary_scalar_op("micro_vmaxs", dst, src, value, mask)


def vmins(dst: Reg, src: Reg, value: Union[Var, int, float], mask: Optional[MaskReg] = None) -> None:
    _unary_scalar_op("micro_vmins", dst, src, value, mask)


def adds(dst: Reg, src: Reg, value: Union[Var, int, float], mask: Optional[MaskReg] = None) -> None:
    _unary_scalar_op("micro_vadds", dst, src, value, mask)


def muls(dst: Reg, src: Reg, value: Union[Var, int, float], mask: Optional[MaskReg] = None) -> None:
    _unary_scalar_op("micro_vmuls", dst, src, value, mask)


def lrelu(dst: Reg, src: Reg, value: Union[Var, int, float], mask: Optional[MaskReg] = None) -> None:
    _unary_scalar_op("micro_vlrelu", dst, src, value, mask)


def shiftls(dst: Reg, src: Reg, value: Union[Var, int], mask: Optional[MaskReg] = None) -> None:
    if not isinstance(value, (Var, int)):
        raise TypeError(f"value must be Var or int type, current type: {type(value)}")
    _unary_scalar_op("micro_shiftls", dst, src, value, mask)


def shiftrs(dst: Reg, src: Reg, value: Union[Var, int], mask: Optional[MaskReg] = None) -> None:
    if not isinstance(value, (Var, int)):
        raise TypeError(f"value must be Var or int type, current type: {type(value)}")
    _unary_scalar_op("micro_shiftrs", dst, src, value, mask)


def axpy(dst: Reg, src: Reg, value: Union[Var, int, float], mask: Optional[MaskReg] = None) -> None:
    _unary_scalar_op("micro_vaxpy", dst, src, value, mask)
