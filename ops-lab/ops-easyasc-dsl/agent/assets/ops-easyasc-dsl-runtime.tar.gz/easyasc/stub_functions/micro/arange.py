# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Union

from ...utils.datatype import Datatype as DT
from ...utils.reg import Reg
from ...utils.var import Var
from ...utils.instruction import Instruction
from .microutils import format_scalar, require_micro


def arange(dst: Reg, start: Union[Var, int, float], increase: bool = True) -> None:
    micro = require_micro()
    if not isinstance(dst, Reg):
        raise TypeError(f"dst must be Reg type, current type: {type(dst)}")
    if dst.dtype not in (DT.int8, DT.int16, DT.int, DT.half, DT.float):
        raise TypeError(
            "arange only supports dst dtype int8/int16/int32(=int)/half/float, "
            f"current dtype: {dst.dtype}"
        )
    if not isinstance(start, (Var, int, float)):
        raise TypeError(f"start must be Var or numeric value type, current type: {type(start)}")
    if not isinstance(increase, bool):
        raise TypeError(f"increase must be booltype, current type: {type(increase)}") 
    mode = "MicroAPI::IndexOrder::INCREASE_ORDER" if increase else "MicroAPI::IndexOrder::DECREASE_ORDER"
    v = format_scalar(start, dst.dtype)
    micro.instructions.append(
        Instruction("micro_arange", dst=dst, v=v, dtype=dst.dtype, mode=mode)
    )
