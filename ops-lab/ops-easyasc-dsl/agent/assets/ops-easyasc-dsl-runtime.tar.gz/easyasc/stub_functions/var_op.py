# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Optional, Union
import math

from ..utils.var import Var
from ..utils.datatype import Datatype
from ..utils.instruction import Instruction
from .. import globvars


def _value_of(value: Union[Var, int, float]) -> Optional[Union[int, float]]:
    if isinstance(value, Var):
        if isinstance(value.value, (int, float)):
            return value.value
        return None
    if isinstance(value, (int, float)):
        return value
    return None


def _append_instruction(inst: Instruction) -> None:
    target = globvars.active_micro if globvars.active_micro is not None else globvars.active_kernel
    if target is not None:
        target.instructions.append(inst)


def CeilDiv(a: Union[Var, int], b: Union[Var, int], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(b, (Var, int)):
        raise TypeError(f"b must be Var or int type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    out = Var(name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None and b_val != 0:
        out.value = (a_val + b_val - 1) // b_val
    _append_instruction(Instruction("CeilDiv", a=a, b=b, out=out))
    return out


def GetCubeNum(*, name: str = "") -> Var:
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    out = Var(name=name)
    _append_instruction(Instruction("GetCubeNum", out=out))
    return out


def GetCubeIdx(*, name: str = "") -> Var:
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    out = Var(name=name)
    _append_instruction(Instruction("GetCubeIdx", out=out))
    return out


def GetVecNum(*, name: str = "") -> Var:
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    out = Var(dtype=Datatype.int, name=name)
    _append_instruction(Instruction("GetVecNum", out=out))
    return out


def GetVecIdx(*, name: str = "") -> Var:
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    out = Var(dtype=Datatype.int, name=name)
    _append_instruction(Instruction("GetVecIdx", out=out))
    return out


def GetSubBlockIdx(*, name: str = "") -> Var:
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    out = Var(dtype=Datatype.int, name=name)
    _append_instruction(Instruction("GetSubBlockIdx", out=out))
    return out


def scalar_sqrt(a: Union[Var, float], *, name: str = "") -> Var:
    if not isinstance(a, (Var, float)):
        raise TypeError(f"a must be Var or float type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.float:
        raise TypeError("scalar_sqrt only supports float Var")
    out = Var(dtype=Datatype.float, name=name)
    a_val = _value_of(a)
    if isinstance(a_val, (int, float)):
        out.value = math.sqrt(a_val)
    _append_instruction(Instruction("scalar_sqrt", a=a, out=out))
    return out


def _align_value(a: Union[Var, int], align: int) -> Optional[int]:
    a_val = _value_of(a)
    if isinstance(a_val, (int, float)):
        return (int(a_val) + align - 1) // align * align
    return None


def Align8(a: Union[Var, int], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align8 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 8)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align8", a=a, out=out))
    return out


def Align16(a: Union[Var, int], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align16 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 16)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align16", a=a, out=out))
    return out


def Align32(a: Union[Var, int], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align32 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 32)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align32", a=a, out=out))
    return out


def Align64(a: Union[Var, int], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align64 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 64)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align64", a=a, out=out))
    return out


def Align128(a: Union[Var, int], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align128 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 128)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align128", a=a, out=out))
    return out


def Align256(a: Union[Var, int], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError("Align256 only supports int Var")
    out = Var(dtype=Datatype.int, name=name)
    aligned = _align_value(a, 256)
    if aligned is not None:
        out.value = aligned
    _append_instruction(Instruction("Align256", a=a, out=out))
    return out


def var_mul(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    dtype = None
    if isinstance(a, float) or isinstance(b, float):
        dtype = Datatype.float
    elif isinstance(a, Var) and a.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(b, Var) and b.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(a, int) or isinstance(b, int):
        dtype = Datatype.int
    elif isinstance(a, Var) and a.dtype is Datatype.int:
        dtype = Datatype.int
    elif isinstance(b, Var) and b.dtype is Datatype.int:
        dtype = Datatype.int

    out = Var(dtype=dtype, name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None:
        out.value = a_val * b_val
    _append_instruction(Instruction("var_mul", a=a, b=b, out=out))
    return out


def var_add(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    dtype = None
    if isinstance(a, float) or isinstance(b, float):
        dtype = Datatype.float
    elif isinstance(a, Var) and a.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(b, Var) and b.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(a, int) or isinstance(b, int):
        dtype = Datatype.int
    elif isinstance(a, Var) and a.dtype is Datatype.int:
        dtype = Datatype.int
    elif isinstance(b, Var) and b.dtype is Datatype.int:
        dtype = Datatype.int

    out = Var(dtype=dtype, name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None:
        out.value = a_val + b_val
    _append_instruction(Instruction("var_add", a=a, b=b, out=out))
    return out


def var_sub(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    dtype = None
    if isinstance(a, float) or isinstance(b, float):
        dtype = Datatype.float
    elif isinstance(a, Var) and a.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(b, Var) and b.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(a, int) or isinstance(b, int):
        dtype = Datatype.int
    elif isinstance(a, Var) and a.dtype is Datatype.int:
        dtype = Datatype.int
    elif isinstance(b, Var) and b.dtype is Datatype.int:
        dtype = Datatype.int

    out = Var(dtype=dtype, name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None:
        out.value = a_val - b_val
    _append_instruction(Instruction("var_sub", a=a, b=b, out=out))
    return out


def var_div(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    def _dtype_of(value, label: str):
        if isinstance(value, Var):
            if value.dtype is None:
                raise TypeError(f"{label}dtype is None, cannot infer")
            return value.dtype
        if isinstance(value, float):
            return Datatype.float
        if isinstance(value, int):
            return Datatype.int
        raise TypeError(f"{label} must be Var or numeric value type, current type: {type(value)}")
    dtype_a = _dtype_of(a, "a")
    dtype_b = _dtype_of(b, "b")
    if dtype_a is not dtype_b:
        raise TypeError(f"a and b data types must match, current {dtype_a} and {dtype_b}") 
    out = Var(dtype=dtype_a, name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None and b_val != 0:
        if dtype_a is Datatype.int:
            out.value = a_val // b_val
        else:
            out.value = a_val / b_val
    _append_instruction(Instruction("var_div", a=a, b=b, out=out))
    return out


def var_mod(a: Union[Var, int], b: Union[Var, int], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int)):
        raise TypeError(f"a must be Var or int type, current type: {type(a)}")
    if not isinstance(b, (Var, int)):
        raise TypeError(f"b must be Var or int type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}")
    if isinstance(a, Var) and a.dtype is not Datatype.int:
        raise TypeError(f"a data type must be int for var_mod, current: {a.dtype}")
    if isinstance(b, Var) and b.dtype is not Datatype.int:
        raise TypeError(f"b data type must be int for var_mod, current: {b.dtype}")

    out = Var(dtype=Datatype.int, name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if isinstance(a_val, (int, float)) and isinstance(b_val, (int, float)):
        if int(b_val) == 0:
            raise ZeroDivisionError("var_mod divide by zero")
        out.value = int(a_val) % int(b_val)
    _append_instruction(Instruction("var_mod", a=a, b=b, out=out))
    return out


def Min(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    dtype = None
    if isinstance(a, float) or isinstance(b, float):
        dtype = Datatype.float
    elif isinstance(a, Var) and a.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(b, Var) and b.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(a, int) or isinstance(b, int):
        dtype = Datatype.int
    elif isinstance(a, Var) and a.dtype is Datatype.int:
        dtype = Datatype.int
    elif isinstance(b, Var) and b.dtype is Datatype.int:
        dtype = Datatype.int

    out = Var(dtype=dtype, name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None:
        out.value = min(a_val, b_val)
    _append_instruction(Instruction("Min", a=a, b=b, out=out))
    return out


def Max(a: Union[Var, int, float], b: Union[Var, int, float], *, name: str = "") -> Var:
    if not isinstance(a, (Var, int, float)):
        raise TypeError(f"a must be Var or numeric value type, current type: {type(a)}")
    if not isinstance(b, (Var, int, float)):
        raise TypeError(f"b must be Var or numeric value type, current type: {type(b)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    dtype = None
    if isinstance(a, float) or isinstance(b, float):
        dtype = Datatype.float
    elif isinstance(a, Var) and a.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(b, Var) and b.dtype is Datatype.float:
        dtype = Datatype.float
    elif isinstance(a, int) or isinstance(b, int):
        dtype = Datatype.int
    elif isinstance(a, Var) and a.dtype is Datatype.int:
        dtype = Datatype.int
    elif isinstance(b, Var) and b.dtype is Datatype.int:
        dtype = Datatype.int

    out = Var(dtype=dtype, name=name)
    a_val = _value_of(a)
    b_val = _value_of(b)
    if a_val is not None and b_val is not None:
        out.value = max(a_val, b_val)
    _append_instruction(Instruction("Max", a=a, b=b, out=out))
    return out
