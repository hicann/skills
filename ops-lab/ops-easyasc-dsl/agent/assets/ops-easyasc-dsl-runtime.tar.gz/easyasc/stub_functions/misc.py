# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Any, Union

from ..utils.Tensor import Tensor, GMTensor
from ..utils.var import Var
from ..utils.datatype import DataTypeValue, Datatype
from ..utils.instruction import Instruction
from ..utils.pipe import Pipe, PipeType
from ..utils.positions import Position
from ..utils.cacheline import DcciDst, DcciDstType, EntireType, EntireTypeValue
from .. import globvars
from .var_op import var_mul, var_div


def _scale_dim(value: Union[int, Var], num: int, den: int, label: str) -> Union[int, Var]:
    if isinstance(value, Var):
        if value.dtype is not None and value.dtype is not Datatype.int:
            raise TypeError(f"{label} must be DT.int Var, current type: {value.dtype}")
        if num == den:
            return value
        if num % den == 0:
            factor = num // den
            if factor == 1:
                return value
            return var_mul(value, factor)
        if den % num == 0:
            factor = den // num
            return var_div(value, factor)
        return var_div(var_mul(value, num), den)
    if isinstance(value, int):
        if num == den:
            return value
        return (value * num) // den
    raise TypeError(f"{label} must be int or Var type, current type: {type(value)}")

def reinterpret(src: Tensor, target_dtype: DataTypeValue, name: str = "") -> Tensor:
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if not isinstance(target_dtype, DataTypeValue):
        raise TypeError(f"target_dtype must be DataTypeValue type, current type: {type(target_dtype)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str type, current type: {type(name)}") 
    if src.position is Position.L0C:
        raise ValueError("reinterpret does not support L0C position")
    src_c0 = src.dtype.C0
    dst_c0 = target_dtype.C0

    shape = list(src.shape)
    span = list(src.span)
    shape1 = shape[1]
    span1 = span[1]
    if not isinstance(shape1, (int, Var)):
        raise TypeError(f"shape[1] must be int or Var type, current type: {type(shape1)}")
    if not isinstance(span1, (int, Var)):
        raise TypeError(f"span[1] must be int or Var type, current type: {type(span1)}") 
    shape[1] = _scale_dim(shape1, dst_c0, src_c0, "shape[1]")
    span[1] = _scale_dim(span1, dst_c0, src_c0, "span[1]")

    idx = globvars.tmp_idx
    globvars.tmp_idx += 1
    if name == "":
        name = f"_tmp_tensor_{idx}"
    else:
        kernel = globvars.active_kernel
        if kernel is not None:
            counts = getattr(kernel, "_reinterpret_name_counts", None)
            if counts is None:
                counts = {}
                kernel._reinterpret_name_counts = counts
            base = name
            seen = counts.get(base, 0)
            if seen > 0:
                name = f"{base}_{seen}"
            counts[base] = seen + 1

    out = object.__new__(Tensor)
    out.dtype = target_dtype
    out.shape = shape
    out.name = name
    out.position = src.position
    out.idx = idx
    out.offset = list(src.offset)
    out.span = span
    out.step = list(src.step)
    out.source_buf = src.source_buf
    out.source_index = src.source_index
    out.is_transpose = src.is_transpose
    out._is_nz = src._is_nz
    out._is_relu = getattr(src, "_is_relu", False)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "reinterpret",
                dst=out,
                src=src,
                dst_shape=list(out.shape),
                dst_span=list(out.span),
            )
        )
    return out


def _shape_numel(shape: Union[list, tuple]) -> Union[int, Var]:
    numel: Union[int, Var] = 1
    for dim in shape:
        if not isinstance(dim, (int, Var)):
            raise TypeError(f"shape element must be int or Var, got: {type(dim)}")
        if isinstance(dim, int) and dim == 1:
            continue
        if isinstance(numel, int) and numel == 1:
            numel = dim
            continue
        if isinstance(numel, int) and isinstance(dim, int):
            numel *= dim
        else:
            numel = var_mul(numel, dim)
    return numel


def reshape_gm_tensor(src: GMTensor, shape: Union[list, tuple], name: str = "") -> GMTensor:
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}")
    if not isinstance(shape, (list, tuple)):
        raise TypeError(f"shape must be list or tuple, got: {type(shape)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str, got: {type(name)}")
    if len(shape) == 0:
        raise ValueError("shape must have at least 1 dimension")
    for dim in shape:
        if not isinstance(dim, (int, Var)):
            raise TypeError(f"shape element must be int or Var, got: {type(dim)}")
    if not src.is_plain_view():
        raise ValueError("GMTensor.reshape only supports plain_view GMTensor")

    src_numel = _shape_numel(src.shape)
    dst_numel = _shape_numel(shape)
    if isinstance(src_numel, int) and isinstance(dst_numel, int) and src_numel != dst_numel:
        raise ValueError(
            f"GMTensor.reshape requires same numel, got src_numel={src_numel}, dst_numel={dst_numel}"
        )

    idx = globvars.tmp_idx
    globvars.tmp_idx += 1
    if name == "":
        name = f"_tmp_gmtensor_{idx}"

    out = object.__new__(GMTensor)
    out.dtype = src.dtype
    out.shape = list(shape)
    out.name = name
    out.idx = idx
    out.offset = [0 for _ in shape]
    out.span = list(shape)
    out.step = [1 for _ in shape]
    out.slice_mask = [False for _ in shape]
    out._mutex = getattr(src, "_mutex", None)
    out.data = getattr(src, "data", None)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "reshape_gm_tensor",
                src=src,
                out=out,
                dst_shape=list(out.shape),
            )
        )
    return out


def split_workspace(dtype: DataTypeValue, shape: Union[list, tuple], name: str = "") -> GMTensor:
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
    if not isinstance(shape, (list, tuple)):
        raise TypeError(f"shape must be list or tuple, got: {type(shape)}")
    if not isinstance(name, str):
        raise TypeError(f"name must be str, got: {type(name)}") 
    numel = _shape_numel(shape)
    idx = globvars.tmp_idx
    globvars.tmp_idx += 1
    if name == "":
        name = f"_tmp_gmtensor_{idx}"

    out = object.__new__(GMTensor)
    out.dtype = dtype
    out.shape = shape
    out.name = name
    out.idx = idx
    out.offset = [0 for _ in shape]
    out.span = list(shape)
    out.step = [1 for _ in shape]
    out.slice_mask = [False for _ in shape]
    out._mutex = None
    out.data = None

    if globvars.active_kernel is not None:
        globvars.active_kernel.workspace_shapes.append({"shape": list(shape), "dtype": dtype})
        globvars.active_kernel.instructions.append(
            Instruction("split_workspace", val=out, dtype=dtype, numel=numel, name=name)
        )
    return out


def reset_cache() -> None:
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("reset_cache")
        )


def clean_dcache(
    dst: GMTensor,
    entire_type: EntireTypeValue = EntireType.single,
    dcci_dst: DcciDstType = DcciDst.all,
    mode: str = "all",
) -> None:
    if not isinstance(dst, GMTensor):
        raise TypeError(f"dst must be GMTensor type, current type: {type(dst)}")
    if not isinstance(entire_type, EntireTypeValue):
        raise TypeError(
            f"entire_type must be EntireTypeValue type, current type: {type(entire_type)}"
        )
    if not isinstance(dcci_dst, DcciDstType):
        raise TypeError(f"dcci_dst must be DcciDstType type, current type: {type(dcci_dst)}")
    if not isinstance(mode, str):
        raise TypeError(f"mode must be str type, current type: {type(mode)}")
    if mode not in ("all", "vec", "cube"):
        raise ValueError(f"mode must be one of ('all', 'vec', 'cube'), current value: {mode}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "clean_dcache",
                dst=dst,
                entire_type=entire_type,
                dcci_dst=dcci_dst,
                mode=mode,
            )
        )


def sim_print(*args: Any, pipe: PipeType = Pipe.S) -> None:
    if not isinstance(pipe, PipeType):
        raise TypeError(f"pipe must be PipeType type, current type: {type(pipe)}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("sim_print", payload=list(args), pipe=pipe)
        )


def kernel_print(fmt: str, *args: Any) -> None:
    if not isinstance(fmt, str):
        raise TypeError(f"fmt must be str type, current type: {type(fmt)}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("kernel_print", fmt=fmt, payload=list(args))
        )


def sim_dump_tensor(tensor: Tensor, filename: str, pipe: PipeType) -> None:
    if not isinstance(tensor, Tensor):
        raise TypeError(f"tensor must be Tensor type, current type: {type(tensor)}")
    if not isinstance(filename, str):
        raise TypeError(f"filename must be str type, current type: {type(filename)}")
    if not isinstance(pipe, PipeType):
        raise TypeError(f"pipe must be PipeType type, current type: {type(pipe)}")
    if pipe == Pipe.ALL:
        raise ValueError("pipe cannot be Pipe.ALL")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("sim_dump_tensor", tensor=tensor, filename=filename, pipe=pipe)
        )


def kernel_dump_tensor(src: Union[GMTensor, Tensor], desc: Union[int, Var], dumpSize: Union[int, Var]) -> None:
    if not isinstance(src, (GMTensor, Tensor)):
        raise TypeError(f"src must be GMTensor or Tensor type, current type: {type(src)}")
    if isinstance(src, Tensor) and src.position not in (Position.UB, Position.L1, Position.L0C):
        raise ValueError(
            f"kernel_dump_tensor Tensor src only supports UB/L1/L0C, current position: {src.position}"
        )
    if not isinstance(desc, (int, Var)):
        raise TypeError(f"desc must be int or Var type, current type: {type(desc)}")
    if not isinstance(dumpSize, (int, Var)):
        raise TypeError(f"dumpSize must be int or Var type, current type: {type(dumpSize)}")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("kernel_dump_tensor", src=src, desc=desc, dumpSize=dumpSize)
        )


def inline(code: str) -> None:
    if not isinstance(code, str):
        raise TypeError(f"code must be str type, current type: {type(code)}")
    if globvars.active_micro is not None:
        raise ValueError("inline is not supported in vf context")
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("inline", code=code)
        )
