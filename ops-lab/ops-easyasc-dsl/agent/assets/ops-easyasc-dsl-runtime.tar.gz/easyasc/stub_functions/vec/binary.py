# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Union, Tuple

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ... import globvars
from .vecutils import infer_repeat, resolve_strides, validate_var_or_int, apply_vector_mode_transition


def _validate_binary_tensors(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    allowed_dtypes: Tuple,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src1, Tensor):
        raise TypeError(f"src1 must be Tensor type, current type: {type(src1)}")
    if not isinstance(src2, Tensor):
        raise TypeError(f"src2 must be Tensor type, current type: {type(src2)}") 
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src1.position is not Position.UB:
        raise ValueError(f"src1 must be at UB position, current position: {src1.position}")
    if src2.position is not Position.UB:
        raise ValueError(f"src2 must be at UB position, current position: {src2.position}") 
    if dst.dtype != src1.dtype or dst.dtype != src2.dtype:
        raise ValueError("dst/src1/src2 data types must match")
    if dst.dtype not in allowed_dtypes:
        raise ValueError(f"does not support data type: {dst.dtype}") 

def _emit_binary_inst(
    opname: str,
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var],
    dst_blk_stride: Union[int, Var],
    src1_blk_stride: Union[int, Var],
    src2_blk_stride: Union[int, Var],
    dst_rep_stride: Union[int, Var],
    src1_rep_stride: Union[int, Var],
    src2_rep_stride: Union[int, Var],
) -> None:
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                opname,
                dst=dst,
                src1=src1,
                src2=src2,
                repeat=repeat,
                dst_blk_stride=dst_blk_stride,
                src1_blk_stride=src1_blk_stride,
                src2_blk_stride=src2_blk_stride,
                dst_rep_stride=dst_rep_stride,
                src1_rep_stride=src1_rep_stride,
                src2_rep_stride=src2_rep_stride,
            )
        )


def add(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half, Datatype.int))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    _emit_binary_inst(
        "add",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def sub(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half, Datatype.int))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    _emit_binary_inst(
        "sub",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def mul(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half, Datatype.int))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    _emit_binary_inst(
        "mul",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def div(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    _emit_binary_inst(
        "div",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def vmax(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half, Datatype.int))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    _emit_binary_inst(
        "vmax",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def vmin(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half, Datatype.int))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    _emit_binary_inst(
        "vmin",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def vand(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    _validate_binary_tensors(dst, src1, src2, (Datatype.int16, Datatype.uint16))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    _emit_binary_inst(
        "vand",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def vor(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    _validate_binary_tensors(dst, src1, src2, (Datatype.int,))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    _emit_binary_inst(
        "vor",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )


def muladddst(
    dst: Tensor,
    src1: Tensor,
    src2: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src1_blk_stride: Union[int, Var, None] = None,
    src2_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src1_rep_stride: Union[int, Var, None] = None,
    src2_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    _validate_binary_tensors(dst, src1, src2, (Datatype.float, Datatype.half, Datatype.int))

    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)
    src1_blk_stride, src1_rep_stride = resolve_strides(src1, src1_blk_stride, src1_rep_stride)
    src2_blk_stride, src2_rep_stride = resolve_strides(src2, src2_blk_stride, src2_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src1_blk_stride, "src1_blk_stride")
    validate_var_or_int(src2_blk_stride, "src2_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src1_rep_stride, "src1_rep_stride")
    validate_var_or_int(src2_rep_stride, "src2_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    _emit_binary_inst(
        "muladddst",
        dst,
        src1,
        src2,
        repeat,
        dst_blk_stride,
        src1_blk_stride,
        src2_blk_stride,
        dst_rep_stride,
        src1_rep_stride,
        src2_rep_stride,
    )
