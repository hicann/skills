# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import List, Tuple, Union

from ...utils.Tensor import Tensor, GMTensor
from ...utils.var import Var
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ... import globvars
from .vecutils import validate_var_or_int
from ..var_op import CeilDiv


def _dim_product(dims: List[Union[int, Var]]) -> Union[int, Var]:
    out: Union[int, Var] = 1
    for dim in dims:
        validate_var_or_int(dim, "dim")
        out = out * dim
    return out


def _same_dim(a: Union[int, Var], b: Union[int, Var]) -> bool:
    return str(a) == str(b)


def _is_rank1_gm_view(tensor: GMTensor) -> bool:
    return len(list(tensor.shape)) == 1


def _infer_gm_transfer(
    tensor: GMTensor,
    context: str,
) -> Tuple[Union[int, Var], Union[int, Var], Union[int, Var]]:
    shape = list(tensor.shape)
    span = list(tensor.span if hasattr(tensor, "span") else tensor.shape)
    slice_mask = list(getattr(tensor, "slice_mask", [True for _ in shape]))

    if len(shape) == 1:
        return 1, span[0], 0

    if len(shape) == 2:
        return span[0], span[1], shape[1] - span[1]

    slice_dims = [idx for idx, flag in enumerate(slice_mask) if flag]
    if len(slice_dims) == 0:
        raise ValueError(f"{context} default inference for rank>2 requires at least one sliced dimension")
    if len(slice_dims) > 2:
        raise ValueError(f"{context} default inference supports at most 2 sliced dimensions")

    if len(slice_dims) == 1:
        outer_dim = slice_dims[0]
        if outer_dim == len(shape) - 1:
            return 1, span[outer_dim], 0
        burst_len = _dim_product(span[outer_dim + 1 :])
        dst_step = _dim_product(shape[outer_dim + 1 :])
        return span[outer_dim], burst_len, dst_step - burst_len

    outer_dim, inner_dim = slice_dims
    trailing_shape = shape[inner_dim + 1 :]
    trailing_span = span[inner_dim + 1 :]
    for shape_dim, span_dim in zip(trailing_shape, trailing_span):
        if not _same_dim(shape_dim, span_dim):
            raise ValueError(
                f"{context} default inference requires the innermost sliced dimension "
                "to cover the contiguous suffix of the GM view"
            )
    burst_len = _dim_product(span[inner_dim:])
    dst_step = _dim_product(shape[outer_dim + 1 :])
    return span[outer_dim], burst_len, dst_step - burst_len


def gm_to_ub_pad(
    dst: Tensor,
    src: GMTensor,
    n_burst: Union[int, Var, None] = None,
    burst_len_element: Union[int, Var, None] = None,
    src_stride_element: Union[int, Var, None] = None,
    dst_stride: Union[int, Var, None] = None,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, GMTensor):
        raise TypeError(f"src must be GMTensor type, current type: {type(src)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    is_rank1_gm_view = _is_rank1_gm_view(src)
    if n_burst is None or burst_len_element is None or src_stride_element is None:
        auto_n_burst, auto_burst_len_element, auto_src_stride_element = _infer_gm_transfer(
            src,
            "gm_to_ub_pad",
        )
    else:
        auto_n_burst = None
        auto_burst_len_element = None
        auto_src_stride_element = None
    if n_burst is None:
        n_burst = auto_n_burst
    if burst_len_element is None:
        burst_len_element = auto_burst_len_element
    if src_stride_element is None:
        src_stride_element = auto_src_stride_element
    if dst_stride is None:
        if is_rank1_gm_view:
            dst_stride = 0
        else:
            shape1 = dst.shape[1]
            validate_var_or_int(shape1, "dst.shape[1]")
            dst_stride = (shape1 - burst_len_element) // dst.dtype.C0
    if n_burst is None or burst_len_element is None or src_stride_element is None or dst_stride is None:
        raise ValueError("gm_to_ub_padparameter inference failed") 
    validate_var_or_int(n_burst, "n_burst")
    validate_var_or_int(burst_len_element, "burst_len_element")
    validate_var_or_int(src_stride_element, "src_stride_element")
    validate_var_or_int(dst_stride, "dst_stride")

    burst_len_byte = burst_len_element * dst.dtype.size
    src_stride_byte = src_stride_element * dst.dtype.size

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gm_to_ub_pad",
                dst=dst,
                src=src,
                n_burst=n_burst,
                burst_len_byte=burst_len_byte,
                src_stride_byte=src_stride_byte,
                dst_stride=dst_stride,
            )
        )


def ub_to_gm_pad(
    dst: GMTensor,
    src: Tensor,
    n_burst: Union[int, Var, None] = None,
    burst_len_element: Union[int, Var, None] = None,
    src_stride: Union[int, Var, None] = None,
    dst_stride_element: Union[int, Var, None] = None,
) -> None:
    if not isinstance(dst, GMTensor):
        raise TypeError(f"dst must be GMTensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    is_rank1_gm_view = _is_rank1_gm_view(dst)
    if n_burst is None or burst_len_element is None or dst_stride_element is None:
        auto_n_burst, auto_burst_len, auto_dst_stride = _infer_gm_transfer(
            dst,
            "ub_to_gm_pad",
        )
    else:
        auto_n_burst = None
        auto_burst_len = None
        auto_dst_stride = None
    if n_burst is None:
        n_burst = auto_n_burst
    if burst_len_element is None:
        if auto_burst_len is None:
            raise ValueError("ub_to_gm_pad parameter inference failed for burst_len_element")
        burst_len_element = auto_burst_len
    if dst_stride_element is None:
        if auto_dst_stride is None:
            raise ValueError("ub_to_gm_pad parameter inference failed for dst_stride_element")
        dst_stride_element = auto_dst_stride
    if src_stride is None:
        if is_rank1_gm_view:
            src_stride = 0
        else:
            src_shape1 = src.shape[1]
            validate_var_or_int(src_shape1, "src.shape[1]")
            src_stride = (src_shape1 - burst_len_element) // src.dtype.C0
    if n_burst is None or burst_len_element is None or src_stride is None or dst_stride_element is None:
        raise ValueError("ub_to_gm_padparameter inference failed") 
    validate_var_or_int(n_burst, "n_burst")
    validate_var_or_int(burst_len_element, "burst_len_element")
    validate_var_or_int(src_stride, "src_stride")
    validate_var_or_int(dst_stride_element, "dst_stride_element")

    burst_len_byte = burst_len_element * src.dtype.size
    dst_stride_byte = dst_stride_element * src.dtype.size

    if globvars.active_kernel is not None:
        if globvars.atomic_enabled and globvars.atomic_type is not dst.dtype:
            globvars.active_kernel.instructions.append(
                Instruction("set_atomic_type", dtype=dst.dtype)
            )
            globvars.atomic_type = dst.dtype
        globvars.active_kernel.instructions.append(
            Instruction(
                "ub_to_gm_pad",
                dst=dst,
                src=src,
                n_burst=n_burst,
                burst_len_byte=burst_len_byte,
                src_stride=src_stride,
                dst_stride_byte=dst_stride_byte,
            )
        )


def ub_to_l1_nd2nz(
    dst: Tensor,
    src: Tensor,
    m_dst: Union[int, Var, None] = None,
    n_dst: Union[int, Var, None] = None,
    m_src: Union[int, Var, None] = None,
    n_src: Union[int, Var, None] = None,
) -> None:
    if globvars.device_type != "950":
        raise ValueError(
            "ub_to_l1_nd2nz only supports a5 (device_type='950'), "
            f"current device_type: {globvars.device_type}"
        )
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")

    dst_span = dst.span if hasattr(dst, "span") else dst.shape
    src_span = src.span if hasattr(src, "span") else src.shape
    if m_dst is None:
        m_dst = dst.shape[0]
    if n_dst is None:
        n_dst = dst_span[1]
    if m_src is None:
        m_src = src_span[0]
    if n_src is None:
        n_src = src_span[1]

    validate_var_or_int(m_dst, "m_dst")
    validate_var_or_int(n_dst, "n_dst")
    validate_var_or_int(m_src, "m_src")
    validate_var_or_int(n_src, "n_src")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "ub_to_l1_nd2nz",
                dst=dst,
                src=src,
                m_dst=m_dst,
                n_dst=n_dst,
                m_src=m_src,
                n_src=n_src,
            )
        )


def ub_to_l1_nz(
    dst: Tensor,
    src: Tensor,
    m_dst: Union[int, Var, None] = None,
    n_dst: Union[int, Var, None] = None,
    m_src: Union[int, Var, None] = None,
    n_src: Union[int, Var, None] = None,
) -> None:
    if globvars.device_type != "950":
        raise ValueError(
            "ub_to_l1_nz only supports a5 (device_type='950'), "
            f"current device_type: {globvars.device_type}"
        )
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.L1:
        raise ValueError(f"dst must be at L1 position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")

    dst_span = dst.span if hasattr(dst, "span") else dst.shape
    src_span = src.span if hasattr(src, "span") else src.shape
    if m_dst is None:
        m_dst = dst.shape[0]
    if n_dst is None:
        n_dst = dst_span[1]
    if m_src is None:
        m_src = src_span[0]
    if n_src is None:
        n_src = src_span[1]

    validate_var_or_int(m_dst, "m_dst")
    validate_var_or_int(n_dst, "n_dst")
    validate_var_or_int(m_src, "m_src")
    validate_var_or_int(n_src, "n_src")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "ub_to_l1_nz",
                dst=dst,
                src=src,
                m_dst=m_dst,
                n_dst=n_dst,
                m_src=m_src,
                n_src=n_src,
            )
        )


def ub_to_ub(
    dst: Tensor,
    src: Tensor,
    n_burst: Union[int, Var, None] = None,
    burst_len: Union[int, Var, None] = None,
    src_stride: Union[int, Var, None] = None,
    dst_stride: Union[int, Var, None] = None,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    span = dst.span if hasattr(dst, "span") else dst.shape
    span0 = span[0]
    span1 = span[1]
    dst_shape0 = dst.shape[0]
    src_shape1 = src.shape[1]
    dst_shape1 = dst.shape[1]
    validate_var_or_int(span0, "dst.span[0]")
    validate_var_or_int(span1, "dst.span[1]")
    validate_var_or_int(dst_shape0, "dst.shape[0]")
    validate_var_or_int(src_shape1, "src.shape[1]")
    validate_var_or_int(dst_shape1, "dst.shape[1]")
    if n_burst is None:
        n_burst = span0
    if burst_len is None:
        burst_len = CeilDiv(span1, dst.dtype.C0)
    if dst_stride is None:
        dst_stride = CeilDiv(dst_shape1 - span1, dst.dtype.C0)
    if src_stride is None:
        src_stride = CeilDiv(src_shape1 - span1, src.dtype.C0)
    if n_burst is None or burst_len is None or dst_stride is None or src_stride is None:
        raise ValueError("ub_to_ubparameter inference failed") 
    validate_var_or_int(n_burst, "n_burst")
    validate_var_or_int(burst_len, "burst_len")
    validate_var_or_int(src_stride, "src_stride")
    validate_var_or_int(dst_stride, "dst_stride")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "ub_to_ub",
                dst=dst,
                src=src,
                n_burst=n_burst,
                burst_len=burst_len,
                src_stride=src_stride,
                dst_stride=dst_stride,
            )
        )
