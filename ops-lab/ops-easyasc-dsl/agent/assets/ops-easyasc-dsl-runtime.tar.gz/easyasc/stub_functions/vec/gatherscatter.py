# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Union

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ... import globvars
from .vecutils import apply_vector_mode_transition, infer_repeat, resolve_strides, validate_var_or_int


_gather_unit_warning = True


def _warn_gather_byte_units() -> None:
    global _gather_unit_warning
    if _gather_unit_warning:
        print("Usage reminder: gather/scatter offset and start_idx are both in bytes.")
        _gather_unit_warning = False


def gather(
    dst: Tensor,
    src: Tensor,
    offset: Tensor,
    start_idx: Union[int, Var] = 0,
    repeat: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if not isinstance(offset, Tensor):
        raise TypeError(f"offset must be Tensor type, current type: {type(offset)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if offset.position is not Position.UB:
        raise ValueError(f"offset must be at UB position, current position: {offset.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    if offset.dtype is not Datatype.uint32:
        raise ValueError(f"offset must be uint32 type, current type: {offset.dtype}")
    if repeat is None:
        repeat = infer_repeat(dst)
    if dst_rep_stride is None:
        _, dst_rep_stride = resolve_strides(dst, None, None)

    validate_var_or_int(start_idx, "start_idx")
    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")

    apply_vector_mode_transition(count)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "gather",
                dst=dst,
                src=src,
                offset=offset,
                start_idx=start_idx,
                repeat=repeat,
                dst_rep_stride=dst_rep_stride,
                count=count,
            )
        )
    _warn_gather_byte_units()


def scatter(
    dst: Tensor,
    src: Tensor,
    offset: Tensor,
    start_idx: Union[int, Var] = 0,
    repeat: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if not isinstance(offset, Tensor):
        raise TypeError(f"offset must be Tensor type, current type: {type(offset)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if offset.position is not Position.UB:
        raise ValueError(f"offset must be at UB position, current position: {offset.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match")
    if offset.dtype is not Datatype.uint32:
        raise ValueError(f"offset must be uint32 type, current type: {offset.dtype}") 
    if repeat is None:
        repeat = infer_repeat(src)
    if src_rep_stride is None:
        _, src_rep_stride = resolve_strides(src, None, None)

    validate_var_or_int(start_idx, "start_idx")
    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(src_rep_stride, "src_rep_stride")

    apply_vector_mode_transition(count)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "scatter",
                dst=dst,
                src=src,
                offset=offset,
                start_idx=start_idx,
                repeat=repeat,
                src_rep_stride=src_rep_stride,
                count=count,
            )
        )
