# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Union

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ...utils.roundmode import RoundMode, RoundModeType
from ... import globvars
from .vecutils import apply_vector_mode_transition, infer_repeat, resolve_strides, validate_var_or_int
from ..var_op import CeilDiv


def _infer_cast_repeat(dst: Tensor, src: Tensor) -> Union[int, Var]:
    span = dst.span if hasattr(dst, "span") else dst.shape
    dim0 = span[0]
    dim1 = span[1]
    validate_var_or_int(dim0, "dst.span[0]")
    validate_var_or_int(dim1, "dst.span[1]")
    count = dim0 * dim1
    denom = 256 // max(src.dtype.size, dst.dtype.size)
    if isinstance(count, Var):
        return CeilDiv(count, denom)
    if not isinstance(count, int):
        raise TypeError(f"repeat cannot be inferred from shape, current count type: {type(count)}")
    return CeilDiv(count, denom)


def _resolve_cast_rep_strides(
    dst: Tensor,
    src: Tensor,
    dst_rep_stride: Union[int, Var, None],
    src_rep_stride: Union[int, Var, None],
) -> tuple[Union[int, Var], Union[int, Var]]:
    if (dst_rep_stride is None) != (src_rep_stride is None):
        raise ValueError("src_rep_stride and dst_rep_stride must all be None or simultaneously specified")
    if dst_rep_stride is not None and src_rep_stride is not None:
        return dst_rep_stride, src_rep_stride

    c0_src = src.dtype.C0
    c0_dst = dst.dtype.C0
    if c0_src > c0_dst:
        src_rep_stride = 8 * c0_dst // c0_src
        dst_rep_stride = 8 
    elif c0_src < c0_dst:
        dst_rep_stride = 8 * c0_src // c0_dst
        src_rep_stride = 8 
    else:
        src_rep_stride = 8
        dst_rep_stride = 8
    return dst_rep_stride, src_rep_stride


def cast(
    dst: Tensor,
    src: Tensor,
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    src_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    src_rep_stride: Union[int, Var, None] = None,
    round_mode: RoundModeType = RoundMode.AWAY_FROM_ZERO,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if not isinstance(round_mode, RoundModeType):
        raise TypeError(f"round_mode must be RoundModeTypetype, current type: {type(round_mode)}")

    if repeat is None:
        repeat = _infer_cast_repeat(dst, src)

    if dst_blk_stride is None or src_blk_stride is None:
        auto_dst_blk, _ = resolve_strides(dst, dst_blk_stride, 8)
        auto_src_blk, _ = resolve_strides(src, src_blk_stride, 8)
        if dst_blk_stride is None:
            dst_blk_stride = auto_dst_blk
        if src_blk_stride is None:
            src_blk_stride = auto_src_blk

    dst_rep_stride, src_rep_stride = _resolve_cast_rep_strides(
        dst, src, dst_rep_stride, src_rep_stride
    )

    if dst.dtype.size > src.dtype.size:
        round_mode = RoundMode.NONE

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(src_blk_stride, "src_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")
    validate_var_or_int(src_rep_stride, "src_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "cast",
                dst=dst,
                src=src,
                mode=round_mode,
                repeat=repeat,
                dst_blk_stride=dst_blk_stride,
                src_blk_stride=src_blk_stride,
                dst_rep_stride=dst_rep_stride,
                src_rep_stride=src_rep_stride,
            )
        )
