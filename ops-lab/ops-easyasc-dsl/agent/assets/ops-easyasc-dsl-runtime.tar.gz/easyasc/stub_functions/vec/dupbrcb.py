# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Union

from ...utils.Tensor import Tensor
from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.positions import Position
from ...utils.instruction import Instruction
from ... import globvars
from .vecutils import (
    apply_vector_mode_transition,
    ensure_repeat_mode,
    infer_repeat,
    infer_repeat_brcb,
    resolve_strides,
    validate_scalar,
    validate_var_or_int,
)


def dup(
    dst: Tensor,
    value: Union[int, float, Var],
    repeat: Union[int, Var, None] = None,
    dst_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    *,
    count: Union[int, Var, None] = None,
    count_per_rep: Union[int, Var, None] = None,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    validate_scalar(value, "value")
    if dst.dtype not in (Datatype.float, Datatype.half, Datatype.int, Datatype.uint32):
        raise ValueError(f"does not support data type: {dst.dtype}")
    if repeat is None:
        repeat = infer_repeat(dst)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")

    apply_vector_mode_transition(count, count_per_rep)

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "dup",
                dst=dst,
                src=value,
                repeat=repeat,
                dst_blk_stride=dst_blk_stride,
                dst_rep_stride=dst_rep_stride,
            )
        )


# NOTE: brcb does not honor count mode in the a2 simulator; ensure the pipe is
# back in repeat/normal mode before emitting.
def brcb(
    dst: Tensor,
    src: Tensor,
    dst_blk_stride: Union[int, Var, None] = None,
    dst_rep_stride: Union[int, Var, None] = None,
    repeat: Union[int, Var, None] = None,
) -> None:
    if not isinstance(dst, Tensor):
        raise TypeError(f"dst must be Tensor type, current type: {type(dst)}")
    if not isinstance(src, Tensor):
        raise TypeError(f"src must be Tensor type, current type: {type(src)}")
    if dst.position is not Position.UB:
        raise ValueError(f"dst must be at UB position, current position: {dst.position}")
    if src.position is not Position.UB:
        raise ValueError(f"src must be at UB position, current position: {src.position}")
    if dst.dtype != src.dtype:
        raise ValueError("dst/src data types must match") 
    if repeat is None:
        repeat = infer_repeat_brcb(src)

    dst_blk_stride, dst_rep_stride = resolve_strides(dst, dst_blk_stride, dst_rep_stride)

    validate_var_or_int(repeat, "repeat")
    validate_var_or_int(dst_blk_stride, "dst_blk_stride")
    validate_var_or_int(dst_rep_stride, "dst_rep_stride")

    ensure_repeat_mode()

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction(
                "brcb",
                dst=dst,
                src=src,
                repeat=repeat,
                dst_blk_stride=dst_blk_stride,
                dst_rep_stride=dst_rep_stride,
            )
        )
