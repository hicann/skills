# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Union

from ...utils.var import Var
from ...utils.datatype import Datatype
from ...utils.instruction import Instruction
from ... import globvars


def set_mask(mask_high: Union[int, Var], mask_low: Union[int, Var]) -> None:
    if isinstance(mask_high, Var) and mask_high.dtype is not Datatype.uint64:
        raise TypeError(f"mask_high must be uint64type, current type: {mask_high.dtype}")
    if isinstance(mask_low, Var) and mask_low.dtype is not Datatype.uint64:
        raise TypeError(f"mask_low must be uint64type, current type: {mask_low.dtype}")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("set_mask", low=mask_low, high=mask_high)
        )


def set_mask_by_count(count: Union[int, Var]) -> None:
    if not isinstance(count, (int, Var)):
        raise TypeError(f"count must be int or Var type, current type: {type(count)}")

    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("set_mask_by_count", count=count)
        )


def reset_mask() -> None:
    if globvars.active_kernel is not None:
        globvars.active_kernel.instructions.append(
            Instruction("reset_mask")
        )
