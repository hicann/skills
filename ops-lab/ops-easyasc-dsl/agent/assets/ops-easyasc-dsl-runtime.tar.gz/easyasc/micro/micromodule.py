import inspect
from typing import Any, Callable, Dict, List, Tuple

from .. import globvars
from ..utils.datatype import DataTypeValue, Datatype
from ..utils.instruction import Instruction
from ..utils.mask import MaskType
from ..utils.reg import MaskReg, Reg
from ..utils.sync_key import SyncKeyGroup, collect_tensor_sync_keys, normalize_sync_key_group
from ..utils.Tensor import Tensor
from ..utils.var import Var
from ..utils.positions import Position
from ..utils.castconfig import CastConfig
from ..utils.roundmode import RoundMode


class TempRegStatus:
    def __init__(self, idx: int, dtype: DataTypeValue):
        self.reg = object.__new__(Reg)
        self.reg.name = f'_tmp_reg_{idx}'
        self.reg.dtype = dtype
        self.valid = True 
    
    def lock(self):
        self.valid = False 
    
    def release(self):
        self.valid = True 


class MicroModule:
    def __init__(self, name: str, func: Callable[..., Any]) -> None:
        self.func = func
        self.name = name
        self.instructions: List[Any] = []
        self.input_list: List[Any] = []
        self.tmp_idx = 0
        self.tmp_masks: Dict[str, MaskReg] = {}
        self.default_cast_cfg = None 
        self.default_cast_cfg_hif8 = None 
        self.cast_cfg_list: List[Any] = []
        self.tmp_regs: Dict[str, List[TempRegStatus]] = {}
        self._declared_reg_names: Dict[str, str] = {}
        self._read_sync_keys: SyncKeyGroup = tuple()
        self._write_sync_keys: SyncKeyGroup = tuple()

    def get_default_cast_cfg(self, dtype: DataTypeValue):
        if dtype == Datatype.hif8:
            if self.default_cast_cfg_hif8 is not None:
                return self.default_cast_cfg_hif8
            self.default_cast_cfg_hif8 = CastConfig(name='default_castcfg_round', round_mode=RoundMode.AWAY_FROM_ZERO)
            return self.default_cast_cfg_hif8
        else:
            if self.default_cast_cfg is not None:
                return self.default_cast_cfg
            self.default_cast_cfg = CastConfig(name='default_castcfg')
            return self.default_cast_cfg

    def get_reg(self, dtype: DataTypeValue):
        if dtype.name not in self.tmp_regs:
            self.tmp_regs[dtype.name] = []
        for i in self.tmp_regs[dtype.name]:
            if i.valid:
                i.lock()
                return i.reg 
        new_stat = TempRegStatus(self.tmp_idx, dtype)
        self.tmp_idx += 1 
        self.tmp_regs[dtype.name].append(new_stat)
        self._register_reg_name(new_stat.reg.name, "Reg")
        # Hoist temp register declaration to micro scope to keep it valid when
        # first use appears inside loop/if blocks.
        self.instructions.insert(0, Instruction("create_reg", reg=new_stat.reg))
        new_stat.lock()
        return new_stat.reg

    def release_reg(self, reg: Reg):
        for i in self.tmp_regs[reg.dtype.name]:
            if i.reg.name == reg.name:
                i.release()

    @staticmethod
    def _normalize_arg(arg: Any) -> Any:
        if type(arg) is int:
            scalar = object.__new__(Var)
            scalar.dtype = Datatype.int
            scalar.name = str(arg)
            scalar.value = arg
            scalar.idx = -1
            return scalar
        if type(arg) is float:
            scalar = object.__new__(Var)
            scalar.dtype = Datatype.float
            scalar.name = repr(arg)
            scalar.value = arg
            scalar.idx = -1
            return scalar
        return arg

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        if kwargs:
            raise TypeError("MicroModule does not support keyword arguments")
        normalized_args: Tuple[Any, ...] = tuple(self._normalize_arg(arg) for arg in args)
        for arg in normalized_args:
            if not isinstance(arg, (Tensor, Var)):
                raise TypeError(
                    f"MicroModule only accepts Tensor, Var, int, or float inputs, got: {type(arg)}"
                )
            if isinstance(arg, Tensor) and arg.position is not Position.UB:
                raise ValueError(f"MicroModule only accepts Tensor inputs in UB, current position: {arg.position}")
        sig = inspect.signature(self.func)
        try:
            bound = sig.bind(*normalized_args)
        except TypeError as exc:
            raise TypeError(f"MicroModule call argument mismatch: {exc}") from exc
        micro_args: List[Any] = []
        for name, arg in bound.arguments.items():
            if isinstance(arg, Tensor):
                cloned = object.__new__(Tensor)
                cloned.__dict__ = {
                    k: (v.copy() if isinstance(v, list) else v)
                    for k, v in arg.__dict__.items()
                }
                cloned.name = name
                micro_args.append(cloned)
            elif isinstance(arg, Var):
                cloned = object.__new__(Var)
                cloned.__dict__ = arg.__dict__.copy()
                cloned.name = name
                micro_args.append(cloned)
            else:
                raise TypeError(f"MicroModule only accepts Tensor or Var inputs, got: {type(arg)}")
        if not self.input_list:
            self.input_list = micro_args
            prev_micro = globvars.active_micro
            globvars.active_micro = self
            try:
                self.func(*micro_args)
                for _, v in self.tmp_masks.items():
                    self.instructions.insert(0, Instruction("create_maskreg", reg=v))
                self._refresh_sync_keys()
            finally:
                globvars.active_micro = prev_micro
        if globvars.active_kernel is not None:
            globvars.active_kernel.used_micros.add(self)
            globvars.active_kernel.instructions.append(
                Instruction(
                    "call_micro",
                    name=self.name,
                    args=list(normalized_args),
                    read_sync_keys=list(self._read_sync_keys),
                    write_sync_keys=list(self._write_sync_keys),
                )
            )

    def get_mask(self, dtype: DataTypeValue) -> MaskReg:
        if not isinstance(dtype, DataTypeValue):
            raise TypeError(f"dtype must be DataTypeValue, got: {type(dtype)}")
        key = dtype.name
        if key not in self.tmp_masks:
            mask = object.__new__(MaskReg)
            mask.dtype = dtype
            mask.init_mode = MaskType.ALL
            idx = self.tmp_idx
            self.tmp_idx += 1
            mask.name = f"_tmp_maskreg_{idx}"
            self.tmp_masks[key] = mask
        return self.tmp_masks[key]

    def _register_reg_name(self, name: str, kind: str) -> None:
        if not isinstance(name, str):
            raise TypeError(f"register name must be str, got: {type(name)}")
        if not isinstance(kind, str):
            raise TypeError(f"register kind must be str, got: {type(kind)}")
        prev_kind = self._declared_reg_names.get(name)
        if prev_kind is not None:
            raise ValueError(
                f"Duplicate {kind} name in vf {self.name}: {name}. "
                f"Existing declaration kind: {prev_kind}"
            )
        self._declared_reg_names[name] = kind

    def _refresh_sync_keys(self) -> None:
        read_keys = set()
        write_keys = set()
        skip_ops = {
            "create_tensor",
            "create_var",
            "create_reg",
            "create_maskreg",
            "slice_tensor",
            "micro_slice_tensor",
        }
        for inst in self.instructions:
            if inst.opname in skip_ops:
                continue
            read_keys.update(collect_tensor_sync_keys(inst.kwargs.get("src", None)))
            read_keys.update(collect_tensor_sync_keys(inst.kwargs.get("src_a", None)))
            read_keys.update(collect_tensor_sync_keys(inst.kwargs.get("src_b", None)))
            if inst.opname == "call_micro":
                read_keys.update(tuple(inst.kwargs.get("read_sync_keys", ())))
                write_keys.update(tuple(inst.kwargs.get("write_sync_keys", ())))
            write_keys.update(collect_tensor_sync_keys(inst.kwargs.get("dst", None)))

        normalized_reads = normalize_sync_key_group(read_keys)
        normalized_writes = normalize_sync_key_group(write_keys)
        self._read_sync_keys = normalized_reads or tuple()
        self._write_sync_keys = normalized_writes or tuple()

    def gen_code(self, path: str) -> None:
        if not isinstance(path, str):
            raise TypeError(f"path must be str, got: {type(path)}")
        from ..parser.asc import translate
        from ..parser.asc_utils import dtype_to_cpp
        from ..parser.helper import CodeHelper
        from ..utils.castconfig import CastConfig

        helper = CodeHelper()
        helper("#pragma once")
        helper('#include "tensorutils.h"')
        helper()

        for cfg in self.cast_cfg_list:
            if not isinstance(cfg, CastConfig):
                continue
            sat = "SAT" if cfg.saturate else "NO_SAT"
            helper(
                "static constexpr MicroAPI::CastTrait "
                f"{cfg.name} = {{ MicroAPI::RegLayout::{cfg.reg_layout}, "
                f"MicroAPI::SatMode::{sat}, MicroAPI::MaskMergeMode::ZEROING, "
                f"RoundMode::{cfg.round_mode} }};"
            )
        if self.cast_cfg_list:
            helper()

        args = []
        for arg in self.input_list:
            if isinstance(arg, Tensor):
                args.append(
                    f"__ubuf__ {dtype_to_cpp(arg.dtype)}* {arg.name}"
                )
            elif isinstance(arg, Var):
                args.append(
                    f"const {dtype_to_cpp(arg.dtype)} &{arg.name}"
                )
            else:
                raise TypeError(f"MicroModule only accepts Tensor or Var inputs, got: {type(arg)}")
        args_str = ", ".join(args)

        helper(f"__aicore__ inline void {self.name}({args_str}){{")
        helper.ir()
        helper("__VEC_SCOPE__")
        helper("{")
        helper.ir()

        code = translate(self.instructions)
        for line in code.splitlines():
            helper(line)

        helper.il()
        helper("}")
        helper.il()
        helper("}")
        helper()

        with open(path, "w", encoding="utf-8") as f:
            f.write(str(helper))
