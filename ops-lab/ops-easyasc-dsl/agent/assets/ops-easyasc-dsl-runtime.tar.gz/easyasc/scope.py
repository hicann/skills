# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Optional, Type

from . import globvars
from .utils.instruction import Instruction


class _side_scope:
    enter_opname = ""
    end_opname = ""
    label = "scope"

    def _emit(self, opname: str) -> None:
        if globvars.active_kernel is None:
            raise RuntimeError(f"{self.label} can only be used inside a kernel")
        globvars.active_kernel.instructions.append(Instruction(opname))

    def __enter__(self):
        self._emit(self.enter_opname)
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc: Optional[BaseException],
        tb,
    ) -> bool:
        self._emit(self.end_opname)
        return False


class vec_scope(_side_scope):
    enter_opname = "enter_vec_scope"
    end_opname = "end_vec_scope"
    label = "vec_scope"


class cube_scope(_side_scope):
    enter_opname = "enter_cube_scope"
    end_opname = "end_cube_scope"
    label = "cube_scope"
