# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import os

ascend_op_extension_name = 'test_aclnnop'
ascend_op_src_files = ['test.cpp']
ascend_toolkit_install_path=os.environ.get('ASCEND_HOME_PATH') or os.environ.get('ASCEND_INSTALL_PATH') or os.path.expanduser('~/ascend-toolkit/latest')
custom_op_path = ascend_toolkit_install_path + '/opp'

ascend_include_paths=[
    ascend_toolkit_install_path + '/aarch64-linux/include',
    ascend_toolkit_install_path + '/acllib/include',
    custom_op_path + '/vendors/customize/op_api/include/',
    './'
]
# aclnn host test (test.cpp): omit hccl and opapi (not needed here; some CANN trees lack -lhccl/-lopapi).
ascend_libraries = ['runtime', 'ascendcl', 'stdc++', 'nnopbase', 'msprofiler', 'cust_opapi']
ascend_library_paths = [
    ascend_toolkit_install_path + '/runtime/lib64',
    ascend_toolkit_install_path + '/aarch64-linux/lib64',
    custom_op_path + '/vendors/customize/op_api/lib/',
]

cmd = 'g++ -O2 '
cmd += ' '.join(ascend_op_src_files) + ' '

cmd += ' '.join(['-L'+p for p in ascend_library_paths]) + ' '
cmd += ' '.join(['-I'+p for p in ascend_include_paths]) + ' '
cmd += ' '.join(['-l'+l for l in ascend_libraries]) + ' '
cmd += '-o ' + ascend_op_extension_name + ' -std=c++17 -pthread '
cmd += '-Wl,-rpath=' + ascend_toolkit_install_path + '/aarch64-linux/lib64 '

print('--> Compiling aclnn testcase...')
os.system(cmd)
