/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */


/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2022-2023. All rights reserved.
 */
#include "torch/extension.h" 
#include "torch_npu/csrc/core/npu/NPUStream.h" 
#include "acl/acl.h" 
#include "aclnn_test_xxx.h" 

#define CHECK_RET(x) \
    do { \
        auto __ret = x; \
        if (__ret != ACL_SUCCESS) { \
            std::cerr << __FILE__ << ":" << __LINE__ << " Error:" << __ret << std::endl; \
        } \
    } while (0); 

#define PREPARE_OP() uint64_t workspaceSize = 0; aclOpExecutor* executor = nullptr; void* workspaceAddr = nullptr; 
#define EXECOP(opname, stream, ...) \
    CHECK_RET(opname##GetWorkspaceSize(__VA_ARGS__, &workspaceSize, &executor)); \
    if (workspaceSize>0) CHECK_RET(aclrtMalloc(&workspaceAddr, workspaceSize, ACL_MEM_MALLOC_HUGE_FIRST)); \
    CHECK_RET(opname(workspaceAddr, workspaceSize, executor, stream)); \
    CHECK_RET(aclDestroyAclOpExecutor(executor)); \
    if (workspaceSize>0) CHECK_RET(aclrtFree(workspaceAddr));


aclTensor* toAclTensor(at::Tensor x, aclDataType aclT){ 
    std::vector<int64_t> shape = x.sizes().vec(); 
    std::vector<int64_t> strides = x.strides().vec(); 
    return aclCreateTensor(shape.data(), shape.size(), aclT, strides.data(), 0, aclFormat::ACL_FORMAT_ND, shape.data(), shape.size(), (void*)(x.storage().data())); 
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) { 
    m.def("test_xxx", &test_xxx, "test_xxx"); 
}
