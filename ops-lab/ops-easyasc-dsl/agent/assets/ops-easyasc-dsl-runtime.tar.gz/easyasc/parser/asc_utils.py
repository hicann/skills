# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
import re
from typing import Dict, Iterable, Set, Tuple

from ..utils.instruction import Instruction
from ..utils.positions import POSITION_CPP_MAPPING, Position
from ..utils.Tensor import DBuff, GMTensor, QBuff, TBuff, Tensor
from ..utils.var import Expr, Var, VarRef
from ..utils.datatype import Datatype
from .. import globvars

try:
    import sympy as sp
    from sympy.printing.str import StrPrinter
    from sympy.printing.precedence import precedence
except ImportError:
    sp = None
    StrPrinter = object  # type: ignore
    def precedence(expr):  # type: ignore
        return 0



_PRINTER = None
_CPP_PRINTER = None

class _MulPowPrinter(StrPrinter):
    def _print_Pow(self, expr):
        base, exp = expr.as_base_exp()
        if exp.is_Integer and exp > 0:
            base_str = self.parenthesize(base, precedence(expr))
            return "*".join([base_str] * int(exp))
        return super()._print_Pow(expr) # type: ignore

    def _print_Mod(self, expr):
        lhs = self._print(expr.args[0]) # type: ignore
        rhs = self._print(expr.args[1]) # type: ignore
        return f"({lhs}) % ({rhs})"

    def _print_Equality(self, expr):
        lhs = self._print(expr.lhs) # type: ignore
        rhs = self._print(expr.rhs) # type: ignore
        return f"({lhs}) == ({rhs})"

    def _print_Unequality(self, expr):
        lhs = self._print(expr.lhs) # type: ignore
        rhs = self._print(expr.rhs) # type: ignore
        return f"({lhs}) != ({rhs})"

    def _print_And(self, expr):
        parts = [self._print(arg) for arg in expr.args] # type: ignore
        parts = ["(" + p + ")" for p in parts]
        return " && ".join(parts)

    def _print_Or(self, expr):
        parts = [self._print(arg) for arg in expr.args] # type: ignore
        parts = ["(" + p + ")" for p in parts]
        return " || ".join(parts)


class _CppExprPrinter(_MulPowPrinter):
    def _print_Function(self, expr):
        name = expr.func.__name__
        if name == "IDiv" and len(expr.args) == 2:
            lhs = self._print(expr.args[0]) # type: ignore
            rhs = self._print(expr.args[1]) # type: ignore
            return f"(({lhs}) / ({rhs}))"
        if name == "IMod" and len(expr.args) == 2:
            lhs = self._print(expr.args[0]) # type: ignore
            rhs = self._print(expr.args[1]) # type: ignore
            return f"(({lhs}) % ({rhs}))"
        return super()._print_Function(expr) # type: ignore


_PRINTER = _MulPowPrinter() if sp is not None else None
_CPP_PRINTER = _CppExprPrinter() if sp is not None else None


def dtype_to_cpp(dtype) -> str:
    if dtype is None:
        return "auto"
    return str(dtype)


def position_to_cpp(position) -> str:
    key = str(position)
    if key not in POSITION_CPP_MAPPING:
        raise ValueError(f"not foundpositionmapping: {key}")
    return POSITION_CPP_MAPPING[key]


def _expr_to_sympy_text(expr: str) -> str:
    return expr.replace(".", "___").replace("&&", "&").replace("||", "|")



def _restore_expr_text(expr: str) -> str:
    return expr.replace("___", ".")



def _sympify_expr(expr: str):
    if sp is None:
        raise RuntimeError("sympy unavailable")
    expr_for_sympy = _expr_to_sympy_text(expr)
    names = set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", expr_for_sympy))
    func_names = set(re.findall(r"([A-Za-z_][A-Za-z0-9_]*)\s*\(", expr_for_sympy))
    locals_map = {}
    for name in names:
        if name == "true":
            locals_map[name] = sp.true
        elif name == "false":
            locals_map[name] = sp.false
        elif name in func_names:
            locals_map[name] = sp.Function(name)
        else:
            locals_map[name] = sp.Symbol(name)
    return sp.sympify(expr_for_sympy, locals=locals_map, evaluate=False)



def simplify_expr(expr: str) -> str:
    if sp is None or _PRINTER is None:
        return expr
    try:
        sym = _sympify_expr(expr)
        simplified = sp.simplify(sym, evaluate=False)
        result = _PRINTER.doprint(simplified)
    except Exception:
        return expr
    return _restore_expr_text(str(result))



def _split_call_args(arg_text: str) -> Tuple[str, str]:
    depth = 0
    split_idx = -1
    for idx, ch in enumerate(arg_text):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            split_idx = idx
            break
    if split_idx == -1:
        raise ValueError(f"opaque function expects two args, got: {arg_text!r}")
    return arg_text[:split_idx].strip(), arg_text[split_idx + 1 :].strip()



def _render_opaque_funcs(expr: str) -> str:
    out = []
    idx = 0
    while idx < len(expr):
        opname = None
        opchar = None
        if expr.startswith("IDiv(", idx):
            opname = "IDiv"
            opchar = "/"
        elif expr.startswith("IMod(", idx):
            opname = "IMod"
            opchar = "%"
        if opname is None or opchar is None:
            out.append(expr[idx])
            idx += 1
            continue
        start = idx + len(opname)
        depth = 0
        end = start
        while end < len(expr):
            ch = expr[end]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    break
            end += 1
        if end >= len(expr):
            out.append(expr[idx])
            idx += 1
            continue
        inner = expr[start + 1 : end]
        lhs_raw, rhs_raw = _split_call_args(inner)
        lhs = _render_opaque_funcs(lhs_raw)
        rhs = _render_opaque_funcs(rhs_raw)
        out.append(f"(({lhs}) {opchar} ({rhs}))")
        idx = end + 1
    return "".join(out)



def render_cpp_expr(expr: str) -> str:
    if "IDiv(" not in expr and "IMod(" not in expr:
        return expr
    if sp is None or _CPP_PRINTER is None:
        return _render_opaque_funcs(expr)
    try:
        sym = _sympify_expr(expr)
        result = _CPP_PRINTER.doprint(sym)
    except Exception:
        return _render_opaque_funcs(expr)
    return _restore_expr_text(str(result))



def _needs_parens(expr: str) -> bool:
    return any(token in expr for token in (" + ", " - ", " * ", " / ", " % "))


def _wrap_expr(expr: str) -> str:
    if _needs_parens(expr):
        return f"({expr})"
    return expr


def _is_zero_literal(expr: str) -> bool:
    text = expr.strip()
    if text.startswith("(") and text.endswith(")"):
        text = text[1:-1].strip()
    return text == "0"


def format_binop(op: str, left: str, right: str) -> str:
    return f"{_wrap_expr(left)} {op} {_wrap_expr(right)}"


def _preserve_slice_offset_expr(expr: str) -> str:
    """
    Keep rendered slice offsets verbatim.

    Slice builders already consume `value_to_cpp()`, which renders opaque integer
    helpers like `IDiv` into C operators. A second symbolic simplify pass here can
    collapse integer floor-division structure such as `64*((a) / (64)) / 2` into
    `a/2`, which changes indexing semantics.
    """
    return expr


def is_tmp_var(value: object) -> bool:
    return isinstance(value, Var) and value.name.startswith("_tmp_var_")


def is_tmp_tensor(value: object) -> bool:
    return isinstance(value, Tensor) and value.name.startswith("_tmp_tensor_")


def is_tmp_gmtensor(value: object) -> bool:
    return isinstance(value, GMTensor) and value.name.startswith("_tmp_gmtensor_")


def value_to_expr(value, expr_map: Dict[str, str]) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, Expr):
        expr = str(value)
        if expr_map:
            for name, mapped in expr_map.items():
                if name not in expr:
                    continue
                mapped_expr = simplify_expr(mapped)
                mapped_expr = _wrap_expr(mapped_expr)
                expr = re.sub(rf"\b{re.escape(name)}\b", mapped_expr, expr)
        return expr
    if isinstance(value, VarRef):
        parent_name = getattr(getattr(value, "parent", None), "name", None)
        index = getattr(value, "index", None)
        if isinstance(parent_name, str) and parent_name != "" and index is not None:
            return f"{parent_name}[{value_to_expr(index, expr_map)}]"
    if isinstance(value, Var):
        mapped = expr_map.get(value.name)
        if mapped is not None:
            simplified = simplify_expr(mapped)
            if simplified != mapped:
                expr_map[value.name] = simplified
            return simplified
        return value.name
    if isinstance(value, Tensor):
        mapped = expr_map.get(value.name)
        if mapped is not None:
            return mapped
        return value.name
    if isinstance(value, GMTensor):
        mapped = expr_map.get(value.name)
        if mapped is not None:
            return mapped
        return value.name
    if isinstance(value, (DBuff, TBuff, QBuff)):
        return value.name
    return str(value)



def value_to_cpp(value, expr_map: Dict[str, str]) -> str:
    return render_cpp_expr(value_to_expr(value, expr_map))


def build_offset_expr(shape, offset, expr_map: Dict[str, str]) -> str:
    if shape is None or offset is None:
        raise ValueError("slice_gm_tensor requires outcontainsshape and offset")
    if len(shape) != len(offset):
        raise ValueError("slice_gm_tensorshape and offsetdimensionsnotmatch")
    if not shape:
        return "0"
    # Linearized offset: sum(off[i] * prod(shape[i+1:])) + off[last]
    terms = []
    dim = len(shape)
    for idx in range(dim - 1):
        off_raw = value_to_cpp(offset[idx], expr_map)
        if _is_zero_literal(off_raw):
            continue
        off = _wrap_expr(off_raw)
        if dim - idx - 1 == 1:
            stride_expr = _wrap_expr(value_to_cpp(shape[idx + 1], expr_map))
        else:
            strides = [_wrap_expr(value_to_cpp(shape[j], expr_map)) for j in range(idx + 1, dim)]
            stride_expr = " * ".join(strides)
        terms.append(f"{off} * {stride_expr}")
    tail = value_to_cpp(offset[-1], expr_map)
    if not _is_zero_literal(tail):
        terms.append(_wrap_expr(tail))
    if not terms:
        return "0"
    return " + ".join(terms)


def build_offset_expr_nz(shape, offset, dtype, expr_map: Dict[str, str], position=None) -> str:
    if shape is None or offset is None:
        raise ValueError("slice_tensor requires outcontainsshape and offset")
    if len(shape) != 2 or len(offset) != 2:
        raise ValueError("slice_tensorshape and offset must be 2D")
    if dtype is None:
        raise ValueError("slice_tensor requires outcontainsdtype")
    if position is Position.L0C:
        c0 = 16
    else:
        c0 = dtype.C0
    off0 = _wrap_expr(value_to_cpp(offset[0], expr_map))
    off1 = _wrap_expr(value_to_cpp(offset[1], expr_map))
    shape0 = _wrap_expr(value_to_cpp(shape[0], expr_map))
    expr = f"{off0} * {c0} + {off1} * {shape0}"
    return expr


def build_offset_expr_zz(shape, offset, dtype, expr_map: Dict[str, str]) -> str:
    if shape is None or offset is None:
        raise ValueError("slice_tensor requires outcontainsshape and offset")
    if len(shape) != 2 or len(offset) != 2:
        raise ValueError("slice_tensorshape and offset must be 2D")
    if dtype is None:
        raise ValueError("slice_tensor requires outcontainsdtype")
    if dtype is not Datatype.float:
        raise ValueError(f"ZZ slice offset only supports float dtype, current dtype: {dtype}")
    off0 = _wrap_expr(value_to_cpp(offset[0], expr_map))
    off1 = _wrap_expr(value_to_cpp(offset[1], expr_map))
    shape1 = _wrap_expr(value_to_cpp(shape[1], expr_map))
    expr = f"{off0} * {shape1} + {off1} * 16"
    return expr


def is_nz_local_position(position) -> bool:
    return position in (Position.L1, Position.L0A, Position.L0B, Position.L0C)


_ASSIGNMENT_OPS = {
    "GetValueFrom",
    "GetCubeNum",
    "GetCubeIdx",
    "GetVecNum",
    "GetVecIdx",
    "GetSubBlockIdx",
    "scalar_sqrt",
    "Align8",
    "Align16",
    "Align32",
    "Align64",
    "Align128",
    "Align256",
    "CeilDiv",
    "Min",
    "Max",
    "var_mul",
    "var_div",
    "var_add",
    "var_sub",
    "var_mod",
    "var_assign",
}


def is_assignment_op(opname: str) -> bool:
    return opname in _ASSIGNMENT_OPS


def uses_var_in_operands(inst: Instruction, name: str) -> bool:
    if inst.opname in ("GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx"):
        return False
    if inst.opname == "var_assign":
        val = inst.kwargs.get("src", None)
        return isinstance(val, Var) and val.name == name
    if inst.opname in (
        "CeilDiv",
        "Min",
        "Max",
        "var_mul",
        "var_div",
        "var_add",
        "var_sub",
        "var_mod",
        "scalar_sqrt",
        "Align8",
        "Align16",
        "Align32",
        "Align64",
        "Align128",
        "Align256",
    ):
        for key in ("a", "b"):
            val = inst.kwargs.get(key, None)
            if isinstance(val, Var) and val.name == name:
                return True
    return False


def assignment_expr(inst: Instruction, expr_map: Dict[str, str]) -> str:
    def _rhs_with_float_cast_for_float_left(rhs_expr: str) -> str:
        left = inst.kwargs.get("a", None)
        if isinstance(left, Var) and left.dtype is Datatype.float:
            return f"(float) {rhs_expr}"
        return rhs_expr

    opname = inst.opname
    if opname == "GetValueFrom":
        out = inst.kwargs.get("out", None)
        if out is None:
            out = inst.kwargs.get("dst", None)
        if not isinstance(out, Var):
            raise TypeError(f"GetValueFrom requires Var dst/out type, got: {type(out)}")
        src = value_to_expr(inst.kwargs.get("src", None), expr_map)
        return f"({dtype_to_cpp(out.dtype)}) {src}.GetValue(0)"
    if opname == "GetCubeNum":
        return "GetBlockNum()"
    if opname == "GetCubeIdx":
        return "get_block_idx()"
    if opname == "GetVecNum":
        return "GetBlockNum() * 2"
    if opname == "GetVecIdx":
        return "GetBlockIdx()"
    if opname == "GetSubBlockIdx":
        return "get_subblockid()"
    if opname == "var_assign":
        src = value_to_expr(inst.kwargs.get("src", None), expr_map)
        return src
    if opname == "scalar_sqrt":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"sqrt({a})"
    if opname == "Align8":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align8B({a})"
    if opname == "Align16":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align16B({a})"
    if opname == "Align32":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align32B({a})"
    if opname == "Align64":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align64B({a})"
    if opname == "Align128":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align128B({a})"
    if opname == "Align256":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        return f"Align256B({a})"
    if opname == "CeilDiv":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        return f"CeilDiv({a}, {b})"
    if opname == "Min":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        return f"Min({a}, {b})"
    if opname == "Max":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        return f"Max({a}, {b})"
    if opname == "var_mul":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        b = _rhs_with_float_cast_for_float_left(b)
        return simplify_expr(format_binop("*", a, b))
    if opname == "var_div":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        if isinstance(inst.kwargs.get("out", None), Var) and inst.kwargs.get("out", None).dtype is Datatype.int:
            return f"IDiv({a}, {b})"
        b = _rhs_with_float_cast_for_float_left(b)
        return simplify_expr(format_binop("/", a, b))
    if opname == "var_add":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        b = _rhs_with_float_cast_for_float_left(b)
        return simplify_expr(format_binop("+", a, b))
    if opname == "var_sub":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        b = _rhs_with_float_cast_for_float_left(b)
        return simplify_expr(format_binop("-", a, b))
    if opname == "var_mod":
        a = value_to_expr(inst.kwargs.get("a", None), expr_map)
        b = value_to_expr(inst.kwargs.get("b", None), expr_map)
        return f"IMod({a}, {b})"
    raise ValueError(f"unsupported assignment op: {opname}")


def build_expr_state(
    instructions: Iterable[Instruction],
) -> Tuple[Dict[str, str], Set[str], Set[str], Set[str]]:
    expr_map: Dict[str, str] = {}
    tmp_var_names: Set[str] = set()
    for inst in instructions:
        opname = inst.opname
        if opname == "GetCubeNum":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and is_tmp_var(out):
                expr_map[out.name] = "GetBlockNum()"
                tmp_var_names.add(out.name)
            continue
        if opname == "GetCubeIdx":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and is_tmp_var(out):
                expr_map[out.name] = "get_block_idx()"
                tmp_var_names.add(out.name)
            continue
        if opname == "GetVecNum":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and is_tmp_var(out):
                expr_map[out.name] = "GetBlockNum() * 2"
                tmp_var_names.add(out.name)
            continue
        if opname == "GetVecIdx":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and is_tmp_var(out):
                expr_map[out.name] = "GetBlockIdx()"
                tmp_var_names.add(out.name)
            continue
        if opname == "GetSubBlockIdx":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and is_tmp_var(out):
                expr_map[out.name] = "get_subblockid()"
                tmp_var_names.add(out.name)
            continue
        if opname in ("GetValueFrom", "CeilDiv", "Min", "Max", "var_mul", "var_div", "var_add", "var_sub", "var_mod", "var_assign"):
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Var) or not is_tmp_var(out):
                continue
            expr_map[out.name] = assignment_expr(inst, expr_map)
            tmp_var_names.add(out.name)
        if opname in ("scalar_sqrt", "Align8", "Align16", "Align32", "Align64", "Align128", "Align256"):
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Var) or not is_tmp_var(out):
                continue
            expr_map[out.name] = assignment_expr(inst, expr_map)
            tmp_var_names.add(out.name)

    tmp_tensor_names: Set[str] = set()
    for inst in instructions:
        if inst.opname == "get_buf":
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Tensor) or not is_tmp_tensor(out):
                continue
            buf = inst.kwargs.get("buf", None)
            if not isinstance(buf, (DBuff, TBuff, QBuff)):
                continue
            index = value_to_cpp(inst.kwargs.get("index", None), expr_map)
            expr_map[out.name] = f"{buf.name}.get({index})"
            tmp_tensor_names.add(out.name)
            continue
        if inst.opname == "slice_tensor":
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Tensor) or not is_tmp_tensor(out):
                continue
            src = inst.kwargs.get("src", None)
            shape = getattr(out, "shape", None)
            offset = inst.kwargs.get("offset", None)
            use_zz_l1_float = (
                out.position is Position.L1
                and getattr(globvars, "device_type", "").startswith('b')
                and out.dtype is Datatype.float
            )
            if use_zz_l1_float:
                offset_expr = _preserve_slice_offset_expr(build_offset_expr_zz(shape, offset, out.dtype, expr_map))
            elif is_nz_local_position(out.position):
                offset_expr = _preserve_slice_offset_expr(
                    build_offset_expr_nz(shape, offset, out.dtype, expr_map, position=out.position)
                )
            else:
                offset_expr = _preserve_slice_offset_expr(build_offset_expr(shape, offset, expr_map))
            src_expr = value_to_cpp(src, expr_map)
            if offset_expr == "0":
                expr_map[out.name] = f"{src_expr}"
            else:
                expr_map[out.name] = f"{src_expr}[{offset_expr}]"
            tmp_tensor_names.add(out.name)
            continue
        if inst.opname == "micro_slice_tensor":
            out = inst.kwargs.get("out", None)
            if not isinstance(out, Tensor) or not is_tmp_tensor(out):
                continue
            src = inst.kwargs.get("src", None)
            shape = getattr(out, "shape", None)
            offset = inst.kwargs.get("offset", None)
            offset_expr = _preserve_slice_offset_expr(build_offset_expr(shape, offset, expr_map))
            src_expr = value_to_cpp(src, expr_map)
            if offset_expr == "0":
                expr_map[out.name] = f"{src_expr}"
            else:
                expr_map[out.name] = f"{src_expr} + {offset_expr}"
            tmp_tensor_names.add(out.name)
            continue

    tmp_gmtensor_names: Set[str] = set()
    for inst in instructions:
        if inst.opname not in ("slice_gm_tensor", "reshape_gm_tensor"):
            continue
        out = inst.kwargs.get("out", None)
        if not isinstance(out, GMTensor) or not is_tmp_gmtensor(out):
            continue
        src = inst.kwargs.get("src", None)
        src_expr = value_to_cpp(src, expr_map)
        if inst.opname == "reshape_gm_tensor":
            expr_map[out.name] = f"{src_expr}"
            tmp_gmtensor_names.add(out.name)
            continue
        shape = getattr(out, "shape", None)
        offset = getattr(out, "offset", None)
        offset_expr = _preserve_slice_offset_expr(build_offset_expr(shape, offset, expr_map))
        if offset_expr == "0":
            expr_map[out.name] = f"{src_expr}"
        else:
            expr_map[out.name] = f"{src_expr}[{offset_expr}]"
        tmp_gmtensor_names.add(out.name)

    return expr_map, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names


def should_skip_inst(
    inst: Instruction,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
) -> bool:
    if inst.opname == "create_var":
        val = inst.kwargs.get("val", None)
        return isinstance(val, Var) and is_tmp_var(val) and val.name in tmp_var_names
    if inst.opname in (
        "GetValueFrom",
        "GetCubeNum",
        "GetCubeIdx",
        "GetVecNum",
        "GetVecIdx",
        "GetSubBlockIdx",
        "scalar_sqrt",
        "Align8",
        "Align16",
        "Align32",
        "Align64",
        "Align128",
        "Align256",
        "CeilDiv",
        "Min",
        "Max",
        "var_mul",
        "var_div",
        "var_add",
        "var_sub",
        "var_mod",
        "var_assign",
    ):
        out = inst.kwargs.get("out", None)
        return isinstance(out, Var) and out.name in tmp_var_names
    if inst.opname in ("get_buf", "slice_tensor", "micro_slice_tensor", "create_tensor"):
        out = inst.kwargs.get("out", None)
        return isinstance(out, Tensor) and is_tmp_tensor(out) and out.name in tmp_tensor_names
    if inst.opname in ("slice_gm_tensor", "reshape_gm_tensor"):
        out = inst.kwargs.get("out", None)
        return isinstance(out, GMTensor) and is_tmp_gmtensor(out) and out.name in tmp_gmtensor_names
    return False
