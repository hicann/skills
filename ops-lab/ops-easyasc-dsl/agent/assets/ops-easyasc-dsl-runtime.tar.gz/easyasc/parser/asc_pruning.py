import re
from typing import Callable, Iterable, List, Optional, Set, Tuple

from .asc_utils import build_expr_state, is_assignment_op, should_skip_inst
from ..utils.instruction import Instruction
from ..utils.var import Expr, Var, VarList, VarRef
from ..utils.Tensor import DBuff, GMTensor, QBuff, TBuff, Tensor
from ..utils.events import DEvent, SEvent
from ..utils.positions import Position

# A classifier returns "cube", "vec", or "both" for a single instruction.
ClassifyFn = Callable[[Instruction], str]

_IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_LOOP_STARTS = ("start_loop", "start_micro_loop")
_LOCAL_DECL_OPS = ("create_dbuf", "create_tbuf", "create_qbuf", "create_tensor")
_DECL_OPS = _LOCAL_DECL_OPS + ("create_var", "create_varlist", "create_gm_tensor", "create_sevent", "create_devent")
_BLOCK_MARKER_OPS = (
    "start_loop",
    "start_micro_loop",
    "end_loop",
    "start_if",
    "start_elif",
    "start_else",
    "end_if",
)
_NON_CONTENT_OPS = ("barrier", "start_auto_sync", "end_auto_sync")
_VIEW_HELPER_OPS = ("get_buf", "slice_tensor", "micro_slice_tensor", "slice_gm_tensor", "reshape_gm_tensor", "reinterpret")
_NON_SEED_OPS = set(_DECL_OPS + _BLOCK_MARKER_OPS + _VIEW_HELPER_OPS + ("inline", "reset_cache"))


# ---------------------------
# Block parsing utilities
# ---------------------------

def _same_var(left: object, right: object) -> bool:
    """Return True when two Var-like objects refer to the same logical variable."""
    if left is right:
        return True
    left_name = getattr(left, "name", None)
    right_name = getattr(right, "name", None)
    left_idx = getattr(left, "idx", None)
    right_idx = getattr(right, "idx", None)
    return left_name == right_name and left_idx == right_idx and left_name is not None


def _tensor_identity_key(value: object) -> Optional[Tuple[str, int]]:
    """Return a logical identity key for Tensor aliases such as .T/.nz() clones."""
    if not isinstance(value, Tensor):
        return None
    name = getattr(value, "name", None)
    idx = getattr(value, "idx", None)
    if not isinstance(name, str) or name == "":
        return None
    if not isinstance(idx, int):
        return None
    return name, idx


def _parse_loop_node(
    instructions: List[Instruction],
    idx: int,
    with_prelude: bool,
) -> Tuple[dict, int]:
    """Parse a loop node, optionally including a leading create_var prelude."""
    prelude = None
    if with_prelude:
        prelude = instructions[idx]
        idx += 1
    start = instructions[idx]
    idx += 1
    body, idx = _parse_block(instructions, idx, {"end_loop"})
    if idx >= len(instructions) or instructions[idx].opname != "end_loop":
        raise ValueError("start_loop/start_micro_loopmissingend_loop")
    end = instructions[idx]
    idx += 1
    return {
        "type": "loop",
        "prelude": prelude,
        "start": start,
        "end": end,
        "body": body,
    }, idx


def _parse_if_chain(
    instructions: List[Instruction],
    idx: int,
) -> Tuple[dict, int]:
    """Parse a flat start_if/start_elif/start_else/.../end_if chain."""

    def _find_if_chain_end(start_idx: int) -> int:
        depth = 1
        scan_idx = start_idx + 1
        while scan_idx < len(instructions):
            opname = instructions[scan_idx].opname
            if opname == "start_if":
                depth += 1
            elif opname == "end_if":
                depth -= 1
                if depth == 0:
                    return scan_idx
            scan_idx += 1
        raise ValueError("start_ifmissingend_if")

    def _parse_range(start_idx: int, end_idx: int) -> List[dict]:
        body, consumed = _parse_block(instructions[start_idx:end_idx], 0, None)
        if consumed != end_idx - start_idx:
            raise ValueError("if-chain body parsing did not fully consume instructions")
        return body

    chain_end = _find_if_chain_end(idx)
    branches = []
    header_idx = idx
    body_start = idx + 1
    nested_if = 0
    nested_loop = 0
    scan_idx = idx + 1
    while scan_idx < chain_end:
        opname = instructions[scan_idx].opname
        if opname in _LOOP_STARTS:
            nested_loop += 1
        elif opname == "end_loop":
            nested_loop -= 1
        elif opname == "start_if":
            nested_if += 1
        elif opname == "end_if":
            nested_if -= 1
        elif opname in ("start_elif", "start_else") and nested_if == 0 and nested_loop == 0:
            branches.append({"start": instructions[header_idx], "body": _parse_range(body_start, scan_idx)})
            header_idx = scan_idx
            body_start = scan_idx + 1
        scan_idx += 1
    branches.append({"start": instructions[header_idx], "body": _parse_range(body_start, chain_end)})
    return {"type": "if", "branches": branches, "end": instructions[chain_end]}, chain_end + 1


def _parse_block(
    instructions: List[Instruction],
    idx: int,
    stop_ops: Optional[Set[str]],
) -> Tuple[List[dict], int]:
    """Parse a flat instruction list into a structured tree of blocks."""
    nodes: List[dict] = []
    while idx < len(instructions) and (stop_ops is None or instructions[idx].opname not in stop_ops):
        inst = instructions[idx]
        # A loop may be preceded by a loop var declaration; keep that with the loop.
        if inst.opname == "create_var" and idx + 1 < len(instructions) and instructions[idx + 1].opname in _LOOP_STARTS:
            loop_var = instructions[idx + 1].kwargs.get("var", None)
            val = inst.kwargs.get("val", None)
            if _same_var(loop_var, val):
                node, idx = _parse_loop_node(instructions, idx, True)
                nodes.append(node)
                continue
        if inst.opname in _LOOP_STARTS:
            node, idx = _parse_loop_node(instructions, idx, False)
            nodes.append(node)
            continue
        if inst.opname == "start_if":
            node, idx = _parse_if_chain(instructions, idx)
            nodes.append(node)
            continue
        nodes.append({"type": "inst", "inst": inst})
        idx += 1
    return nodes, idx


def _emit_instructions(nodes: List[dict]) -> List[Instruction]:
    """Flatten structured nodes back to a linear instruction list."""
    result: List[Instruction] = []
    for node in nodes:
        ntype = node["type"]
        if ntype == "inst":
            result.append(node["inst"])
        elif ntype == "loop":
            prelude = node.get("prelude")
            if prelude is not None:
                result.append(prelude)
            result.append(node["start"])
            result.extend(_emit_instructions(node["body"]))
            result.append(node["end"])
        elif ntype == "if":
            for branch in node["branches"]:
                result.append(branch["start"])
                result.extend(_emit_instructions(branch["body"]))
            result.append(node["end"])
    return result


# ---------------------------
# 1) Empty block pruning
# ---------------------------

def _is_emitting_inst(
    inst: Instruction,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
) -> bool:
    """Check whether an instruction would produce output code."""
    if inst.opname in ("start_loop", "start_micro_loop", "end_loop", "start_if", "start_elif", "start_else", "end_if"):
        return False
    if inst.opname in _NON_CONTENT_OPS:
        return False
    return not should_skip_inst(inst, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names)


def _prune_nodes(
    nodes: List[dict],
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
) -> Tuple[List[dict], bool]:
    """Remove empty loops/if-chains while preserving blocks that emit code."""
    pruned: List[dict] = []
    has_content = False
    for node in nodes:
        ntype = node["type"]
        if ntype == "inst":
            inst = node["inst"]
            if _is_emitting_inst(inst, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names):
                has_content = True
            pruned.append(node)
        elif ntype == "loop":
            body, body_has_content = _prune_nodes(node["body"], tmp_var_names, tmp_tensor_names, tmp_gmtensor_names)
            if not body_has_content:
                continue
            node["body"] = body
            pruned.append(node)
            has_content = True
        elif ntype == "if":
            any_branch_content = False
            new_branches = []
            for branch in node["branches"]:
                body, body_has_content = _prune_nodes(branch["body"], tmp_var_names, tmp_tensor_names, tmp_gmtensor_names)
                branch["body"] = body
                new_branches.append(branch)
                if body_has_content:
                    any_branch_content = True
            if not any_branch_content:
                continue
            node["branches"] = new_branches
            pruned.append(node)
            has_content = True
    return pruned, has_content


def prune_empty_blocks(instructions: List[Instruction]) -> List[Instruction]:
    """
    Remove loops/if-chains that do not emit any code.
    This pass only analyzes structural blocks and does not change semantics.
    """
    _, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names = build_expr_state(instructions)
    nodes, idx = _parse_block(list(instructions), 0, None)
    if idx != len(instructions):
        raise ValueError("instruction block parsing did not fully consume instructions")
    pruned_nodes, _ = _prune_nodes(nodes, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names)
    return _emit_instructions(pruned_nodes)


# ---------------------------
# 2) Unused declaration pruning
# ---------------------------

def _mark_used_from_value(
    value: object,
    used_ids: Set[int],
    tmp_tensor_names: Set[str],
    used_tmp_tensors: Set[str],
    tmp_gmtensor_names: Set[str],
) -> None:
    """Mark objects referenced by instruction operands as used."""
    if isinstance(value, Tensor):
        if value.name in tmp_tensor_names:
            used_tmp_tensors.add(value.name)
            return
        used_ids.add(id(value))
        return
    if isinstance(value, GMTensor):
        if value.name in tmp_gmtensor_names:
            return
        used_ids.add(id(value))
        return
    if isinstance(value, (DBuff, TBuff, QBuff, SEvent, DEvent)):
        used_ids.add(id(value))
        return
    if isinstance(value, dict):
        for item in value.values():
            _mark_used_from_value(item, used_ids, tmp_tensor_names, used_tmp_tensors, tmp_gmtensor_names)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _mark_used_from_value(item, used_ids, tmp_tensor_names, used_tmp_tensors, tmp_gmtensor_names)
        return


def _build_tmp_tensor_sources(
    instructions: List[Instruction],
    tmp_tensor_names: Set[str],
) -> dict[str, object]:
    """Map temporary tensor names to their source DBuff/TBuff/QBuff/Tensor, if any."""
    sources: dict[str, object] = {}
    for inst in instructions:
        if inst.opname == "get_buf":
            out = inst.kwargs.get("out", None)
            if isinstance(out, Tensor) and out.name in tmp_tensor_names:
                sources[out.name] = inst.kwargs.get("buf", None)
        elif inst.opname in ("slice_tensor", "micro_slice_tensor"):
            out = inst.kwargs.get("out", None)
            if isinstance(out, Tensor) and out.name in tmp_tensor_names:
                sources[out.name] = inst.kwargs.get("src", None)
    return sources


def _collect_used_ids(
    instructions: List[Instruction],
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
) -> Set[int]:
    """
    Collect object ids (DBuff/TBuff/QBuff/Tensor/GMTensor/SEvent/DEvent) that are referenced
    by any emitting instruction. This allows us to drop unused create_* decls.
    """
    used_ids: Set[int] = set()
    used_tmp_tensors: Set[str] = set()
    for inst in instructions:
        # Skip declarations; they are the ones we're deciding to keep or remove.
        if inst.opname in ("create_dbuf", "create_tbuf", "create_qbuf", "create_tensor", "create_gm_tensor", "create_sevent", "create_devent"):
            continue
        # Skip tmp-only helper instructions, but preserve their sources.
        if should_skip_inst(inst, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names):
            if inst.opname in ("slice_gm_tensor", "reshape_gm_tensor"):
                src = inst.kwargs.get("src", None)
                if isinstance(src, GMTensor) and src.name not in tmp_gmtensor_names:
                    used_ids.add(id(src))
            continue
        for value in inst.kwargs.values():
            _mark_used_from_value(value, used_ids, tmp_tensor_names, used_tmp_tensors, tmp_gmtensor_names)

    # Propagate usage from temporary tensors to their original buffers.
    sources = _build_tmp_tensor_sources(instructions, tmp_tensor_names)
    pending = list(used_tmp_tensors)
    seen_tmp = set(pending)
    while pending:
        name = pending.pop()
        src = sources.get(name, None)
        if src is None:
            continue
        if isinstance(src, Tensor) and src.name in tmp_tensor_names:
            if src.name not in seen_tmp:
                seen_tmp.add(src.name)
                pending.append(src.name)
            continue
        if isinstance(src, (DBuff, TBuff, QBuff, Tensor, GMTensor, SEvent, DEvent)):
            used_ids.add(id(src))
    return used_ids


def prune_unused_decls(
    instructions: List[Instruction],
    side: Optional[str] = None,
) -> List[Instruction]:
    """
    Remove create_* declarations for objects that are never referenced
    by any emitting instruction in this instruction list.
    """
    _, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names = build_expr_state(instructions)
    _ = tmp_var_names
    used_ids = _collect_used_ids(instructions, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names)
    pruned: List[Instruction] = []
    for inst in instructions:
        if inst.opname in ("create_gm_tensor", "create_sevent", "create_devent") + _LOCAL_DECL_OPS:
            val = inst.kwargs.get("val", None)
            if val is None:
                pruned.append(inst)
                continue
            # Temporary tensors/gmtensors are inlined and should not emit declarations.
            if isinstance(val, Tensor) and val.name in tmp_tensor_names:
                continue
            if isinstance(val, GMTensor) and val.name in tmp_gmtensor_names:
                continue
            if _should_keep_local_decl_for_side(inst, side):
                pruned.append(inst)
                continue
            if id(val) not in used_ids:
                continue
        pruned.append(inst)
    return pruned


# ---------------------------
# 3) Unused Var pruning
# ---------------------------

def _collect_known_var_names(instructions: List[Instruction]) -> Set[str]:
    """Collect all Var names declared in this instruction list."""
    names: Set[str] = set()
    for inst in instructions:
        if inst.opname == "create_var":
            val = inst.kwargs.get("val", None)
            if isinstance(val, Var):
                names.add(val.name)
    return names


def _collect_known_varlist_names(instructions: List[Instruction]) -> Set[str]:
    """Collect all VarList names declared in this instruction list."""
    names: Set[str] = set()
    for inst in instructions:
        if inst.opname == "create_varlist":
            varlist = inst.kwargs.get("varlist", None)
            if isinstance(varlist, VarList):
                names.add(varlist.name)
    return names


def _extract_live_names_from_value(
    value: object,
    known_var_names: Set[str],
    known_varlist_names: Set[str],
    out_vars: Set[str],
    out_varlists: Set[str],
) -> None:
    """Extract live Var / VarList names from a structured operand value."""
    if isinstance(value, VarRef):
        parent = getattr(value, "parent", None)
        if isinstance(parent, VarList) and parent.name in known_varlist_names:
            out_varlists.add(parent.name)
        index = getattr(value, "index", None)
        if index is not None:
            _extract_live_names_from_value(index, known_var_names, known_varlist_names, out_vars, out_varlists)
        return
    if isinstance(value, Var):
        if value.name in known_var_names:
            out_vars.add(value.name)
        return
    if isinstance(value, VarList):
        if value.name in known_varlist_names:
            out_varlists.add(value.name)
        return
    if isinstance(value, Expr):
        for name in _IDENT_RE.findall(value.expr):
            if name in known_var_names:
                out_vars.add(name)
            if name in known_varlist_names:
                out_varlists.add(name)
        return
    if isinstance(value, (Tensor, DBuff, TBuff, QBuff, GMTensor, SEvent, DEvent)):
        return
    if isinstance(value, dict):
        for item in value.values():
            _extract_live_names_from_value(item, known_var_names, known_varlist_names, out_vars, out_varlists)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _extract_live_names_from_value(item, known_var_names, known_varlist_names, out_vars, out_varlists)
        return


def _extract_var_names_from_value(value: object, known_names: Set[str], out: Set[str]) -> None:
    """Extract Var names from a value (Var / Expr / containers)."""
    _extract_live_names_from_value(value, known_names, set(), out, set())


def _extract_varlist_names_from_value(value: object, known_names: Set[str], out: Set[str]) -> None:
    """Extract VarList names from a value (VarRef / Expr / containers)."""
    _extract_live_names_from_value(value, set(), known_names, set(), out)


def _collect_live_names_from_inst(
    inst: Instruction,
    known_var_names: Set[str],
    known_varlist_names: Set[str],
) -> Tuple[Set[str], Set[str]]:
    vars_out: Set[str] = set()
    varlists_out: Set[str] = set()
    for value in inst.kwargs.values():
        _extract_live_names_from_value(
            value,
            known_var_names,
            known_varlist_names,
            vars_out,
            varlists_out,
        )
    return vars_out, varlists_out


def _inst_is_side_specific(inst: Instruction, side: str, classify_inst: ClassifyFn) -> bool:
    """Return True if this instruction is specific to the given side."""
    side_tag = classify_inst(inst)
    return side_tag == side or side_tag == "both"


def _inst_is_material_seed(
    inst: Instruction,
    side: str,
    classify_inst: ClassifyFn,
) -> bool:
    """
    Return True when an instruction should act as a seed/root for var retention.

    We keep dependencies for side-specific instructions that materialize code on the
    current side, but exclude pure declarations, scalar-only assignments, and view
    helpers such as get_buf/slice/reinterpret that should only survive when a later
    material instruction actually consumes them.
    """
    if not _inst_is_side_specific(inst, side, classify_inst):
        return False
    if inst.opname in _NON_SEED_OPS:
        return False
    if inst.opname == "GetValueFrom":
        return True
    if is_assignment_op(inst.opname):
        return False
    return True


def _should_keep_local_decl_for_side(inst: Instruction, side: Optional[str]) -> bool:
    """Keep side-specific local declarations that must remain even if currently unused."""
    if side not in ("cube", "vec"):
        return False
    if inst.opname not in _LOCAL_DECL_OPS:
        return False
    val = inst.kwargs.get("val", None)
    if not isinstance(val, (Tensor, DBuff, TBuff, QBuff)):
        return False
    return val.position in (Position.L1, Position.UB)


def _seed_vars_from_retained_local_decls(
    instructions: List[Instruction],
    known_names: Set[str],
) -> Set[str]:
    """Retained local declarations still need their shape Vars kept alive."""
    used_vars: Set[str] = set()
    for inst in instructions:
        if inst.opname not in _LOCAL_DECL_OPS:
            continue
        shape = inst.kwargs.get("shape", None)
        if shape is None:
            val = inst.kwargs.get("val", None)
            shape = getattr(val, "shape", None)
        _extract_var_names_from_value(shape, known_names, used_vars)
    return used_vars


def _collect_tensor_identity_keys_from_value(
    value: object,
    out: dict[int, Tuple[str, int]],
) -> None:
    """Collect logical identity keys for Tensor objects recursively."""
    if isinstance(value, Tensor):
        key = _tensor_identity_key(value)
        if key is not None:
            out[id(value)] = key
        return
    if isinstance(value, dict):
        for item in value.values():
            _collect_tensor_identity_keys_from_value(item, out)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _collect_tensor_identity_keys_from_value(item, out)
        return


def _build_tensor_identity_map(instructions: List[Instruction]) -> dict[int, Tuple[str, int]]:
    """Map each Tensor object id seen in instructions to its logical alias key."""
    identity_map: dict[int, Tuple[str, int]] = {}
    for inst in instructions:
        for value in inst.kwargs.values():
            _collect_tensor_identity_keys_from_value(value, identity_map)
    return identity_map


def _collect_var_deps(
    instructions: List[Instruction],
    known_var_names: Set[str],
    known_varlist_names: Set[str],
) -> dict[str, Set[str]]:
    """Build a dependency map: out_var -> input_vars plus enclosing control vars."""
    deps: dict[str, Set[str]] = {}
    nodes, idx = _parse_block(list(instructions), 0, None)
    if idx != len(instructions):
        raise ValueError("instruction block parsing did not fully consume instructions")

    def _extract_assignment_inputs(inst: Instruction) -> Set[str]:
        inputs: Set[str] = set()
        if inst.opname in ("CeilDiv", "Min", "Max", "var_mul", "var_div", "var_add", "var_sub", "var_mod"):
            _extract_live_names_from_value(inst.kwargs.get("a", None), known_var_names, known_varlist_names, inputs, set())
            _extract_live_names_from_value(inst.kwargs.get("b", None), known_var_names, known_varlist_names, inputs, set())
        elif inst.opname == "var_assign":
            _extract_live_names_from_value(inst.kwargs.get("src", None), known_var_names, known_varlist_names, inputs, set())
        elif inst.opname in ("scalar_sqrt", "Align8", "Align16", "Align32", "Align64", "Align128", "Align256"):
            _extract_live_names_from_value(inst.kwargs.get("a", None), known_var_names, known_varlist_names, inputs, set())
        return inputs

    def _collect_control_inputs(inst: Instruction) -> Set[str]:
        inputs: Set[str] = set()
        if inst.opname in _LOOP_STARTS:
            var = inst.kwargs.get("var", None)
            if isinstance(var, Var) and var.name in known_var_names:
                inputs.add(var.name)
            _extract_live_names_from_value(inst.kwargs.get("start", None), known_var_names, known_varlist_names, inputs, set())
            _extract_live_names_from_value(inst.kwargs.get("stop", None), known_var_names, known_varlist_names, inputs, set())
            _extract_live_names_from_value(inst.kwargs.get("step", None), known_var_names, known_varlist_names, inputs, set())
        elif inst.opname in ("start_if", "start_elif"):
            _extract_live_names_from_value(inst.kwargs.get("cond", None), known_var_names, known_varlist_names, inputs, set())
        return inputs

    def _walk(block: List[dict], control_inputs: Set[str]) -> None:
        for node in block:
            ntype = node["type"]
            if ntype == "inst":
                inst = node["inst"]
                if not is_assignment_op(inst.opname):
                    continue
                out = inst.kwargs.get("out", None)
                if not isinstance(out, Var):
                    continue
                inputs = _extract_assignment_inputs(inst)
                inputs.update(control_inputs)
                deps.setdefault(out.name, set()).update(inputs)
            elif ntype == "loop":
                loop_inputs = set(control_inputs)
                loop_inputs.update(_collect_control_inputs(node["start"]))
                _walk(node["body"], loop_inputs)
            elif ntype == "if":
                for branch in node["branches"]:
                    branch_inputs = set(control_inputs)
                    branch_inputs.update(_collect_control_inputs(branch["start"]))
                    _walk(branch["body"], branch_inputs)

    _walk(nodes, set())
    return deps


def _collect_seed_usage(
    nodes: List[dict],
    side: str,
    classify_inst: ClassifyFn,
    known_var_names: Set[str],
    known_varlist_names: Set[str],
) -> Tuple[Set[str], Set[str], Set[int], Set[int]]:
    """
    Collect seed usage from blocks that actually emit side-specific code.
    We seed:
      - Vars used directly by side-specific instructions or by the loop/if that
        encloses them.
      - Tensors/GMTensors passed directly to side-specific instructions.
    """
    seed_vars: Set[str] = set()
    seed_varlists: Set[str] = set()
    seed_tensors: Set[int] = set()
    seed_gmtensors: Set[int] = set()

    def _collect_from_value(value: object) -> None:
        if isinstance(value, Tensor):
            seed_tensors.add(id(value))
            return
        if isinstance(value, GMTensor):
            seed_gmtensors.add(id(value))
            return
        if isinstance(value, dict):
            for item in value.values():
                _collect_from_value(item)
            return
        if isinstance(value, (list, tuple, set)):
            for item in value:
                _collect_from_value(item)
            return
        _extract_live_names_from_value(
            value,
            known_var_names,
            known_varlist_names,
            seed_vars,
            seed_varlists,
        )

    def _walk(block: List[dict]) -> Tuple[Set[str], Set[str], bool]:
        block_used: Set[str] = set()
        block_used_varlists: Set[str] = set()
        has_side = False
        for node in block:
            ntype = node["type"]
            if ntype == "inst":
                inst = node["inst"]
                if _inst_is_material_seed(inst, side, classify_inst):
                    has_side = True
                    for value in inst.kwargs.values():
                        _collect_from_value(value)
                        _extract_live_names_from_value(
                            value,
                            known_var_names,
                            known_varlist_names,
                            block_used,
                            block_used_varlists,
                        )
            elif ntype == "loop":
                body_used, body_varlists, body_has = _walk(node["body"])
                if body_has:
                    has_side = True
                    block_used.update(body_used)
                    block_used_varlists.update(body_varlists)
                    start_inst = node["start"]
                    for value in start_inst.kwargs.values():
                        _extract_live_names_from_value(
                            value,
                            known_var_names,
                            known_varlist_names,
                            block_used,
                            block_used_varlists,
                        )
            elif ntype == "if":
                branch_used: Set[str] = set()
                branch_used_varlists: Set[str] = set()
                any_branch = False
                for branch in node["branches"]:
                    used, used_varlists, has = _walk(branch["body"])
                    branch_used.update(used)
                    branch_used_varlists.update(used_varlists)
                    if has:
                        any_branch = True
                if any_branch:
                    has_side = True
                    block_used.update(branch_used)
                    block_used_varlists.update(branch_used_varlists)
                    for branch in node["branches"]:
                        start_inst = branch["start"]
                        for value in start_inst.kwargs.values():
                            _extract_live_names_from_value(
                                value,
                                known_var_names,
                                known_varlist_names,
                                block_used,
                                block_used_varlists,
                            )
        return block_used, block_used_varlists, has_side

    vars_in_blocks, varlists_in_blocks, _ = _walk(nodes)
    seed_vars.update(vars_in_blocks)
    seed_varlists.update(varlists_in_blocks)
    return seed_vars, seed_varlists, seed_tensors, seed_gmtensors


def _build_tensor_defs(
    instructions: List[Instruction],
) -> Tuple[dict[int, Instruction], dict[Tuple[str, int], Instruction]]:
    """Map Tensor ids and logical Tensor aliases to defining instructions."""
    defs_by_id: dict[int, Instruction] = {}
    defs_by_key: dict[Tuple[str, int], Instruction] = {}
    for inst in instructions:
        if inst.opname in ("get_buf", "slice_tensor", "micro_slice_tensor"):
            out = inst.kwargs.get("out", None)
            if isinstance(out, Tensor):
                defs_by_id[id(out)] = inst
                key = _tensor_identity_key(out)
                if key is not None:
                    defs_by_key[key] = inst
        elif inst.opname == "reinterpret":
            out = inst.kwargs.get("dst", None)
            if isinstance(out, Tensor):
                defs_by_id[id(out)] = inst
                key = _tensor_identity_key(out)
                if key is not None:
                    defs_by_key[key] = inst
    return defs_by_id, defs_by_key


def _build_gmtensor_defs(instructions: List[Instruction]) -> dict[int, Instruction]:
    """Map GMTensor id -> defining instruction (slice_gm_tensor / reshape_gm_tensor)."""
    defs: dict[int, Instruction] = {}
    for inst in instructions:
        if inst.opname in ("slice_gm_tensor", "reshape_gm_tensor"):
            out = inst.kwargs.get("out", None)
            if isinstance(out, GMTensor):
                defs[id(out)] = inst
    return defs


def prune_unused_vars(
    instructions: List[Instruction],
    side: str,
    classify_inst: ClassifyFn,
) -> List[Instruction]:
    """
    Remove Vars that do not affect any side-specific instruction.

    Strategy:
      1) Identify seed Vars/Tensors/GMTensors required by side-specific ops.
      2) Propagate Var usage through tensor/gmtensor definitions.
      3) Expand Var usage via Var->Var dependency graph and VarList-touching ops.
      4) Drop unused Var / VarList declarations and dead scalar ops.
      5) Drop unused temp tensor/gmtensor defs (get_buf/slice_*).
    """
    known_var_names = _collect_known_var_names(instructions)
    known_varlist_names = _collect_known_varlist_names(instructions)
    nodes, idx = _parse_block(list(instructions), 0, None)
    if idx != len(instructions):
        raise ValueError("instruction block parsing did not fully consume instructions")
    seed_vars, seed_varlists, seed_tensors, seed_gmtensors = _collect_seed_usage(
        nodes,
        side,
        classify_inst,
        known_var_names,
        known_varlist_names,
    )
    seed_vars.update(_seed_vars_from_retained_local_decls(instructions, known_var_names))

    tensor_identity_map = _build_tensor_identity_map(instructions)
    tensor_defs, tensor_defs_by_key = _build_tensor_defs(instructions)
    gmtensor_defs = _build_gmtensor_defs(instructions)
    used_tensors = set(seed_tensors)
    used_tensor_keys = {tensor_identity_map[tid] for tid in seed_tensors if tid in tensor_identity_map}
    used_gmtensors = set(seed_gmtensors)

    # Walk tensor defs and pull in Vars used by indexing/offsets.
    pending_tensors = list(used_tensors)
    seen_tensors = set(pending_tensors)
    while pending_tensors:
        tid = pending_tensors.pop()
        inst = tensor_defs.get(tid)
        if inst is None:
            key = tensor_identity_map.get(tid)
            if key is not None:
                used_tensor_keys.add(key)
                inst = tensor_defs_by_key.get(key)
        if inst is None:
            continue
        out = inst.kwargs.get("out", None)
        if inst.opname == "reinterpret":
            out = inst.kwargs.get("dst", None)
        if isinstance(out, Tensor):
            used_tensors.add(id(out))
            out_key = _tensor_identity_key(out)
            if out_key is not None:
                used_tensor_keys.add(out_key)
        if inst.opname == "get_buf":
            _extract_live_names_from_value(
                inst.kwargs.get("index", None),
                known_var_names,
                known_varlist_names,
                seed_vars,
                seed_varlists,
            )
        elif inst.opname in ("slice_tensor", "micro_slice_tensor"):
            _extract_live_names_from_value(
                inst.kwargs.get("offset", None),
                known_var_names,
                known_varlist_names,
                seed_vars,
                seed_varlists,
            )
            _extract_live_names_from_value(
                inst.kwargs.get("span", None),
                known_var_names,
                known_varlist_names,
                seed_vars,
                seed_varlists,
            )
            _extract_live_names_from_value(
                inst.kwargs.get("step", None),
                known_var_names,
                known_varlist_names,
                seed_vars,
                seed_varlists,
            )
            src = inst.kwargs.get("src", None)
            if isinstance(src, Tensor):
                sid = id(src)
                if sid not in seen_tensors:
                    seen_tensors.add(sid)
                    pending_tensors.append(sid)
                    used_tensors.add(sid)
                src_key = _tensor_identity_key(src)
                if src_key is not None:
                    used_tensor_keys.add(src_key)
        elif inst.opname == "reinterpret":
            # Reinterpret keeps data view; usage must propagate to the source tensor.
            src = inst.kwargs.get("src", None)
            if isinstance(src, Tensor):
                sid = id(src)
                if sid not in seen_tensors:
                    seen_tensors.add(sid)
                    pending_tensors.append(sid)
                    used_tensors.add(sid)
                src_key = _tensor_identity_key(src)
                if src_key is not None:
                    used_tensor_keys.add(src_key)

    # Walk gmtensor defs and pull in Vars used by offsets/shapes.
    pending_gmtensors = list(used_gmtensors)
    seen_gmtensors = set(pending_gmtensors)
    while pending_gmtensors:
        gid = pending_gmtensors.pop()
        inst = gmtensor_defs.get(gid)
        if inst is None:
            continue
        _extract_live_names_from_value(
            inst.kwargs.get("offset", None),
            known_var_names,
            known_varlist_names,
            seed_vars,
            seed_varlists,
        )
        _extract_live_names_from_value(
            inst.kwargs.get("shape", None),
            known_var_names,
            known_varlist_names,
            seed_vars,
            seed_varlists,
        )
        src = inst.kwargs.get("src", None)
        if isinstance(src, GMTensor):
            sid = id(src)
            if sid not in seen_gmtensors:
                seen_gmtensors.add(sid)
                pending_gmtensors.append(sid)
                used_gmtensors.add(sid)

    # Expand var usage through assignment dependencies.
    deps = _collect_var_deps(instructions, known_var_names, known_varlist_names)
    used_vars = set(seed_vars)
    used_varlists = set(seed_varlists)
    changed = True
    while changed:
        changed = False
        for out_name, inputs in deps.items():
            if out_name in used_vars:
                for name in inputs:
                    if name not in used_vars:
                        used_vars.add(name)
                        changed = True
        for inst in instructions:
            inst_vars, inst_varlists = _collect_live_names_from_inst(inst, known_var_names, known_varlist_names)
            out = inst.kwargs.get("out", None)
            out_live = isinstance(out, Var) and out.name in used_vars
            if not ((inst_varlists & used_varlists) or out_live):
                continue
            for name in inst_varlists:
                if name not in used_varlists:
                    used_varlists.add(name)
                    changed = True
            for name in inst_vars:
                if name not in used_vars:
                    used_vars.add(name)
                    changed = True

    _, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names = build_expr_state(instructions)
    _ = tmp_var_names
    _ = tmp_tensor_names
    _ = tmp_gmtensor_names
    declared_vars = {name for name in known_var_names if name not in tmp_var_names}
    pruned_vars = declared_vars - used_vars
    pruned_varlists = known_varlist_names - used_varlists

    pruned: List[Instruction] = []
    for inst in instructions:
        inst_vars, inst_varlists = _collect_live_names_from_inst(inst, known_var_names, known_varlist_names)
        touches_live_varlist = bool(inst_varlists & used_varlists)
        if inst.opname == "create_varlist":
            varlist = inst.kwargs.get("varlist", None)
            if isinstance(varlist, VarList) and varlist.name in pruned_varlists:
                continue
            pruned.append(inst)
            continue
        if inst.opname == "create_var":
            val = inst.kwargs.get("val", None)
            if isinstance(val, Var) and val.name in pruned_vars:
                continue
        if is_assignment_op(inst.opname):
            if touches_live_varlist:
                pruned.append(inst)
                continue
            if inst_varlists:
                continue
            out = inst.kwargs.get("out", None)
            if isinstance(out, Var) and out.name in pruned_vars:
                continue
        if inst.opname in ("get_buf", "slice_tensor", "micro_slice_tensor"):
            out = inst.kwargs.get("out", None)
            if isinstance(out, Tensor) and id(out) not in used_tensors:
                key = _tensor_identity_key(out)
                if key is not None and key in used_tensor_keys:
                    pruned.append(inst)
                    continue
                continue
        if inst.opname == "reinterpret":
            out = inst.kwargs.get("dst", None)
            if isinstance(out, Tensor) and id(out) not in used_tensors:
                key = _tensor_identity_key(out)
                if key is not None and key in used_tensor_keys:
                    pruned.append(inst)
                    continue
                continue
        if inst.opname in ("slice_gm_tensor", "reshape_gm_tensor"):
            out = inst.kwargs.get("out", None)
            if isinstance(out, GMTensor) and id(out) not in used_gmtensors:
                continue
        pruned.append(inst)
    return pruned
