# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Callable, Dict

from ..helper import CodeHelper
from ..asc_utils import (
    build_offset_expr,
    build_offset_expr_nz,
    build_offset_expr_zz,
    dtype_to_cpp,
    format_binop,
    is_nz_local_position,
    position_to_cpp,
    render_cpp_expr,
    value_to_cpp,
)
from ...utils.instruction import Instruction
from ...utils.Tensor import DBuff, GMTensor, QBuff, TBuff, Tensor
from ...utils.events import SEvent, DEvent
from ...utils.positions import Position
from ...utils.pipe import PipeType
from ...utils.var import Var


Handler = Callable[[Instruction, CodeHelper, Dict[str, str]], None]


def _pipe_name(pipe) -> str:
    return f"PIPE_{pipe}"


def handle_start_auto_sync(inst: Instruction, helper: CodeHelper, expr_map: Dict[str, str]) -> None:
    # helper("// start auto sync")
    ...


def handle_end_auto_sync(inst: Instruction, helper: CodeHelper, expr_map: Dict[str, str]) -> None:
    # helper("// end auto sync")
    ...
