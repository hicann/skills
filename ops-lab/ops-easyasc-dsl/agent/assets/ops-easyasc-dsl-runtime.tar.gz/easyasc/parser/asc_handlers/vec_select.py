from .common import Tensor, dtype_to_cpp, value_to_cpp


def handle_vec_select(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"select requires Tensor type, current type: {type(dst)}")
    selmask = inst.kwargs.get("selmask", None)
    if not isinstance(selmask, Tensor):
        raise TypeError(f"select requires Tensor type for selmask, current type: {type(selmask)}")
    src1 = inst.kwargs.get("src1", None)
    if not isinstance(src1, Tensor):
        raise TypeError(f"select requires Tensor type, current type: {type(src1)}")
    src2 = inst.kwargs.get("src2", None)
    if not isinstance(src2, Tensor):
        raise TypeError(f"select requires Tensor type for src2, current type: {type(src2)}")

    dst_expr = value_to_cpp(dst, expr_map)
    selmask_expr = value_to_cpp(selmask, expr_map)
    src1_expr = value_to_cpp(src1, expr_map)
    src2_expr = value_to_cpp(src2, expr_map)

    mode = inst.kwargs.get("mode", None)
    if mode is None:
        raise ValueError("select requires an explicit mode argument")
    mode_name = value_to_cpp(mode, expr_map)

    repeat = value_to_cpp(inst.kwargs.get("repeat", None), expr_map)
    dst_blk_stride = value_to_cpp(inst.kwargs.get("dst_blk_stride", None), expr_map)
    src1_blk_stride = value_to_cpp(inst.kwargs.get("src1_blk_stride", None), expr_map)
    src2_blk_stride = value_to_cpp(inst.kwargs.get("src2_blk_stride", None), expr_map)
    dst_rep_stride = value_to_cpp(inst.kwargs.get("dst_rep_stride", None), expr_map)
    src1_rep_stride = value_to_cpp(inst.kwargs.get("src1_rep_stride", None), expr_map)
    src2_rep_stride = value_to_cpp(inst.kwargs.get("src2_rep_stride", None), expr_map)
    dst_dtype = dtype_to_cpp(dst.dtype)

    stride_block = (
        f"{{(uint8_t){dst_blk_stride}, (uint8_t){src1_blk_stride}, (uint8_t){src2_blk_stride}, "
        f"(uint8_t){dst_rep_stride}, (uint8_t){src1_rep_stride}, (uint8_t){src2_rep_stride}}}"
    )

    if mode_name == "TENSOR_SCALAR":
        helper(f"SetCmpMask({src2_expr});")
        helper(
            f"Select({dst_expr}, {selmask_expr}, {src1_expr}, {repeat}, {stride_block});"
        )
    elif mode_name == "TENSOR_TENSOR":
        helper(f"SetCmpMask({selmask_expr});")
        helper(
            f"Select<{dst_dtype}, SELMODE::VSEL_{mode_name}_MODE>("
            f"{dst_expr}, {src1_expr}, {src2_expr}, {repeat}, {stride_block});"
        )
    else:
        raise ValueError(f"select mode must be TENSOR_SCALAR or TENSOR_TENSOR, got: {mode_name}")
