# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from .common import Position, Tensor, dtype_to_cpp, value_to_cpp


def handle_reinterpret(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"reinterpret requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"reinterpret requires Tensor type, current type: {type(src)}")
    if src.position is Position.L0C or dst.position is Position.L0C:
        raise ValueError("reinterpret does not support L0C position")
    dst_dtype = dtype_to_cpp(dst.dtype)
    src_expr = value_to_cpp(src, expr_map)
    helper(f"LocalTensor<{dst_dtype}> {dst.name} = {src_expr}.ReinterpretCast<{dst_dtype}>();")
