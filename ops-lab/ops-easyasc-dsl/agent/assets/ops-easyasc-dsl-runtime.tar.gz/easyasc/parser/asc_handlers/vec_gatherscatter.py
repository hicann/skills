from .common import Tensor, value_to_cpp


def handle_vec_gather(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"Gather requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"Gather requires Tensor type, current type: {type(src)}")
    offset = inst.kwargs.get("offset", None)
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    offset_expr = value_to_cpp(offset, expr_map)
    start_idx_expr = value_to_cpp(inst.kwargs.get("start_idx", None), expr_map)
    count = inst.kwargs.get("count", None)
    if count is not None:
        count_expr = value_to_cpp(count, expr_map)
        helper(
            f"Gather({dst_expr}, {src_expr}, {offset_expr}, {start_idx_expr}, {count_expr});"
        )
        return
    repeat = value_to_cpp(inst.kwargs.get("repeat", None), expr_map)
    dst_rep_stride = value_to_cpp(inst.kwargs.get("dst_rep_stride", None), expr_map)
    helper(
        f"Gather({dst_expr}, {src_expr}, {offset_expr}, {start_idx_expr}, "
        f"VECTORFULLMASK, {repeat}, {dst_rep_stride});"
    )


def handle_vec_scatter(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Tensor):
        raise TypeError(f"Scatter requires Tensor type, current type: {type(dst)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"Scatter requires Tensor type, current type: {type(src)}")
    offset = inst.kwargs.get("offset", None)
    dst_expr = value_to_cpp(dst, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    offset_expr = value_to_cpp(offset, expr_map)
    start_idx_expr = value_to_cpp(inst.kwargs.get("start_idx", None), expr_map)
    count = inst.kwargs.get("count", None)
    if count is not None:
        count_expr = value_to_cpp(count, expr_map)
        helper(
            f"Scatter({dst_expr}, {src_expr}, {offset_expr}, {start_idx_expr}, {count_expr});"
        )
        return
    repeat = value_to_cpp(inst.kwargs.get("repeat", None), expr_map)
    src_rep_stride = value_to_cpp(inst.kwargs.get("src_rep_stride", None), expr_map)
    helper(
        f"Scatter({dst_expr}, {src_expr}, {offset_expr}, {start_idx_expr}, "
        f"VECTORFULLMASK, {repeat}, {src_rep_stride});"
    )
