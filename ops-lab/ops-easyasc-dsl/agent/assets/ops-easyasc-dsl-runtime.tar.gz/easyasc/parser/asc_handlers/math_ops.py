# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from .common import Var, dtype_to_cpp, format_binop, value_to_cpp
from ...utils.datatype import DataTypeValue, Datatype


def handle_get_cube_num(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"GetCubeNum requires Var type, current type: {type(out)}")
    helper(f"{out.name} = GetBlockNum();")


def handle_get_cube_idx(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"GetCubeIdx requires Var type, current type: {type(out)}")
    helper(f"{out.name} = get_block_idx();")


def handle_get_vec_num(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"GetVecNum requires Var type, current type: {type(out)}")
    helper(f"{out.name} = GetBlockNum() * 2;")


def handle_get_vec_idx(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"GetVecIdx requires Var type, current type: {type(out)}")
    helper(f"{out.name} = GetBlockIdx();")


def handle_get_sub_block_idx(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"GetSubBlockIdx requires Var type, current type: {type(out)}")
    helper(f"{out.name} = get_subblockid();")


def handle_ceil_div(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"CeilDiv requires Var type, current type: {type(out)}")
    a = value_to_cpp(inst.kwargs.get("a", None), expr_map)
    b = value_to_cpp(inst.kwargs.get("b", None), expr_map)
    helper(f"{out.name} = CeilDiv({a}, {b});")


def handle_min(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"Min requires Var type, current type: {type(out)}")
    a = value_to_cpp(inst.kwargs.get("a", None), expr_map)
    b = value_to_cpp(inst.kwargs.get("b", None), expr_map)
    helper(f"{out.name} = Min({a}, {b});")


def handle_max(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"Max requires Var type, current type: {type(out)}")
    a = value_to_cpp(inst.kwargs.get("a", None), expr_map)
    b = value_to_cpp(inst.kwargs.get("b", None), expr_map)
    helper(f"{out.name} = Max({a}, {b});")


def _handle_align(inst, helper, expr_map, func_name: str, label: str) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"{label}requires Var type, current type: {type(out)}")
    a = value_to_cpp(inst.kwargs.get("a", None), expr_map)
    helper(f"{out.name} = {func_name}({a});")


def handle_align16(inst, helper, expr_map) -> None:
    _handle_align(inst, helper, expr_map, "Align16B", "Align16")


def handle_align8(inst, helper, expr_map) -> None:
    _handle_align(inst, helper, expr_map, "Align8B", "Align8")


def handle_align32(inst, helper, expr_map) -> None:
    _handle_align(inst, helper, expr_map, "Align32B", "Align32")


def handle_align64(inst, helper, expr_map) -> None:
    _handle_align(inst, helper, expr_map, "Align64B", "Align64")


def handle_align128(inst, helper, expr_map) -> None:
    _handle_align(inst, helper, expr_map, "Align128B", "Align128")


def handle_align256(inst, helper, expr_map) -> None:
    _handle_align(inst, helper, expr_map, "Align256B", "Align256")


def handle_scalar_sqrt(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"scalar_sqrt requires Var type, current type: {type(out)}")
    a = value_to_cpp(inst.kwargs.get("a", None), expr_map)
    helper(f"{out.name} = sqrt({a});")


def _rhs_with_float_cast_for_float_left(inst, b_expr: str) -> str:
    left = inst.kwargs.get("a", None)
    if isinstance(left, Var) and left.dtype is Datatype.float:
        return f"(float) {b_expr}"
    return b_expr


def handle_mul(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"var_mul requires Var type, current type: {type(out)}")
    a = value_to_cpp(inst.kwargs.get("a", None), expr_map)
    b = value_to_cpp(inst.kwargs.get("b", None), expr_map)
    b = _rhs_with_float_cast_for_float_left(inst, b)
    helper(f"{out.name} = {format_binop('*', a, b)};")


def handle_div(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"var_div requires Var type, current type: {type(out)}")
    a = value_to_cpp(inst.kwargs.get("a", None), expr_map)
    b = value_to_cpp(inst.kwargs.get("b", None), expr_map)
    b = _rhs_with_float_cast_for_float_left(inst, b)
    helper(f"{out.name} = {format_binop('/', a, b)};")


def handle_add(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"var_add requires Var type, current type: {type(out)}")
    a = value_to_cpp(inst.kwargs.get("a", None), expr_map)
    b = value_to_cpp(inst.kwargs.get("b", None), expr_map)
    b = _rhs_with_float_cast_for_float_left(inst, b)
    helper(f"{out.name} = {format_binop('+', a, b)};")


def handle_sub(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"var_sub requires Var type, current type: {type(out)}")
    a = value_to_cpp(inst.kwargs.get("a", None), expr_map)
    b = value_to_cpp(inst.kwargs.get("b", None), expr_map)
    b = _rhs_with_float_cast_for_float_left(inst, b)
    helper(f"{out.name} = {format_binop('-', a, b)};")


def handle_mod(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"var_mod requires Var type, current type: {type(out)}")
    a = value_to_cpp(inst.kwargs.get("a", None), expr_map)
    b = value_to_cpp(inst.kwargs.get("b", None), expr_map)
    helper(f"{out.name} = {format_binop('%', a, b)};")


def handle_assign(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Var):
        raise TypeError(f"var_assign requires Var out type, current type: {type(out)}")
    if not isinstance(out.dtype, DataTypeValue):
        raise TypeError(f"var_assign requires destination Var dtype, got: {type(out.dtype)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, (Var, int, float)):
        raise TypeError(f"var_assign requires Var/int/float src type, current type: {type(src)}")
    out_expr = value_to_cpp(out, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    dtype = dtype_to_cpp(out.dtype)
    helper(f"{out_expr} = ({dtype}) {src_expr};")
