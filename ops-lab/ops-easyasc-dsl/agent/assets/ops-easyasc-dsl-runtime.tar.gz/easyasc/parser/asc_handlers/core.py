from .common import (
    DBuff,
    GMTensor,
    QBuff,
    TBuff,
    Tensor,
    Var,
    Position,
    build_offset_expr,
    build_offset_expr_nz,
    build_offset_expr_zz,
    dtype_to_cpp,
    format_binop,
    position_to_cpp,
    value_to_cpp,
)
from ...utils.datatype import DataTypeValue, Datatype
from ...utils.reg import Reg, MaskReg, RegList
from ...utils.var import VarList


def handle_create_var(inst, helper, expr_map) -> None:
    val = inst.kwargs.get("val", None)
    if not isinstance(val, Var):
        raise TypeError(f"create_var requires Var type, current type: {type(val)}")
    dtype = dtype_to_cpp(val.dtype)
    init_expr = value_to_cpp(val.value, expr_map)
    helper(f"{dtype} {val.name} = {init_expr};")


def handle_create_varlist(inst, helper, expr_map) -> None:
    _ = expr_map
    varlist = inst.kwargs.get("varlist", None)
    if not isinstance(varlist, VarList):
        raise TypeError(f"create_varlist requires VarList type, current type: {type(varlist)}")
    dtype = dtype_to_cpp(varlist.dtype)
    helper(f"{dtype} {varlist.name}[{varlist.length}] = {{}};")


def handle_get_value_from(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if dst is None:
        dst = inst.kwargs.get("out", None)
    if not isinstance(dst, Var):
        raise TypeError(f"GetValueFrom requires Var dst type, current type: {type(dst)}")
    if not isinstance(dst.dtype, DataTypeValue):
        raise TypeError(f"GetValueFrom requires destination Var dtype, got: {type(dst.dtype)}")
    src = inst.kwargs.get("src", None)
    if isinstance(src, Tensor):
        if src.position is not Position.UB:
            raise ValueError(
                f"GetValueFrom on Tensor only supports UB position, current position: {src.position}"
            )
    elif not isinstance(src, GMTensor):
        raise TypeError(f"GetValueFrom requires Tensor/GMTensor src, current type: {type(src)}")
    src_expr = value_to_cpp(src, expr_map)
    dtype = dtype_to_cpp(dst.dtype)
    helper(f"{dst.name} = ({dtype}) {src_expr}.GetValue(0);")


def handle_set_value_to(inst, helper, expr_map) -> None:
    src = inst.kwargs.get("src", None)
    if isinstance(src, Tensor):
        if src.position is not Position.UB:
            raise ValueError(f"SetValueTo only supports UB Tensor src, current position: {src.position}")
    elif not isinstance(src, GMTensor):
        raise TypeError(f"SetValueTo requires Tensor/GMTensor src type, current type: {type(src)}")
    if not isinstance(src.dtype, DataTypeValue):
        raise TypeError(f"SetValueTo requires Tensor/GMTensor src dtype, got: {type(src.dtype)}")
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, Var):
        raise TypeError(f"SetValueTo requires Var dst type, current type: {type(dst)}")
    if not isinstance(dst.dtype, DataTypeValue):
        raise TypeError(f"SetValueTo requires Var dtype, got: {type(dst.dtype)}")
    src_expr = value_to_cpp(src, expr_map)
    dst_expr = value_to_cpp(dst, expr_map)
    dtype = dtype_to_cpp(src.dtype)
    helper(f"{src_expr}.SetValue(0, ({dtype})({dst_expr}));")


def handle_create_reg(inst, helper, expr_map) -> None:
    reg = inst.kwargs.get("reg", None)
    if not isinstance(reg, Reg):
        raise TypeError(f"create_reg requires Reg type, current type: {type(reg)}")
    dtype = dtype_to_cpp(reg.dtype)
    helper(f"MicroAPI::RegTensor<{dtype}> {reg.name};")


def handle_create_maskreg(inst, helper, expr_map) -> None:
    reg = inst.kwargs.get("reg", None)
    if not isinstance(reg, MaskReg):
        raise TypeError(f"create_maskreg requires MaskReg type, current type: {type(reg)}")
    dtype = dtype_to_cpp(reg.dtype)
    helper(
        f"MicroAPI::MaskReg {reg.name} = "
        f"MicroAPI::CreateMask<{dtype}, MicroAPI::MaskPattern::{reg.init_mode.name}>();"
    )


def handle_create_reglist(inst, helper, expr_map) -> None:
    reglist = inst.kwargs.get("reglist", None)
    if not isinstance(reglist, RegList):
        raise TypeError(f"create_reglist requires RegListtype, current type: {type(reglist)}")
    dtype = dtype_to_cpp(reglist.dtype)
    helper(f"MicroAPI::RegTensor<{dtype}> {reglist.name}[{reglist.length}];")


def handle_create_dbuf(inst, helper, expr_map) -> None:
    val = inst.kwargs.get("val", None)
    if not isinstance(val, DBuff):
        raise TypeError(f"create_dbuf requires DBufftype, current type: {type(val)}")
    dtype = dtype_to_cpp(val.dtype)
    position = position_to_cpp(val.position)
    shape = inst.kwargs.get("shape", None)
    if shape is None:
        shape = getattr(val, "shape", None)
    if not isinstance(shape, (list, tuple)):
        raise TypeError(f"create_dbuf requires shapebelistortuple, current type: {type(shape)}")
    numel_expr = None
    for dim in shape:
        dim_expr = value_to_cpp(dim, expr_map)
        numel_expr = dim_expr if numel_expr is None else format_binop("*", numel_expr, dim_expr)
    if numel_expr is None:
        numel_expr = "0"
    helper(f"DBuff<{dtype}, {position}> {val.name}; {val.name}.Init({numel_expr});")


def handle_create_tbuf(inst, helper, expr_map) -> None:
    val = inst.kwargs.get("val", None)
    if not isinstance(val, TBuff):
        raise TypeError(f"create_tbuf requires TBufftype, current type: {type(val)}")
    dtype = dtype_to_cpp(val.dtype)
    position = position_to_cpp(val.position)
    shape = inst.kwargs.get("shape", None)
    if shape is None:
        shape = getattr(val, "shape", None)
    if not isinstance(shape, (list, tuple)):
        raise TypeError(f"create_tbuf requires shapebelistortuple, current type: {type(shape)}")
    numel_expr = None
    for dim in shape:
        dim_expr = value_to_cpp(dim, expr_map)
        numel_expr = dim_expr if numel_expr is None else format_binop("*", numel_expr, dim_expr)
    if numel_expr is None:
        numel_expr = "0"
    helper(f"TBuff<{dtype}, {position}> {val.name}; {val.name}.Init({numel_expr});")


def handle_create_qbuf(inst, helper, expr_map) -> None:
    val = inst.kwargs.get("val", None)
    if not isinstance(val, QBuff):
        raise TypeError(f"create_qbuf requires QBufftype, current type: {type(val)}")
    dtype = dtype_to_cpp(val.dtype)
    position = position_to_cpp(val.position)
    shape = inst.kwargs.get("shape", None)
    if shape is None:
        shape = getattr(val, "shape", None)
    if not isinstance(shape, (list, tuple)):
        raise TypeError(f"create_qbuf requires shapebelistortuple, current type: {type(shape)}")
    numel_expr = None
    for dim in shape:
        dim_expr = value_to_cpp(dim, expr_map)
        numel_expr = dim_expr if numel_expr is None else format_binop("*", numel_expr, dim_expr)
    if numel_expr is None:
        numel_expr = "0"
    helper(f"QBuff<{dtype}, {position}> {val.name}; {val.name}.Init({numel_expr});")


def handle_create_tensor(inst, helper, expr_map) -> None:
    val = inst.kwargs.get("val", None)
    if not isinstance(val, Tensor):
        raise TypeError(f"create_tensor requires Tensor type, current type: {type(val)}")
    dtype = dtype_to_cpp(val.dtype)
    position = position_to_cpp(val.position)
    shape = inst.kwargs.get("shape", None)
    if shape is None:
        shape = getattr(val, "shape", None)
    if not isinstance(shape, (list, tuple)):
        raise TypeError(f"create_tensor requires shapebelistortuple, current type: {type(shape)}")
    numel_expr = None
    for dim in shape:
        dim_expr = value_to_cpp(dim, expr_map)
        numel_expr = dim_expr if numel_expr is None else format_binop("*", numel_expr, dim_expr)
    if numel_expr is None:
        numel_expr = "0"
    helper(f"LocalTensor<{dtype}> {val.name} = AllocateLocalTensor<{position}, {dtype}>({numel_expr});")


def handle_create_gm_tensor(inst, helper, expr_map) -> None:
    val = inst.kwargs.get("val", None)
    if not isinstance(val, GMTensor):
        raise TypeError(f"create_gm_tensor requires GMTensor type, current type: {type(val)}")
    dtype = dtype_to_cpp(val.dtype)
    helper(f"GlobalTensor<{dtype}> {val.name}; {val.name}.SetGlobalBuffer((__gm__ {dtype}*) {val.name}_);")


def handle_split_workspace(inst, helper, expr_map) -> None:
    dtype = inst.kwargs.get("dtype", None)
    if not isinstance(dtype, DataTypeValue):
        raise TypeError(f"split_workspace expects DataTypeValue, got: {type(dtype)}")
    numel = inst.kwargs.get("numel", None)
    name = inst.kwargs.get("name", None)
    if not isinstance(name, str):
        raise TypeError(f"split_workspace expects name as str, got: {type(name)}")
    dtype_cpp = dtype_to_cpp(dtype)
    numel_cpp = value_to_cpp(numel, expr_map)
    helper(f"auto tmp_{name}_ptr = shiftAddr<{dtype_cpp}>(workspace, {numel_cpp}, _offset);")
    helper(f"GlobalTensor<{dtype_cpp}> {name};")
    helper(f"{name}.SetGlobalBuffer((__gm__ {dtype_cpp}*) tmp_{name}_ptr);")


def handle_get_buf(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Tensor):
        raise TypeError(f"get_buf requires Tensor type, current type: {type(out)}")
    buf = inst.kwargs.get("buf", None)
    if not isinstance(buf, (DBuff, TBuff, QBuff)):
        raise TypeError(f"get_buf requires DBuff/TBuff/QBuff type, current type: {type(buf)}")
    dtype = dtype_to_cpp(out.dtype)
    index = value_to_cpp(inst.kwargs.get("index", None), expr_map)
    helper(f"Tensor<{dtype}> {out.name} = {buf.name}.get({index});")


def handle_slice_gm_tensor(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, GMTensor):
        raise TypeError(f"slice_gm_tensor requires GMTensor type, current type: {type(out)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, GMTensor):
        raise TypeError(f"slice_gm_tensor requires GMTensor type, current type: {type(src)}")
    shape = getattr(out, "shape", None)
    offset = getattr(out, "offset", None)
    offset_expr = build_offset_expr(shape, offset, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    dtype = dtype_to_cpp(out.dtype)
    helper(f"GlobalTensor<{dtype}> {out.name} = {src_expr}[{offset_expr}];")


def handle_reshape_gm_tensor(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, GMTensor):
        raise TypeError(f"reshape_gm_tensor requires GMTensor type, current type: {type(out)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, GMTensor):
        raise TypeError(f"reshape_gm_tensor requires GMTensor type, current type: {type(src)}")
    dtype = dtype_to_cpp(out.dtype)
    src_expr = value_to_cpp(src, expr_map)
    helper(f"GlobalTensor<{dtype}> {out.name} = {src_expr};")


def handle_slice_tensor(inst, helper, expr_map) -> None:
    from ... import globvars

    out = inst.kwargs.get("out", None)
    if not isinstance(out, Tensor):
        raise TypeError(f"slice_tensor requires Tensor type, current type: {type(out)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"slice_tensor requires Tensor type, current type: {type(src)}")
    shape = getattr(out, "shape", None)
    offset = inst.kwargs.get("offset", None)
    use_zz_l1_float = (
        out.position is Position.L1
        and globvars.device_type.startswith('b')
        and out.dtype is Datatype.float
    )
    if use_zz_l1_float:
        offset_expr = render_cpp_expr(build_offset_expr_zz(shape, offset, out.dtype, expr_map))
    elif is_nz_local_position(out.position):
        offset_expr = build_offset_expr_nz(shape, offset, out.dtype, expr_map, position=out.position)
    else:
        offset_expr = build_offset_expr(shape, offset, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    dtype = dtype_to_cpp(out.dtype)
    helper(f"Tensor<{dtype}> {out.name} = {src_expr}[{offset_expr}];")


def handle_micro_slice_tensor(inst, helper, expr_map) -> None:
    out = inst.kwargs.get("out", None)
    if not isinstance(out, Tensor):
        raise TypeError(f"micro_slice_tensor requires Tensor type, current type: {type(out)}")
    src = inst.kwargs.get("src", None)
    if not isinstance(src, Tensor):
        raise TypeError(f"micro_slice_tensor requires Tensor type, current type: {type(src)}")
    shape = getattr(out, "shape", None)
    offset = inst.kwargs.get("offset", None)
    offset_expr = build_offset_expr(shape, offset, expr_map)
    src_expr = value_to_cpp(src, expr_map)
    dtype = dtype_to_cpp(out.dtype)
    helper(f"__ubuf__ {dtype}* {out.name} = {src_expr} + {offset_expr};")
