# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from .common import Var, value_to_cpp


def handle_start_loop(inst, helper, expr_map) -> None:
    var = inst.kwargs.get("var", None)
    if not isinstance(var, Var):
        raise TypeError(f"start_loop requires Var type, current type: {type(var)}")
    start = value_to_cpp(inst.kwargs.get("start", None), expr_map)
    stop = value_to_cpp(inst.kwargs.get("stop", None), expr_map)
    step = value_to_cpp(inst.kwargs.get("step", None), expr_map)
    helper(f"for ({var.name} = {start}; {var.name} < {stop}; {var.name} += {step}) {{")
    helper.ir()


def handle_start_micro_loop(inst, helper, expr_map) -> None:
    var = inst.kwargs.get("var", None)
    if not isinstance(var, Var):
        raise TypeError(f"start_micro_loop requires Var type, current type: {type(var)}")
    start = value_to_cpp(inst.kwargs.get("start", None), expr_map)
    stop = value_to_cpp(inst.kwargs.get("stop", None), expr_map)
    step = value_to_cpp(inst.kwargs.get("step", None), expr_map)
    helper(
        f"for ({var.name} = (uint16_t){start}; {var.name} < (uint16_t){stop}; "
        f"{var.name} += (uint16_t){step}) {{"
    )
    helper.ir()


def handle_end_loop(inst, helper, expr_map) -> None:
    helper.il()
    helper("}")


def handle_break_loop(inst, helper, expr_map) -> None:
    helper("break;")


def handle_continue_loop(inst, helper, expr_map) -> None:
    helper("continue;")


def handle_start_if(inst, helper, expr_map) -> None:
    cond = value_to_cpp(inst.kwargs.get("cond", None), expr_map)
    helper(f"if ({cond}) {{")
    helper.ir()


def handle_start_elif(inst, helper, expr_map) -> None:
    cond = value_to_cpp(inst.kwargs.get("cond", None), expr_map)
    helper.il()
    helper(f"}} else if ({cond}) {{")
    helper.ir()


def handle_start_else(inst, helper, expr_map) -> None:
    helper.il()
    helper("} else {")
    helper.ir()


def handle_end_if(inst, helper, expr_map) -> None:
    helper.il()
    helper("}")
