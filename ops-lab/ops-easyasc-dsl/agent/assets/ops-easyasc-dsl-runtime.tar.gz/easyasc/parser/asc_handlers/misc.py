# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from .common import GMTensor, Tensor, dtype_to_cpp, value_to_cpp
from ...utils.cacheline import DcciDstType, EntireTypeValue


def _cpp_string_literal(value: str) -> str:
    escaped = []
    for ch in value:
        if ch == "\\":
            escaped.append("\\\\")
        elif ch == "\"":
            escaped.append("\\\"")
        elif ch == "\n":
            escaped.append("\\n")
        elif ch == "\t":
            escaped.append("\\t")
        elif ch == "\r":
            escaped.append("\\r")
        else:
            escaped.append(ch)
    return "\"" + "".join(escaped) + "\""


def _value_to_cpp_misc(value, expr_map) -> str:
    if isinstance(value, str):
        return _cpp_string_literal(value)
    return value_to_cpp(value, expr_map)


def handle_reset_cache(inst, helper, expr_map) -> None:
    helper("pipe_ptr->Reset();")
    helper("OccupyMMTE1Events();")


def handle_clean_dcache(inst, helper, expr_map) -> None:
    dst = inst.kwargs.get("dst", None)
    if not isinstance(dst, GMTensor):
        raise TypeError(f"clean_dcache requires GMTensor dst, current type: {type(dst)}")
    entire_type = inst.kwargs.get("entire_type", None)
    if not isinstance(entire_type, EntireTypeValue):
        raise TypeError(
            f"clean_dcache requires EntireTypeValue entire_type, current type: {type(entire_type)}"
        )
    dcci_dst = inst.kwargs.get("dcci_dst", None)
    if not isinstance(dcci_dst, DcciDstType):
        raise TypeError(f"clean_dcache requires DcciDstType dcci_dst, current type: {type(dcci_dst)}")

    dst_dtype = dtype_to_cpp(dst.dtype)
    dst_expr = value_to_cpp(dst, expr_map)
    helper(
        f"DataCacheCleanAndInvalid<{dst_dtype}, AscendC::CacheLine::{entire_type}, "
        f"AscendC::DcciDst::{dcci_dst}>({dst_expr});"
    )


def handle_sim_print(inst, helper, expr_map) -> None:
    _ = inst
    _ = helper
    _ = expr_map


def handle_kernel_print(inst, helper, expr_map) -> None:
    fmt = inst.kwargs.get("fmt", None)
    if not isinstance(fmt, str):
        raise TypeError(f"kernel_print requires str fmt, current type: {type(fmt)}")
    raw_payload = inst.kwargs.get("payload", [])
    if not isinstance(raw_payload, (list, tuple)):
        raise TypeError(f"kernel_print payload must be list/tuple, got: {type(raw_payload)}")
    fmt_expr = _cpp_string_literal(fmt)
    payload_exprs = [_value_to_cpp_misc(item, expr_map) for item in raw_payload]
    if payload_exprs:
        helper(f"printf({fmt_expr}, {', '.join(payload_exprs)});")
        return
    helper(f"printf({fmt_expr});")


def handle_sim_dump_tensor(inst, helper, expr_map) -> None:
    _ = inst
    _ = helper
    _ = expr_map


def handle_kernel_dump_tensor(inst, helper, expr_map) -> None:
    src = inst.kwargs.get("src", None)
    if not isinstance(src, (GMTensor, Tensor)):
        raise TypeError(f"kernel_dump_tensor requires GMTensor/Tensor src, current type: {type(src)}")
    desc = inst.kwargs.get("desc", None)
    dump_size = inst.kwargs.get("dumpSize", None)
    src_expr = value_to_cpp(src, expr_map)
    desc_expr = value_to_cpp(desc, expr_map)
    dump_size_expr = value_to_cpp(dump_size, expr_map)
    helper(f"DumpTensor({src_expr}, (uint32_t) {desc_expr}, (uint32_t) {dump_size_expr});")


def handle_inline(inst, helper, expr_map) -> None:
    _ = expr_map
    code = inst.kwargs.get("code", None)
    if not isinstance(code, str):
        raise TypeError(f"inline requires str code, current type: {type(code)}")
    if code == "":
        helper("")
        return
    for line in code.splitlines():
        helper(line)
