# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from .common import Tensor, Var, dtype_to_cpp, value_to_cpp


def handle_call_micro(inst, helper, expr_map) -> None:
    name = inst.kwargs.get("name", None)
    if not isinstance(name, str):
        raise TypeError(f"call_micro requires namebestrtype, current type: {type(name)}") 
    args = inst.kwargs.get("args", None)
    if args is None:
        args = []
    if not isinstance(args, (list, tuple)):
        raise TypeError(f"call_micro requires argsbelistortuple, current type: {type(args)}") 
    arg_exprs = []
    for arg in args:
        if isinstance(arg, Tensor):
            dtype = dtype_to_cpp(arg.dtype)
            expr = value_to_cpp(arg, expr_map)
            arg_exprs.append(f"(__ubuf__ {dtype}*) ({expr}).GetPhyAddr()")
        elif isinstance(arg, Var):
            arg_exprs.append(value_to_cpp(arg, expr_map))
        else:
            raise TypeError(f"call_micro only supports Tensor or Var parameter, current type: {type(arg)}") 
    helper(f"{name}({', '.join(arg_exprs)});")
