# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from .common import value_to_cpp


def handle_set_mask(inst, helper, expr_map) -> None:
    low = value_to_cpp(inst.kwargs.get("low", None), expr_map)
    high = value_to_cpp(inst.kwargs.get("high", None), expr_map)
    helper(f"SetVectorMask<half, MaskMode::NORMAL>({high}, {low});")


def handle_reset_mask(inst, helper, expr_map) -> None:
    helper("ResetMask();")


def handle_set_mask_count(inst, helper, expr_map) -> None:
    helper("SetMaskCount();")


def handle_set_mask_normal(inst, helper, expr_map) -> None:
    helper("SetMaskNorm();")


def handle_set_mask_counter(inst, helper, expr_map) -> None:
    count = value_to_cpp(inst.kwargs.get("count", None), expr_map)
    helper(f"SetVectorMask<half, MaskMode::COUNTER>({count});")


def handle_set_mask_by_count(inst, helper, expr_map) -> None:
    count = value_to_cpp(inst.kwargs.get("count", None), expr_map)
    helper(f"SetVectorMaskByCount({count});")
