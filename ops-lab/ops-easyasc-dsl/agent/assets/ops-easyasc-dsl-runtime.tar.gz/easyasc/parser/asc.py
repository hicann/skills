import os
import re
import warnings
from functools import lru_cache
from typing import Dict, Iterable, List, Optional, Set, Tuple

from .asc_handlers import build_handlers
from .asc_utils import (
    assignment_expr,
    build_expr_state,
    dtype_to_cpp,
    is_assignment_op,
    is_tmp_var,
    render_cpp_expr,
    should_skip_inst,
    uses_var_in_operands,
    value_to_cpp,
)
from .asc_pruning import (
    _collect_known_var_names,
    _collect_var_deps,
    _extract_live_names_from_value,
    prune_empty_blocks,
    prune_unused_decls,
    prune_unused_vars,
)
from .asc_autosync import insert_auto_sync
from .helper import CodeHelper
from ..utils.instruction import Instruction
from .. import globvars
from ..utils.var import Var
from ..utils.Tensor import Tensor, DBuff, GMTensor, QBuff, TBuff
from ..utils.positions import Position
from rich import box
from rich.align import Align
from rich.console import Console
from rich.table import Table
from rich.text import Text

_EVENT_OPS = {
    "create_sevent",
    "create_devent",
    "event_set",
    "event_wait",
    "event_setall",
    "event_release",
}
_EVENT_CREATE_OPS = {"create_sevent", "create_devent"}
_EVENT_SWAP_OPS = {"event_set", "event_wait"}
_CUBE_PIPE_OPS = {"allcube_ready", "allcube_wait", "cube_ready", "wait_vec"}
_VEC_PIPE_OPS = {"allvec_ready", "allvec_wait", "vec_ready", "wait_cube"}
_VEC_ONLY_SCALAR_OPS = {"GetVecNum", "GetVecIdx", "GetSubBlockIdx"}
_PIPE_CUBE_NAMES = {"M", "FIX", "MTE1"}
_PIPE_VEC_NAMES = {"V", "MTE3"}
_INSTRUCTION_RE = re.compile(r"Instruction\(\s*['\"]([A-Za-z0-9_]+)['\"]")
_BLOCK_FORBIDDEN_OPS = {
    "create_gm_tensor",
    "create_tensor",
    "create_dbuf",
    "create_tbuf",
    "create_qbuf",
    "create_devent",
    "create_sevent",
}
_IF_STARTS = ("start_if", "start_elif", "start_else")
_LOOP_STARTS = ("start_loop", "start_micro_loop")
_SCOPE_ENTER_OPS = {"enter_vec_scope": "vec", "enter_cube_scope": "cube"}
_SCOPE_END_OPS = {"end_vec_scope": "vec", "end_cube_scope": "cube"}
_HELPER_VIEW_OUT_KEYS = {
    "get_buf": "out",
    "slice_tensor": "out",
    "micro_slice_tensor": "out",
    "slice_gm_tensor": "out",
    "reshape_gm_tensor": "out",
    "reinterpret": "dst",
}


def _collect_opnames_from_file(path: str) -> Set[str]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except OSError:
        return set()
    return set(_INSTRUCTION_RE.findall(text))


def _collect_opnames_from_dir(path: str) -> Set[str]:
    names: Set[str] = set()
    for root, _, files in os.walk(path):
        for filename in files:
            if filename.endswith(".py"):
                names |= _collect_opnames_from_file(os.path.join(root, filename))
    return names


@lru_cache(maxsize=1)
def _get_stub_opnames() -> Tuple[Set[str], Set[str]]:
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    cube_path = os.path.join(base_dir, "stub_functions", "cube.py")
    vec_dir = os.path.join(base_dir, "stub_functions", "vec")
    cube_ops = _collect_opnames_from_file(cube_path)
    vec_ops = _collect_opnames_from_dir(vec_dir)
    handler_map = build_handlers()
    for opname, handler in handler_map.items():
        module = getattr(handler, "__module__", "")
        if ".vec_" in module:
            vec_ops.add(opname)
        elif module.endswith(".cube"):
            cube_ops.add(opname)
    return cube_ops, vec_ops


def _event_sides(event: object) -> Tuple[bool, bool]:
    if event is None:
        return False, False
    pipes = []
    src = getattr(event, "src_pipe", None)
    dst = getattr(event, "dst_pipe", None)
    if src is not None:
        pipes.append(src)
    if dst is not None:
        pipes.append(dst)
    cube_side = any(str(pipe) in _PIPE_CUBE_NAMES for pipe in pipes)
    vec_side = any(str(pipe) in _PIPE_VEC_NAMES for pipe in pipes)
    return cube_side, vec_side


def _value_sides(value: object) -> Tuple[bool, bool]:
    if isinstance(value, GMTensor):
        return True, True
    if isinstance(value, Tensor):
        if value.position is Position.UB:
            return False, True
        if value.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C):
            return True, False
        return True, True
    if isinstance(value, dict):
        cube_side = False
        vec_side = False
        for item in value.values():
            cube_item, vec_item = _value_sides(item)
            cube_side = cube_side or cube_item
            vec_side = vec_side or vec_item
        return cube_side, vec_side
    if isinstance(value, (list, tuple, set)):
        cube_side = False
        vec_side = False
        for item in value:
            cube_item, vec_item = _value_sides(item)
            cube_side = cube_side or cube_item
            vec_side = vec_side or vec_item
        return cube_side, vec_side
    return False, False


def _warn_unscoped_set_value_to(idx: int) -> None:
    warnings.warn(
        f"SetValueTo at instruction {idx} is not limited by vec_scope()/cube_scope(); "
        "a GMTensor target will be emitted to both cube and vec sides.",
        UserWarning,
        stacklevel=2,
    )


def _validate_set_value_to_side(
    inst: Instruction,
    target_side: str,
    idx: int,
    scope_info: Optional[Tuple[int, str]] = None,
) -> None:
    if inst.opname != "SetValueTo" or target_side != "cube":
        return
    src = inst.kwargs.get("src", None)
    if isinstance(src, GMTensor):
        return
    if isinstance(src, Tensor):
        scope_suffix = ""
        if scope_info is not None:
            start_idx, start_opname = scope_info
            scope_suffix = f" inside {start_opname} started at instruction {start_idx}"
        raise ValueError(
            f"Instruction 'SetValueTo' at instruction {idx} targets cube side{scope_suffix}, "
            "but cube-side SetValueTo only supports GMTensor src"
        )
    raise TypeError(f"SetValueTo requires Tensor/GMTensor src type, current type: {type(src)}")


def _infer_vec_control_vars(instructions: List[Instruction]) -> Set[str]:
    known_var_names = _collect_known_var_names(instructions)
    if not known_var_names:
        return set()
    vec_control_vars: Set[str] = set()
    for inst in instructions:
        if inst.opname not in _VEC_ONLY_SCALAR_OPS:
            continue
        out = inst.kwargs.get("out", None)
        if isinstance(out, Var) and out.name in known_var_names:
            vec_control_vars.add(out.name)
    if not vec_control_vars:
        return vec_control_vars
    deps = _collect_var_deps(instructions, known_var_names, set())
    changed = True
    while changed:
        changed = False
        for out_name, inputs in deps.items():
            if out_name in vec_control_vars:
                continue
            if inputs & vec_control_vars:
                vec_control_vars.add(out_name)
                changed = True
    return vec_control_vars


def _control_inst_is_vec_only(
    inst: Instruction,
    vec_control_vars: Set[str],
    known_var_names: Set[str],
) -> bool:
    if not vec_control_vars:
        return False
    inputs: Set[str] = set()
    if inst.opname in _LOOP_STARTS:
        var = inst.kwargs.get("var", None)
        if isinstance(var, Var) and var.name in known_var_names:
            inputs.add(var.name)
        _extract_live_names_from_value(inst.kwargs.get("start", None), known_var_names, set(), inputs, set())
        _extract_live_names_from_value(inst.kwargs.get("stop", None), known_var_names, set(), inputs, set())
        _extract_live_names_from_value(inst.kwargs.get("step", None), known_var_names, set(), inputs, set())
    elif inst.opname in ("start_if", "start_elif"):
        _extract_live_names_from_value(inst.kwargs.get("cond", None), known_var_names, set(), inputs, set())
    return bool(inputs & vec_control_vars)


def _build_vec_control_scope_map(instructions: List[Instruction]) -> Dict[int, str]:
    known_var_names = _collect_known_var_names(instructions)
    vec_control_vars = _infer_vec_control_vars(instructions)
    scope_map: Dict[int, str] = {}
    if not vec_control_vars:
        return scope_map
    if_stack: List[Dict[str, object]] = []
    for inst in instructions:
        opname = inst.opname
        if opname in _LOOP_STARTS:
            scope_map[id(inst)] = "vec" if _control_inst_is_vec_only(inst, vec_control_vars, known_var_names) else "both"
            continue
        if opname == "start_if":
            side = "vec" if _control_inst_is_vec_only(inst, vec_control_vars, known_var_names) else "both"
            frame: Dict[str, object] = {"side": side, "starts": [id(inst)]}
            if_stack.append(frame)
            scope_map[id(inst)] = side
            continue
        if opname == "start_elif":
            if not if_stack:
                continue
            frame = if_stack[-1]
            starts = frame.setdefault("starts", [])
            if isinstance(starts, list):
                starts.append(id(inst))
            if _control_inst_is_vec_only(inst, vec_control_vars, known_var_names):
                frame["side"] = "vec"
            side = str(frame.get("side", "both"))
            for start_id in starts if isinstance(starts, list) else []:
                scope_map[start_id] = side
            continue
        if opname == "start_else":
            if not if_stack:
                continue
            frame = if_stack[-1]
            starts = frame.setdefault("starts", [])
            if isinstance(starts, list):
                starts.append(id(inst))
            side = str(frame.get("side", "both"))
            for start_id in starts if isinstance(starts, list) else []:
                scope_map[start_id] = side
            continue
        if opname == "end_if" and if_stack:
            if_stack.pop()
    return scope_map


def _describe_split_var_reference(inst: Instruction) -> str:
    if inst.opname in ("start_if", "start_elif"):
        cond = inst.kwargs.get("cond", None)
        return f"condition {cond!s}"
    if inst.opname in _LOOP_STARTS:
        start = inst.kwargs.get("start", None)
        stop = inst.kwargs.get("stop", None)
        step = inst.kwargs.get("step", None)
        return f"loop bounds start={start!s}, stop={stop!s}, step={step!s}"
    return f"operands of {inst.opname!r}"


def _collect_control_inst_inputs(inst: Instruction, known_var_names: Set[str]) -> Set[str]:
    inputs: Set[str] = set()
    if inst.opname in _LOOP_STARTS:
        var = inst.kwargs.get("var", None)
        if isinstance(var, Var) and var.name in known_var_names:
            inputs.add(var.name)
        _extract_live_names_from_value(inst.kwargs.get("start", None), known_var_names, set(), inputs, set())
        _extract_live_names_from_value(inst.kwargs.get("stop", None), known_var_names, set(), inputs, set())
        _extract_live_names_from_value(inst.kwargs.get("step", None), known_var_names, set(), inputs, set())
        return inputs
    if inst.opname in ("start_if", "start_elif"):
        _extract_live_names_from_value(inst.kwargs.get("cond", None), known_var_names, set(), inputs, set())
    return inputs


def _collect_written_local_var_names(inst: Instruction, known_var_names: Set[str]) -> Set[str]:
    written: Set[str] = set()
    if inst.opname == "GetValueFrom":
        dst = inst.kwargs.get("dst", None)
        if isinstance(dst, Var) and dst.name in known_var_names:
            written.add(dst.name)
        return written
    if not is_assignment_op(inst.opname):
        return written
    out = inst.kwargs.get("out", None)
    if isinstance(out, Var) and out.name in known_var_names:
        written.add(out.name)
    return written


def _validate_side_local_var_references(
    instructions: List[Instruction],
    side: str,
    original_instructions: List[Instruction],
    original_local_var_names: Set[str],
    original_tmp_var_names: Set[str],
) -> None:
    tracked_local_vars = {
        name for name in original_local_var_names if name not in original_tmp_var_names
    }
    if not tracked_local_vars:
        return
    retained_local_vars = _collect_known_var_names(instructions)
    original_inst_index_by_id = {id(inst): idx for idx, inst in enumerate(original_instructions)}
    original_write_indices: Dict[str, List[int]] = {}
    retained_write_indices: Dict[str, List[int]] = {}
    for inst in original_instructions:
        original_idx = original_inst_index_by_id[id(inst)]
        for name in _collect_written_local_var_names(inst, tracked_local_vars):
            original_write_indices.setdefault(name, []).append(original_idx)
    for inst in instructions:
        original_idx = original_inst_index_by_id.get(id(inst), -1)
        if original_idx < 0:
            continue
        for name in _collect_written_local_var_names(inst, tracked_local_vars):
            retained_write_indices.setdefault(name, []).append(original_idx)
    for idx, inst in enumerate(instructions):
        referenced_vars: Set[str] = set()
        for value in inst.kwargs.values():
            _extract_live_names_from_value(
                value,
                tracked_local_vars,
                set(),
                referenced_vars,
                set(),
            )
        missing_vars = sorted(name for name in referenced_vars if name not in retained_local_vars)
        if not missing_vars:
            control_inputs = _collect_control_inst_inputs(inst, tracked_local_vars)
            if not control_inputs:
                continue
            original_idx = original_inst_index_by_id.get(id(inst), -1)
            if original_idx < 0:
                continue
            stale_inputs: List[str] = []
            for name in sorted(control_inputs):
                original_prior_writes = original_write_indices.get(name, [])
                retained_prior_writes = retained_write_indices.get(name, [])
                if not any(write_idx < original_idx for write_idx in original_prior_writes):
                    continue
                if any(write_idx < original_idx for write_idx in retained_prior_writes):
                    continue
                stale_inputs.append(name)
            if not stale_inputs:
                continue
            missing_text = ", ".join(repr(name) for name in stale_inputs)
            detail = _describe_split_var_reference(inst)
            raise ValueError(
                f"Side-split inconsistency on {side} side at instruction {idx} ({inst.opname}): "
                f"{detail} depends on local Var(s) {missing_text}, but no retained writer reaches this control point "
                f"on the {side} side. This usually means a cross-side scalar dependency leaked into shared control flow."
            )
        missing_text = ", ".join(repr(name) for name in missing_vars)
        detail = _describe_split_var_reference(inst)
        raise ValueError(
            f"Side-split inconsistency on {side} side at instruction {idx} ({inst.opname}): "
            f"{detail} references local Var(s) {missing_text}, but they were pruned from this side. "
            "This usually means a cross-side scalar dependency leaked into shared control flow."
        )


def _current_forced_side(
    explicit_scope_stack: List[Tuple[str, int, str]],
    control_scope_stack: List[Tuple[str, int, str, str]],
    idx: int,
    opname: str,
) -> Optional[Tuple[str, int, str]]:
    explicit = explicit_scope_stack[-1] if explicit_scope_stack else None
    vec_control = None
    for frame in reversed(control_scope_stack):
        if frame[0] == "vec":
            vec_control = frame
            break
    if explicit is not None and explicit[0] == "cube" and vec_control is not None:
        _, start_idx, start_opname, _ = vec_control
        raise ValueError(
            f"Instruction {opname!r} at instruction {idx} is inside cube scope but also depends on vec-only control flow "
            f"from {start_opname} started at instruction {start_idx}"
        )
    if explicit is not None:
        return explicit
    if vec_control is not None:
        side, start_idx, start_opname, _ = vec_control
        return side, start_idx, start_opname
    return None


def _helper_output_value(inst: Instruction) -> Optional[object]:
    out_key = _HELPER_VIEW_OUT_KEYS.get(inst.opname, None)
    if out_key is None:
        return None
    out = inst.kwargs.get(out_key, None)
    if inst.opname in ("slice_gm_tensor", "reshape_gm_tensor"):
        return out if isinstance(out, GMTensor) else None
    return out if isinstance(out, Tensor) else None


def _defined_var_name(inst: Instruction) -> Optional[str]:
    if inst.opname == "create_var":
        val = inst.kwargs.get("val", None)
        return val.name if isinstance(val, Var) else None
    if is_assignment_op(inst.opname):
        out = inst.kwargs.get("out", None)
        return out.name if isinstance(out, Var) else None
    return None


def _iter_instruction_input_values(inst: Instruction) -> Iterable[object]:
    skip_keys: Set[str] = set()
    helper_out_key = _HELPER_VIEW_OUT_KEYS.get(inst.opname, None)
    if helper_out_key is not None:
        skip_keys.add(helper_out_key)
    if inst.opname == "create_var":
        skip_keys.add("val")
    if is_assignment_op(inst.opname):
        skip_keys.add("out")
    if inst.opname in _LOOP_STARTS:
        skip_keys.add("var")
    for key, value in inst.kwargs.items():
        if key in skip_keys:
            continue
        yield value


def _collect_helper_output_ids_from_value(
    value: object,
    helper_output_ids: Set[int],
    out: Set[int],
) -> None:
    if isinstance(value, (Tensor, GMTensor)):
        value_id = id(value)
        if value_id in helper_output_ids:
            out.add(value_id)
        return
    if isinstance(value, dict):
        for item in value.values():
            _collect_helper_output_ids_from_value(item, helper_output_ids, out)
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _collect_helper_output_ids_from_value(item, helper_output_ids, out)
        return


def _merge_side(existing: Optional[str], new: str) -> str:
    if existing is None or existing == new:
        return new
    if existing == "both" or new == "both":
        return "both"
    return "both"


def _control_side_from_flags(cube_has: bool, vec_has: bool) -> Optional[str]:
    if cube_has and vec_has:
        return "both"
    if cube_has:
        return "cube"
    if vec_has:
        return "vec"
    return None


def _inst_emits_material_for_control(inst: Instruction, cube_ops: Set[str], vec_ops: Set[str]) -> bool:
    if inst.opname in _LOOP_STARTS or inst.opname in ("end_loop", "start_if", "start_elif", "start_else", "end_if"):
        return False
    if inst.opname in _SCOPE_ENTER_OPS or inst.opname in _SCOPE_END_OPS:
        return False
    if inst.opname in (
        "create_var",
        "create_varlist",
        "create_gm_tensor",
        "create_tensor",
        "create_dbuf",
        "create_tbuf",
        "create_qbuf",
        "create_sevent",
        "create_devent",
        "inline",
        "reset_cache",
        "start_auto_sync",
        "end_auto_sync",
    ):
        return False
    if is_assignment_op(inst.opname):
        return False
    if inst.opname in _HELPER_VIEW_OUT_KEYS:
        return False
    return _classify_inst_base(inst, cube_ops, vec_ops) in ("cube", "vec", "both")


def _build_control_consumer_side_map(
    instructions: List[Instruction],
    cube_ops: Set[str],
    vec_ops: Set[str],
    vec_control_scope_map: Dict[int, str],
) -> Dict[int, str]:
    side_map: Dict[int, str] = {}
    stack: List[Dict[str, object]] = []

    def _push_control(kind: str, inst: Instruction) -> None:
        forced = vec_control_scope_map.get(id(inst), None)
        stack.append(
            {
                "kind": kind,
                "start_ids": [id(inst)],
                "cube": forced == "cube",
                "vec": forced == "vec",
            }
        )

    def _pop_control(kind: str) -> None:
        if not stack or stack[-1].get("kind") != kind:
            return
        frame = stack.pop()
        side = _control_side_from_flags(bool(frame.get("cube")), bool(frame.get("vec")))
        if side is None:
            return
        for start_id in frame.get("start_ids", []):
            if isinstance(start_id, int):
                side_map[start_id] = side

    for inst in instructions:
        opname = inst.opname
        if opname in _LOOP_STARTS:
            _push_control("loop", inst)
            continue
        if opname == "start_if":
            _push_control("if", inst)
            continue
        if opname in ("start_elif", "start_else"):
            if not stack or stack[-1].get("kind") != "if":
                continue
            frame = stack[-1]
            start_ids = frame.setdefault("start_ids", [])
            if isinstance(start_ids, list):
                start_ids.append(id(inst))
            forced = vec_control_scope_map.get(id(inst), None)
            if forced == "cube":
                frame["cube"] = True
            elif forced == "vec":
                frame["vec"] = True
            continue
        if opname == "end_loop":
            _pop_control("loop")
            continue
        if opname == "end_if":
            _pop_control("if")
            continue
        if not _inst_emits_material_for_control(inst, cube_ops, vec_ops):
            continue
        side = _classify_inst_base(inst, cube_ops, vec_ops)
        for frame in stack:
            if side in ("cube", "both"):
                frame["cube"] = True
            if side in ("vec", "both"):
                frame["vec"] = True

    return side_map


def _classify_inst_base(inst: Instruction, cube_ops: Set[str], vec_ops: Set[str]) -> str:
    opname = inst.opname
    if opname == "SetValueTo":
        src = inst.kwargs.get("src", None)
        if isinstance(src, Tensor):
            return "vec"
        if isinstance(src, GMTensor):
            return "both"
        return "both"
    if opname == "GetValueFrom":
        src = inst.kwargs.get("src", None)
        if isinstance(src, Tensor):
            return "vec"
        if isinstance(src, GMTensor):
            return "both"
        return "both"
    if opname == "sim_dump_tensor":
        pipe_name = str(inst.kwargs.get("pipe", ""))
        if pipe_name in ("MTE1", "M", "FIX"):
            return "cube"
        if pipe_name in ("V", "MTE3"):
            return "vec"
        if pipe_name in ("MTE2", "S"):
            return "both"
        return "both"
    if opname == "kernel_dump_tensor":
        src = inst.kwargs.get("src", None)
        if isinstance(src, GMTensor):
            return "both"
        if isinstance(src, Tensor):
            if src.position is Position.UB:
                return "vec"
            if src.position in (Position.L1, Position.L0C):
                return "cube"
            return "both"
        return "both"
    if opname == "kernel_print":
        cube_side = False
        vec_side = False
        for value in inst.kwargs.values():
            cube_item, vec_item = _value_sides(value)
            cube_side = cube_side or cube_item
            vec_side = vec_side or vec_item
        if cube_side and not vec_side:
            return "cube"
        if vec_side and not cube_side:
            return "vec"
        return "both"
    if opname == "clean_dcache":
        mode = inst.kwargs.get("mode", "all")
        if mode == "vec":
            return "vec"
        if mode == "cube":
            return "cube"
        return "both"
    if opname in _CUBE_PIPE_OPS:
        return "cube"
    if opname in _VEC_PIPE_OPS:
        return "vec"
    if opname in _VEC_ONLY_SCALAR_OPS:
        return "vec"
    if opname in _EVENT_OPS:
        event = inst.kwargs.get("event")
        if event is None:
            event = inst.kwargs.get("val")
        cube_side, vec_side = _event_sides(event)
        if cube_side and not vec_side:
            return "cube"
        if vec_side and not cube_side:
            return "vec"
        return "both"
    if opname in cube_ops and opname not in vec_ops:
        return "cube"
    if opname in vec_ops and opname not in cube_ops:
        return "vec"
    if opname in cube_ops or opname in vec_ops:
        return "both"
    if opname in ("setflag", "waitflag"):
        pipes = []
        src = inst.kwargs.get("src", None)
        dst = inst.kwargs.get("dst", None)
        if src is not None:
            pipes.append(src)
        if dst is not None:
            pipes.append(dst)
        cube_side = any(str(pipe) in _PIPE_CUBE_NAMES for pipe in pipes)
        vec_side = any(str(pipe) in _PIPE_VEC_NAMES for pipe in pipes)
        if cube_side and not vec_side:
            return "cube"
        if vec_side and not cube_side:
            return "vec"
        return "both"
    return "both"


def _infer_side_routed_outputs(
    instructions: List[Instruction],
    cube_ops: Set[str],
    vec_ops: Set[str],
    control_consumer_side_map: Dict[int, str],
) -> Tuple[Dict[int, str], Dict[str, str]]:
    known_var_names = _collect_known_var_names(instructions)
    helper_output_ids: Set[int] = set()
    for inst in instructions:
        out = _helper_output_value(inst)
        if out is not None:
            helper_output_ids.add(id(out))

    helper_output_sides: Dict[int, str] = {}
    var_output_sides: Dict[str, str] = {}

    for inst in reversed(instructions):
        if inst.opname in _LOOP_STARTS or inst.opname in _IF_STARTS:
            base_side = control_consumer_side_map.get(id(inst), None)
        else:
            base_side = _classify_inst_base(inst, cube_ops, vec_ops)

        helper_out = _helper_output_value(inst)
        out_name = None if helper_out is not None else _defined_var_name(inst)
        consumer_side: Optional[str]
        if helper_out is not None:
            consumer_side = helper_output_sides.get(id(helper_out), None)
        elif out_name is not None:
            consumer_side = var_output_sides.get(out_name, None)
        else:
            consumer_side = base_side

        if consumer_side is None:
            continue

        helper_input_ids: Set[int] = set()
        used_vars: Set[str] = set()
        for value in _iter_instruction_input_values(inst):
            _collect_helper_output_ids_from_value(value, helper_output_ids, helper_input_ids)
            _extract_live_names_from_value(
                value,
                known_var_names,
                set(),
                used_vars,
                set(),
            )

        for helper_id in helper_input_ids:
            helper_output_sides[helper_id] = _merge_side(
                helper_output_sides.get(helper_id, None),
                consumer_side,
            )
        for var_name in used_vars:
            var_output_sides[var_name] = _merge_side(
                var_output_sides.get(var_name, None),
                consumer_side,
            )

    return helper_output_sides, var_output_sides


def _classify_inst(
    inst: Instruction,
    cube_ops: Set[str],
    vec_ops: Set[str],
    helper_output_sides: Optional[Dict[int, str]] = None,
    var_output_sides: Optional[Dict[str, str]] = None,
) -> str:
    if helper_output_sides is not None:
        helper_out = _helper_output_value(inst)
        if helper_out is not None:
            side = helper_output_sides.get(id(helper_out), None)
            if side is not None:
                return side
    if var_output_sides is not None:
        out_name = _defined_var_name(inst)
        if out_name is not None:
            side = var_output_sides.get(out_name, None)
            if side is not None:
                return side
    return _classify_inst_base(inst, cube_ops, vec_ops)


def split_instructions(instructions: Iterable[Instruction]) -> Tuple[List[Instruction], List[Instruction]]:
    instructions = list(instructions)
    original_local_var_names = _collect_known_var_names(instructions)
    _, original_tmp_var_names, _, _ = build_expr_state(instructions)
    cube_ops, vec_ops = _get_stub_opnames()
    vec_control_scope_map = _build_vec_control_scope_map(instructions)
    control_consumer_side_map = _build_control_consumer_side_map(
        instructions,
        cube_ops,
        vec_ops,
        vec_control_scope_map,
    )
    helper_output_sides, var_output_sides = _infer_side_routed_outputs(
        instructions,
        cube_ops,
        vec_ops,
        control_consumer_side_map,
    )
    cube_insts: List[Instruction] = []
    vec_insts: List[Instruction] = []
    explicit_scope_stack: List[Tuple[str, int, str]] = []
    control_scope_stack: List[Tuple[str, int, str, str]] = []

    def _emit_with_current_forcing(inst: Instruction, idx: int, side: str) -> bool:
        forced = _current_forced_side(explicit_scope_stack, control_scope_stack, idx, inst.opname)
        if forced is None:
            return False
        forced_side, start_idx, start_opname = forced
        _validate_set_value_to_side(inst, forced_side, idx, (start_idx, start_opname))
        if forced_side == "vec":
            if side == "cube":
                raise ValueError(
                    f"Instruction {inst.opname!r} at instruction {idx} is cube-only inside "
                    f"{start_opname} started at instruction {start_idx}"
                )
            vec_insts.append(inst)
            return True
        if side == "vec":
            raise ValueError(
                f"Instruction {inst.opname!r} at instruction {idx} is vec-only inside "
                f"{start_opname} started at instruction {start_idx}"
            )
        cube_insts.append(inst)
        return True

    for idx, inst in enumerate(instructions):
        opname = inst.opname
        enter_side = _SCOPE_ENTER_OPS.get(opname, None)
        if enter_side is not None:
            explicit_scope_stack.append((enter_side, idx, opname))
            continue
        end_side = _SCOPE_END_OPS.get(opname, None)
        if end_side is not None:
            if not explicit_scope_stack:
                raise ValueError(f"{opname} at instruction {idx} has no matching scope start")
            start_side, start_idx, start_opname = explicit_scope_stack.pop()
            if start_side != end_side:
                raise ValueError(
                    f"{opname} at instruction {idx} closes {end_side} scope, "
                    f"but the active scope started with {start_opname} at instruction {start_idx}"
                )
            continue

        if opname in _LOOP_STARTS:
            control_side = control_consumer_side_map.get(id(inst), vec_control_scope_map.get(id(inst), "both"))
            control_scope_stack.append((control_side, idx, opname, "loop"))
            if _emit_with_current_forcing(inst, idx, "both"):
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            continue
        if opname == "end_loop":
            if not control_scope_stack or control_scope_stack[-1][3] != "loop":
                raise ValueError(f"{opname} at instruction {idx} has no matching loop start")
            if _emit_with_current_forcing(inst, idx, "both"):
                control_scope_stack.pop()
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            control_scope_stack.pop()
            continue
        if opname in ("break_loop", "continue_loop"):
            if _emit_with_current_forcing(inst, idx, "both"):
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            continue
        if opname == "start_if":
            control_side = control_consumer_side_map.get(id(inst), vec_control_scope_map.get(id(inst), "both"))
            control_scope_stack.append((control_side, idx, opname, "if"))
            if _emit_with_current_forcing(inst, idx, "both"):
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            continue
        if opname in ("start_elif", "start_else"):
            if not control_scope_stack or control_scope_stack[-1][3] != "if":
                raise ValueError(f"{opname} at instruction {idx} has no matching if start")
            control_side = control_consumer_side_map.get(
                id(inst),
                vec_control_scope_map.get(id(inst), control_scope_stack[-1][0]),
            )
            _, start_idx, start_opname, kind = control_scope_stack[-1]
            control_scope_stack[-1] = (control_side, start_idx, start_opname, kind)
            if _emit_with_current_forcing(inst, idx, "both"):
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            continue
        if opname == "end_if":
            if not control_scope_stack or control_scope_stack[-1][3] != "if":
                raise ValueError(f"{opname} at instruction {idx} has no matching if start")
            if _emit_with_current_forcing(inst, idx, "both"):
                control_scope_stack.pop()
                continue
            cube_insts.append(inst)
            vec_insts.append(inst)
            control_scope_stack.pop()
            continue

        side = _classify_inst(inst, cube_ops, vec_ops, helper_output_sides, var_output_sides)
        forced = _current_forced_side(explicit_scope_stack, control_scope_stack, idx, opname)
        if forced is None and inst.opname == "SetValueTo" and side == "both":
            _warn_unscoped_set_value_to(idx)
        if _emit_with_current_forcing(inst, idx, side):
            continue

        if side in ("cube", "both"):
            _validate_set_value_to_side(inst, "cube", idx)
        if side in ("cube", "both"):
            cube_insts.append(inst)
        if side in ("vec", "both"):
            vec_insts.append(inst)

    if explicit_scope_stack:
        side, start_idx, start_opname = explicit_scope_stack[-1]
        raise ValueError(
            f"{start_opname} at instruction {start_idx} is not closed before the instruction stream ends"
        )
    if control_scope_stack:
        _, start_idx, start_opname, _ = control_scope_stack[-1]
        raise ValueError(
            f"{start_opname} at instruction {start_idx} is not closed before the instruction stream ends"
        )

    def _classify_for_prune(inst: Instruction) -> str:
        return _classify_inst(inst, cube_ops, vec_ops, helper_output_sides, var_output_sides)

    cube_insts = prune_empty_blocks(cube_insts)
    vec_insts = prune_empty_blocks(vec_insts)
    cube_insts = prune_unused_decls(cube_insts, "cube")
    vec_insts = prune_unused_decls(vec_insts, "vec")
    cube_insts = prune_unused_vars(cube_insts, "cube", _classify_for_prune)
    vec_insts = prune_unused_vars(vec_insts, "vec", _classify_for_prune)
    cube_insts = prune_unused_decls(cube_insts, "cube")
    vec_insts = prune_unused_decls(vec_insts, "vec")
    cube_insts = prune_empty_blocks(cube_insts)
    vec_insts = prune_empty_blocks(vec_insts)
    _validate_side_local_var_references(
        cube_insts,
        "cube",
        instructions,
        original_local_var_names,
        original_tmp_var_names,
    )
    _validate_side_local_var_references(
        vec_insts,
        "vec",
        instructions,
        original_local_var_names,
        original_tmp_var_names,
    )
    return cube_insts, vec_insts


def _event_creation_signature(inst: Instruction) -> Optional[Tuple[str, str, str, str, bool]]:
    if inst.opname not in _EVENT_CREATE_OPS:
        return None
    val = inst.kwargs.get("val", None)
    if val is None:
        raise ValueError(f"{inst.opname} requires 'val' in kwargs")
    name = getattr(val, "name", None)
    if not isinstance(name, str) or not name:
        raise ValueError(f"{inst.opname} requires event name, current value: {name!r}")
    src_pipe = str(getattr(val, "src_pipe", None))
    dst_pipe = str(getattr(val, "dst_pipe", None))
    preset = bool(getattr(val, "preset", False))
    return name, inst.opname, src_pipe, dst_pipe, preset


def eliminate_duplicated_event_creation(instructions: Iterable[Instruction]) -> List[Instruction]:
    deduped: List[Instruction] = []
    seen_by_name: Dict[str, Tuple[str, str, str, bool]] = {}
    for inst in instructions:
        signature = _event_creation_signature(inst)
        if signature is None:
            deduped.append(inst)
            continue
        name, opname, src_pipe, dst_pipe, preset = signature
        current_signature = (opname, src_pipe, dst_pipe, preset)
        previous_signature = seen_by_name.get(name, None)
        if previous_signature is None:
            seen_by_name[name] = current_signature
            deduped.append(inst)
            continue
        if previous_signature != current_signature:
            raise ValueError(
                f"Conflicting event creation for {name!r}: "
                f"{previous_signature!r} vs {current_signature!r}"
            )
    return deduped


def _next_emit_index(
    instructions: List[Instruction],
    start_idx: int,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
) -> int:
    idx = start_idx
    while idx < len(instructions) and should_skip_inst(
        instructions[idx],
        tmp_var_names,
        tmp_tensor_names,
        tmp_gmtensor_names,
    ):
        idx += 1
    return idx


def _try_swap_create_var_with_event(
    instructions: List[Instruction],
    idx: int,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
) -> bool:
    inst = instructions[idx]
    if inst.opname != "create_var":
        return False
    next_idx = _next_emit_index(
        instructions,
        idx + 1,
        tmp_var_names,
        tmp_tensor_names,
        tmp_gmtensor_names,
    )
    if next_idx >= len(instructions):
        return False
    next_inst = instructions[next_idx]
    if next_inst.opname not in _EVENT_SWAP_OPS:
        return False
    instructions[idx], instructions[next_idx] = instructions[next_idx], instructions[idx]
    return True


def _try_fold_loop(
    instructions: List[Instruction],
    idx: int,
    expr_map: dict,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
    helper: CodeHelper,
) -> int:
    inst = instructions[idx]
    if inst.opname != "create_var":
        return -1
    val = inst.kwargs.get("val", None)
    if not isinstance(val, Var) or is_tmp_var(val):
        return -1
    next_idx = _next_emit_index(
        instructions,
        idx + 1,
        tmp_var_names,
        tmp_tensor_names,
        tmp_gmtensor_names,
    )
    if next_idx >= len(instructions):
        return -1
    next_inst = instructions[next_idx]
    if next_inst.opname not in _LOOP_STARTS:
        return -1
    loop_var = next_inst.kwargs.get("var", None)
    if not isinstance(loop_var, Var) or loop_var.name != val.name:
        return -1
    start = value_to_cpp(next_inst.kwargs.get("start", None), expr_map)
    stop = value_to_cpp(next_inst.kwargs.get("stop", None), expr_map)
    step = value_to_cpp(next_inst.kwargs.get("step", None), expr_map)
    if next_inst.opname == "start_micro_loop":
        helper(
            f"for (uint16_t {val.name} = (uint16_t){start}; "
            f"{val.name} < (uint16_t){stop}; {val.name} += (uint16_t){step}) {{"
        )
    else:
        dtype = dtype_to_cpp(val.dtype)
        helper(f"for ({dtype} {val.name} = {start}; {val.name} < {stop}; {val.name} += {step}) {{")
    helper.ir()
    return next_idx + 1


def _try_fold_decl_assign(
    instructions: List[Instruction],
    idx: int,
    expr_map: dict,
    tmp_var_names: Set[str],
    tmp_tensor_names: Set[str],
    tmp_gmtensor_names: Set[str],
    helper: CodeHelper,
) -> int:
    inst = instructions[idx]
    if inst.opname != "create_var":
        return -1
    val = inst.kwargs.get("val", None)
    if not isinstance(val, Var) or is_tmp_var(val):
        return -1
    next_idx = _next_emit_index(
        instructions,
        idx + 1,
        tmp_var_names,
        tmp_tensor_names,
        tmp_gmtensor_names,
    )
    if next_idx >= len(instructions):
        return -1
    next_inst = instructions[next_idx]
    if not is_assignment_op(next_inst.opname):
        return -1
    out = next_inst.kwargs.get("out", None)
    if not isinstance(out, Var) or out.name != val.name:
        return -1
    if uses_var_in_operands(next_inst, val.name):
        return -1
    dtype = dtype_to_cpp(val.dtype)
    expr = render_cpp_expr(assignment_expr(next_inst, expr_map))
    helper(f"{dtype} {val.name} = {expr};")
    return next_idx + 1


def validate(instructions: Iterable[Instruction]) -> None:
    loop_depth = 0
    if_depth = 0
    for idx, inst in enumerate(instructions):
        op = inst.opname
        if op in _LOOP_STARTS:
            loop_depth += 1
        elif op == "end_loop":
            if loop_depth > 0:
                loop_depth -= 1
        elif op in _IF_STARTS:
            if_depth += 1
        elif op == "end_if":
            if if_depth > 0:
                if_depth -= 1
        if op in _BLOCK_FORBIDDEN_OPS and (loop_depth > 0 or if_depth > 0):
            if loop_depth > 0 and if_depth > 0:
                scope = "loop/if"
            elif loop_depth > 0:
                scope = "loop"
            else:
                scope = "if/elif/else"
            raise ValueError(f"{op} cannot be inside {scope} block (index {idx}).")


def translate(instructions: Iterable[Instruction]) -> str:
    instructions = list(instructions)
    validate(instructions)
    expr_map, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names = build_expr_state(instructions)
    helper = CodeHelper()
    handlers = build_handlers()
    unhandled = []
    seen = set()
    idx = 0
    while idx < len(instructions):
        inst = instructions[idx]
        if should_skip_inst(inst, tmp_var_names, tmp_tensor_names, tmp_gmtensor_names):
            idx += 1
            continue
        if _try_swap_create_var_with_event(
            instructions,
            idx,
            tmp_var_names,
            tmp_tensor_names,
            tmp_gmtensor_names,
        ):
            continue
        folded = _try_fold_loop(
            instructions,
            idx,
            expr_map,
            tmp_var_names,
            tmp_tensor_names,
            tmp_gmtensor_names,
            helper,
        )
        if folded != -1:
            idx = folded
            continue
        folded = _try_fold_decl_assign(
            instructions,
            idx,
            expr_map,
            tmp_var_names,
            tmp_tensor_names,
            tmp_gmtensor_names,
            helper,
        )
        if folded != -1:
            idx = folded
            continue
        handler = handlers.get(inst.opname)
        if handler is not None:
            handler(inst, helper, expr_map)
        else:
            opname = inst.opname
            if opname not in seen:
                seen.add(opname)
                unhandled.append(opname)
        idx += 1
    if unhandled:
        helper(f"// Untranslated instructions: {', '.join(unhandled)}")
    return str(helper)


def translate_split(instructions: Iterable[Instruction], name: Optional[str] = None) -> Tuple[str, str]:
    cube_insts, vec_insts = split_instructions(instructions)
    # print('inserting auto sync instructions...')
    cube_insts = insert_auto_sync(cube_insts, mode='cube')
    cube_insts = eliminate_duplicated_event_creation(cube_insts)
    analyze_usage(cube_insts, f"{name}_cube" if name else None)
    # print('auto sync instructions inserted cuebe side.')
    vec_insts = insert_auto_sync(vec_insts, mode='vec')
    vec_insts = eliminate_duplicated_event_creation(vec_insts)
    analyze_usage(vec_insts, f"{name}_vec" if name else None)
    # print('auto sync instructions inserted vec side.')
    return translate(cube_insts), translate(vec_insts)


def analyze_usage(instructions: Iterable[Instruction], label: Optional[str] = None) -> None:
    table_width = 50
    cap_map = {
        "L1": globvars.l1_cap,
        "L0A": globvars.l0a_cap,
        "L0B": globvars.l0b_cap,
        "L0C": globvars.l0c_cap,
        "UB": globvars.ub_cap,
    }
    mode = None
    if label:
        if label.endswith("_cube"):
            mode = "cube"
        elif label.endswith("_vec"):
            mode = "vec"
    device_type = globvars.device_type or ""
    allowed_positions = None
    if device_type.startswith("b"):
        if mode == "cube":
            allowed_positions = ["L1", "L0C"]
        elif mode == "vec":
            allowed_positions = ["UB"]
    elif device_type.startswith("950"):
        if mode == "cube":
            allowed_positions = ["L1", "L0C", "UB"]
        elif mode == "vec":
            allowed_positions = ["UB", "L1"]

    def _fmt_num(value: float):
        if isinstance(value, float) and value.is_integer():
            return int(value)
        return value

    def _make_reset_line(width: int) -> str:
        text = "reset cache"
        content = f" {text} "
        if len(content) >= width:
            return content[:width]
        pad = width - len(content)
        left = pad // 2
        right = pad - left
        return "-" * left + content + "-" * right

    def _make_label_line(text: str, width: int) -> str:
        content = f" {text} "
        if len(content) >= width:
            return content[:width]
        pad = width - len(content)
        left = pad // 2
        right = pad - left
        return "-" * left + content + "-" * right

    def _emit_shape(val, pos_order, grouped, totals) -> None:
        if not isinstance(val, (Tensor, DBuff, TBuff, QBuff)):
            return
        shape_values = []
        for dim in val.shape:
            if isinstance(dim, Var):
                shape_values.append(dim.value)
            else:
                shape_values.append(dim)
        if isinstance(val, Tensor):
            label = "(Tensor)"
            label_style = "bright_cyan"
        elif isinstance(val, DBuff):
            label = "(DBuff)"
            label_style = "blue"
        elif isinstance(val, TBuff):
            label = "(TBuff)"
            label_style = "magenta"
        else:
            label = "(QBuff)"
            label_style = "bright_magenta"
        size_kb = "UNKNOWN KB"
        size_kb_value = None
        if len(shape_values) >= 2:
            dim0, dim1 = shape_values[0], shape_values[1]
            if isinstance(dim0, (int, float)) and isinstance(dim1, (int, float)):
                elem_size = getattr(val.dtype, "size", None)
                if isinstance(elem_size, (int, float)):
                    scale = 1
                    if isinstance(val, DBuff):
                        scale = 2
                    elif isinstance(val, TBuff):
                        scale = 3
                    elif isinstance(val, QBuff):
                        scale = 4
                    size_kb_value = (dim0 * dim1 * elem_size * scale) / 1024
                else:
                    size_kb_value = (dim0 * dim1) / 1024
                size_kb = f"{_fmt_num(size_kb_value)} KB"
        line = Text.assemble(
            (label, label_style),
            (" ", "white"),
            (val.name, "white"),
            (": ", "white"),
            (size_kb, "white"),
        )
        pos_label = str(getattr(val, "position", "UNKNOWN"))
        if allowed_positions is not None and pos_label not in allowed_positions:
            return
        if pos_label not in grouped:
            grouped[pos_label] = []
            if allowed_positions is None:
                pos_order.append(pos_label)
        grouped[pos_label].append(line)
        if size_kb_value is not None:
            totals[pos_label] = totals.get(pos_label, 0.0) + float(size_kb_value)

    def _print_table(console, pos_order, grouped, totals) -> None:
        table = Table(show_header=False, box=box.ASCII, width=table_width)
        table.add_column(justify="center")
        for pos_idx, pos_label in enumerate(pos_order):
            if pos_idx:
                table.add_section()
            table.add_row(Text(f"Position: {pos_label}", style="bright_green"))
            used_value = totals.get(pos_label, None)
            cap_value = cap_map.get(pos_label, None)
            used_str = "UNKNOWN" if used_value is None else str(_fmt_num(used_value))
            cap_str = "UNKNOWN" if cap_value is None else str(cap_value)
            for line in grouped.get(pos_label, []):
                table.add_row(line)
            table.add_row(Text(f"Usage: {used_str} KB / {cap_str} KB", style="bright_yellow"))
        console.print(Align.center(table))

    blocks: List[Tuple[str, object]] = []
    pos_order: List[str] = []
    grouped: dict[str, List[Text]] = {}
    totals: dict[str, float] = {}

    def _snapshot_table():
        if allowed_positions is not None:
            return ([pos for pos in allowed_positions if pos in grouped], grouped, totals)
        return (pos_order, grouped, totals)

    for inst in instructions:
        if inst.opname == "reset_cache":
            if grouped:
                blocks.append(("table", _snapshot_table()))
            blocks.append(("reset", None))
            pos_order = []
            grouped = {}
            totals = {}
            continue
        if inst.opname not in ("create_tensor", "create_dbuf", "create_tbuf", "create_qbuf"):
            continue
        _emit_shape(inst.kwargs.get("val", None), pos_order, grouped, totals)

    if grouped:
        blocks.append(("table", _snapshot_table()))

    if not any(kind == "table" for kind, _ in blocks):
        return

    console = Console()
    if label:
        label_width = table_width + 40
        label_line = Text(_make_label_line(label, label_width), style="bright_cyan")
        console.print(Align.center(label_line))

    pending_reset = False
    for kind, payload in blocks:
        if kind == "reset":
            pending_reset = True
            continue
        if pending_reset:
            reset_line = Text(_make_reset_line(table_width), style="bright_magenta")
            console.print(Align.center(reset_line))
            pending_reset = False
        pos_order, grouped, totals = payload  # type: ignore[misc]
        _print_table(console, pos_order, grouped, totals)
