# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Dict, Iterable, List, Optional, Set, Tuple, Literal, Union
from functools import lru_cache

from .asc_utils import build_expr_state, should_skip_inst
from ..utils.events import DEvent, SEvent
from .asc_handlers import build_handlers
from ..utils.Tensor import Tensor
from ..utils.instruction import Instruction
from ..utils.pipe import Pipe, PipeType
from ..utils.sync_key import SyncKey, SyncKeyGroup, collect_tensor_sync_keys, normalize_sync_key_group
from .. import globvars


_AUTO_SYNC_START = "start_auto_sync"
_AUTO_SYNC_END = "end_auto_sync"
_EXPLICIT_VEC_OPNAMES = {
    "abs",
    "add",
    "adds",
    "axpy",
    "brcb",
    "call_micro",
    "cadd",
    "cast",
    "cgadd",
    "cgmax",
    "cgmin",
    "cmax",
    "cmin",
    "compare",
    "compare_scalar",
    "cpadd",
    "div",
    "dup",
    "exp",
    "gather",
    "gm_to_ub_pad",
    "ln",
    "lrelu",
    "mergesort4",
    "mergesort_2seq",
    "mul",
    "muladddst",
    "muls",
    "rec",
    "relu",
    "reset_mask",
    "rsqrt",
    "scatter",
    "select",
    "set_atomic_type",
    "set_mask",
    "sort32",
    "sqrt",
    "sub",
    "ub_to_l1_nz",
    "ub_to_l1_nd2nz",
    "ub_to_gm_pad",
    "ub_to_ub",
    "vand",
    "vmax",
    "vmaxs",
    "vmin",
    "vmins",
    "vnot",
    "vor",
}


@lru_cache(maxsize=1)
def get_pipe_opnames() -> Dict[str, Set[str]]:
    pipe_opnames: Dict[str, Set[str]] = {
        str(Pipe.MTE2): {"gm_to_l1_nd2nz", "set_constant_to_l1", "gm_to_ub_pad"},
        str(Pipe.MTE1): {"l1_to_l0"},
        str(Pipe.M): {"mmad"},
        str(Pipe.FIX): {"l0c_to_gm_nz2nd", "l0c_to_l1", "l0c_to_ub"},
        str(Pipe.MTE3): {"ub_to_gm_pad", "ub_to_l1_nd2nz", "ub_to_l1_nz"},
    }
    vec_pipe_ops = set(_EXPLICIT_VEC_OPNAMES)
    for opnames in pipe_opnames.values():
        vec_pipe_ops -= opnames
    pipe_opnames[str(Pipe.V)] = vec_pipe_ops
    return pipe_opnames


PIPE_OPNAMES = get_pipe_opnames()
_PIPE_NAME_TO_TYPE: Dict[str, PipeType] = {
    str(Pipe.MTE2): Pipe.MTE2,
    str(Pipe.MTE1): Pipe.MTE1,
    str(Pipe.M): Pipe.M,
    str(Pipe.FIX): Pipe.FIX,
    str(Pipe.MTE3): Pipe.MTE3,
    str(Pipe.V): Pipe.V,
}
_OPNAME_TO_PIPE: Dict[str, PipeType] = {
    opname: _PIPE_NAME_TO_TYPE[pipe_name]
    for pipe_name, opnames in PIPE_OPNAMES.items()
    if pipe_name in _PIPE_NAME_TO_TYPE
    for opname in opnames
}
_EVENT_TYPES = (SEvent, DEvent)
_VEC_READ_FIELDS = ("src", "src1", "src2", "selmask", "offset", "idx")


def _collect_region_pipes(instructions: List[Instruction]) -> Set[PipeType]:
    used: Set[PipeType] = set()
    for inst in instructions:
        if not isinstance(inst, Instruction):
            continue
        pipe = _OPNAME_TO_PIPE.get(inst.opname)
        if pipe is not None:
            used.add(pipe)
    return used


def _is_b_device() -> bool:
    device_type = str(getattr(globvars, "device_type", "")).lower()
    return device_type.startswith("b")


def _collect_tensor_keys_from_fields(inst: Instruction, fields: Iterable[str]) -> Set[SyncKey]:
    keys: Set[SyncKey] = set()
    for field in fields:
        keys.update(collect_tensor_sync_keys(inst.kwargs.get(field, None)))
    return keys


def _collect_vec_read_keys(inst: Instruction) -> Set[SyncKey]:
    if inst.opname == "call_micro":
        return set(inst.kwargs.get("read_sync_keys", ()))
    return _collect_tensor_keys_from_fields(inst, _VEC_READ_FIELDS)


def _collect_vec_write_keys(inst: Instruction) -> Set[SyncKey]:
    if inst.opname == "call_micro":
        return set(inst.kwargs.get("write_sync_keys", ()))
    return collect_tensor_sync_keys(inst.kwargs.get("dst", None))


def _is_vec_barrier(inst: Instruction) -> bool:
    return inst.opname == "barrier" and str(inst.kwargs.get("pipe", "")) == str(Pipe.V)


def _insert_b_device_vec_barriers(instructions: List[Instruction]) -> List[Instruction]:
    if not _is_b_device():
        return instructions

    pending_reads: Set[SyncKey] = set()
    pending_writes: Set[SyncKey] = set()
    result: List[Instruction] = []
    for inst in instructions:
        if _is_vec_barrier(inst):
            pending_reads.clear()
            pending_writes.clear()
            result.append(inst)
            continue

        inst_pipe = _OPNAME_TO_PIPE.get(inst.opname)
        if inst_pipe is Pipe.V:
            read_keys = _collect_vec_read_keys(inst)
            write_keys = _collect_vec_write_keys(inst)
            has_raw = pending_writes and pending_writes.intersection(read_keys)
            has_war = pending_reads and pending_reads.intersection(write_keys)
            has_waw = pending_writes and pending_writes.intersection(write_keys)
            if has_raw or has_war or has_waw:
                result.append(Instruction("barrier", pipe=Pipe.V))
                pending_reads.clear()
                pending_writes.clear()
            result.append(inst)
            pending_reads.update(read_keys)
            pending_writes.update(write_keys)
            continue

        result.append(inst)
    return result


class AutosyncNode:
    def __init__(self, instructions: List[Instruction], src_pipe: PipeType, dst_pipe: PipeType,
                             producer_src: bool, producer_dst: bool, consumer_src: bool, consumer_dst: bool, 
                             buf_name: str):
        self.insts = list(instructions)
        self.new_insts: List[Union[Instruction, "AutosyncNode"]] = []
        self.src_pipe = src_pipe
        self.dst_pipe = dst_pipe
        self.producer_src = producer_src
        self.producer_dst = producer_dst
        self.consumer_src = consumer_src
        self.consumer_dst = consumer_dst
        self.buf_idx = 0
        self.buf_name = buf_name
        self.events_to_be_created: List[str] = []
        self.has_inst = False
        self.is_mixed_scope = False
        self.is_single_buffer = False 
        self.used_pipes: Set[PipeType] = set()
        self.local_sync_keys: Set[SyncKey] = set()
        self.sync_key: Optional[SyncKeyGroup] = None
        self.local_pending_valid_carry_events: Dict[str, Union[SEvent, DEvent]] = {}
        self.pending_valid_carry_events: Dict[str, Union[SEvent, DEvent]] = {}
        self.pre_process()
        self.summarize_used_pipes()

    def _configure_sync_event(self, event: Union[SEvent, DEvent], is_valid: bool) -> None:
        if is_valid:
            event.src_pipe = self.dst_pipe
            event.dst_pipe = self.src_pipe
            event.preset = True
            event.idx = 9999
        else:
            event.src_pipe = self.src_pipe
            event.dst_pipe = self.dst_pipe
            event.preset = False
            event.idx = 9998

    def _registry_sync_key(self) -> SyncKeyGroup:
        if self.sync_key is not None:
            return self.sync_key
        return (("scope", self.buf_name, str(id(self))),)

    def assign_buf_indices(self, key_registry: Optional[Dict[SyncKeyGroup, int]] = None):
        if key_registry is None:
            key_registry = {}
        if self.is_mixed_scope:
            sync_key = self._registry_sync_key()
            if sync_key not in key_registry:
                key_registry[sync_key] = len(key_registry)
            self.buf_idx = key_registry[sync_key]
        for inst in self.new_insts:
            if isinstance(inst, AutosyncNode):
                inst.assign_buf_indices(key_registry)
        return self 

    def _collect_inst_sync_keys(self, inst: Instruction, pipe: Optional[PipeType]) -> Set[SyncKey]:
        if pipe is None:
            return set()
        if inst.opname == "call_micro":
            if pipe == self.src_pipe:
                if self.src_pipe == Pipe.V:
                    return set(inst.kwargs.get("write_sync_keys", ()))
                return set(inst.kwargs.get("read_sync_keys", ()))
            if pipe == self.dst_pipe:
                if self.dst_pipe == Pipe.V:
                    return set(inst.kwargs.get("read_sync_keys", ()))
                return set(inst.kwargs.get("write_sync_keys", ()))
            return set()

        if pipe == self.src_pipe:
            if pipe in (Pipe.MTE2, Pipe.MTE1, Pipe.V, Pipe.M):
                return collect_tensor_sync_keys(inst.kwargs.get("dst", None))
            return set()

        if pipe == self.dst_pipe:
            if pipe == Pipe.M:
                keys = set()
                keys.update(collect_tensor_sync_keys(inst.kwargs.get("src_a", None)))
                keys.update(collect_tensor_sync_keys(inst.kwargs.get("src_b", None)))
                return keys
            if pipe in (Pipe.V, Pipe.MTE1, Pipe.FIX, Pipe.MTE3):
                return collect_tensor_sync_keys(inst.kwargs.get("src", None))
            return set()

        return set()

    def summarize_used_pipes(self):
        used = self.used_pipes
        op_to_pipe = _OPNAME_TO_PIPE
        src_pipe = self.src_pipe
        dst_pipe = self.dst_pipe
        producer_src = self.producer_src
        producer_dst = self.producer_dst
        consumer_src = self.consumer_src
        consumer_dst = self.consumer_dst
        is_single_buffer = self.is_single_buffer
        for inst in self.new_insts:
            if isinstance(inst, AutosyncNode):
                if inst.used_pipes:
                    used.update(inst.used_pipes)
                if inst.is_single_buffer:
                    is_single_buffer = True
                continue
            if not isinstance(inst, Instruction):
                continue
            pipe = op_to_pipe.get(inst.opname)
            if pipe is not None and pipe in [self.src_pipe, self.dst_pipe]:
                used.add(pipe)
                self.has_inst = True
                self.local_sync_keys.update(self._collect_inst_sync_keys(inst, pipe))
                if pipe == src_pipe:
                    if producer_src:
                        src = inst.kwargs.get("src")
                        if isinstance(src, Tensor):
                            source_buf = src.source_buf
                            if source_buf is None or isinstance(source_buf, Tensor):
                                is_single_buffer = True
                    if not is_single_buffer and producer_dst:
                        dst = inst.kwargs.get("dst")
                        if isinstance(dst, Tensor):
                            source_buf = dst.source_buf
                            if source_buf is None or isinstance(source_buf, Tensor):
                                is_single_buffer = True
                elif pipe == dst_pipe:
                    if consumer_src:
                        src = inst.kwargs.get("src")
                        if isinstance(src, Tensor):
                            source_buf = src.source_buf
                            if source_buf is None or isinstance(source_buf, Tensor):
                                is_single_buffer = True
                    if not is_single_buffer and consumer_dst:
                        dst = inst.kwargs.get("dst")
                        if isinstance(dst, Tensor):
                            source_buf = dst.source_buf
                            if source_buf is None or isinstance(source_buf, Tensor):
                                is_single_buffer = True
        self.is_single_buffer = is_single_buffer
        self.sync_key = normalize_sync_key_group(self.local_sync_keys)
        self.is_mixed_scope = len(used)==2 and self.has_inst

    def pre_process(self):
        insts = self.insts
        new_insts = self.new_insts
        n = len(insts)
        if n == 0:
            return
        start_loop = "start_loop"
        end_loop = "end_loop"
        if_starts = ("start_if",)
        end_if = "end_if"

        def _find_loop_end(idx: int) -> Optional[int]:
            depth = 1
            while idx < n:
                op = insts[idx].opname
                if op == start_loop:
                    depth += 1
                elif op == end_loop:
                    depth -= 1
                    if depth == 0:
                        return idx
                idx += 1
            return None

        def _find_if_end(idx: int) -> Optional[int]:
            depth = 1
            while idx < n:
                op = insts[idx].opname
                if op in if_starts:
                    depth += 1
                elif op == end_if:
                    depth -= 1
                    if depth == 0:
                        return idx
                idx += 1
            return None

        i = 0
        while i < n:
            if i==0 and (insts[i].opname==start_loop or insts[i].opname in if_starts):
                new_insts.append(insts[i])
                i += 1
                continue
            inst = insts[i]
            op = inst.opname
            if op == start_loop:
                end_idx = _find_loop_end(i + 1)
                if end_idx is None:
                    new_insts.extend(insts[i:])
                    break
                body = insts[i:end_idx + 1]
                sub_insts = AutosyncNode(
                    body,
                    self.src_pipe,
                    self.dst_pipe,
                    self.producer_src,
                    self.producer_dst,
                    self.consumer_src,
                    self.consumer_dst,
                    self.buf_name,
                )
                new_insts.append(sub_insts)
                i = end_idx + 1
                continue
            if op in if_starts:
                end_idx = _find_if_end(i + 1)
                if end_idx is None:
                    new_insts.extend(insts[i:])
                    break
                body = insts[i:end_idx + 1]
                sub_insts = AutosyncNode(
                    body,
                    self.src_pipe,
                    self.dst_pipe,
                    self.producer_src,
                    self.producer_dst,
                    self.consumer_src,
                    self.consumer_dst,
                    self.buf_name,
                )
                new_insts.append(sub_insts)
                i = end_idx + 1
                continue
            new_insts.append(inst)
            i += 1
    
    def insert_auto_sync_inst(self):
        self.local_pending_valid_carry_events = {}
        if not self.is_mixed_scope:
            return self

        is_control_subregion = bool(self.insts) and self.insts[0].opname in ("start_loop", "start_if")
        
        if self.is_single_buffer:
            event_valid: Union[SEvent, DEvent] = object.__new__(SEvent)
            event_valid.name = f"_tmp_sevent_valid_{self.buf_name}_{self.buf_idx}"
            self._configure_sync_event(event_valid, is_valid=True)
            self.events_to_be_created.append(event_valid.name)
            event_ready: Union[SEvent, DEvent] = object.__new__(SEvent)
            event_ready.name = f"_tmp_sevent_ready_{self.buf_name}_{self.buf_idx}"
            self._configure_sync_event(event_ready, is_valid=False)
            self.events_to_be_created.append(event_ready.name)
        else:
            event_valid: Union[SEvent, DEvent] = object.__new__(DEvent)
            event_valid.name = f"_tmp_devent_valid_{self.buf_name}_{self.buf_idx}"
            self._configure_sync_event(event_valid, is_valid=True)
            self.events_to_be_created.append(event_valid.name)
            event_ready: Union[SEvent, DEvent] = object.__new__(DEvent)
            event_ready.name = f"_tmp_devent_ready_{self.buf_name}_{self.buf_idx}"
            self._configure_sync_event(event_ready, is_valid=False)
            self.events_to_be_created.append(event_ready.name)

        valid_wait_inst = Instruction(opname="event_wait", event=event_valid)
        valid_set_inst = Instruction(opname="event_set", event=event_valid)
        ready_wait_inst = Instruction(opname="event_wait", event=event_ready)
        ready_set_inst = Instruction(opname="event_set", event=event_ready)


        declared = False 
        changed = False
        result: List[Instruction | AutosyncNode] = []
        for i in self.new_insts:
            if isinstance(i, AutosyncNode):
                child_has_src = self.src_pipe in i.used_pipes
                child_has_dst = self.dst_pipe in i.used_pipes
                if child_has_src and child_has_dst:
                    same_event_family = i.buf_idx == self.buf_idx
                    # A nested mixed-scope node already owns its internal src/dst
                    # handshake. Re-wrapping it at the parent scope can create a
                    # dangling ready/valid pair after the child loop ends.
                    #
                    # The parent may still have an outstanding producer token
                    # before entering the child. In that case the child's dst-side
                    # work closes the parent handshake, but the child remains
                    # responsible for its own internal buffering/events.
                    if same_event_family and declared and not changed:
                        result.append(ready_set_inst)
                        result.append(ready_wait_inst)
                        declared = False
                        changed = True
                    elif same_event_family and changed and not declared:
                        # Parent already finished a prior src->dst round, so the
                        # next producer round must republish valid before handing
                        # control to a child that owns both sides of the same
                        # event family. The child will perform the matching
                        # valid.wait for its own producer-side work.
                        result.append(valid_set_inst)
                        changed = False
                    result.append(i)
                    continue
                if child_has_src and changed and not declared:
                    result.append(valid_set_inst)
                    result.append(valid_wait_inst)
                    declared = True
                    changed = False
                elif child_has_src and not declared:
                    result.append(valid_wait_inst)
                    declared = True
                elif child_has_dst and declared and not changed:
                    result.append(ready_set_inst)
                    result.append(ready_wait_inst)
                    declared = False
                    changed = True
                result.append(i)
            else:
                if not isinstance(i, Instruction):
                    raise TypeError("Expected Instruction or AutosyncNode")
                if i.opname in ("start_else", "start_elif") and changed and not declared:
                    result.append(valid_set_inst)
                    changed = False
                    result.append(i)
                    continue
                pipe = _OPNAME_TO_PIPE.get(i.opname)
                if pipe is not None:
                    if pipe == self.src_pipe and changed and not declared:
                        result.append(valid_set_inst)
                        result.append(valid_wait_inst)
                        declared = True
                        changed = False
                    elif pipe == self.src_pipe and not declared:
                        result.append(valid_wait_inst)
                        declared = True
                    elif pipe == self.dst_pipe and declared and not changed:
                        result.append(ready_set_inst)
                        result.append(ready_wait_inst)
                        declared = False
                        changed = True
                result.append(i)
            
        if changed:
            tail_opname = result[-1].opname if result else ""
            internal_valid_set_count = sum(
                1
                for inst in result
                if isinstance(inst, Instruction)
                and inst.opname == "event_set"
                and inst.kwargs.get("event", None) is not None
                and inst.kwargs["event"].name == event_valid.name
            )
            if (
                is_control_subregion
                and self.is_single_buffer
                and tail_opname in ("end_loop", "end_if")
                and internal_valid_set_count >= 2
            ):
                # Some single-buffer control subregions already republish valid
                # multiple times before leaving the subregion. In those cases an
                # extra tail valid.set leaves the single-event flag published
                # across control-flow re-entry and the next round's prefix
                # valid.set becomes a duplicate already-set error.
                self.local_pending_valid_carry_events[event_valid.name] = event_valid
            elif tail_opname not in ['end_loop', 'end_if']:
                result.append(valid_set_inst)
            else:
                result.insert(-1, valid_set_inst)
        if declared:
            if result[-1].opname not in ['end_loop', 'end_if']:
                result.append(ready_set_inst)
                result.append(ready_wait_inst)
                result.append(valid_set_inst)
            else:
                result.insert(-1, ready_set_inst)
                result.insert(-1, ready_wait_inst)
                result.insert(-1, valid_set_inst)
            # Nested loop/if regions often end with a producer-side carry that this
            # pass already closes by inserting a local ready/wait/valid tail. That
            # conservative auto-close is noisy but not actionable for users, so we
            # keep the synthesized closure and only warn on non-control subregions.
            if not is_control_subregion:
                print('WARNING: NOT balanced auto_sync events, please check the code logic!')
        
        self.new_insts = result
        return self

    def get_instructions(self):
        result: List[Instruction | AutosyncNode] = []
        child_pending_valid_carry_events: Dict[str, Union[SEvent, DEvent]] = {}
        for i in self.new_insts:
            if isinstance(i, AutosyncNode):
                child = i.insert_auto_sync_inst().get_instructions()
                child_is_if = bool(child.insts) and child.insts[0].opname == "start_if"
                result.extend(child.new_insts)
                self.events_to_be_created.extend(child.events_to_be_created)
                if child.pending_valid_carry_events and child_is_if:
                    end_if_idx = None
                    for idx in range(len(result) - 1, -1, -1):
                        inst = result[idx]
                        if isinstance(inst, Instruction) and inst.opname == "end_if":
                            end_if_idx = idx
                            break
                    if end_if_idx is None:
                        raise RuntimeError("pending if-carry requires end_if in expanded child instructions")
                    insert_pos = end_if_idx
                    for event in child.pending_valid_carry_events.values():
                        result.insert(insert_pos, Instruction(opname="event_set", event=event))
                        insert_pos += 1
                elif child.pending_valid_carry_events:
                    for event in child.pending_valid_carry_events.values():
                        result.append(Instruction(opname="event_set", event=event))
                else:
                    child_pending_valid_carry_events.update(child.pending_valid_carry_events)
            else:
                result.append(i)

        self.pending_valid_carry_events = dict(self.local_pending_valid_carry_events)
        self.pending_valid_carry_events.update(child_pending_valid_carry_events)
        self.new_insts = result
        return self 

    def create_events(self, full_instructions: List[Instruction]):
        for name in set(self.events_to_be_created):
            if name.startswith("_tmp_sevent"):
                event: Union[SEvent, DEvent] = object.__new__(SEvent)
            else:
                event = object.__new__(DEvent)

            event.name = name
            self._configure_sync_event(event, is_valid=('valid' in name))

            if name.startswith("_tmp_sevent"):
                event_create_inst = Instruction(opname="create_sevent", val=event)
            else:
                event_create_inst = Instruction(opname="create_devent", val=event)
            full_instructions.append(event_create_inst)
        return self.new_insts


def _insert_autosync_node(instructions: List[Instruction], mode: Literal['cube', 'vec']) -> Tuple[List[Instruction], List[Instruction]]:
    event_creation: List[Instruction] = []
    if mode == 'vec':
        region_pipes = {
            pipe for pipe in _collect_region_pipes(instructions)
            if pipe in (Pipe.MTE2, Pipe.V, Pipe.MTE3)
        }
        if region_pipes == {Pipe.MTE2, Pipe.MTE3}:
            instructions = AutosyncNode(instructions, Pipe.MTE2, Pipe.MTE3, False, True, True, False, 'ubrelay').assign_buf_indices().insert_auto_sync_inst().get_instructions().create_events(event_creation)
        else:
            instructions = AutosyncNode(instructions, Pipe.MTE2, Pipe.V, False, True, False, False, 'ubin').assign_buf_indices().insert_auto_sync_inst().get_instructions().create_events(event_creation)
            instructions = AutosyncNode(instructions, Pipe.V, Pipe.MTE3, False, False, True, False, 'ubout').assign_buf_indices().insert_auto_sync_inst().get_instructions().create_events(event_creation)
    else:
        instructions = AutosyncNode(instructions, Pipe.MTE2, Pipe.MTE1, False, True, False, False, 'l1').assign_buf_indices().insert_auto_sync_inst().get_instructions().create_events(event_creation)
        instructions = AutosyncNode(instructions, Pipe.MTE1, Pipe.M, False, True, False, False, 'l0').assign_buf_indices().insert_auto_sync_inst().get_instructions().create_events(event_creation)
        instructions = AutosyncNode(instructions, Pipe.M, Pipe.FIX, False, False, True, False, 'fix').assign_buf_indices().insert_auto_sync_inst().get_instructions().create_events(event_creation)
    return instructions, event_creation


def insert_auto_sync(instructions: List[Instruction], mode: Literal['cube', 'vec']) -> List[Instruction]:
    if mode not in ['cube', 'vec']:
        raise ValueError("mode must be either 'cube' or 'vec'")
    
    insts = list(instructions)
    if not insts:
        return insts
    result: List[Instruction] = []
    tmp_insts: List[Instruction] = []
    curr_inst_list = result

    for i in insts:
        if i.opname==_AUTO_SYNC_START:
            curr_inst_list = tmp_insts
        curr_inst_list.append(i)
        if i.opname==_AUTO_SYNC_END:
            tmp_insts_with_autosync, event_creation = _insert_autosync_node(tmp_insts, mode)
            if mode == 'vec':
                tmp_insts_with_autosync = _insert_b_device_vec_barriers(tmp_insts_with_autosync)
            result.extend(tmp_insts_with_autosync)
            result = event_creation + result
            curr_inst_list = result
            tmp_insts = []
    return result
