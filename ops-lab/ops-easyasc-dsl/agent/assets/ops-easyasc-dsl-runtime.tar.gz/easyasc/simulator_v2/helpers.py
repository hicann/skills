# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Shared helpers for the V2 simulator.

Functions migrated from the V1 simulator's shared/runtime_helpers.py.
"""
from __future__ import annotations

import logging
from typing import Any


def resolve_core_num(device_type: str) -> int:
    lowered = str(device_type).lower()
    if lowered in ("b3", "b4"):
        return 20
    if lowered in ("b1", "b2"):
        return 24
    if lowered == "950":
        return 32
    raise ValueError("Unsupported device_type for simulator: " + lowered)


def resolve_simulator_core_num(core_num: Any, device_type: str) -> int:
    if core_num is None:
        return resolve_core_num(device_type)
    if isinstance(core_num, bool) or not isinstance(core_num, int):
        raise TypeError(
            "globvars.core_num must be None or a positive int, got: "
            + str(type(core_num))
        )
    if core_num <= 0:
        raise ValueError("globvars.core_num must be > 0, got: " + str(core_num))
    return int(core_num)


_SIM_LOGGER = logging.getLogger("easyasc.simulator")
if not _SIM_LOGGER.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(message)s"))
    _SIM_LOGGER.addHandler(_handler)
_SIM_LOGGER.setLevel(logging.INFO)
_SIM_LOGGER.propagate = False
