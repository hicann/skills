from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple


class OperandKind(Enum):
    LOCAL = "local"
    SHARED = "shared"
    GLOBAL = "global"


@dataclass(frozen=True)
class OperandHandle:
    """Lightweight runtime reference to an operand or view."""

    name: str
    kind: OperandKind
    shape: Tuple[int, ...]
    dtype: str
    offset: int = 0
    mutable: bool = False
    alias_of: Optional[str] = None

