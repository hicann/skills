from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class ControlFrame:
    """Interpreter state for lane-level control flow."""

    cursor: int = 0
    loop_stack: List[int] = field(default_factory=list)
    branch_stack: List[int] = field(default_factory=list)
    variables: Dict[str, int] = field(default_factory=dict)

