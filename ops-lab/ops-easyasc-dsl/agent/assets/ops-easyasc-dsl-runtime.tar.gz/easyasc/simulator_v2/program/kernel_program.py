# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from .lane_program import LaneProgram


@dataclass
class KernelProgram:
    """Runtime-ready kernel plan."""

    name: str
    core_count: int
    lane_programs: List[LaneProgram] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_lane_program(self, lane_name: str) -> LaneProgram:
        for lane_program in self.lane_programs:
            if lane_program.lane_name == lane_name:
                return lane_program
        raise KeyError("lane program not found: " + str(lane_name))

    def get_pipe_names(self, lane_name: str) -> List[str]:
        try:
            lane_program = self.get_lane_program(lane_name)
        except KeyError:
            return []
        return list(lane_program.pipe_names)
