from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from .lane_program import LaneProgram


@dataclass
class KernelProgram:
    """Runtime-ready kernel plan."""

    name: str
    core_count: int
    lane_programs: List[LaneProgram] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_lane_program(self, lane_name: str) -> LaneProgram:
        for lane_program in self.lane_programs:
            if lane_program.lane_name == lane_name:
                return lane_program
        raise KeyError("lane program not found: " + str(lane_name))

    def get_pipe_names(self, lane_name: str) -> List[str]:
        try:
            lane_program = self.get_lane_program(lane_name)
        except KeyError:
            return []
        return list(lane_program.pipe_names)
