# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .control_instruction import ControlInstruction
from .task import PipeTask


@dataclass
class LaneProgram:
    """Instruction stream for one logical lane."""

    lane_name: str
    pipe_names: List[str] = field(default_factory=list)
    tasks: List[PipeTask] = field(default_factory=list)
    instructions: List[ControlInstruction] = field(default_factory=list)

    def task_count(self) -> int:
        return len(self.tasks)

    def has_instructions(self) -> bool:
        """True when this program carries V2 control instructions."""
        return len(self.instructions) > 0
