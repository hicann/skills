from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .control_instruction import ControlInstruction
from .task import PipeTask


@dataclass
class LaneProgram:
    """Instruction stream for one logical lane."""

    lane_name: str
    pipe_names: List[str] = field(default_factory=list)
    tasks: List[PipeTask] = field(default_factory=list)
    instructions: List[ControlInstruction] = field(default_factory=list)

    def task_count(self) -> int:
        return len(self.tasks)

    def has_instructions(self) -> bool:
        """True when this program carries V2 control instructions."""
        return len(self.instructions) > 0
