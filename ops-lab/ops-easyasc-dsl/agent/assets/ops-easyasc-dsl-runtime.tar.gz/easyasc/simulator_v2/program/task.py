from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional


class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass
class PipeTask:
    """A unit of work submitted to a pipe worker."""

    pipe_name: str
    opname: str
    args: Dict[str, Any] = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    error: Optional[str] = None

    def clone(self) -> "PipeTask":
        return PipeTask(
            pipe_name=self.pipe_name,
            opname=self.opname,
            args=dict(self.args),
            status=TaskStatus.PENDING,
            error=None,
        )
