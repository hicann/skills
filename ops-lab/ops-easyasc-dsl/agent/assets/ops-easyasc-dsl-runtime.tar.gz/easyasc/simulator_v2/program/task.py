# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional


class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass
class PipeTask:
    """A unit of work submitted to a pipe worker."""

    pipe_name: str
    opname: str
    args: Dict[str, Any] = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    error: Optional[str] = None
    error_details: Optional[str] = None
    earliest_start_cycle: float = 0.0
    start_cycle: float = 0.0
    end_cycle: float = 0.0
    estimated_cycles: float = 0.0

    def clone(self) -> "PipeTask":
        return PipeTask(
            pipe_name=self.pipe_name,
            opname=self.opname,
            args=dict(self.args),
            status=TaskStatus.PENDING,
            error=None,
            error_details=None,
            earliest_start_cycle=0.0,
            start_cycle=0.0,
            end_cycle=0.0,
            estimated_cycles=0.0,
        )
