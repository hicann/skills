from __future__ import annotations

from dataclasses import dataclass
from typing import List

from ..config import SimulatorV2Config
from .kernel_program import KernelProgram
from .lane_program import LaneProgram
from ..runtime.execution_plan import resolve_target_core_count


@dataclass
class ProgramPlanner:
    """Builds runtime plans from lowered kernel instructions."""

    config: SimulatorV2Config

    def plan(self, program: KernelProgram) -> List[LaneProgram]:
        return program.lane_programs

    def validate(self, program: KernelProgram) -> None:
        target_core_count = resolve_target_core_count(program, self.config)
        if target_core_count <= 0:
            raise ValueError("resolved simulator_v2 core_count must be positive")
