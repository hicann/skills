# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass
from typing import List

from ..config import SimulatorV2Config
from .kernel_program import KernelProgram
from .lane_program import LaneProgram
from ..runtime.execution_plan import resolve_target_core_count


@dataclass
class ProgramPlanner:
    """Builds runtime plans from lowered kernel instructions."""

    config: SimulatorV2Config

    def plan(self, program: KernelProgram) -> List[LaneProgram]:
        return program.lane_programs

    def validate(self, program: KernelProgram) -> None:
        target_core_count = resolve_target_core_count(program, self.config)
        if target_core_count <= 0:
            raise ValueError("resolved simulator_v2 core_count must be positive")
