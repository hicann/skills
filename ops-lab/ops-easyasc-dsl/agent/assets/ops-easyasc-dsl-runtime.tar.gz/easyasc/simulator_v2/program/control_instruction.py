from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class ControlInstruction:
    """A single instruction for the V2 control actor to interpret.

    Control-flow instructions (start_loop, start_if, etc.) have an empty
    pipe_name.  Pipe instructions carry a non-empty pipe_name and are
    converted to PipeTasks by the control actor before submission.
    """

    opname: str
    args: Dict[str, Any] = field(default_factory=dict)
    pipe_name: str = ""

    def is_pipe_op(self) -> bool:
        return self.pipe_name != ""
