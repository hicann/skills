# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class ControlInstruction:
    """A single instruction for the V2 control actor to interpret.

    Control-flow instructions (start_loop, start_if, etc.) have an empty
    pipe_name.  Pipe instructions carry a non-empty pipe_name and are
    converted to PipeTasks by the control actor before submission.
    """

    opname: str
    args: Dict[str, Any] = field(default_factory=dict)
    pipe_name: str = ""

    def is_pipe_op(self) -> bool:
        return self.pipe_name != ""
