"""Trace scaffolding for simulator V2."""

from .chrome import dump_chrome_trace, export_chrome_trace
from .event_types import TraceEvent, TraceEventKind
from .merge import merge_trace_buffers
from .recorder import TraceRecorderV2

__all__ = [
    "dump_chrome_trace",
    "export_chrome_trace",
    "TraceEvent",
    "TraceEventKind",
    "TraceRecorderV2",
    "merge_trace_buffers",
]
