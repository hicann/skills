from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
from enum import Enum
from typing import Dict, Any


class TraceEventKind(Enum):
    CONTROL = "control"
    PIPE = "pipe"
    SYNC = "sync"


@dataclass(frozen=True)
class TraceEvent:
    """A trace event emitted by the V2 runtime."""

    kind: TraceEventKind
    name: str
    ts: float = 0.0
    dur: float = 0.0
    args: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind.value,
            "name": self.name,
            "ts": float(self.ts),
            "dur": float(self.dur),
            "args": dict(self.args),
        }

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "TraceEvent":
        return cls(
            kind=TraceEventKind(str(value["kind"])),
            name=str(value["name"]),
            ts=float(value.get("ts", 0.0)),
            dur=float(value.get("dur", 0.0)),
            args=dict(value.get("args", {})),
        )
