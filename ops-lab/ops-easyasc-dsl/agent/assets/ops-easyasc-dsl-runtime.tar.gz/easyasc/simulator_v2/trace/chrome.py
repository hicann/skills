# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

import json
import os
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .event_types import TraceEvent, TraceEventKind

_SECONDS_TO_NS = 1_000_000_000.0
_DEFAULT_CONTROL_DUR_NS = 1_000.0
_DEFAULT_PIPE_DUR_NS = 1_000.0
_DEFAULT_SYNC_DUR_NS = 1_000.0


def _track_label(core_idx: int, lane_name: str, pipe_name: str) -> str:
    if lane_name == "runtime":
        return "core" + str(core_idx) + ".runtime." + str(pipe_name)
    if lane_name == "cube":
        return "core" + str(core_idx) + ".cube." + str(pipe_name)
    if lane_name.startswith("vec"):
        return "core" + str(core_idx) + "." + lane_name + "." + str(pipe_name)
    return "core" + str(core_idx) + "." + lane_name + "." + str(pipe_name)


def _track_sort_index(core_idx: int, lane_name: str, pipe_name: str) -> int:
    base = core_idx * 100
    if lane_name == "runtime":
        order = {"S": -1}
        return base + order.get(pipe_name, -1)
    if lane_name == "cube":
        order = {"S": 0, "MTE2": 1, "MTE1": 2, "M": 3, "FIX": 4}
        return base + order.get(pipe_name, 49)
    if lane_name == "vec0":
        order = {"S": 5, "MTE2": 6, "V": 7, "MTE3": 8}
        return base + order.get(pipe_name, 59)
    if lane_name == "vec1":
        order = {"S": 9, "MTE2": 10, "V": 11, "MTE3": 12}
        return base + order.get(pipe_name, 69)
    return base + 99


def _event_descriptor(event: TraceEvent) -> Optional[Dict[str, Any]]:
    args = dict(event.args)
    core_idx = int(args.get("core_idx", -1))
    if core_idx < 0:
        return None
    if event.kind == TraceEventKind.CONTROL:
        if event.name == "dispatch_task":
            lane_name = str(args.get("lane_name", "runtime"))
            pipe_name = "S"
            payload = dict(args)
            payload["trace_phase"] = "dispatch"
            return {
                "core_idx": core_idx,
                "lane_name": lane_name,
                "pipe_name": pipe_name,
                "name": str(args.get("opname", event.name)),
                "cat": pipe_name,
                "dur": _DEFAULT_CONTROL_DUR_NS if float(event.dur) <= 0 else float(event.dur),
                "args": payload,
            }
        payload = dict(args)
        payload["trace_kind"] = "control"
        return {
            "core_idx": core_idx,
            "lane_name": "runtime",
            "pipe_name": "S",
            "name": event.name,
            "cat": "runtime",
            "dur": _DEFAULT_CONTROL_DUR_NS if float(event.dur) <= 0 else float(event.dur),
            "args": payload,
        }
    if event.kind == TraceEventKind.PIPE:
        lane_name = str(args.get("lane_name", "runtime"))
        pipe_name = str(args.get("pipe_name", "PIPE"))
        payload = dict(args)
        payload["trace_phase"] = "execute"
        return {
            "core_idx": core_idx,
            "lane_name": lane_name,
            "pipe_name": pipe_name,
            "name": str(args.get("opname", event.name)),
            "cat": pipe_name,
            "dur": _DEFAULT_PIPE_DUR_NS if float(event.dur) <= 0 else float(event.dur),
            "args": payload,
        }
    if event.kind == TraceEventKind.SYNC:
        lane_name = str(args.get("lane_name", "runtime"))
        pipe_name = str(args.get("pipe_name", "S"))
        payload = dict(args)
        payload["trace_kind"] = "sync"
        return {
            "core_idx": core_idx,
            "lane_name": lane_name,
            "pipe_name": pipe_name,
            "name": event.name,
            "cat": "sync",
            "dur": _DEFAULT_SYNC_DUR_NS if float(event.dur) <= 0 else float(event.dur),
            "args": payload,
        }
    return None


def _is_cycle_event(event: TraceEvent, descriptor: Dict[str, Any]) -> bool:
    args = descriptor.get("args", {})
    return str(args.get("time_domain", "")).lower() == "cycle"


def _duration_units(event: TraceEvent, descriptor: Dict[str, Any], is_cycle: bool) -> float:
    if event.kind == TraceEventKind.CONTROL:
        if float(event.dur) > 0:
            return float(event.dur) if is_cycle else float(event.dur) * _SECONDS_TO_NS
        if is_cycle:
            return 1.0
        return float(descriptor.get("dur", _DEFAULT_CONTROL_DUR_NS))
    if event.kind == TraceEventKind.PIPE:
        if float(event.dur) > 0:
            return float(event.dur) if is_cycle else float(event.dur) * _SECONDS_TO_NS
        if is_cycle:
            return 1.0
        return float(descriptor.get("dur", _DEFAULT_PIPE_DUR_NS))
    if event.kind == TraceEventKind.SYNC:
        if float(event.dur) > 0:
            return float(event.dur) if is_cycle else float(event.dur) * _SECONDS_TO_NS
        if is_cycle:
            return 1.0
        return float(descriptor.get("dur", _DEFAULT_SYNC_DUR_NS))
    return float(descriptor.get("dur", _DEFAULT_CONTROL_DUR_NS))


def export_chrome_trace(kernel_name: str, events: Iterable[TraceEvent]) -> Dict[str, Any]:
    trace_events: List[Dict[str, Any]] = [
        {
            "name": "process_name",
            "ph": "M",
            "pid": 1,
            "tid": 0,
            "args": {"name": "easyasc:" + str(kernel_name)},
        }
    ]
    tid_by_track: Dict[Tuple[int, str, str], int] = {}
    next_tid = 1
    ordered_events = sorted(
        list(events),
        key=lambda event: (float(event.ts), str(event.name), str(event.kind.value)),
    )
    base_ts = 0.0
    if ordered_events:
        base_ts = min(float(event.ts) for event in ordered_events)
    uses_cycle_domain = False
    for event in ordered_events:
        descriptor = _event_descriptor(event)
        if descriptor is None:
            continue
        is_cycle = _is_cycle_event(event, descriptor)
        uses_cycle_domain = uses_cycle_domain or is_cycle
        core_idx = int(descriptor["core_idx"])
        lane_name = str(descriptor["lane_name"])
        pipe_name = str(descriptor["pipe_name"])
        track_key = (core_idx, lane_name, pipe_name)
        tid = tid_by_track.get(track_key)
        if tid is None:
            tid = next_tid
            next_tid += 1
            tid_by_track[track_key] = tid
            trace_events.append(
                {
                    "name": "thread_name",
                    "ph": "M",
                    "pid": 1,
                    "tid": tid,
                    "args": {"name": _track_label(core_idx, lane_name, pipe_name)},
                }
            )
            trace_events.append(
                {
                    "name": "thread_sort_index",
                    "ph": "M",
                    "pid": 1,
                    "tid": tid,
                    "args": {"sort_index": _track_sort_index(core_idx, lane_name, pipe_name)},
                }
            )
        start = round(float(event.ts) - base_ts, 3) if is_cycle else round((float(event.ts) - base_ts) * _SECONDS_TO_NS, 3)
        dur = round(_duration_units(event, descriptor, is_cycle), 3)
        trace_events.append(
            {
                "name": str(descriptor["name"]),
                "cat": str(descriptor["cat"]),
                "ph": "X",
                "pid": 1,
                "tid": tid,
                "ts": start,
                "dur": dur,
                "args": dict(descriptor["args"]),
            }
        )
    payload = {"traceEvents": trace_events, "displayTimeUnit": "ns"}
    if uses_cycle_domain:
        payload["easyasc_time_domain"] = "cycle"
    return payload


def dump_chrome_trace(trace_path: str, kernel_name: str, events: Iterable[TraceEvent]) -> None:
    if not isinstance(trace_path, str):
        raise TypeError("trace_path must be str, got: " + str(type(trace_path)))
    if trace_path == "":
        raise ValueError("trace_path must be non-empty when exporting trace")
    out_dir = os.path.dirname(os.path.abspath(trace_path))
    if out_dir != "":
        os.makedirs(out_dir, exist_ok=True)
    with open(trace_path, "w", encoding="utf-8") as handle:
        json.dump(export_chrome_trace(kernel_name, events), handle, indent=2)
        handle.write("\n")
