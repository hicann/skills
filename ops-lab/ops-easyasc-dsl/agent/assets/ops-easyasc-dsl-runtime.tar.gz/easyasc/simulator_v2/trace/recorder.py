from __future__ import annotations

from dataclasses import dataclass, field
import threading
import time
from typing import List

from .event_types import TraceEvent, TraceEventKind


@dataclass
class TraceRecorderV2:
    """In-memory trace collector used by the V2 scaffold."""

    core_idx: int = -1
    events: List[TraceEvent] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    def record(self, event: TraceEvent) -> None:
        with self._lock:
            self.events.append(event)

    def record_event(
        self,
        kind: TraceEventKind,
        name: str,
        dur: float = 0.0,
        args: dict = None,
    ) -> None:
        payload = dict(args or {})
        if self.core_idx >= 0 and "core_idx" not in payload:
            payload["core_idx"] = self.core_idx
        self.record(
            TraceEvent(
                kind=kind,
                name=name,
                ts=time.monotonic(),
                dur=dur,
                args=payload,
            )
        )

    def snapshot(self) -> List[TraceEvent]:
        with self._lock:
            return list(self.events)

    def flush(self) -> List[TraceEvent]:
        with self._lock:
            events = list(self.events)
            self.events.clear()
            return events
