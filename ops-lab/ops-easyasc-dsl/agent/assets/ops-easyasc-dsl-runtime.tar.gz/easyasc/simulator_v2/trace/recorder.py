# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
import threading
import time
from typing import List, Optional

from .event_types import TraceEvent, TraceEventKind


@dataclass
class TraceRecorderV2:
    """In-memory trace collector used by the V2 scaffold."""

    core_idx: int = -1
    events: List[TraceEvent] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    def record(self, event: TraceEvent) -> None:
        with self._lock:
            self.events.append(event)

    def record_event(
        self,
        kind: TraceEventKind,
        name: str,
        dur: float = 0.0,
        args: dict = None,
        ts: Optional[float] = None,
    ) -> None:
        payload = dict(args or {})
        if self.core_idx >= 0 and "core_idx" not in payload:
            payload["core_idx"] = self.core_idx
        self.record(
            TraceEvent(
                kind=kind,
                name=name,
                ts=time.monotonic() if ts is None else float(ts),
                dur=dur,
                args=payload,
            )
        )

    def snapshot(self) -> List[TraceEvent]:
        with self._lock:
            return list(self.events)

    def flush(self) -> List[TraceEvent]:
        with self._lock:
            events = list(self.events)
            self.events.clear()
            return events
