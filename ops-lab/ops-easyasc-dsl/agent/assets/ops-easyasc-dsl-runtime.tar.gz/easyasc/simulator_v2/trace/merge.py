from __future__ import annotations

from typing import Iterable, List

from .event_types import TraceEvent


def merge_trace_buffers(buffers: Iterable[List[TraceEvent]]) -> List[TraceEvent]:
    merged: List[TraceEvent] = []
    for buffer in buffers:
        merged.extend(buffer)
    merged.sort(key=lambda event: (event.ts, event.name))
    return merged
