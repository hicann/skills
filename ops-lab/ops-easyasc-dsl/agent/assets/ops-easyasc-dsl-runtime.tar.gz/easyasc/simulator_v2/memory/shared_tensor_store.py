# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
import multiprocessing
from multiprocessing import shared_memory
import threading
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

from .local_memory import LocalMemoryAllocator
from .shared_tensor import (
    SharedTensorHandle,
    SharedTensorSpec,
    normalize_shared_dtype_name,
    numpy_dtype_from_shared_name,
    torch_dtype_from_shared_name,
)
from .workspace import WorkspacePlan


def _resource_tracker_shm_name(shm: Any) -> str:
    name = getattr(shm, "_name", None)
    if isinstance(name, str) and name != "":
        return name
    public_name = getattr(shm, "name", None)
    if not isinstance(public_name, str) or public_name == "":
        return ""
    if public_name.startswith("/"):
        return public_name
    return "/" + public_name


def _detach_non_owner_shm_from_tracker(shm: Any) -> None:
    """Child processes attach to parent-owned shm and should not track cleanup."""

    tracker_name = _resource_tracker_shm_name(shm)
    if tracker_name == "":
        return
    try:
        from multiprocessing import resource_tracker
    except Exception:
        return
    try:
        resource_tracker.unregister(tracker_name, "shared_memory")
        if hasattr(shm, "_track"):
            shm._track = False
    except Exception:
        pass


@dataclass
class SharedTensorStore:
    """Registry for globally shared tensor specs and handles."""

    tensors: Dict[str, SharedTensorHandle] = field(default_factory=dict)
    storage: Dict[str, Any] = field(default_factory=dict, repr=False)
    shared_blocks: Dict[str, Dict[str, Any]] = field(default_factory=dict, repr=False)
    allocation_modes: Dict[str, str] = field(default_factory=dict, repr=False)
    auto_allocate: bool = True
    prefer_shared_memory: bool = True
    local_allocator: Optional[LocalMemoryAllocator] = field(default=None, repr=False)
    atomic_lock_proxy: Any = field(default=None, repr=False)
    _sync_manager: Any = field(default=None, init=False, repr=False)
    _lock: threading.RLock = field(default_factory=threading.RLock, init=False, repr=False)

    def prepare(self, program: object) -> None:
        """Prepare shared tensors for a program."""
        with self._lock:
            self.clear()
            self._ensure_atomic_lock()
            for spec in self._declared_specs(program):
                self.register(spec)

    def _declared_specs(self, program: object) -> Iterator[SharedTensorSpec]:
        if program is None:
            return
        candidates: List[Any] = []
        metadata = getattr(program, "metadata", None)
        if isinstance(metadata, dict):
            for key in (
                "shared_tensors",
                "shared_tensor_specs",
                "tensors",
                "workspace",
                "workspace_plan",
                "tensor_specs",
            ):
                value = metadata.get(key)
                if value is not None:
                    candidates.append(value)
        for attr_name in ("shared_tensors", "shared_tensor_specs", "workspace", "workspace_plan"):
            value = getattr(program, attr_name, None)
            if value is not None:
                candidates.append(value)
        for candidate in candidates:
            yield from self._iter_specs(candidate)

    def _iter_specs(self, candidate: Any) -> Iterator[SharedTensorSpec]:
        if candidate is None:
            return
        if isinstance(candidate, SharedTensorSpec):
            yield candidate
            return
        if isinstance(candidate, SharedTensorHandle):
            yield candidate.spec
            return
        if isinstance(candidate, WorkspacePlan):
            for spec in candidate.entries:
                yield SharedTensorSpec.from_any(spec)
            return
        if isinstance(candidate, dict):
            if "entries" in candidate and isinstance(candidate["entries"], (list, tuple)):
                for item in candidate["entries"]:
                    yield from self._iter_specs(item)
                return
            if "tensors" in candidate and isinstance(candidate["tensors"], (list, tuple, dict)):
                yield from self._iter_specs(candidate["tensors"])
                return
            if "name" in candidate and "dtype" in candidate and "shape" in candidate:
                yield SharedTensorSpec.from_any(candidate)
                return
            for key, value in candidate.items():
                if isinstance(value, (SharedTensorSpec, SharedTensorHandle)):
                    yield SharedTensorSpec.from_any(value, name_hint=str(key))
                elif isinstance(value, dict) and ("dtype" in value or "shape" in value):
                    candidate_dict = dict(value)
                    candidate_dict.setdefault("name", str(key))
                    yield SharedTensorSpec.from_any(candidate_dict)
                elif isinstance(value, (list, tuple)):
                    try:
                        yield SharedTensorSpec.from_any(value, name_hint=str(key))
                    except Exception:
                        import warnings
                        warnings.warn(
                            "simulator_v2: failed to parse spec candidate from key "
                            + repr(str(key)) + ": " + repr(value),
                            stacklevel=2,
                        )
                        continue
            return
        if isinstance(candidate, (list, tuple, set)):
            for item in candidate:
                yield from self._iter_specs(item)
            return
        if hasattr(candidate, "entries"):
            entries = getattr(candidate, "entries")
            if entries is not None:
                yield from self._iter_specs(entries)
            return
        if hasattr(candidate, "name") and hasattr(candidate, "dtype") and hasattr(candidate, "shape"):
            yield SharedTensorSpec.from_any(candidate)

    def register(self, spec: SharedTensorSpec) -> SharedTensorHandle:
        with self._lock:
            if not isinstance(spec, SharedTensorSpec):
                spec = SharedTensorSpec.from_any(spec)
            self._register_local_allocation(spec)
            existing = self.tensors.get(spec.name)
            if existing is not None:
                if existing.spec != spec:
                    raise ValueError("shared tensor already registered with different spec: " + spec.name)
                return existing
            handle = SharedTensorHandle(tensor_id=spec.name, spec=spec)
            self.tensors[spec.name] = handle
            if self.auto_allocate:
                self.allocate(handle.tensor_id)
            return handle

    def register_many(self, specs: Iterable[SharedTensorSpec]) -> List[SharedTensorHandle]:
        handles = []
        for spec in specs:
            handles.append(self.register(spec))
        return handles

    def contains(self, tensor_id: str) -> bool:
        with self._lock:
            return tensor_id in self.tensors

    def get(self, tensor_id: str) -> SharedTensorHandle:
        with self._lock:
            return self.tensors[tensor_id]

    def values(self) -> List[SharedTensorHandle]:
        with self._lock:
            return list(self.tensors.values())

    def specs(self) -> List[SharedTensorSpec]:
        with self._lock:
            return [handle.spec for handle in self.tensors.values()]

    def is_allocated(self, tensor_id: str) -> bool:
        with self._lock:
            return tensor_id in self.storage

    def allocate(self, tensor_id: str) -> Any:
        with self._lock:
            handle = self.get(tensor_id)
            if self.is_allocated(tensor_id):
                return self.storage[tensor_id]
            if handle.is_view:
                return self.resolve(handle.tensor_id)
            if not self.prefer_shared_memory:
                tensor = self._allocate_local_tensor(handle)
                self.allocation_modes[tensor_id] = "local"
            else:
                try:
                    tensor = self._allocate_python_shm(handle)
                    self.allocation_modes[tensor_id] = "python_shm"
                except Exception as exc:
                    import warnings
                    warnings.warn(
                        "simulator_v2: shared memory allocation failed for "
                        + tensor_id + ", falling back to local: " + str(exc),
                        stacklevel=2,
                    )
                    tensor = self._allocate_local_tensor(handle)
                    self.allocation_modes[tensor_id] = "local"
            self.storage[tensor_id] = tensor
            return tensor

    def _allocate_local_tensor(self, handle: SharedTensorHandle) -> Any:
        try:
            import torch
        except Exception as exc:
            raise RuntimeError("torch is required for shared tensor allocation") from exc
        torch_dtype = torch_dtype_from_shared_name(handle.spec.dtype)
        return torch.zeros(handle.spec.shape, dtype=torch_dtype)

    def _allocate_python_shm(self, handle: SharedTensorHandle) -> Any:
        try:
            import numpy as np
            import torch
        except Exception as exc:
            raise RuntimeError("torch and numpy are required for shared tensor allocation") from exc
        np_dtype = numpy_dtype_from_shared_name(handle.spec.dtype)
        torch_dtype = torch_dtype_from_shared_name(handle.spec.dtype)
        itemsize = int(np.dtype(np_dtype).itemsize)
        size_bytes = max(handle.numel * itemsize, 1)
        shm = shared_memory.SharedMemory(create=True, size=size_bytes)
        shape = handle.spec.shape if handle.spec.shape else tuple()
        array = np.ndarray(shape=shape, dtype=np_dtype, buffer=shm.buf)
        array.fill(0)
        tensor = torch.from_numpy(array)
        if tensor.dtype != torch_dtype:
            tensor = tensor.view(torch_dtype)
        self.shared_blocks[handle.tensor_id] = {
            "backend": "python_shm",
            "shm": shm,
            "owner": True,
        }
        return tensor

    def resolve(self, tensor_id: str) -> Any:
        with self._lock:
            if tensor_id in self.storage:
                return self.storage[tensor_id]
            handle = self.get(tensor_id)
            if not handle.is_view:
                return self.allocate(tensor_id)
            source_name = handle.source_name
            if source_name is None:
                raise KeyError("shared tensor view has no source: " + tensor_id)
            source = self.resolve(source_name)
            return self._resolve_view(handle, source)

    def _resolve_view(self, handle: SharedTensorHandle, source: Any) -> Any:
        flat = source.reshape(-1)
        source_dtype = normalize_shared_dtype_name(str(getattr(source, "dtype", "")))
        if source_dtype != handle.spec.dtype:
            dst_dtype = torch_dtype_from_shared_name(handle.spec.dtype)
            flat = flat.view(dst_dtype)
        offset = handle.spec.storage_offset
        logical_shape = handle.spec.view_shape or handle.spec.shape
        logical_numel = 1
        for dim in logical_shape:
            logical_numel *= int(dim)
        if any(int(dim) == 0 for dim in logical_shape):
            if offset > int(flat.numel()):
                raise ValueError(
                    "shared tensor empty view exceeds source storage: "
                    + handle.tensor_id
                    + " offset="
                    + str(offset)
                )
            return flat.narrow(0, offset, 0).view(logical_shape)
        if handle.spec.view_strides:
            required_end = offset + 1
            for dim, stride in zip(logical_shape, handle.spec.view_strides):
                required_end += max(int(dim) - 1, 0) * int(stride)
            if required_end > int(flat.numel()):
                raise ValueError(
                    "shared tensor strided view exceeds source storage: "
                    + handle.tensor_id
                    + " offset="
                    + str(offset)
                    + " required_end="
                    + str(required_end)
                )
            return flat.as_strided(logical_shape, handle.spec.view_strides, storage_offset=offset)
        if offset + logical_numel > int(flat.numel()):
            raise ValueError(
                "shared tensor view exceeds source storage: "
                + handle.tensor_id
                + " offset="
                + str(offset)
                + " numel="
                + str(logical_numel)
            )
        view = flat.narrow(0, offset, logical_numel)
        if logical_shape:
            return view.view(logical_shape)
        return view

    def tensor(self, tensor_id: str) -> Any:
        return self.resolve(tensor_id)

    def local_allocation(self, tensor_id: str) -> Any:
        with self._lock:
            if self.local_allocator is None:
                return None
            return self.local_allocator.allocation_for(str(tensor_id))

    def _register_local_allocation(self, spec: SharedTensorSpec) -> None:
        allocator = self.local_allocator
        if allocator is None:
            return
        allocator.register_spec(spec)

    def resolve_handle(self, handle: SharedTensorHandle) -> Any:
        with self._lock:
            if not isinstance(handle, SharedTensorHandle):
                raise TypeError("resolve_handle requires SharedTensorHandle")
            registered = self.get(handle.tensor_id)
            if registered.spec != handle.spec:
                raise ValueError(
                    "shared tensor handle spec does not match registered spec: "
                    + handle.tensor_id
                )
            return self.resolve(handle.tensor_id)

    def uses_shared_memory(self, tensor_id: str) -> bool:
        with self._lock:
            if tensor_id in self.shared_blocks:
                return True
            tensor = self.storage.get(tensor_id)
            return bool(tensor is not None and hasattr(tensor, "is_shared") and tensor.is_shared())

    def allocation_mode(self, tensor_id: str) -> str:
        with self._lock:
            if tensor_id in self.shared_blocks:
                block = self.shared_blocks[tensor_id]
                return str(block.get("backend", "shared"))
            if tensor_id in self.allocation_modes:
                return self.allocation_modes[tensor_id]
            if tensor_id in self.tensors and self.tensors[tensor_id].is_view:
                return "view"
            return "unallocated"

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            storage = {}
            for tensor_id, tensor in self.storage.items():
                block = self.shared_blocks.get(tensor_id)
                if block is not None and block.get("backend") == "python_shm":
                    storage[tensor_id] = {
                        "backend": "python_shm",
                        "name": block["shm"].name,
                    }
                else:
                    storage[tensor_id] = tensor
            return {
                "handles": [handle.to_dict() for handle in self.tensors.values()],
                "storage": storage,
                "allocation_modes": dict(self.allocation_modes),
                "atomic_lock": self.atomic_lock_proxy,
            }

    def load_snapshot(self, snapshot: Dict[str, Any]) -> None:
        with self._lock:
            self.clear()
            self.atomic_lock_proxy = snapshot.get("atomic_lock")
            handles = snapshot.get("handles", [])
            for item in handles:
                if not isinstance(item, dict):
                    raise TypeError("shared tensor snapshot handle must be dict")
                spec = SharedTensorSpec.from_any(item)
                runtime_name = item.get("runtime_name")
                if runtime_name is not None:
                    runtime_name = str(runtime_name)
                handle = SharedTensorHandle(
                    tensor_id=str(item.get("tensor_id", spec.name)),
                    spec=spec,
                    runtime_name=runtime_name,
                )
                self.tensors[handle.tensor_id] = handle
            storage = snapshot.get("storage", {})
            if not isinstance(storage, dict):
                raise TypeError("shared tensor snapshot storage must be dict")
            allocation_modes = snapshot.get("allocation_modes", {})
            if isinstance(allocation_modes, dict):
                for tensor_id, mode in allocation_modes.items():
                    self.allocation_modes[str(tensor_id)] = str(mode)
            for tensor_id, tensor in storage.items():
                tensor_id = str(tensor_id)
                if isinstance(tensor, dict) and tensor.get("backend") == "python_shm":
                    self.storage[tensor_id] = self._open_python_shm(
                        tensor_id,
                        name=str(tensor["name"]),
                    )
                    continue
                self.storage[tensor_id] = tensor

    def _open_python_shm(self, tensor_id: str, name: str) -> Any:
        try:
            import numpy as np
            import torch
        except Exception as exc:
            raise RuntimeError("torch and numpy are required for shared tensor allocation") from exc
        handle = self.get(tensor_id)
        shm = shared_memory.SharedMemory(name=name)
        _detach_non_owner_shm_from_tracker(shm)
        np_dtype = numpy_dtype_from_shared_name(handle.spec.dtype)
        torch_dtype = torch_dtype_from_shared_name(handle.spec.dtype)
        shape = handle.spec.shape if handle.spec.shape else tuple()
        array = np.ndarray(shape=shape, dtype=np_dtype, buffer=shm.buf)
        tensor = torch.from_numpy(array)
        if tensor.dtype != torch_dtype:
            tensor = tensor.view(torch_dtype)
        self.shared_blocks[tensor_id] = {
            "backend": "python_shm",
            "shm": shm,
            "owner": False,
        }
        return tensor

    def clear(self) -> None:
        with self._lock:
            for block in self.shared_blocks.values():
                shm = block.get("shm")
                if shm is None:
                    continue
                try:
                    shm.close()
                except Exception:
                    pass  # best-effort cleanup; shm may already be closed
                if block.get("owner"):
                    try:
                        shm.unlink()
                    except Exception:
                        pass  # best-effort cleanup; shm may already be unlinked
            self.tensors.clear()
            self.storage.clear()
            self.shared_blocks.clear()
            self.allocation_modes.clear()
            self.atomic_lock_proxy = None
            if self._sync_manager is not None:
                try:
                    self._sync_manager.shutdown()
                except Exception:
                    pass
                self._sync_manager = None
            if self.local_allocator is not None:
                self.local_allocator.clear()

    def _ensure_atomic_lock(self) -> None:
        if self.atomic_lock_proxy is not None:
            return
        if self._sync_manager is None:
            self._sync_manager = multiprocessing.Manager()
        self.atomic_lock_proxy = self._sync_manager.RLock()

    def atomic_lock(self) -> Any:
        with self._lock:
            self._ensure_atomic_lock()
            return self.atomic_lock_proxy

    def summary(self) -> List[Dict[str, Any]]:
        with self._lock:
            out = []
            for handle in self.tensors.values():
                item = handle.to_dict()
                item["allocated"] = self.is_allocated(handle.tensor_id)
                item["is_view"] = handle.is_view
                item["shared_memory"] = self.uses_shared_memory(handle.tensor_id)
                item["backend"] = self.allocation_mode(handle.tensor_id)
                out.append(item)
            return out

    def dump(self) -> str:
        with self._lock:
            lines = ["SharedTensorStore("]
            for handle in self.tensors.values():
                lines.append(
                    "  "
                    + handle.tensor_id
                    + ": dtype="
                    + handle.spec.dtype
                    + ", shape="
                    + str(handle.spec.shape)
                    + ", numel="
                    + str(handle.numel)
                    + ", role="
                    + handle.spec.role
                    + ", allocated="
                    + str(self.is_allocated(handle.tensor_id))
                )
            lines.append(")")
            return "\n".join(lines)
