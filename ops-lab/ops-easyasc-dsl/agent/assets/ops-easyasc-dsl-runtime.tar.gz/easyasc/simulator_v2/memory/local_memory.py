from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class LocalMemoryBank:
    """Per-core local memory bank."""

    name: str
    size_bytes: int = 0
    role: str = "local"
    tags: Tuple[str, ...] = tuple()
