# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

import re
import threading
from dataclasses import dataclass
from dataclasses import field
from typing import Any
from typing import Dict
from typing import Iterable
from typing import Optional
from typing import Tuple

from .shared_tensor import normalize_shared_dtype_name

_LOCAL_ROLE_TO_BANK = {
    "l1": "L1",
    "l0a": "L0A",
    "l0b": "L0B",
    "l0c": "L0C",
}

_DTYPE_SIZE_BYTES = {
    "float16": 2,
    "float32": 4,
    "int32": 4,
    "int64": 8,
    "int16": 2,
    "int8": 1,
    "uint8": 1,
    "uint16": 2,
    "uint32": 4,
    "uint64": 8,
    "bfloat16": 2,
    "float8_e4m3fn": 1,
    "float8_e5m2": 1,
    "bool": 1,
}

_EXPLICIT_STORAGE_OFFSET_TAG = "storage_offset_resolved"

_SCOPED_LANE_RE = re.compile(r"^__local_c\d+_(?P<lane>[^_].*?)__")


@dataclass(frozen=True)
class LocalMemoryBank:
    """Per-core local memory bank."""

    name: str
    size_bytes: int = 0
    role: str = "local"
    tags: Tuple[str, ...] = tuple()


@dataclass(frozen=True)
class LocalMemoryAllocation:
    """Allocation record for one local tensor inside a simulated bank."""

    tensor_id: str
    bank_name: str
    offset_bytes: int
    size_bytes: int
    source_tensor_id: Optional[str] = None


@dataclass
class LocalMemoryAllocator:
    """Sequential bank allocator for per-core local tensors."""

    banks: Dict[str, LocalMemoryBank]
    allocations: Dict[str, LocalMemoryAllocation] = field(default_factory=dict)
    next_offsets: Dict[str, int] = field(default_factory=dict)
    _lock: threading.RLock = field(default_factory=threading.RLock, init=False, repr=False)

    def __post_init__(self) -> None:
        normalized = {}
        for name, bank in self.banks.items():
            if not isinstance(bank, LocalMemoryBank):
                raise TypeError("banks must contain LocalMemoryBank values, got: " + str(type(bank)))
            normalized[str(name)] = bank
        self.banks = normalized
        for bank_name in self.banks:
            self.next_offsets.setdefault(bank_name, 0)

    @classmethod
    def from_banks(cls, banks: Iterable[LocalMemoryBank]) -> "LocalMemoryAllocator":
        mapping = {}
        for bank in banks:
            if not isinstance(bank, LocalMemoryBank):
                raise TypeError("banks must contain LocalMemoryBank values, got: " + str(type(bank)))
            mapping[str(bank.name)] = bank
        return cls(banks=mapping)

    def register_spec(self, spec: Any) -> Optional[LocalMemoryAllocation]:
        name = str(getattr(spec, "name", ""))
        role = str(getattr(spec, "role", "")).lower()
        if name == "" or role == "":
            return None
        source_name = getattr(spec, "source_name", None)
        if source_name is not None:
            source_name = str(source_name)
        if not self._is_local_tensor_name(name, source_name):
            return None
        with self._lock:
            existing = self.allocations.get(name)
            if existing is not None:
                return existing
            if source_name not in (None, "", name):
                source_alloc = self.allocations.get(source_name)
                if source_alloc is None:
                    raise KeyError("local memory source tensor is not allocated: " + source_name)
                alloc = LocalMemoryAllocation(
                    tensor_id=name,
                    bank_name=source_alloc.bank_name,
                    offset_bytes=source_alloc.offset_bytes,
                    size_bytes=self._spec_size_bytes(spec),
                    source_tensor_id=source_name,
                )
                self.allocations[name] = alloc
                return alloc

            bank_name = self._bank_name_for_spec(name, role)
            bank = self.banks.get(bank_name)
            if bank is None:
                raise KeyError("local memory bank is not configured: " + bank_name)
            size_bytes = self._spec_size_bytes(spec)
            used_bytes = int(self.next_offsets.get(bank_name, 0))
            offset_bytes = used_bytes
            if self._has_explicit_storage_offset(spec):
                offset_bytes = self._storage_offset_bytes(spec)
            next_used_bytes = max(used_bytes, offset_bytes + size_bytes)
            capacity_bytes = int(bank.size_bytes)
            if capacity_bytes > 0 and next_used_bytes > capacity_bytes:
                raise MemoryError(
                    "local memory allocation exceeds bank capacity: "
                    + "tensor="
                    + name
                    + ", bank="
                    + bank_name
                    + ", request="
                    + str(size_bytes)
                    + " bytes, used="
                    + str(offset_bytes)
                    + " bytes, capacity="
                    + str(capacity_bytes)
                    + " bytes"
                )
            alloc = LocalMemoryAllocation(
                tensor_id=name,
                bank_name=bank_name,
                offset_bytes=offset_bytes,
                size_bytes=size_bytes,
                source_tensor_id=None,
            )
            self.allocations[name] = alloc
            self.next_offsets[bank_name] = next_used_bytes
            return alloc

    def allocation_for(self, tensor_id: str) -> Optional[LocalMemoryAllocation]:
        with self._lock:
            return self.allocations.get(str(tensor_id))

    def clear(self) -> None:
        with self._lock:
            self.allocations.clear()
            self.next_offsets = {bank_name: 0 for bank_name in self.banks}

    @staticmethod
    def _is_local_tensor_name(name: str, source_name: Optional[str]) -> bool:
        if name.startswith("__local_c"):
            return True
        return isinstance(source_name, str) and source_name.startswith("__local_c")

    @staticmethod
    def _lane_name_from_tensor_id(tensor_id: str) -> str:
        match = _SCOPED_LANE_RE.match(str(tensor_id))
        if match is None:
            return ""
        lane_name = match.group("lane")
        if not isinstance(lane_name, str):
            return ""
        return lane_name

    @classmethod
    def _bank_name_for_spec(cls, tensor_id: str, role: str) -> str:
        normalized_role = str(role).lower()
        if normalized_role == "ub":
            lane_name = cls._lane_name_from_tensor_id(tensor_id)
            if lane_name == "vec1":
                return "UB1"
            return "UB0"
        bank_name = _LOCAL_ROLE_TO_BANK.get(normalized_role)
        if bank_name is None:
            raise KeyError("unsupported local tensor role for allocation: " + str(role))
        return bank_name

    @staticmethod
    def _dtype_size_bytes(dtype: Any) -> int:
        normalized = normalize_shared_dtype_name(dtype)
        size_bytes = _DTYPE_SIZE_BYTES.get(normalized)
        if size_bytes is None:
            raise TypeError("unsupported local allocation dtype: " + str(dtype))
        return int(size_bytes)

    @staticmethod
    def _has_explicit_storage_offset(spec: Any) -> bool:
        tags = getattr(spec, "tags", tuple())
        if not isinstance(tags, (list, tuple, set)):
            return False
        return _EXPLICIT_STORAGE_OFFSET_TAG in {str(tag) for tag in tags}

    @classmethod
    def _storage_offset_bytes(cls, spec: Any) -> int:
        storage_offset = getattr(spec, "storage_offset", 0)
        if not isinstance(storage_offset, int):
            raise TypeError("local allocation storage_offset must be int")
        if storage_offset < 0:
            raise ValueError("local allocation storage_offset must be non-negative")
        return int(storage_offset)

    @classmethod
    def _spec_size_bytes(cls, spec: Any) -> int:
        numel = getattr(spec, "numel", None)
        if not isinstance(numel, int):
            raise TypeError("local allocation spec must expose integer numel")
        return int(numel) * cls._dtype_size_bytes(getattr(spec, "dtype", ""))
