# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence, Tuple, Union


def _shape_to_tuple(shape: Any) -> Tuple[int, ...]:
    if shape is None:
        return tuple()
    if not isinstance(shape, (list, tuple)):
        raise TypeError("shape must be list/tuple, got: " + str(type(shape)))
    out = []
    for idx, dim in enumerate(shape):
        if isinstance(dim, bool) or not isinstance(dim, int):
            raise TypeError("shape[" + str(idx) + "] must be int, got: " + str(type(dim)))
        if dim < 0:
            raise ValueError("shape[" + str(idx) + "] must be non-negative, got: " + str(dim))
        out.append(int(dim))
    return tuple(out)


def _tags_to_tuple(tags: Any) -> Tuple[str, ...]:
    if tags is None:
        return tuple()
    if isinstance(tags, str):
        return (tags,)
    if not isinstance(tags, (list, tuple, set)):
        raise TypeError("tags must be str or list/tuple/set of str, got: " + str(type(tags)))
    out = []
    for idx, tag in enumerate(tags):
        if not isinstance(tag, str):
            raise TypeError("tags[" + str(idx) + "] must be str, got: " + str(type(tag)))
        if tag != "":
            out.append(tag)
    return tuple(out)


def _strides_to_tuple(strides: Any) -> Tuple[int, ...]:
    if strides is None:
        return tuple()
    if not isinstance(strides, (list, tuple)):
        raise TypeError("view_strides must be list/tuple, got: " + str(type(strides)))
    out = []
    for idx, stride in enumerate(strides):
        if isinstance(stride, bool) or not isinstance(stride, int):
            raise TypeError("view_strides[" + str(idx) + "] must be int, got: " + str(type(stride)))
        if stride < 0:
            raise ValueError("view_strides[" + str(idx) + "] must be non-negative, got: " + str(stride))
        out.append(int(stride))
    return tuple(out)


def _numel_from_shape(shape: Tuple[int, ...]) -> int:
    total = 1
    for dim in shape:
        total *= dim
    return total


def normalize_shared_dtype_name(dtype: Any) -> str:
    if hasattr(dtype, "name"):
        dtype = getattr(dtype, "name")
    name = str(dtype).strip()
    aliases = {
        "torch.float16": "float16",
        "half": "float16",
        "float16_t": "float16",
        "torch.float32": "float32",
        "float": "float32",
        "float_t": "float32",
        "torch.int32": "int32",
        "int": "int32",
        "int32_t": "int32",
        "torch.int64": "int64",
        "int64_t": "int64",
        "torch.int16": "int16",
        "int16_t": "int16",
        "torch.int8": "int8",
        "int8_t": "int8",
        "torch.uint8": "uint8",
        "uint8_t": "uint8",
        "torch.bfloat16": "bfloat16",
        "bfloat16_t": "bfloat16",
        "torch.float8_e4m3fn": "float8_e4m3fn",
        "float8_e4m3_t": "float8_e4m3fn",
        "torch.float8_e5m2": "float8_e5m2",
        "float8_e5m2_t": "float8_e5m2",
        "torch.bool": "bool",
        "bool_t": "bool",
    }
    return aliases.get(name, name)


def torch_dtype_from_shared_name(dtype: Any) -> Any:
    try:
        import torch
    except Exception as exc:
        raise RuntimeError("torch is required for shared tensor allocation") from exc
    name = normalize_shared_dtype_name(dtype)
    mapping = {
        "float16": torch.float16,
        "float32": torch.float32,
        "int32": torch.int32,
        "int64": torch.int64,
        "int16": torch.int16,
        "int8": torch.int8,
        "uint8": torch.uint8,
        "bfloat16": torch.bfloat16,
        "bool": torch.bool,
    }
    if name in mapping:
        return mapping[name]
    if name == "uint16" and hasattr(torch, "uint16"):
        return torch.uint16  # type: ignore[attr-defined]
    if name == "uint32" and hasattr(torch, "uint32"):
        return torch.uint32  # type: ignore[attr-defined]
    if name == "uint64" and hasattr(torch, "uint64"):
        return torch.uint64  # type: ignore[attr-defined]
    if name == "float8_e4m3fn" and hasattr(torch, "float8_e4m3fn"):
        return torch.float8_e4m3fn  # type: ignore[attr-defined]
    if name == "float8_e5m2" and hasattr(torch, "float8_e5m2"):
        return torch.float8_e5m2  # type: ignore[attr-defined]
    raise TypeError("unsupported shared tensor dtype: " + str(dtype))


def numpy_dtype_from_shared_name(dtype: Any) -> Any:
    try:
        import numpy as np
    except Exception as exc:
        raise RuntimeError("numpy is required for shared tensor allocation") from exc
    name = normalize_shared_dtype_name(dtype)
    mapping = {
        "float16": np.float16,
        "float32": np.float32,
        "int32": np.int32,
        "int64": np.int64,
        "int16": np.int16,
        "int8": np.int8,
        "uint8": np.uint8,
        # numpy has no native bfloat16 dtype here, but the simulator only
        # needs 2-byte-compatible backing for torch bfloat16 views.
        "bfloat16": np.uint16,
        # numpy has no native float8 dtype here, but simulator shared-memory
        # storage only needs byte-compatible backing for torch float8 views.
        "float8_e4m3fn": np.uint8,
        "float8_e5m2": np.uint8,
        "bool": np.bool_,
    }
    if name in mapping:
        return mapping[name]
    if name == "uint16":
        return np.uint16
    if name == "uint32":
        return np.uint32
    if name == "uint64":
        return np.uint64
    raise TypeError("unsupported numpy shared tensor dtype: " + str(dtype))


@dataclass(frozen=True)
class SharedTensorSpec:
    """Specification for a shared tensor allocation."""

    name: str
    shape: Tuple[int, ...]
    dtype: str
    mutable: bool = True
    role: str = "shared"
    tags: Tuple[str, ...] = tuple()
    storage_offset: int = 0
    source_name: Optional[str] = None
    view_shape: Tuple[int, ...] = tuple()
    view_strides: Tuple[int, ...] = tuple()

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or self.name == "":
            raise TypeError("name must be non-empty str, got: " + str(type(self.name)))
        object.__setattr__(self, "shape", _shape_to_tuple(self.shape))
        if not isinstance(self.dtype, str) or self.dtype == "":
            raise TypeError("dtype must be non-empty str, got: " + str(type(self.dtype)))
        object.__setattr__(self, "dtype", normalize_shared_dtype_name(self.dtype))
        if not isinstance(self.mutable, bool):
            raise TypeError("mutable must be bool, got: " + str(type(self.mutable)))
        if not isinstance(self.role, str) or self.role == "":
            raise TypeError("role must be non-empty str, got: " + str(type(self.role)))
        object.__setattr__(self, "tags", _tags_to_tuple(self.tags))
        if not isinstance(self.storage_offset, int):
            raise TypeError("storage_offset must be int, got: " + str(type(self.storage_offset)))
        if self.storage_offset < 0:
            raise ValueError("storage_offset must be non-negative, got: " + str(self.storage_offset))
        if self.source_name is not None and not isinstance(self.source_name, str):
            raise TypeError("source_name must be str or None, got: " + str(type(self.source_name)))
        object.__setattr__(self, "view_shape", _shape_to_tuple(self.view_shape))
        object.__setattr__(self, "view_strides", _strides_to_tuple(self.view_strides))
        if self.view_strides and not self.view_shape:
            raise ValueError("view_strides requires non-empty view_shape")
        if self.view_shape and self.view_strides and len(self.view_shape) != len(self.view_strides):
            raise ValueError("view_shape and view_strides rank mismatch")

    @property
    def numel(self) -> int:
        return _numel_from_shape(self.shape)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "shape": list(self.shape),
            "dtype": self.dtype,
            "mutable": self.mutable,
            "role": self.role,
            "tags": list(self.tags),
            "storage_offset": self.storage_offset,
            "source_name": self.source_name,
            "view_shape": list(self.view_shape),
            "view_strides": list(self.view_strides),
            "numel": self.numel,
        }

    @classmethod
    def from_any(cls, value: Any, name_hint: Optional[str] = None) -> "SharedTensorSpec":
        if isinstance(value, SharedTensorSpec):
            if name_hint is not None and value.name != name_hint:
                return cls(
                    name=name_hint,
                    shape=value.shape,
                    dtype=value.dtype,
                    mutable=value.mutable,
                    role=value.role,
                    tags=value.tags,
                    storage_offset=value.storage_offset,
                    source_name=value.source_name or value.name,
                    view_shape=value.view_shape,
                    view_strides=value.view_strides,
                )
            return value
        if hasattr(value, "spec") and isinstance(getattr(value, "spec"), SharedTensorSpec):
            spec = getattr(value, "spec")
            if name_hint is not None and spec.name != name_hint:
                return cls(
                    name=name_hint,
                    shape=spec.shape,
                    dtype=spec.dtype,
                    mutable=spec.mutable,
                    role=spec.role,
                    tags=spec.tags,
                    storage_offset=spec.storage_offset,
                    source_name=spec.source_name or spec.name,
                    view_shape=spec.view_shape,
                    view_strides=spec.view_strides,
                )
            return spec
        if isinstance(value, dict):
            name = str(value.get("name", name_hint or ""))
            if name == "":
                raise ValueError("shared tensor spec requires a name")
            shape = value.get("shape", tuple())
            dtype = str(value.get("dtype", ""))
            mutable = bool(value.get("mutable", True))
            role = str(value.get("role", "shared"))
            tags = value.get("tags", tuple())
            storage_offset = int(value.get("storage_offset", 0))
            source_name = value.get("source_name", value.get("source", None))
            view_shape = value.get("view_shape", tuple())
            view_strides = value.get("view_strides", tuple())
            if source_name is not None:
                source_name = str(source_name)
            return cls(
                name=name,
                shape=_shape_to_tuple(shape),
                dtype=dtype,
                mutable=mutable,
                role=role,
                tags=_tags_to_tuple(tags),
                storage_offset=storage_offset,
                source_name=source_name,
                view_shape=_shape_to_tuple(view_shape),
                view_strides=_strides_to_tuple(view_strides),
            )
        if isinstance(value, (list, tuple)):
            if len(value) == 3 and isinstance(value[0], str):
                name, dtype, shape = value
                return cls(name=name, dtype=str(dtype), shape=_shape_to_tuple(shape))
            raise TypeError("unsupported shared tensor declaration tuple: " + str(value))
        if name_hint is not None and hasattr(value, "shape") and hasattr(value, "dtype"):
            shape = _shape_to_tuple(getattr(value, "shape"))
            dtype = str(getattr(value, "dtype"))
            mutable = bool(getattr(value, "mutable", True))
            role = str(getattr(value, "role", "shared"))
            tags = _tags_to_tuple(getattr(value, "tags", tuple()))
            storage_offset = int(getattr(value, "storage_offset", 0))
            source_name = getattr(value, "source_name", None)
            view_shape = _shape_to_tuple(getattr(value, "view_shape", tuple()))
            view_strides = _strides_to_tuple(getattr(value, "view_strides", tuple()))
            if source_name is not None:
                source_name = str(source_name)
            return cls(
                name=name_hint,
                shape=shape,
                dtype=dtype,
                mutable=mutable,
                role=role,
                tags=tags,
                storage_offset=storage_offset,
                source_name=source_name,
                view_shape=view_shape,
                view_strides=view_strides,
            )
        raise TypeError("unsupported shared tensor spec declaration: " + str(type(value)))


@dataclass(frozen=True)
class SharedTensorHandle:
    """Handle to a shared tensor stored in global runtime memory."""

    tensor_id: str
    spec: SharedTensorSpec
    runtime_name: Optional[str] = None

    @property
    def name(self) -> str:
        return self.runtime_name or self.tensor_id

    @property
    def numel(self) -> int:
        return self.spec.numel

    @property
    def source_name(self) -> Optional[str]:
        return self.spec.source_name

    @property
    def is_view(self) -> bool:
        return self.source_name not in (None, "", self.tensor_id)

    def to_dict(self) -> Dict[str, Any]:
        out = self.spec.to_dict()
        out["tensor_id"] = self.tensor_id
        out["runtime_name"] = self.runtime_name
        return out
