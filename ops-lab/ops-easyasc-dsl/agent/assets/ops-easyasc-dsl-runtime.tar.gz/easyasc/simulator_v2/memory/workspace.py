# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional

from .shared_tensor import SharedTensorSpec


@dataclass
class WorkspacePlan:
    """Preallocated workspace layout for the global runtime."""

    entries: List[SharedTensorSpec] = field(default_factory=list)
    name: str = "workspace"

    def add(self, spec: SharedTensorSpec) -> SharedTensorSpec:
        if not isinstance(spec, SharedTensorSpec):
            spec = SharedTensorSpec.from_any(spec)
        self.entries.append(spec)
        return spec

    def extend(self, specs: Iterable[SharedTensorSpec]) -> None:
        for spec in specs:
            self.add(spec)

    def total_numel(self) -> int:
        total = 0
        for spec in self.entries:
            total += spec.numel
        return total

    def summary(self) -> List[Dict[str, Any]]:
        return [spec.to_dict() for spec in self.entries]

    @classmethod
    def from_any(cls, value: Any) -> "WorkspacePlan":
        if isinstance(value, WorkspacePlan):
            return value
        plan = cls()
        if value is None:
            return plan
        if isinstance(value, SharedTensorSpec):
            plan.add(value)
            return plan
        if isinstance(value, dict):
            entries = value.get("entries", value.get("tensors", value))
            if isinstance(entries, (list, tuple, set)):
                for item in entries:
                    plan.add(SharedTensorSpec.from_any(item))
            elif isinstance(entries, dict):
                for key, item in entries.items():
                    plan.add(SharedTensorSpec.from_any(item, name_hint=str(key)))
            return plan
        if isinstance(value, (list, tuple, set)):
            for item in value:
                plan.add(SharedTensorSpec.from_any(item))
            return plan
        if hasattr(value, "entries"):
            entries = getattr(value, "entries")
            if entries is not None:
                return cls.from_any(entries)
        return plan
