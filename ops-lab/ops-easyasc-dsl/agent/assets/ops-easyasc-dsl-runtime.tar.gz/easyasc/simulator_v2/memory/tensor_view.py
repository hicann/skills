from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

from .shared_tensor import SharedTensorSpec


@dataclass(frozen=True)
class TensorViewSpec:
    """Logical tensor view descriptor."""

    base_name: str
    shape: Tuple[int, ...]
    strides: Tuple[int, ...]
    offset: int = 0
    dtype: str = "float"
    mutable: bool = False
    role: str = "view"
    source_name: Optional[str] = None

    def to_shared_spec(self, name: Optional[str] = None) -> SharedTensorSpec:
        spec_name = name if name is not None else self.base_name
        return SharedTensorSpec(
            name=spec_name,
            shape=self.shape,
            dtype=self.dtype,
            mutable=self.mutable,
            role=self.role,
            storage_offset=self.offset,
            source_name=self.source_name or self.base_name,
            view_shape=self.shape,
            view_strides=self.strides,
        )
