# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

from .shared_tensor import SharedTensorSpec


@dataclass(frozen=True)
class TensorViewSpec:
    """Logical tensor view descriptor."""

    base_name: str
    shape: Tuple[int, ...]
    strides: Tuple[int, ...]
    offset: int = 0
    dtype: str = "float"
    mutable: bool = False
    role: str = "view"
    source_name: Optional[str] = None

    def to_shared_spec(self, name: Optional[str] = None) -> SharedTensorSpec:
        spec_name = name if name is not None else self.base_name
        return SharedTensorSpec(
            name=spec_name,
            shape=self.shape,
            dtype=self.dtype,
            mutable=self.mutable,
            role=self.role,
            storage_offset=self.offset,
            source_name=self.source_name or self.base_name,
            view_shape=self.shape,
            view_strides=self.strides,
        )
