# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
"""Compatibility adapters for simulator V2."""

from .kernel_bridge import LegacyInstructionKernelBridge, build_kernel_program_from_legacy_instructions
from .op_exec_adapter import SimulatorV2OpExecAdapter
from .result_adapter import SimulatorV2ResultAdapter

__all__ = [
    "LegacyInstructionKernelBridge",
    "SimulatorV2OpExecAdapter",
    "SimulatorV2ResultAdapter",
    "build_kernel_program_from_legacy_instructions",
]
