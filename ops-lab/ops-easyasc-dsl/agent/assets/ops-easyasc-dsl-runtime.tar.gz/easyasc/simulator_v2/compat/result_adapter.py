from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..runtime.global_runtime import GlobalRuntime


@dataclass
class SimulatorV2ResultAdapter:
    """Future adapter for turning V2 runtime results back into user-facing tensors."""

    def adapt(self, result: Any) -> Any:
        if isinstance(result, GlobalRuntime):
            return {
                "runtime": result,
                "summary": result.summary(),
                "trace": [event.to_dict() for event in result.merged_trace],
                "chrome_trace": result.chrome_trace(),
            }
        return result
