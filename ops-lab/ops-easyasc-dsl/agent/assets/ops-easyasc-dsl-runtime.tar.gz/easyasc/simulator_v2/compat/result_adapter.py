# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..runtime.global_runtime import GlobalRuntime


@dataclass
class SimulatorV2ResultAdapter:
    """Future adapter for turning V2 runtime results back into user-facing tensors."""

    def adapt(self, result: Any) -> Any:
        if isinstance(result, GlobalRuntime):
            return {
                "runtime": result,
                "summary": result.summary(),
                "trace": [event.to_dict() for event in result.merged_trace],
                "chrome_trace": result.chrome_trace(),
            }
        return result
