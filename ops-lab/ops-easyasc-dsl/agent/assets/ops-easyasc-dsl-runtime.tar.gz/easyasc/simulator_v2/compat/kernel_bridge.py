from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

from ...utils.Tensor import GMTensor, Tensor
from ...utils.datatype import DataTypeValue
from ...utils.instruction import Instruction
from ...utils.positions import Position
from ...utils.var import Var
from ..program.kernel_program import KernelProgram
from ..program.lane_program import LaneProgram
from ..program.task import PipeTask


_CUBE_PIPE_NAMES = ["MTE2", "MTE1", "M", "FIX"]
_VEC_PIPE_NAMES = ["MTE2", "V", "MTE3"]
_NOOP_OPNAMES = frozenset(
    [
        "reset_cache",
        "inline",
        "start_auto_sync",
        "end_auto_sync",
        "create_var",
        "var_add",
        "var_sub",
        "var_mul",
        "var_div",
        "var_mod",
        "Min",
        "Max",
        "CeilDiv",
        "Align8",
        "Align16",
        "Align32",
        "Align64",
        "Align128",
        "Align256",
        "set_atomic_type",
    ]
)
_CUBE_PIPE_BY_OPNAME = {
    "gm_to_l1_nd2nz": "MTE2",
    "set_constant_to_l1": "MTE2",
    "l1_to_l0": "MTE1",
    "mmad": "M",
    "l0c_to_gm_nz2nd": "FIX",
    "l0c_to_l1": "FIX",
    "l0c_to_ub": "FIX",
}
_VEC_PIPE_BY_OPNAME = {
    "gm_to_ub_pad": "MTE2",
    "ub_to_gm_pad": "MTE3",
    "ub_to_l1_nd2nz": "MTE3",
    "ub_to_l1_nz": "MTE3",
    "add": "V",
    "sub": "V",
    "mul": "V",
    "div": "V",
    "max": "V",
    "min": "V",
    "abs": "V",
    "relu": "V",
    "vmax": "V",
    "vmin": "V",
    "vabs": "V",
    "vec_v_relu": "V",
    "dup": "V",
    "adds": "V",
    "muls": "V",
    "vmaxs": "V",
    "vmins": "V",
    "lrelu": "V",
    "compare": "V",
    "compare_scalar": "V",
    "select": "V",
    "cast": "V",
}
_VEC_RUNTIME_OPNAME_BY_LEGACY = {
    "max": "vmax",
    "min": "vmin",
    "abs": "vabs",
    "relu": "vec_v_relu",
}
_SHARED_DTYPE_NAMES = {
    "half": "float16",
    "float": "float32",
    "int": "int32",
    "int8_t": "int8",
    "uint8_t": "uint8",
    "int16_t": "int16",
    "uint16_t": "uint16",
    "float8_e4m3_t": "float8_e4m3fn",
    "float8_e5m2_t": "float8_e5m2",
    "bfloat16_t": "bfloat16",
    "uint32_t": "uint32",
    "uint64_t": "uint64",
    "int64_t": "int64",
}
def _align_to(value: int, align: int) -> int:
    if align <= 0:
        raise ValueError("align must be positive, got: " + str(align))
    return ((int(value) + align - 1) // align) * align


def _product(values: Sequence[int]) -> int:
    total = 1
    for value in values:
        total *= int(value)
    return total


def _position_role(position: Any) -> str:
    name = str(getattr(position, "name", position)).upper()
    mapping = {
        "L1": "l1",
        "L0A": "l0a",
        "L0B": "l0b",
        "L0C": "l0c",
        "UB": "ub",
    }
    return mapping.get(name, "shared")


@dataclass
class LegacyInstructionKernelBridge:
    """Translate a narrow lowered-instruction subset into a V2 KernelProgram."""

    kernel: Any
    tensor_specs: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    cube_tasks: List[PipeTask] = field(default_factory=list)
    vec_tasks: List[PipeTask] = field(default_factory=list)
    resolved_vars: Dict[str, Any] = field(default_factory=dict)
    active_atomic_mode: Optional[str] = field(default=None, init=False)
    active_atomic_dtype: Optional[str] = field(default=None, init=False)

    def build(self) -> KernelProgram:
        instructions = list(getattr(self.kernel, "instructions", []) or [])
        for inst in instructions:
            if not isinstance(inst, Instruction):
                raise TypeError("kernel.instructions must contain Instruction objects")
            self._handle_instruction(inst)
        if self.cube_tasks and self.vec_tasks:
            raise NotImplementedError(
                "simulator_v2 default bridge currently supports pure cube or pure vec "
                "linear kernels, not mixed cube/vec kernels"
            )
        return KernelProgram(
            name=str(getattr(self.kernel, "name", "kernel")) + "_v2_bridge",
            core_count=1,
            lane_programs=[
                LaneProgram(lane_name="cube", pipe_names=list(_CUBE_PIPE_NAMES), tasks=list(self.cube_tasks)),
                LaneProgram(lane_name="vec0", pipe_names=list(_VEC_PIPE_NAMES), tasks=list(self.vec_tasks)),
                LaneProgram(lane_name="vec1", pipe_names=list(_VEC_PIPE_NAMES)),
            ],
            metadata={
                "shared_tensors": list(self.tensor_specs.values()),
                "bridge_mode": "legacy_linear_v1",
                "legacy_instruction_count": len(instructions),
            },
        )

    def _handle_instruction(self, inst: Instruction) -> None:
        opname = str(inst.opname)
        if opname in ("atomic_add", "atomic_max", "atomic_min", "atomic_end", "set_atomic_type"):
            self._update_atomic_state(inst)
            return
        if opname == "create_gm_tensor":
            self._register_gm_tensor(inst.val)
            return
        if opname == "slice_gm_tensor":
            self._register_gm_slice(inst)
            return
        if opname == "create_tensor":
            self._register_local_tensor(inst.val)
            return
        if opname == "slice_tensor":
            self._register_local_slice(inst)
            return
        if opname == "create_dbuf":
            return
        if opname == "create_tbuf":
            return
        if opname == "create_qbuf":
            return
        if opname == "get_buf":
            self._register_local_tensor(inst.out)
            return
        if opname == "reinterpret":
            self._register_reinterpret(inst)
            return
        if opname in _NOOP_OPNAMES:
            self._update_var_state(inst)
            return
        pipe_name = _CUBE_PIPE_BY_OPNAME.get(opname)
        if pipe_name is not None:
            self.cube_tasks.append(PipeTask(pipe_name=pipe_name, opname=opname, args=self._task_args(inst)))
            return
        pipe_name = _VEC_PIPE_BY_OPNAME.get(opname)
        if pipe_name is not None:
            runtime_opname = _VEC_RUNTIME_OPNAME_BY_LEGACY.get(opname, opname)
            self.vec_tasks.append(PipeTask(pipe_name=pipe_name, opname=runtime_opname, args=self._task_args(inst)))
            return
        raise NotImplementedError(
            "simulator_v2 default bridge does not support legacy instruction: " + opname
        )

    def _update_atomic_state(self, inst_or_opname: Any) -> None:
        opname = str(getattr(inst_or_opname, "opname", inst_or_opname))
        if opname == "atomic_add":
            self.active_atomic_mode = "add"
            self.active_atomic_dtype = "float"
            return
        if opname == "atomic_max":
            self.active_atomic_mode = "max"
            self.active_atomic_dtype = "float"
            return
        if opname == "atomic_min":
            self.active_atomic_mode = "min"
            self.active_atomic_dtype = "float"
            return
        if opname == "set_atomic_type":
            dtype_ref = getattr(inst_or_opname, "dtype", None)
            if dtype_ref is not None:
                self.active_atomic_dtype = str(dtype_ref)
            return
        self.active_atomic_mode = None
        self.active_atomic_dtype = None

    def _update_var_state(self, inst: Instruction) -> None:
        opname = str(inst.opname)
        if opname == "create_var":
            var_obj = getattr(inst, "val", None)
            if isinstance(var_obj, Var):
                self.resolved_vars[var_obj.name] = self._resolve_value(var_obj, "create_var value")
            return
        if opname == "var_add":
            out = getattr(inst, "out", None)
            if isinstance(out, Var):
                lhs = self._resolve_value(getattr(inst, "a", 0), "var_add a")
                rhs = self._resolve_value(getattr(inst, "b", 0), "var_add b")
                value = lhs + rhs
                self.resolved_vars[out.name] = value
            return
        if opname == "var_sub":
            out = getattr(inst, "out", None)
            if isinstance(out, Var):
                lhs = self._resolve_value(getattr(inst, "a", 0), "var_sub a")
                rhs = self._resolve_value(getattr(inst, "b", 0), "var_sub b")
                value = lhs - rhs
                self.resolved_vars[out.name] = value
            return
        if opname == "var_mul":
            out = getattr(inst, "out", None)
            if isinstance(out, Var):
                lhs = self._resolve_value(getattr(inst, "a", 0), "var_mul a")
                rhs = self._resolve_value(getattr(inst, "b", 0), "var_mul b")
                value = lhs * rhs
                self.resolved_vars[out.name] = value
            return
        if opname == "var_div":
            out = getattr(inst, "out", None)
            if isinstance(out, Var):
                lhs = self._resolve_value(getattr(inst, "a", 0), "var_div a")
                rhs = self._resolve_value(getattr(inst, "b", 1), "var_div b")
                if int(rhs) == 0:
                    raise ZeroDivisionError("var_div bridge encountered divide-by-zero")
                value = int(lhs) // int(rhs)
                self.resolved_vars[out.name] = value
            return
        if opname == "var_mod":
            out = getattr(inst, "out", None)
            if isinstance(out, Var):
                lhs = self._resolve_value(getattr(inst, "a", 0), "var_mod a")
                rhs = self._resolve_value(getattr(inst, "b", 1), "var_mod b")
                if int(rhs) == 0:
                    raise ZeroDivisionError("var_mod bridge encountered divide-by-zero")
                value = int(lhs) % int(rhs)
                self.resolved_vars[out.name] = value
            return
        if opname in ("Min", "Max", "CeilDiv", "Align8", "Align16", "Align32", "Align64", "Align128", "Align256"):
            out = getattr(inst, "out", None)
            if not isinstance(out, Var):
                return
            if opname == "Min":
                value = min(self._resolve_value(inst.a, "Min a"), self._resolve_value(inst.b, "Min b"))
            elif opname == "Max":
                value = max(self._resolve_value(inst.a, "Max a"), self._resolve_value(inst.b, "Max b"))
            elif opname == "CeilDiv":
                divisor = int(self._resolve_value(inst.b, "CeilDiv b"))
                if divisor == 0:
                    raise ZeroDivisionError("CeilDiv bridge encountered divide-by-zero")
                dividend = int(self._resolve_value(inst.a, "CeilDiv a"))
                value = (dividend + divisor - 1) // divisor
            else:
                align = int(opname.replace("Align", ""))
                value = _align_to(int(self._resolve_value(inst.a, opname + " a")), align)
            self.resolved_vars[out.name] = value

    def _task_args(self, inst: Instruction) -> Dict[str, Any]:
        opname = str(inst.opname)
        if opname == "gm_to_l1_nd2nz":
            return {
                "dst": self._tensor_name(inst.dst, "gm_to_l1_nd2nz dst"),
                "src": self._tensor_name(inst.src, "gm_to_l1_nd2nz src"),
                "M": self._resolve_int(inst.M, "gm_to_l1_nd2nz M"),
                "N": self._resolve_int(inst.N, "gm_to_l1_nd2nz N"),
                "N_src": self._resolve_int(inst.N_src, "gm_to_l1_nd2nz N_src"),
                "M_dst": self._resolve_int(inst.M_dst, "gm_to_l1_nd2nz M_dst"),
            }
        if opname == "set_constant_to_l1":
            return {
                "tensor": self._tensor_name(getattr(inst, "tensor", getattr(inst, "dst", None)), "set_constant_to_l1 tensor"),
                "val": self._resolve_scalar(inst.val, "set_constant_to_l1 val"),
                "n_blocks": self._resolve_int(inst.n_blocks, "set_constant_to_l1 n_blocks"),
            }
        if opname == "l1_to_l0":
            dst = inst.dst
            src = inst.src
            return {
                "dst": self._tensor_name(dst, "l1_to_l0 dst"),
                "src": self._tensor_name(src, "l1_to_l0 src"),
                "m_dst": self._resolve_int(inst.m_dst, "l1_to_l0 m_dst"),
                "n_dst": self._resolve_int(inst.n_dst, "l1_to_l0 n_dst"),
                "m_src": self._resolve_int(inst.m_src, "l1_to_l0 m_src"),
                "n_src": self._resolve_int(inst.n_src, "l1_to_l0 n_src"),
                "src_is_transpose": bool(getattr(src, "is_transpose", False)),
                "src_layout": str(getattr(src, "_sim_layout", "NZ")),
                "dst_layout": str(getattr(dst, "_sim_layout", "ZN" if bool(getattr(src, "is_transpose", False)) else "NZ")),
                "src_position": str(getattr(src, "position", "")),
                "dst_position": str(getattr(dst, "position", "")),
            }
        if opname == "mmad":
            return {
                "dst": self._tensor_name(inst.dst, "mmad dst"),
                "src_a": self._tensor_name(inst.src_a, "mmad src_a"),
                "src_b": self._tensor_name(inst.src_b, "mmad src_b"),
                "M": self._resolve_int(inst.M, "mmad M"),
                "N": self._resolve_int(inst.N, "mmad N"),
                "K": self._resolve_int(inst.K, "mmad K"),
                "is_init": bool(inst.is_init),
                "src_a_layout": str(getattr(inst.src_a, "_sim_layout", "NZ")),
                "src_b_layout": str(getattr(inst.src_b, "_sim_layout", "NZ")),
                "src_a_position": str(getattr(inst.src_a, "position", "")),
                "src_b_position": str(getattr(inst.src_b, "position", "")),
                "dst_position": str(getattr(inst.dst, "position", "")),
            }
        if opname == "l0c_to_gm_nz2nd":
            args = {
                "dst": self._tensor_name(inst.dst, "l0c_to_gm_nz2nd dst"),
                "src": self._tensor_name(inst.src, "l0c_to_gm_nz2nd src"),
                "M": self._resolve_int(inst.M, "l0c_to_gm_nz2nd M"),
                "N": self._resolve_int(inst.N, "l0c_to_gm_nz2nd N"),
                "N_dst": self._resolve_int(inst.N_dst, "l0c_to_gm_nz2nd N_dst"),
                "M_src": self._resolve_int(inst.M_src, "l0c_to_gm_nz2nd M_src"),
                "relu": bool(getattr(inst, "relu", False)),
            }
            if self.active_atomic_mode is not None:
                args["atomic_enabled"] = True
                args["atomic_mode"] = self.active_atomic_mode
                if self.active_atomic_dtype is not None:
                    args["atomic_dtype"] = self.active_atomic_dtype
            return args
        if opname == "l0c_to_l1":
            return {
                "dst": self._tensor_name(inst.dst, "l0c_to_l1 dst"),
                "src": self._tensor_name(inst.src, "l0c_to_l1 src"),
                "M": self._resolve_int(inst.M, "l0c_to_l1 M"),
                "N": self._resolve_int(inst.N, "l0c_to_l1 N"),
                "M_dst": self._resolve_int(inst.M_dst, "l0c_to_l1 M_dst"),
                "M_src": self._resolve_int(inst.M_src, "l0c_to_l1 M_src"),
                "relu": bool(getattr(inst, "relu", False)),
            }
        if opname == "l0c_to_ub":
            return {
                "dst": self._tensor_name(inst.dst, "l0c_to_ub dst"),
                "src": self._tensor_name(inst.src, "l0c_to_ub src"),
                "M": self._resolve_int(inst.M, "l0c_to_ub M"),
                "N": self._resolve_int(inst.N, "l0c_to_ub N"),
                "N_dst": self._resolve_int(inst.N_dst, "l0c_to_ub N_dst"),
                "M_src": self._resolve_int(inst.M_src, "l0c_to_ub M_src"),
                "dual_mode": self._resolve_int(inst.dual_mode, "l0c_to_ub dual_mode"),
                "sub_block_id": self._resolve_int(inst.sub_block_id, "l0c_to_ub sub_block_id"),
                "relu": bool(getattr(inst, "relu", False)),
            }
        if opname == "gm_to_ub_pad":
            return {
                "dst": self._tensor_name(inst.dst, "gm_to_ub_pad dst"),
                "src": self._tensor_name(inst.src, "gm_to_ub_pad src"),
                "n_burst": self._resolve_int(inst.n_burst, "gm_to_ub_pad n_burst"),
                "burst_len_byte": self._resolve_int(inst.burst_len_byte, "gm_to_ub_pad burst_len_byte"),
                "src_stride_byte": self._resolve_int(inst.src_stride_byte, "gm_to_ub_pad src_stride_byte"),
                "dst_stride": self._resolve_int(inst.dst_stride, "gm_to_ub_pad dst_stride"),
            }
        if opname == "ub_to_gm_pad":
            args = {
                "dst": self._tensor_name(inst.dst, "ub_to_gm_pad dst"),
                "src": self._tensor_name(inst.src, "ub_to_gm_pad src"),
                "n_burst": self._resolve_int(inst.n_burst, "ub_to_gm_pad n_burst"),
                "burst_len_byte": self._resolve_int(inst.burst_len_byte, "ub_to_gm_pad burst_len_byte"),
                "src_stride": self._resolve_int(inst.src_stride, "ub_to_gm_pad src_stride"),
                "dst_stride_byte": self._resolve_int(inst.dst_stride_byte, "ub_to_gm_pad dst_stride_byte"),
            }
            if self.active_atomic_mode is not None:
                args["atomic_enabled"] = True
                args["atomic_mode"] = self.active_atomic_mode
                if self.active_atomic_dtype is not None:
                    args["atomic_dtype"] = self.active_atomic_dtype
            return args
        if opname in ("add", "sub", "mul", "div", "max", "min"):
            return {
                "src1": self._tensor_name(inst.src1, opname + " src1"),
                "src2": self._tensor_name(inst.src2, opname + " src2"),
                "dst": self._tensor_name(inst.dst, opname + " dst"),
            }
        if opname in ("adds", "muls", "vmaxs", "vmins", "lrelu"):
            return {
                "src": self._tensor_name(inst.src, opname + " src"),
                "dst": self._tensor_name(inst.dst, opname + " dst"),
                "val": self._resolve_scalar(inst.val, opname + " val"),
            }
        if opname in ("abs", "relu"):
            return {
                "src": self._tensor_name(inst.src, opname + " src"),
                "dst": self._tensor_name(inst.dst, opname + " dst"),
            }
        if opname == "dup":
            return {
                "dst": self._tensor_name(inst.dst, "dup dst"),
                "value": self._resolve_scalar(getattr(inst, "value", getattr(inst, "src", 0)), "dup value"),
            }
        if opname == "compare":
            return {
                "src1": self._tensor_name(inst.src1, "compare src1"),
                "src2": self._tensor_name(inst.src2, "compare src2"),
                "dst": self._tensor_name(inst.dst, "compare dst"),
                "mode": self._resolve_mode_name(inst.mode),
            }
        if opname == "compare_scalar":
            return {
                "src1": self._tensor_name(inst.src1, "compare_scalar src1"),
                "dst": self._tensor_name(inst.dst, "compare_scalar dst"),
                "src2": self._resolve_scalar(inst.src2, "compare_scalar src2"),
                "mode": self._resolve_mode_name(inst.mode),
            }
        if opname == "select":
            src2 = inst.src2
            src2_value: Any
            if isinstance(src2, Tensor):
                src2_value = self._tensor_name(src2, "select src2")
            else:
                src2_value = self._resolve_scalar(src2, "select src2")
            return {
                "selmask": self._tensor_name(inst.selmask, "select selmask"),
                "src1": self._tensor_name(inst.src1, "select src1"),
                "src2": src2_value,
                "dst": self._tensor_name(inst.dst, "select dst"),
                "mode": self._resolve_mode_name(getattr(inst, "mode", None)),
            }
        if opname == "cast":
            return {
                "src": self._tensor_name(inst.src, "cast src"),
                "dst": self._tensor_name(inst.dst, "cast dst"),
                "mode": self._resolve_mode_name(inst.mode),
            }
        raise NotImplementedError("simulator_v2 default bridge task translation is missing for: " + opname)

    def _register_gm_tensor(self, tensor: GMTensor) -> None:
        if not isinstance(tensor, GMTensor):
            raise TypeError("create_gm_tensor val must be GMTensor")
        self._register_spec(
            name=str(tensor.name),
            shape=[self._resolve_numel(tensor.shape, "GM " + str(tensor.name) + " shape")],
            dtype=self._shared_dtype_name(tensor.dtype),
            role="gm",
            tags=["gm"],
        )

    def _register_gm_slice(self, inst: Instruction) -> None:
        src = getattr(inst, "src", None)
        out = getattr(inst, "out", None)
        if not isinstance(src, GMTensor) or not isinstance(out, GMTensor):
            raise TypeError("slice_gm_tensor requires GMTensor src/out")
        src_shape = self._resolve_shape(src.shape, "slice_gm_tensor src shape")
        offsets = self._resolve_shape(inst.offset, "slice_gm_tensor offset")
        spans = self._resolve_shape(inst.span, "slice_gm_tensor span")
        steps = self._resolve_shape(inst.step, "slice_gm_tensor step")
        if len(src_shape) != len(offsets) or len(src_shape) != len(spans) or len(src_shape) != len(steps):
            raise ValueError("slice_gm_tensor rank mismatch between shape/offset/span/step")
        if any(step != 1 for step in steps):
            raise NotImplementedError(
                "simulator_v2 default bridge only supports unit-step GM slices"
            )
        storage_offset = self._flat_contiguous_slice_offset(src_shape, offsets, spans)
        if storage_offset is None:
            raise NotImplementedError(
                "simulator_v2 default bridge only supports contiguous GM slices "
                "(full rows or single-row windows)"
            )
        self._register_spec(
            name=str(out.name),
            shape=[self._flat_slice_numel(src_shape, offsets, spans)],
            dtype=self._shared_dtype_name(out.dtype),
            role="gm_view",
            tags=["gm", "view"],
            source_name=str(src.name),
            storage_offset=storage_offset,
        )

    def _register_local_tensor(self, tensor: Tensor) -> None:
        if not isinstance(tensor, Tensor):
            raise TypeError("local tensor registration requires Tensor")
        role = _position_role(tensor.position)
        self._register_spec(
            name=str(tensor.name),
            shape=[self._storage_numel_for_tensor(tensor)],
            dtype=self._shared_dtype_name(tensor.dtype),
            role=role,
            tags=[role, str(getattr(tensor.position, "name", tensor.position))],
        )

    def _register_local_slice(self, inst: Instruction) -> None:
        src = getattr(inst, "src", None)
        out = getattr(inst, "out", None)
        if not isinstance(src, Tensor) or not isinstance(out, Tensor):
            return
        offsets = getattr(inst, "offset", [0, 0])
        spans = getattr(inst, "span", None)
        if spans is None:
            spans = getattr(out, "shape", [0, 0])
        row_off = self._resolve_int(offsets[0], "slice_tensor offset[0]") if len(offsets) > 0 else 0
        col_off = self._resolve_int(offsets[1], "slice_tensor offset[1]") if len(offsets) > 1 else 0
        src_shape = self._resolve_shape(src.shape, "slice_tensor src shape")
        src_rows = src_shape[0] if len(src_shape) > 0 else 0
        src_cols = src_shape[1] if len(src_shape) > 1 else 0
        storage_offset = self._local_slice_offset(src, row_off, col_off, src_rows, src_cols)
        resolved_spans = [self._resolve_int(span, "slice_tensor span") for span in spans]
        view_numel = self._slice_view_numel(resolved_spans)
        view_shape, view_strides = self._local_view_shape_and_strides(
            src, resolved_spans, src_rows, src_cols
        )
        role = _position_role(out.position)
        self._register_spec(
            name=str(out.name),
            shape=[view_numel],
            dtype=self._shared_dtype_name(out.dtype),
            role=role,
            tags=[role, "view"],
            source_name=str(src.name),
            storage_offset=storage_offset,
            view_shape=view_shape,
            view_strides=view_strides,
        )

    def _register_reinterpret(self, inst: Instruction) -> None:
        src = getattr(inst, "src", None)
        dst = getattr(inst, "dst", None)
        if not isinstance(src, Tensor) or not isinstance(dst, Tensor):
            return
        role = _position_role(dst.position)
        self._register_spec(
            name=str(dst.name),
            shape=[self._storage_numel_for_tensor(dst)],
            dtype=self._shared_dtype_name(dst.dtype),
            role=role,
            tags=[role, "view", "reinterpret"],
            source_name=str(src.name),
            storage_offset=0,
        )

    def _local_slice_offset(self, tensor: Tensor, row: int, col: int,
                            src_rows: int, src_cols: int) -> int:
        if tensor.position is Position.UB:
            return row * src_cols + col
        elem_size = int(tensor.dtype.size) if hasattr(tensor.dtype, "size") else 2
        c0 = 32 // max(elem_size, 1)
        if tensor.position is Position.L0C:
            c0 = 16
        if tensor.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C):
            align_rows = _align_to(src_rows, 16)
            return (col // c0) * align_rows * c0 + row * c0 + (col % c0)
        return row * src_cols + col

    def _register_spec(
        self,
        name: str,
        shape: Sequence[int],
        dtype: str,
        role: str,
        tags: Sequence[str],
        source_name: Optional[str] = None,
        storage_offset: int = 0,
        view_shape: Optional[Sequence[int]] = None,
        view_strides: Optional[Sequence[int]] = None,
    ) -> None:
        spec = {
            "name": str(name),
            "shape": [int(dim) for dim in shape],
            "dtype": str(dtype),
            "role": str(role),
            "tags": [str(tag) for tag in tags if str(tag) != ""],
            "mutable": True,
            "source_name": source_name,
            "storage_offset": int(storage_offset),
            "view_shape": [int(dim) for dim in (view_shape or tuple())],
            "view_strides": [int(stride) for stride in (view_strides or tuple())],
        }
        existing = self.tensor_specs.get(spec["name"])
        if existing is not None:
            if existing != spec:
                raise ValueError("bridge tensor spec conflict for: " + spec["name"])
            return
        self.tensor_specs[spec["name"]] = spec

    def _tensor_name(self, value: Any, label: str) -> str:
        if isinstance(value, (GMTensor, Tensor)):
            return str(value.name)
        raise TypeError(label + " must be GMTensor or Tensor, got: " + str(type(value)))

    def _resolve_shape(self, shape: Any, label: str) -> List[int]:
        if not isinstance(shape, (list, tuple)):
            raise TypeError(label + " must be list/tuple, got: " + str(type(shape)))
        out: List[int] = []
        for idx, dim in enumerate(shape):
            out.append(self._resolve_int(dim, label + "[" + str(idx) + "]"))
        return out

    def _resolve_numel(self, shape: Any, label: str) -> int:
        return _product(self._resolve_shape(shape, label))

    def _resolve_value(self, value: Any, label: str) -> Any:
        if isinstance(value, Var):
            if value.name in self.resolved_vars:
                return self.resolved_vars[value.name]
            raw = value.value
            if isinstance(raw, (int, float, bool)):
                return raw
            raise TypeError(label + " Var has unresolved value: " + value.name)
        if isinstance(value, DataTypeValue):
            return str(value)
        if isinstance(value, (int, float, bool)):
            return value
        raise TypeError(label + " must resolve to scalar, got: " + str(type(value)))

    def _resolve_scalar(self, value: Any, label: str) -> Any:
        resolved = self._resolve_value(value, label)
        if isinstance(resolved, bool):
            return int(resolved)
        if isinstance(resolved, (int, float)):
            return resolved
        raise TypeError(label + " must resolve to numeric scalar, got: " + str(type(resolved)))

    @staticmethod
    def _resolve_mode_name(value: Any) -> Any:
        if value is None:
            return None
        if hasattr(value, "name"):
            return str(getattr(value, "name"))
        return value

    def _resolve_int(self, value: Any, label: str) -> int:
        resolved = self._resolve_scalar(value, label)
        return int(resolved)

    def _shared_dtype_name(self, dtype: Any) -> str:
        if not isinstance(dtype, DataTypeValue):
            raise TypeError("bridge dtype must be DataTypeValue, got: " + str(type(dtype)))
        name = str(dtype)
        if name not in _SHARED_DTYPE_NAMES:
            raise TypeError("simulator_v2 default bridge does not support dtype: " + name)
        return _SHARED_DTYPE_NAMES[name]

    def _storage_numel_for_tensor(self, tensor: Tensor) -> int:
        logical_shape = self._resolve_shape(tensor.shape, str(tensor.name) + " shape")
        if len(logical_shape) != 2:
            raise NotImplementedError(
                "simulator_v2 default bridge only supports rank-2 Tensor storage"
            )
        rows, cols = logical_shape
        if rows < 0 or cols < 0:
            raise ValueError("tensor shape must be non-negative")
        if rows == 0 or cols == 0:
            return 0
        dtype = tensor.dtype
        elem_size = int(dtype.size)
        if elem_size <= 0:
            raise ValueError("unsupported tensor dtype size for bridge: " + str(dtype))
        if tensor.position is Position.UB:
            return rows * cols
        if tensor.position is Position.L1:
            c0 = 32 // elem_size
            return ((cols + c0 - 1) // c0) * _align_to(rows, 16) * c0
        if tensor.position is Position.L0C:
            return ((cols + 15) // 16) * _align_to(rows, 16) * 16
        if tensor.position in (Position.L0A, Position.L0B):
            c0 = 32 // elem_size
            layout = str(getattr(tensor, "_sim_layout", "ZN" if bool(getattr(tensor, "is_transpose", False)) else "NZ")).upper()
            if layout == "ZZ":
                return ((rows + 15) // 16) * _align_to(cols, c0) * 16
            if layout == "ZN":
                row_block = 32 if elem_size == 1 else 16
                col_align = 32 if elem_size == 1 else c0
                return ((rows + row_block - 1) // row_block) * row_block * _align_to(cols, col_align)
            return ((cols + c0 - 1) // c0) * _align_to(rows, 16) * c0
        return rows * cols

    def _flat_contiguous_slice_offset(
        self,
        src_shape: Sequence[int],
        offsets: Sequence[int],
        spans: Sequence[int],
    ) -> Optional[int]:
        rank = len(src_shape)
        if rank == 1:
            return int(offsets[0])
        if rank != 2:
            return None
        row0 = int(offsets[0])
        col0 = int(offsets[1])
        row_count = int(spans[0])
        col_count = int(spans[1])
        cols = int(src_shape[1])
        if row_count <= 1:
            return row0 * cols + col0
        if col0 == 0 and col_count == cols:
            return row0 * cols
        return None

    def _flat_slice_numel(
        self,
        src_shape: Sequence[int],
        offsets: Sequence[int],
        spans: Sequence[int],
    ) -> int:
        rank = len(src_shape)
        if rank == 1:
            return int(spans[0])
        row_count = int(spans[0])
        col_count = int(spans[1])
        cols = int(src_shape[1])
        if row_count <= 1:
            return col_count
        if int(offsets[1]) == 0 and col_count == cols:
            return row_count * cols
        raise NotImplementedError(
            "simulator_v2 default bridge only supports contiguous GM slices "
            "(full rows or single-row windows)"
        )

    def _slice_view_numel(self, spans: Sequence[int]) -> int:
        if not spans:
            return 0
        numel = 1
        for span in spans:
            span_i = int(span)
            if span_i <= 0:
                return 0
            numel *= span_i
        return numel

    def _local_view_shape_and_strides(
        self,
        tensor: Tensor,
        spans: Sequence[int],
        src_rows: int,
        src_cols: int,
    ) -> Tuple[Sequence[int], Sequence[int]]:
        if tensor.position is Position.UB and len(spans) == 2:
            return [max(int(spans[0]), 0), max(int(spans[1]), 0)], [src_cols, 1]
        return tuple(), tuple()


def build_kernel_program_from_legacy_instructions(kernel: Any) -> KernelProgram:
    """Build a V2 KernelProgram from a narrow lowered-instruction subset."""

    return LegacyInstructionKernelBridge(kernel=kernel).build()


__all__ = ["LegacyInstructionKernelBridge", "build_kernel_program_from_legacy_instructions"]
