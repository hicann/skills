# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field

from ..base import SimulatorV2Base
from ..config import SimulatorV2Config
from ..program.kernel_program import KernelProgram
from ..program.planner import ProgramPlanner
from ..runtime.global_runtime import GlobalRuntime
from .result_adapter import SimulatorV2ResultAdapter


@dataclass
class SimulatorV2OpExecAdapter:
    """Thin compatibility hook between planned V2 programs and runtime execution."""

    config: SimulatorV2Config = field(default_factory=SimulatorV2Config)
    result_adapter: SimulatorV2ResultAdapter = field(default_factory=SimulatorV2ResultAdapter)
    planner: ProgramPlanner = field(init=False)
    simulator: SimulatorV2Base = field(init=False)

    def __post_init__(self) -> None:
        self.planner = ProgramPlanner(self.config)
        self.simulator = SimulatorV2Base(config=self.config, planner=self.planner)

    def build(self, program: KernelProgram) -> GlobalRuntime:
        return self.simulator.build_runtime(program)

    def run(self, program: KernelProgram):
        runtime = self.build(program)
        runtime.run()
        return self.result_adapter.adapt(runtime)
