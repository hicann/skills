from __future__ import annotations

from dataclasses import dataclass, field

from ..base import SimulatorV2Base
from ..config import SimulatorV2Config
from ..program.kernel_program import KernelProgram
from ..program.planner import ProgramPlanner
from ..runtime.global_runtime import GlobalRuntime
from .result_adapter import SimulatorV2ResultAdapter


@dataclass
class SimulatorV2OpExecAdapter:
    """Thin compatibility hook between planned V2 programs and runtime execution."""

    config: SimulatorV2Config = field(default_factory=SimulatorV2Config)
    result_adapter: SimulatorV2ResultAdapter = field(default_factory=SimulatorV2ResultAdapter)
    planner: ProgramPlanner = field(init=False)
    simulator: SimulatorV2Base = field(init=False)

    def __post_init__(self) -> None:
        self.planner = ProgramPlanner(self.config)
        self.simulator = SimulatorV2Base(config=self.config, planner=self.planner)

    def build(self, program: KernelProgram) -> GlobalRuntime:
        return self.simulator.build_runtime(program)

    def run(self, program: KernelProgram):
        runtime = self.build(program)
        runtime.run()
        return self.result_adapter.adapt(runtime)
