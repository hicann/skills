"""Bridge that converts legacy Instruction objects into V2 ControlInstructions.

Unlike the linear LegacyInstructionKernelBridge, this bridge preserves
control flow structure (loops, conditionals) and defers variable resolution
to the ControlActor at runtime.

Tensor declarations (create_gm_tensor, create_tensor, split_workspace) are
handled at build time to populate the KernelProgram metadata.  Pipe
operations are emitted as ControlInstructions with a non-empty pipe_name so
the ControlActor can create PipeTasks on the fly.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

from ... import globvars
from ..helpers import resolve_simulator_core_num
from ...utils.Tensor import DBuff, GMTensor, QBuff, TBuff, Tensor
from ...utils.datatype import DataTypeValue
from ...utils.instruction import Instruction
from ...utils.positions import Position
from ...utils.var import Var, Expr, VarList
from ..program.control_instruction import ControlInstruction
from ..program.kernel_program import KernelProgram
from ..program.lane_program import LaneProgram


_CUBE_PIPE_NAMES = ["MTE2", "MTE1", "M", "FIX"]
_VEC_PIPE_NAMES = ["MTE2", "V", "MTE3"]

_CUBE_PIPE_BY_OPNAME = {
    "gm_to_l1_nd2nz": "MTE2",
    "set_constant_to_l1": "MTE2",
    "l1_to_l0": "MTE1",
    "mmad": "M",
    "l0c_to_gm_nz2nd": "FIX",
    "l0c_to_l1": "FIX",
    "l0c_to_ub": "FIX",
}
_VEC_PIPE_BY_OPNAME = {
    "gm_to_ub_pad": "MTE2",
    "ub_to_gm_pad": "MTE3",
    "ub_to_l1_nd2nz": "MTE3",
    "ub_to_l1_nz": "MTE3",
    "ub_to_ub": "V",
    "add": "V", "sub": "V", "mul": "V", "div": "V",
    "max": "V", "min": "V", "abs": "V", "relu": "V",
    "vmax": "V", "vmin": "V", "vabs": "V", "vec_v_relu": "V",
    "dup": "V", "adds": "V", "muls": "V",
    "vmaxs": "V", "vmins": "V", "lrelu": "V", "axpy": "V",
    "compare": "V", "compare_scalar": "V", "select": "V", "cast": "V",
    "exp": "V", "ln": "V", "rec": "V", "sqrt": "V", "rsqrt": "V",
    "vnot": "V", "vand": "V", "vor": "V",
    "cmax": "V", "cmin": "V", "cadd": "V", "brcb": "V",
    "cgmax": "V", "cgmin": "V", "cgadd": "V", "cpadd": "V",
    "set_mask": "V", "reset_mask": "V",
    "muladddst": "V",
    "sort32": "V", "mergesort4": "V", "mergesort_2seq": "V",
    "gather": "V", "scatter": "V",
}
_VEC_RUNTIME_OPNAME_BY_LEGACY = {
    "max": "vmax", "min": "vmin", "abs": "vabs", "relu": "vec_v_relu",
}

_SHARED_DTYPE_NAMES = {
    "half": "float16", "float": "float32", "int": "int32",
    "int8_t": "int8", "uint8_t": "uint8", "int16_t": "int16", "uint16_t": "uint16",
    "float8_e4m3_t": "float8_e4m3fn", "float8_e5m2_t": "float8_e5m2",
    "bfloat16_t": "bfloat16", "uint32_t": "uint32", "uint64_t": "uint64", "int64_t": "int64",
}

# Instructions that become ControlInstructions with var semantics
_VAR_OPNAMES = frozenset([
    "create_var", "create_varlist", "var_add", "var_sub", "var_mul", "var_div", "var_mod",
    "var_assign", "scalar_sqrt",
    "CeilDiv", "Min", "Max",
    "Align8", "Align16", "Align32", "Align64", "Align128", "Align256",
    "GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx",
])

_VALUE_IO_OPNAMES = frozenset(["GetValueFrom", "SetValueTo"])

# Control flow instruction names
_CONTROL_FLOW_OPNAMES = frozenset([
    "start_loop", "start_micro_loop", "end_loop", "break_loop", "continue_loop",
    "start_if", "start_elif", "start_else", "end_if",
])

# Instructions that are control/sync markers
_PASSTHROUGH_OPNAMES = frozenset([
    "reset_cache", "inline", "start_auto_sync", "end_auto_sync",
    "atomic_add", "atomic_max", "atomic_min", "atomic_end", "set_atomic_type",
    "setflag", "waitflag",
    "cube_ready", "wait_vec", "vec_ready", "wait_cube",
    "allcube_ready", "allcube_wait", "allvec_ready", "allvec_wait",
    "barrier",
    "enter_vec_scope", "end_vec_scope", "enter_cube_scope", "end_cube_scope",
    "clean_dcache", "kernel_print", "kernel_dump_tensor",
])
_EVENT_OPNAMES = frozenset([
    "create_sevent", "create_devent", "event_wait", "event_set", "event_setall", "event_release",
])
_AUTO_SYNC_MARKERS = frozenset(["start_auto_sync", "end_auto_sync"])


def _align_to(value: int, align: int) -> int:
    return ((int(value) + align - 1) // align) * align


def _product(values: Sequence[int]) -> int:
    total = 1
    for v in values:
        total *= int(v)
    return total


def _position_role(position: Any) -> str:
    name = str(getattr(position, "name", position)).upper()
    return {"L1": "l1", "L0A": "l0a", "L0B": "l0b", "L0C": "l0c", "UB": "ub"}.get(name, "shared")


def _buffer_slot_count(buf: Any) -> int:
    if isinstance(buf, DBuff):
        return 2
    if isinstance(buf, TBuff):
        return 3
    if isinstance(buf, QBuff):
        return 4
    raise TypeError("unsupported buffer type: " + str(type(buf)))


@dataclass
class ControlFlowKernelBridge:
    """Convert a kernel's instruction list into V2 ControlInstructions.

    Supports the full control flow instruction set.  Tensor and workspace
    declarations are processed at build time to generate SharedTensorSpecs.
    Variable operations and pipe dispatches are deferred to the ControlActor.
    """

    kernel: Any
    tensor_specs: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    cube_instructions: List[ControlInstruction] = field(default_factory=list)
    vec_instructions: List[ControlInstruction] = field(default_factory=list)
    # Track which lane the current scope targets (for mixed-lane kernels)
    _current_scope: str = field(default="cube", init=False)
    # Map (dbuf_name, buf_index) -> first registered tensor name for dedup
    _dbuf_tensor_map: Dict[str, str] = field(default_factory=dict, init=False)
    _buffer_slot_names: Dict[str, List[str]] = field(default_factory=dict, init=False)
    resolved_vars: Dict[str, Any] = field(default_factory=dict, init=False)
    _scope_is_explicit: bool = field(default=False, init=False)

    @staticmethod
    def _clone_control_instructions(instructions: List[ControlInstruction]) -> List[ControlInstruction]:
        out = []
        for inst in instructions:
            out.append(
                ControlInstruction(
                    inst.opname,
                    args=dict(inst.args),
                    pipe_name=inst.pipe_name,
                )
            )
        return out

    def build(self) -> KernelProgram:
        # Emit create_var for kernel-level scalar Var parameters so the
        # ControlActor can resolve them at runtime.
        self._emit_kernel_scalar_vars()
        instructions = list(getattr(self.kernel, "instructions", []) or [])
        for inst in instructions:
            if not isinstance(inst, Instruction):
                raise TypeError("kernel.instructions must contain Instruction objects")
        if self._has_auto_sync_markers(instructions):
            self._build_lane_streams_with_autosync(instructions)
        else:
            for inst in instructions:
                self._handle_instruction(inst)
        micro_defs = self._collect_micro_defs()
        metadata = {
            "shared_tensors": list(self.tensor_specs.values()),
            "bridge_mode": "control_flow_v2",
            "legacy_instruction_count": len(instructions),
        }
        if micro_defs:
            metadata["micro_defs"] = micro_defs
        return KernelProgram(
            name=str(getattr(self.kernel, "name", "kernel")) + "_v2_cf_bridge",
            core_count=0,  # resolved at runtime from globvars
            lane_programs=[
                LaneProgram(
                    lane_name="cube",
                    pipe_names=list(_CUBE_PIPE_NAMES),
                    instructions=list(self.cube_instructions),
                ),
                LaneProgram(
                    lane_name="vec0",
                    pipe_names=list(_VEC_PIPE_NAMES),
                    instructions=list(self.vec_instructions),
                ),
                LaneProgram(
                    lane_name="vec1",
                    pipe_names=list(_VEC_PIPE_NAMES),
                    instructions=self._clone_control_instructions(self.vec_instructions),
                ),
            ],
            metadata=metadata,
        )

    def _target_list(self) -> List[ControlInstruction]:
        """Return the instruction list for the current scope."""
        if self._current_scope.startswith("vec"):
            return self.vec_instructions
        return self.cube_instructions

    def _emit_to_both(self, ci: ControlInstruction) -> None:
        """Emit a ControlInstruction to both cube and vec lanes."""
        self.cube_instructions.append(ci)
        self.vec_instructions.append(ControlInstruction(ci.opname, args=dict(ci.args), pipe_name=ci.pipe_name))

    @staticmethod
    def _has_auto_sync_markers(instructions: Sequence[Instruction]) -> bool:
        for inst in instructions:
            if str(inst.opname) in _AUTO_SYNC_MARKERS:
                return True
        return False

    def _build_lane_streams_with_autosync(self, instructions: Sequence[Instruction]) -> None:
        from ...parser.asc import eliminate_duplicated_event_creation, split_instructions
        from ...parser.asc_autosync import insert_auto_sync

        cube_insts, vec_insts = split_instructions(instructions)
        cube_insts = eliminate_duplicated_event_creation(insert_auto_sync(cube_insts, mode="cube"))
        vec_insts = eliminate_duplicated_event_creation(insert_auto_sync(vec_insts, mode="vec"))

        self._current_scope = "cube"
        for inst in cube_insts:
            self._handle_lane_instruction(inst, lane_name="cube")
        self._current_scope = "vec"
        for inst in vec_insts:
            self._handle_lane_instruction(inst, lane_name="vec")

    def _handle_instruction(self, inst: Instruction) -> None:
        opname = str(inst.opname)
        self._update_resolved_vars(inst)

        # Scope management — emit to both lanes so both see the structure
        if opname == "enter_vec_scope":
            self._current_scope = "vec"
            self._scope_is_explicit = True
            self._emit_to_both(ControlInstruction("enter_vec_scope"))
            return
        if opname == "end_vec_scope":
            self._emit_to_both(ControlInstruction("end_vec_scope"))
            self._current_scope = "cube"
            self._scope_is_explicit = False
            return
        if opname == "enter_cube_scope":
            self._current_scope = "cube"
            self._scope_is_explicit = True
            self._emit_to_both(ControlInstruction("enter_cube_scope"))
            return
        if opname == "end_cube_scope":
            self._emit_to_both(ControlInstruction("end_cube_scope"))
            self._scope_is_explicit = False
            return

        # Tensor/memory declarations — build-time only
        if opname == "create_gm_tensor":
            self._register_gm_tensor(inst.val)
            return
        if opname == "slice_gm_tensor":
            self._register_gm_slice(inst)
            self._emit_gm_slice_runtime(inst)
            return
        if opname == "create_tensor":
            self._register_local_tensor(inst.val)
            return
        if opname == "split_workspace":
            self._register_workspace(inst)
            return
        if opname in ("create_dbuf", "create_tbuf", "create_qbuf"):
            return
        if opname == "get_buf":
            self._register_buf_tensor(inst)
            self._emit_get_buf_runtime(inst, self._target_list())
            return
        if opname == "reinterpret":
            self._register_reinterpret(inst)
            return
        if opname == "slice_tensor":
            self._register_local_slice(inst)
            self._emit_local_slice_runtime(inst, self._target_list())
            return
        if opname == "reshape_gm_tensor":
            self._register_gm_reshape(inst)
            return
        if opname in ("create_sevent", "create_devent"):
            self._target_list().append(ControlInstruction(opname, args=self._event_args(inst.kwargs.get("val", None))))
            return
        if opname in _EVENT_OPNAMES:
            self._target_list().append(ControlInstruction(opname, args=self._event_args(inst.kwargs.get("event", None))))
            return

        # Control flow — emit as ControlInstruction
        if opname in _CONTROL_FLOW_OPNAMES:
            self._emit_control_flow(inst)
            return

        # Variable ops — emit as ControlInstruction
        if opname in _VAR_OPNAMES:
            self._emit_var_op(inst)
            return

        if opname in _VALUE_IO_OPNAMES:
            self._emit_value_io(inst)
            return

        if opname == "sim_dump_tensor":
            self._emit_sim_dump_tensor(inst)
            return
        if opname == "sim_print":
            self._emit_sim_print(inst)
            return

        # Passthrough sync/control markers
        if opname in _PASSTHROUGH_OPNAMES:
            self._emit_passthrough(inst)
            return

        # Micro call — always vec-side
        if opname == "call_micro":
            self._emit_call_micro(inst, self.vec_instructions)
            return

        # Pipe operation — determine target lane/pipe and emit
        pipe_name = _CUBE_PIPE_BY_OPNAME.get(opname)
        if pipe_name is not None:
            self.cube_instructions.append(
                ControlInstruction(opname, pipe_name=pipe_name, args=self._pipe_args(inst))
            )
            return
        pipe_name = _VEC_PIPE_BY_OPNAME.get(opname)
        if pipe_name is not None:
            runtime_opname = _VEC_RUNTIME_OPNAME_BY_LEGACY.get(opname, opname)
            self.vec_instructions.append(
                ControlInstruction(runtime_opname, pipe_name=pipe_name, args=self._pipe_args(inst))
            )
            return

        # Unknown — emit as no-op ControlInstruction
        self._target_list().append(ControlInstruction(opname, args=self._raw_kwargs(inst)))

    def _handle_lane_instruction(self, inst: Instruction, lane_name: str) -> None:
        opname = str(inst.opname)
        self._update_resolved_vars(inst)
        target = self.cube_instructions if lane_name == "cube" else self.vec_instructions

        if opname == "create_gm_tensor":
            self._register_gm_tensor(inst.val)
            return
        if opname == "slice_gm_tensor":
            self._register_gm_slice(inst)
            self._emit_lane_gm_slice_runtime(inst, target)
            return
        if opname == "create_tensor":
            self._register_local_tensor(inst.val)
            return
        if opname == "split_workspace":
            self._register_workspace(inst)
            return
        if opname in ("create_dbuf", "create_tbuf", "create_qbuf"):
            return
        if opname == "get_buf":
            self._register_buf_tensor(inst)
            self._emit_get_buf_runtime(inst, target)
            return
        if opname == "reinterpret":
            self._register_reinterpret(inst)
            return
        if opname == "slice_tensor":
            self._register_local_slice(inst)
            self._emit_local_slice_runtime(inst, target)
            return
        if opname == "reshape_gm_tensor":
            self._register_gm_reshape(inst)
            return
        if opname in ("create_sevent", "create_devent"):
            target.append(ControlInstruction(opname, args=self._event_args(inst.kwargs.get("val", None))))
            return
        if opname in _EVENT_OPNAMES:
            target.append(ControlInstruction(opname, args=self._event_args(inst.kwargs.get("event", None))))
            return
        if opname in _CONTROL_FLOW_OPNAMES:
            self._emit_lane_control_flow(inst, target)
            return
        if opname in _VAR_OPNAMES:
            self._emit_lane_var_op(inst, target)
            return
        if opname in _VALUE_IO_OPNAMES:
            self._emit_lane_value_io(inst, target)
            return
        if opname == "sim_dump_tensor":
            self._emit_lane_sim_dump_tensor(inst, target, lane_name)
            return
        if opname == "sim_print":
            self._emit_lane_sim_print(inst, target, lane_name)
            return
        if opname in _PASSTHROUGH_OPNAMES:
            self._emit_lane_passthrough(inst, target, lane_name)
            return

        if opname == "call_micro":
            self._emit_call_micro(inst, target)
            return

        if lane_name == "cube":
            pipe_name = _CUBE_PIPE_BY_OPNAME.get(opname)
            if pipe_name is not None:
                target.append(ControlInstruction(opname, pipe_name=pipe_name, args=self._pipe_args(inst)))
                return
        else:
            pipe_name = _VEC_PIPE_BY_OPNAME.get(opname)
            if pipe_name is not None:
                runtime_opname = _VEC_RUNTIME_OPNAME_BY_LEGACY.get(opname, opname)
                target.append(ControlInstruction(runtime_opname, pipe_name=pipe_name, args=self._pipe_args(inst)))
                return

        target.append(ControlInstruction(opname, args=self._raw_kwargs(inst)))

    # ------------------------------------------------------------------
    # Control flow emission
    # ------------------------------------------------------------------

    def _emit_control_flow(self, inst: Instruction) -> None:
        opname = inst.opname

        if opname in ("start_loop", "start_micro_loop"):
            loop_var = inst.kwargs.get("var")
            var_name = str(loop_var.name) if isinstance(loop_var, Var) else ""
            self._emit_to_both(ControlInstruction(opname, args={
                "var_name": var_name,
                "start": self._deferred_value(inst.kwargs.get("start", 0)),
                "stop": self._deferred_value(inst.kwargs.get("stop", 0)),
                "step": self._deferred_value(inst.kwargs.get("step", 1)),
            }))
            return

        if opname in ("end_loop", "break_loop", "continue_loop"):
            self._emit_to_both(ControlInstruction(opname))
            return

        if opname == "start_if":
            cond = inst.kwargs.get("cond")
            self._emit_to_both(ControlInstruction("start_if", args={
                "cond": self._deferred_condition(cond),
            }))
            return

        if opname == "start_elif":
            cond = inst.kwargs.get("cond")
            self._emit_to_both(ControlInstruction("start_elif", args={
                "cond": self._deferred_condition(cond),
            }))
            return

        if opname == "start_else":
            self._emit_to_both(ControlInstruction("start_else"))
            return

        if opname == "end_if":
            self._emit_to_both(ControlInstruction("end_if"))
            return

    def _emit_lane_control_flow(self, inst: Instruction, target: List[ControlInstruction]) -> None:
        opname = str(inst.opname)

        if opname in ("start_loop", "start_micro_loop"):
            loop_var = inst.kwargs.get("var")
            var_name = str(loop_var.name) if isinstance(loop_var, Var) else ""
            target.append(ControlInstruction(opname, args={
                "var_name": var_name,
                "start": self._deferred_value(inst.kwargs.get("start", 0)),
                "stop": self._deferred_value(inst.kwargs.get("stop", 0)),
                "step": self._deferred_value(inst.kwargs.get("step", 1)),
            }))
            return

        if opname in ("end_loop", "break_loop", "continue_loop"):
            target.append(ControlInstruction(opname))
            return

        if opname == "start_if":
            cond = inst.kwargs.get("cond")
            target.append(ControlInstruction("start_if", args={"cond": self._deferred_condition(cond)}))
            return

        if opname == "start_elif":
            cond = inst.kwargs.get("cond")
            target.append(ControlInstruction("start_elif", args={"cond": self._deferred_condition(cond)}))
            return

        if opname in ("start_else", "end_if"):
            target.append(ControlInstruction(opname))
            return

    # ------------------------------------------------------------------
    # Variable operation emission
    # ------------------------------------------------------------------

    def _emit_var_op(self, inst: Instruction) -> None:
        opname = inst.opname

        if opname == "create_var":
            var_obj = getattr(inst, "val", None)
            if isinstance(var_obj, Var):
                self._emit_to_both(ControlInstruction("create_var", args={
                    "var_name": var_obj.name,
                    "value": self._deferred_value(var_obj.value),
                }))
            return

        if opname == "create_varlist":
            varlist = inst.kwargs.get("varlist", None)
            if isinstance(varlist, VarList):
                self._emit_to_both(ControlInstruction("create_varlist", args={
                    "varlist_name": str(varlist.name),
                    "length": int(varlist.length),
                }))
            return

        if opname == "var_assign":
            out = getattr(inst, "out", None)
            src = getattr(inst, "src", None)
            out_name = str(out.name) if isinstance(out, Var) else str(out) if out else ""
            self._emit_to_both(ControlInstruction("var_assign", args={
                "out_name": out_name,
                "src": self._deferred_value(src),
            }))
            return

        # Binary var ops: var_add/sub/mul/div/mod
        if opname in ("var_add", "var_sub", "var_mul", "var_div", "var_mod"):
            out = getattr(inst, "out", None)
            out_name = str(out.name) if isinstance(out, Var) else ""
            self._emit_to_both(ControlInstruction(opname, args={
                "out_name": out_name,
                "a": self._deferred_value(getattr(inst, "a", 0)),
                "b": self._deferred_value(getattr(inst, "b", 0)),
            }))
            return

        if opname == "scalar_sqrt":
            out = getattr(inst, "out", None)
            out_name = str(out.name) if isinstance(out, Var) else ""
            self._emit_to_both(ControlInstruction("scalar_sqrt", args={
                "out_name": out_name,
                "a": self._deferred_value(getattr(inst, "a", 0)),
            }))
            return

        # CeilDiv, Min, Max
        if opname in ("CeilDiv", "Min", "Max"):
            out = getattr(inst, "out", None)
            out_name = str(out.name) if isinstance(out, Var) else ""
            self._emit_to_both(ControlInstruction(opname, args={
                "out_name": out_name,
                "a": self._deferred_value(getattr(inst, "a", 0)),
                "b": self._deferred_value(getattr(inst, "b", 0)),
            }))
            return

        # AlignN
        if opname.startswith("Align"):
            out = getattr(inst, "out", None)
            out_name = str(out.name) if isinstance(out, Var) else ""
            self._emit_to_both(ControlInstruction(opname, args={
                "out_name": out_name,
                "a": self._deferred_value(getattr(inst, "a", 0)),
            }))
            return

        # Topology queries
        if opname in ("GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx"):
            out = getattr(inst, "out", None)
            out_name = str(out.name) if isinstance(out, Var) else ""
            self._emit_to_both(ControlInstruction(opname, args={"out_name": out_name}))
            return

    def _emit_lane_var_op(self, inst: Instruction, target: List[ControlInstruction]) -> None:
        opname = str(inst.opname)

        if opname == "create_var":
            var_obj = getattr(inst, "val", None)
            if isinstance(var_obj, Var):
                target.append(ControlInstruction("create_var", args={
                    "var_name": var_obj.name,
                    "value": self._deferred_value(var_obj.value),
                }))
            return

        if opname == "create_varlist":
            varlist = inst.kwargs.get("varlist", None)
            if isinstance(varlist, VarList):
                target.append(ControlInstruction("create_varlist", args={
                    "varlist_name": str(varlist.name),
                    "length": int(varlist.length),
                }))
            return

        if opname == "var_assign":
            out = getattr(inst, "out", None)
            src = getattr(inst, "src", None)
            out_name = str(out.name) if isinstance(out, Var) else str(out) if out else ""
            target.append(ControlInstruction("var_assign", args={
                "out_name": out_name,
                "src": self._deferred_value(src),
            }))
            return

        if opname in ("var_add", "var_sub", "var_mul", "var_div", "var_mod"):
            out = getattr(inst, "out", None)
            out_name = str(out.name) if isinstance(out, Var) else ""
            target.append(ControlInstruction(opname, args={
                "out_name": out_name,
                "a": self._deferred_value(getattr(inst, "a", 0)),
                "b": self._deferred_value(getattr(inst, "b", 0)),
            }))
            return

        if opname == "scalar_sqrt":
            out = getattr(inst, "out", None)
            out_name = str(out.name) if isinstance(out, Var) else ""
            target.append(ControlInstruction("scalar_sqrt", args={
                "out_name": out_name,
                "a": self._deferred_value(getattr(inst, "a", 0)),
            }))
            return

        if opname in ("CeilDiv", "Min", "Max"):
            out = getattr(inst, "out", None)
            out_name = str(out.name) if isinstance(out, Var) else ""
            target.append(ControlInstruction(opname, args={
                "out_name": out_name,
                "a": self._deferred_value(getattr(inst, "a", 0)),
                "b": self._deferred_value(getattr(inst, "b", 0)),
            }))
            return

        if opname.startswith("Align"):
            out = getattr(inst, "out", None)
            out_name = str(out.name) if isinstance(out, Var) else ""
            target.append(ControlInstruction(opname, args={
                "out_name": out_name,
                "a": self._deferred_value(getattr(inst, "a", 0)),
            }))
            return

        if opname in ("GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx"):
            out = getattr(inst, "out", None)
            out_name = str(out.name) if isinstance(out, Var) else ""
            target.append(ControlInstruction(opname, args={"out_name": out_name}))
            return

    def _emit_value_io(self, inst: Instruction) -> None:
        ci = self._value_io_instruction(inst)
        if ci is None:
            return
        target_mode = self._value_io_target_mode(inst)
        if target_mode == "vec":
            self.vec_instructions.append(ci)
            return
        if target_mode == "cube":
            self.cube_instructions.append(ci)
            return
        self._emit_to_both(ci)

    def _emit_lane_value_io(self, inst: Instruction, target: List[ControlInstruction]) -> None:
        ci = self._value_io_instruction(inst)
        if ci is not None:
            target.append(ci)

    def _value_io_instruction(self, inst: Instruction) -> Optional[ControlInstruction]:
        opname = str(inst.opname)
        src = inst.kwargs.get("src", None)
        if opname == "GetValueFrom":
            dst = inst.kwargs.get("dst", inst.kwargs.get("out", None))
            if not isinstance(dst, Var) or not isinstance(src, (Tensor, GMTensor)):
                return None
            return ControlInstruction("GetValueFrom", args={
                "var_name": str(dst.name),
                "var_dtype": self._shared_dtype_name(dst.dtype),
                "tensor_name": str(src.name),
                "tensor_kind": "local" if isinstance(src, Tensor) else "gm",
                "tensor_position": str(getattr(src, "position", "")),
            })
        if opname == "SetValueTo":
            dst = inst.kwargs.get("dst", None)
            if not isinstance(dst, Var) or not isinstance(src, (Tensor, GMTensor)):
                return None
            return ControlInstruction("SetValueTo", args={
                "var_name": str(dst.name),
                "var_dtype": self._shared_dtype_name(dst.dtype),
                "tensor_name": str(src.name),
                "tensor_kind": "local" if isinstance(src, Tensor) else "gm",
                "tensor_position": str(getattr(src, "position", "")),
            })
        return None

    def _value_io_target_mode(self, inst: Instruction) -> str:
        if self._scope_is_explicit:
            return "vec" if self._current_scope.startswith("vec") else "cube"
        src = inst.kwargs.get("src", None)
        if isinstance(src, Tensor):
            return "vec"
        if isinstance(src, GMTensor):
            return "both"
        return "both"

    def _emit_passthrough(self, inst: Instruction) -> None:
        opname = inst.opname
        args = {}
        if opname in ("setflag", "waitflag"):
            args["src"] = str(inst.kwargs.get("src", ""))
            args["dst"] = str(inst.kwargs.get("dst", ""))
            args["event_id"] = self._deferred_value(inst.kwargs.get("event_id", "0"))
        elif opname in ("cube_ready", "wait_vec", "vec_ready", "wait_cube"):
            flag_id = inst.kwargs.get("flag_id", inst.kwargs.get("id", "0"))
            args["flag_id"] = self._deferred_value(flag_id)
            pipe_val = inst.kwargs.get("pipe", None)
            if pipe_val is not None:
                args["pipe"] = str(pipe_val)
        elif opname in ("allcube_ready", "allcube_wait", "allvec_ready", "allvec_wait"):
            args["flag_id"] = self._deferred_value(inst.kwargs.get("flag_id", "0"))
            pipe_val = inst.kwargs.get("pipe", None)
            if pipe_val is not None:
                args["pipe"] = str(pipe_val)
        elif opname == "barrier":
            args["pipe"] = str(inst.kwargs.get("pipe", "ALL"))
        ci = ControlInstruction(opname, args=args)
        # Cross-lane sync ops must route to the correct lane regardless of
        # the current scope.  Pre-seeded vec_ready/wait_cube go to vec;
        # cube_ready/wait_vec go to cube.  The collective all* family is
        # lane-specific: allcube_* lives on the cube lane, allvec_* on vec.
        if opname in ("vec_ready", "wait_cube", "allvec_ready", "allvec_wait"):
            self.vec_instructions.append(ci)
        elif opname in ("cube_ready", "wait_vec", "allcube_ready", "allcube_wait"):
            self.cube_instructions.append(ci)
        else:
            self._target_list().append(ci)

    # ------------------------------------------------------------------
    # sim_print / sim_dump_tensor emission
    # ------------------------------------------------------------------

    def _emit_sim_dump_tensor(self, inst: Instruction) -> None:
        ci, mode = self._build_sim_dump_tensor(inst)
        self._route_sim_ci(ci, mode)

    def _emit_lane_sim_dump_tensor(
        self, inst: Instruction, target: List[ControlInstruction], lane_name: str
    ) -> None:
        ci, mode = self._build_sim_dump_tensor(inst)
        if not self._lane_matches_sim_mode(lane_name, mode):
            return
        target.append(ci)

    def _build_sim_dump_tensor(self, inst: Instruction) -> Tuple[ControlInstruction, str]:
        tensor = inst.kwargs.get("tensor")
        filename = inst.kwargs.get("filename", "")
        pipe = str(inst.kwargs.get("pipe", ""))
        if not isinstance(tensor, (Tensor, GMTensor)):
            raise TypeError(
                "sim_dump_tensor requires Tensor/GMTensor, got: " + str(type(tensor))
            )
        args = {
            "tensor_name": str(tensor.name),
            "tensor_kind": "local" if isinstance(tensor, Tensor) else "gm",
            "tensor_position": str(getattr(tensor, "position", "")),
            "filename": str(filename),
            "pipe": pipe,
        }
        ci = ControlInstruction("sim_dump_tensor", args=args)
        mode = self._sim_dump_target_mode(tensor, pipe)
        return ci, mode

    def _emit_sim_print(self, inst: Instruction) -> None:
        ci, mode = self._build_sim_print(inst)
        self._route_sim_ci(ci, mode)

    def _emit_lane_sim_print(
        self, inst: Instruction, target: List[ControlInstruction], lane_name: str
    ) -> None:
        ci, mode = self._build_sim_print(inst)
        if not self._lane_matches_sim_mode(lane_name, mode):
            return
        target.append(ci)

    def _build_sim_print(self, inst: Instruction) -> Tuple[ControlInstruction, str]:
        payload = inst.kwargs.get("payload", [])
        if not isinstance(payload, (list, tuple)):
            raise TypeError(
                "sim_print payload must be list/tuple, got: " + str(type(payload))
            )
        pipe = str(inst.kwargs.get("pipe", "S"))
        args: Dict[str, Any] = {"pipe": pipe, "payload_count": len(payload)}
        cube_side = False
        vec_side = False
        for i, item in enumerate(payload):
            kind, value, item_cube, item_vec = self._classify_sim_print_item(item)
            args["payload_" + str(i)] = value
            args["payload_kind_" + str(i)] = kind
            cube_side = cube_side or item_cube
            vec_side = vec_side or item_vec
        if cube_side and not vec_side:
            mode = "cube"
        elif vec_side and not cube_side:
            mode = "vec"
        elif cube_side and vec_side:
            mode = "both"
        else:
            mode = "cube"
        ci = ControlInstruction("sim_print", args=args)
        return ci, mode

    def _classify_sim_print_item(self, item: Any) -> Tuple[str, Any, bool, bool]:
        if isinstance(item, GMTensor):
            return "gm_tensor", str(item.name), True, True
        if isinstance(item, Tensor):
            if item.position is Position.UB:
                return "local_tensor", str(item.name), False, True
            if item.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C):
                return "local_tensor", str(item.name), True, False
            return "local_tensor", str(item.name), True, True
        if isinstance(item, Var):
            return "var", str(item.name), False, False
        if isinstance(item, Expr):
            return "expr", str(item), False, False
        if isinstance(item, DataTypeValue):
            return "literal", str(item), False, False
        if isinstance(item, (int, float, bool, str)):
            return "literal", item, False, False
        return "literal", str(item), False, False

    def _sim_dump_target_mode(self, tensor: Any, pipe: str) -> str:
        if isinstance(tensor, Tensor):
            if tensor.position is Position.UB:
                return "vec"
            if tensor.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C):
                return "cube"
            return "both"
        if pipe in ("MTE1", "M", "FIX"):
            return "cube"
        if pipe in ("V", "MTE3"):
            return "vec"
        return "both"

    def _route_sim_ci(self, ci: ControlInstruction, mode: str) -> None:
        if mode == "cube":
            self.cube_instructions.append(ci)
            return
        if mode == "vec":
            self.vec_instructions.append(ci)
            return
        self._emit_to_both(ci)

    @staticmethod
    def _lane_matches_sim_mode(lane_name: str, mode: str) -> bool:
        if mode == "both":
            return True
        if mode == "cube":
            return lane_name == "cube"
        return lane_name.startswith("vec")

    def _emit_lane_passthrough(
        self, inst: Instruction, target: List[ControlInstruction], lane_name: str = ""
    ) -> None:
        opname = str(inst.opname)
        # Collective allcube/allvec ops must only land on the matching lane.
        # The autosync split already filters these, but the per-lane path is
        # shared by both build paths so we keep an explicit guard here.
        if opname in ("allcube_ready", "allcube_wait") and lane_name and lane_name != "cube":
            return
        if opname in ("allvec_ready", "allvec_wait") and lane_name and not lane_name.startswith("vec"):
            return
        args = {}
        if opname in ("setflag", "waitflag"):
            args["src"] = str(inst.kwargs.get("src", ""))
            args["dst"] = str(inst.kwargs.get("dst", ""))
            args["event_id"] = self._deferred_value(inst.kwargs.get("event_id", "0"))
        elif opname in ("cube_ready", "wait_vec", "vec_ready", "wait_cube"):
            flag_id = inst.kwargs.get("flag_id", inst.kwargs.get("id", "0"))
            args["flag_id"] = self._deferred_value(flag_id)
            pipe_val = inst.kwargs.get("pipe", None)
            if pipe_val is not None:
                args["pipe"] = str(pipe_val)
        elif opname in ("allcube_ready", "allcube_wait", "allvec_ready", "allvec_wait"):
            args["flag_id"] = self._deferred_value(inst.kwargs.get("flag_id", "0"))
            pipe_val = inst.kwargs.get("pipe", None)
            if pipe_val is not None:
                args["pipe"] = str(pipe_val)
        elif opname == "barrier":
            args["pipe"] = str(inst.kwargs.get("pipe", "ALL"))
        target.append(ControlInstruction(opname, args=args))

    # ------------------------------------------------------------------
    # Pipe argument translation (deferred, uses var names)
    # ------------------------------------------------------------------

    def _pipe_args(self, inst: Instruction) -> Dict[str, Any]:
        """Build pipe task args.  Variable references are kept as var names
        so the ControlActor can resolve them at runtime."""
        opname = str(inst.opname)
        args: Dict[str, Any] = {}
        if opname == "gm_to_l1_nd2nz":
            return {
                "dst": self._tensor_name(getattr(inst, "dst", None)),
                "src": self._tensor_name(getattr(inst, "src", None)),
                "M": self._deferred_value(getattr(inst, "M", 0)),
                "N": self._deferred_value(getattr(inst, "N", 0)),
                "N_src": self._deferred_value(getattr(inst, "N_src", 0)),
                "M_dst": self._deferred_value(getattr(inst, "M_dst", 0)),
            }
        if opname == "l1_to_l0":
            src = getattr(inst, "src", None)
            dst = getattr(inst, "dst", None)
            return {
                "dst": self._tensor_name(dst),
                "src": self._tensor_name(src),
                "m_dst": self._deferred_value(getattr(inst, "m_dst", 0)),
                "n_dst": self._deferred_value(getattr(inst, "n_dst", 0)),
                "m_src": self._deferred_value(getattr(inst, "m_src", 0)),
                "n_src": self._deferred_value(getattr(inst, "n_src", 0)),
                "src_is_transpose": bool(getattr(src, "is_transpose", False)),
                "src_layout": str(getattr(src, "_sim_layout", "NZ")),
                "dst_layout": str(getattr(dst, "_sim_layout", "ZN" if bool(getattr(src, "is_transpose", False)) else "NZ")),
                "src_position": str(getattr(src, "position", "")),
                "dst_position": str(getattr(dst, "position", "")),
            }
        if opname == "mmad":
            src_a = getattr(inst, "src_a", None)
            src_b = getattr(inst, "src_b", None)
            return {
                "dst": self._tensor_name(getattr(inst, "dst", None)),
                "src_a": self._tensor_name(src_a),
                "src_b": self._tensor_name(src_b),
                "M": self._deferred_value(getattr(inst, "M", 0)),
                "N": self._deferred_value(getattr(inst, "N", 0)),
                "K": self._deferred_value(getattr(inst, "K", 0)),
                "is_init": bool(getattr(inst, "is_init", True)),
                "src_a_layout": str(getattr(src_a, "_sim_layout", "NZ")),
                "src_b_layout": str(getattr(src_b, "_sim_layout", "NZ")),
                "src_a_position": str(getattr(src_a, "position", "")),
                "src_b_position": str(getattr(src_b, "position", "")),
                "dst_position": str(getattr(getattr(inst, "dst", None), "position", "")),
            }
        for key, val in inst.kwargs.items():
            args[key] = self._deferred_pipe_value(val)
        # Ensure tensor names are strings
        for key in ("src", "dst", "src_a", "src_b", "src1", "src2", "selmask", "tensor"):
            if key in args and isinstance(inst.kwargs.get(key), (GMTensor, Tensor)):
                args[key] = str(inst.kwargs[key].name)
        return args

    @staticmethod
    def _tensor_name(value: Any) -> str:
        if isinstance(value, (GMTensor, Tensor)):
            return str(value.name)
        raise TypeError("pipe tensor arg must be GMTensor or Tensor, got: " + str(type(value)))

    # ------------------------------------------------------------------
    # Kernel scalar parameters
    # ------------------------------------------------------------------

    def _emit_kernel_scalar_vars(self) -> None:
        """Emit create_var for each kernel-level scalar Var parameter.

        When the kernel function signature includes scalar ``Var`` parameters
        (e.g. ``S1: Var, S2: Var``), their runtime values must be available
        in the ControlActor's ``var_values`` dict so that deferred references
        like ``CeilDiv(S1, TILE_M)`` can resolve the string ``'S1'`` to an int.
        """
        import inspect
        bound_args = getattr(self.kernel, "_last_bound_args", None)
        if not bound_args:
            return
        sig = inspect.signature(self.kernel.func)
        for name in sig.parameters:
            val = bound_args.get(name)
            if isinstance(val, Var):
                resolved = val.value
                if isinstance(resolved, (int, float)):
                    self._emit_to_both(ControlInstruction("create_var", args={
                        "var_name": name, "value": resolved,
                    }))

    # ------------------------------------------------------------------
    # Tensor spec registration (build-time)
    # ------------------------------------------------------------------

    def _register_gm_tensor(self, tensor: GMTensor) -> None:
        if not isinstance(tensor, GMTensor):
            return
        numel = self._resolve_numel_best_effort(tensor.shape)
        self._register_spec(
            name=str(tensor.name),
            shape=[numel],
            dtype=self._shared_dtype_name(tensor.dtype),
            role="gm",
        )

    def _register_gm_slice(self, inst: Instruction) -> None:
        src = getattr(inst, "src", None)
        out = getattr(inst, "out", None)
        if isinstance(src, GMTensor) and isinstance(out, GMTensor):
            numel = self._resolve_numel_best_effort(out.shape)
            self._register_spec(
                name=str(out.name),
                shape=[numel],
                dtype=self._shared_dtype_name(out.dtype),
                role="gm_view",
                source_name=str(src.name),
            )

    def _emit_gm_slice_runtime(self, inst: Instruction) -> None:
        """Emit a runtime ControlInstruction for slice_gm_tensor.

        GM tensor slices inside loops have dynamic offsets (Var-valued) that
        change each iteration.  At runtime the ControlActor resolves the offset
        and updates the tensor store view so that pipe ops read/write the
        correct region of the parent GM tensor.
        """
        src = getattr(inst, "src", None)
        out = getattr(inst, "out", None)
        if not (isinstance(src, GMTensor) and isinstance(out, GMTensor)):
            return
        # Collect offset and parent stride info
        offsets = getattr(out, "offset", None) or [0] * len(out.shape)
        src_shape = getattr(src, "shape", None) or []
        spans = getattr(out, "span", None) or list(out.shape)
        args = {
            "view_name": str(out.name),
            "source_name": str(src.name),
        }
        # Store offsets, src_shape, and spans as deferred values
        for i, off in enumerate(offsets):
            args["offset_" + str(i)] = self._deferred_value(off)
        for i, dim in enumerate(src_shape):
            args["src_dim_" + str(i)] = self._deferred_value(dim)
        for i, sp in enumerate(spans):
            args["span_" + str(i)] = self._deferred_value(sp)
        args["ndim"] = len(offsets)
        self._emit_to_both(ControlInstruction("slice_gm_tensor", args=args))

    def _emit_lane_gm_slice_runtime(self, inst: Instruction, target: List[ControlInstruction]) -> None:
        src = getattr(inst, "src", None)
        out = getattr(inst, "out", None)
        if not (isinstance(src, GMTensor) and isinstance(out, GMTensor)):
            return
        offsets = getattr(out, "offset", None) or [0] * len(out.shape)
        src_shape = getattr(src, "shape", None) or []
        spans = getattr(out, "span", None) or list(out.shape)
        args = {
            "view_name": str(out.name),
            "source_name": str(src.name),
        }
        for i, off in enumerate(offsets):
            args["offset_" + str(i)] = self._deferred_value(off)
        for i, dim in enumerate(src_shape):
            args["src_dim_" + str(i)] = self._deferred_value(dim)
        for i, sp in enumerate(spans):
            args["span_" + str(i)] = self._deferred_value(sp)
        args["ndim"] = len(offsets)
        target.append(ControlInstruction("slice_gm_tensor", args=args))

    def _emit_local_slice_runtime(self, inst: Instruction, target: List[ControlInstruction]) -> None:
        src = getattr(inst, "src", None)
        out = getattr(inst, "out", None)
        if not isinstance(src, Tensor) or not isinstance(out, Tensor):
            return
        offsets = getattr(inst, "offset", None) or [0] * len(getattr(out, "shape", []) or [])
        spans = getattr(inst, "span", None) or list(getattr(out, "shape", []) or [])
        steps = getattr(inst, "step", None) or [1] * len(offsets)
        args = {
            "view_name": str(out.name),
            "source_name": str(src.name),
            "source_position": str(getattr(src, "position", "")),
        }
        for i, off in enumerate(offsets):
            args["offset_" + str(i)] = self._deferred_value(off)
        for i, dim in enumerate(getattr(src, "shape", None) or []):
            args["src_dim_" + str(i)] = self._deferred_value(dim)
        for i, sp in enumerate(spans):
            args["span_" + str(i)] = self._deferred_value(sp)
        for i, step in enumerate(steps):
            args["step_" + str(i)] = self._deferred_value(step)
        args["ndim"] = len(offsets)
        target.append(ControlInstruction("slice_tensor", args=args))

    def _register_local_tensor(self, tensor: Tensor) -> None:
        if not isinstance(tensor, Tensor):
            return
        role = _position_role(tensor.position)
        numel = self._resolve_numel_best_effort(tensor.shape)
        # For NZ-layout positions, add alignment padding
        if tensor.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C):
            numel = self._storage_numel_padded(tensor, numel)
        self._register_spec(
            name=str(tensor.name),
            shape=[numel],
            dtype=self._shared_dtype_name(tensor.dtype),
            role=role,
        )

    def _register_buf_tensor(self, inst: Instruction) -> None:
        """Handle get_buf by registering physical slot tensors plus an alias view."""
        buf = inst.kwargs.get("buf")
        index = inst.kwargs.get("index")
        out = getattr(inst, "out", inst.kwargs.get("out"))
        if buf is None or out is None:
            self._register_local_tensor(out)
            return
        if not isinstance(buf, (DBuff, TBuff, QBuff)) or not isinstance(out, Tensor):
            self._register_local_tensor(out)
            return
        slot_names = self._ensure_buffer_slot_specs(buf, out)
        out_name = str(out.name)
        numel = self._resolve_numel_best_effort(out.shape)
        role = _position_role(out.position)
        if out.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C):
            numel = self._storage_numel_padded(out, numel)
        self._register_spec(
            name=out_name,
            shape=[numel],
            dtype=self._shared_dtype_name(out.dtype),
            role=role,
            source_name=slot_names[0],
        )

    def _ensure_buffer_slot_specs(self, buf: Any, out: Tensor) -> List[str]:
        buf_name = str(getattr(buf, "name", ""))
        slot_names = self._buffer_slot_names.get(buf_name)
        if slot_names is not None:
            return slot_names
        slot_count = _buffer_slot_count(buf)
        numel = self._resolve_numel_best_effort(out.shape)
        role = _position_role(out.position)
        if out.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C):
            numel = self._storage_numel_padded(out, numel)
        slot_names = []
        for slot_idx in range(slot_count):
            slot_name = "__bufslot__%s_%d" % (buf_name, slot_idx)
            slot_names.append(slot_name)
            self._register_spec(
                name=slot_name,
                shape=[numel],
                dtype=self._shared_dtype_name(out.dtype),
                role=role,
            )
        self._buffer_slot_names[buf_name] = slot_names
        return slot_names

    def _emit_get_buf_runtime(self, inst: Instruction, target: List[ControlInstruction]) -> None:
        buf = inst.kwargs.get("buf")
        out = getattr(inst, "out", inst.kwargs.get("out"))
        if not isinstance(buf, (DBuff, TBuff, QBuff)) or not isinstance(out, Tensor):
            return
        slot_names = self._ensure_buffer_slot_specs(buf, out)
        target.append(
            ControlInstruction(
                "get_buf",
                args={
                    "view_name": str(out.name),
                    "index": self._deferred_value(inst.kwargs.get("index")),
                    "slot_names": list(slot_names),
                },
            )
        )

    def _register_workspace(self, inst: Instruction) -> None:
        """Handle split_workspace: register a workspace tensor spec."""
        dtype = inst.kwargs.get("dtype")
        name = inst.kwargs.get("name", "")
        val = inst.kwargs.get("val")
        if not isinstance(dtype, DataTypeValue):
            return
        if not isinstance(name, str) or name == "":
            if isinstance(val, GMTensor):
                name = str(val.name)
            else:
                return
        numel = self._resolve_int_best_effort(inst.kwargs.get("numel"))
        if numel <= 0:
            numel = self._resolve_numel_best_effort(
                getattr(val, "shape", None) if isinstance(val, GMTensor) else None
            )
        self._register_spec(
            name=name,
            shape=[max(numel, 1)],
            dtype=self._shared_dtype_name(dtype),
            role="workspace",
        )

    def _register_local_slice(self, inst: Instruction) -> None:
        """Handle slice_tensor: register a view of a local buffer tensor."""
        src = getattr(inst, "src", None)
        out = getattr(inst, "out", None)
        if not isinstance(src, Tensor) or not isinstance(out, Tensor):
            return
        offsets = getattr(inst, "offset", [0, 0])
        spans = getattr(inst, "span", None)
        if spans is None:
            spans = getattr(out, "shape", [0, 0])
        # Resolve offsets and spans to ints (best-effort for Var values)
        row_off = self._resolve_int_best_effort(offsets[0]) if len(offsets) > 0 else 0
        col_off = self._resolve_int_best_effort(offsets[1]) if len(offsets) > 1 else 0
        # Resolve source shape
        src_shape = getattr(src, "shape", [0, 0])
        src_rows = self._resolve_int_best_effort(src_shape[0]) if len(src_shape) > 0 else 0
        src_cols = self._resolve_int_best_effort(src_shape[1]) if len(src_shape) > 1 else 0
        # Compute storage offset based on position
        storage_offset = self._local_slice_offset(src, row_off, col_off, src_rows, src_cols)
        # Compute view numel
        resolved_spans = [self._resolve_int_best_effort(span) for span in spans]
        view_numel = self._slice_view_numel(resolved_spans)
        view_shape, view_strides = self._local_view_shape_and_strides(
            src, resolved_spans, src_rows, src_cols
        )
        role = _position_role(out.position)
        self._register_spec(
            name=str(out.name),
            shape=[view_numel],
            dtype=self._shared_dtype_name(out.dtype),
            role=role,
            source_name=str(src.name),
            storage_offset=storage_offset,
            view_shape=view_shape,
            view_strides=view_strides,
        )

    def _register_gm_reshape(self, inst: Instruction) -> None:
        src = getattr(inst, "src", None)
        out = getattr(inst, "out", None)
        if not isinstance(src, GMTensor) or not isinstance(out, GMTensor):
            return
        if not src.is_plain_view():
            raise ValueError(
                "reshape_gm_tensor only supports plain_view GMTensor src, got: " + str(src.name)
            )
        src_numel = self._resolve_numel_best_effort(src.shape)
        out_numel = self._resolve_numel_best_effort(out.shape)
        if src_numel != out_numel:
            raise ValueError(
                "reshape_gm_tensor requires same numel: src_numel="
                + str(src_numel) + ", out_numel=" + str(out_numel)
            )
        self._register_spec(
            name=str(out.name),
            shape=[out_numel],
            dtype=self._shared_dtype_name(out.dtype),
            role="gm_view",
            source_name=str(src.name),
            storage_offset=0,
        )

    def _register_reinterpret(self, inst: Instruction) -> None:
        src = getattr(inst, "src", None)
        dst = getattr(inst, "dst", None)
        if not isinstance(src, Tensor) or not isinstance(dst, Tensor):
            return
        role = _position_role(dst.position)
        numel = self._resolve_numel_best_effort(dst.shape)
        if dst.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C):
            numel = self._storage_numel_padded(dst, numel)
        self._register_spec(
            name=str(dst.name),
            shape=[max(numel, 1)],
            dtype=self._shared_dtype_name(dst.dtype),
            role=role,
            source_name=str(src.name),
            storage_offset=0,
        )

    def _local_slice_offset(self, tensor: Tensor, row: int, col: int,
                            src_rows: int, src_cols: int) -> int:
        """Compute flat storage offset for a local tensor slice."""
        if tensor.position is Position.UB:
            return row * src_cols + col
        elem_size = int(tensor.dtype.size) if hasattr(tensor.dtype, "size") else 2
        c0 = 32 // max(elem_size, 1)
        if tensor.position is Position.L0C:
            c0 = 16
        if tensor.position in (Position.L1, Position.L0A, Position.L0B, Position.L0C):
            # NZ layout: (col // c0) * align_rows * c0 + row * c0 + (col % c0)
            align_rows = _align_to(src_rows, 16)
            return (col // c0) * align_rows * c0 + row * c0 + (col % c0)
        # Default linear
        return row * src_cols + col

    def _register_spec(
        self,
        name: str,
        shape: List[int],
        dtype: str,
        role: str,
        source_name: Optional[str] = None,
        storage_offset: int = 0,
        view_shape: Optional[Sequence[int]] = None,
        view_strides: Optional[Sequence[int]] = None,
    ) -> None:
        if name in self.tensor_specs:
            return  # already registered
        self.tensor_specs[name] = {
            "name": name, "shape": shape, "dtype": dtype,
            "role": role, "mutable": True,
            "source_name": source_name, "storage_offset": storage_offset,
            "view_shape": [int(dim) for dim in (view_shape or tuple())],
            "view_strides": [int(stride) for stride in (view_strides or tuple())],
            "tags": [role],
        }

    def _slice_view_numel(self, spans: Sequence[int]) -> int:
        if not spans:
            return 0
        numel = 1
        for span in spans:
            span_i = int(span)
            if span_i <= 0:
                return 0
            numel *= span_i
        return numel

    def _local_view_shape_and_strides(
        self,
        tensor: Tensor,
        spans: Sequence[int],
        src_rows: int,
        src_cols: int,
    ) -> Tuple[Sequence[int], Sequence[int]]:
        if tensor.position is Position.UB and len(spans) == 2:
            return [max(int(spans[0]), 0), max(int(spans[1]), 0)], [src_cols, 1]
        return tuple(), tuple()

    # ------------------------------------------------------------------
    # Value helpers
    # ------------------------------------------------------------------

    def _deferred_value(self, value: Any) -> Any:
        """Convert a value to a form the ControlActor can resolve at runtime."""
        if isinstance(value, Var):
            return value.name  # deferred — resolved by ControlActor
        if isinstance(value, (int, float, bool)):
            return value
        if isinstance(value, Expr):
            return str(value)
        if isinstance(value, DataTypeValue):
            return str(value)
        if value is None:
            return 0
        return value

    def _deferred_condition(self, cond: Any) -> Any:
        """Convert a condition expression for the ControlActor."""
        if isinstance(cond, Expr):
            return str(cond)
        if isinstance(cond, bool):
            return cond
        if isinstance(cond, Var):
            return cond.name
        if cond is None:
            return False
        return cond

    def _deferred_pipe_value(self, value: Any) -> Any:
        """Convert a pipe argument value, keeping var references as names."""
        if isinstance(value, Var):
            return value.name
        if isinstance(value, (int, float, bool)):
            return value
        if isinstance(value, (GMTensor, Tensor)):
            return str(value.name)
        if isinstance(value, DataTypeValue):
            return str(value)
        if isinstance(value, Expr):
            return str(value)
        if value is None:
            return None
        return value

    def _build_time_core_count(self) -> int:
        device_type = str(getattr(globvars, "device_type", "")).lower()
        core_num = getattr(globvars, "core_num", None)
        try:
            return int(resolve_simulator_core_num(core_num, device_type))
        except Exception:
            return 1

    def _resolve_build_time_value(self, value: Any) -> Optional[Any]:
        if isinstance(value, (int, float, bool)):
            return value
        if isinstance(value, Var):
            if value.name in self.resolved_vars:
                return self.resolved_vars[value.name]
            if isinstance(value.value, (int, float, bool)):
                return value.value
            return None
        if isinstance(value, str):
            if value in self.resolved_vars:
                return self.resolved_vars[value]
            try:
                return int(value)
            except ValueError:
                pass
            try:
                return float(value)
            except ValueError:
                return None
        return None

    def _update_resolved_vars(self, inst: Instruction) -> None:
        opname = str(inst.opname)

        def _out_var() -> Optional[Var]:
            out = getattr(inst, "out", None)
            if isinstance(out, Var):
                return out
            return None

        if opname == "create_var":
            var_obj = getattr(inst, "val", None)
            if isinstance(var_obj, Var) and isinstance(var_obj.value, (int, float, bool)):
                self.resolved_vars[var_obj.name] = var_obj.value
            return

        if opname == "var_assign":
            out = _out_var()
            value = self._resolve_build_time_value(getattr(inst, "src", None))
            if out is not None and value is not None:
                self.resolved_vars[out.name] = value
            return

        if opname in ("var_add", "var_sub", "var_mul", "var_div", "var_mod", "CeilDiv", "Min", "Max"):
            out = _out_var()
            lhs = self._resolve_build_time_value(getattr(inst, "a", None))
            rhs = self._resolve_build_time_value(getattr(inst, "b", None))
            if out is None or lhs is None or rhs is None:
                return
            if opname == "var_add":
                value = lhs + rhs
            elif opname == "var_sub":
                value = lhs - rhs
            elif opname == "var_mul":
                value = lhs * rhs
            elif opname in ("var_div", "CeilDiv"):
                if int(rhs) == 0:
                    return
                if opname == "var_div":
                    value = int(lhs) // int(rhs)
                else:
                    value = (int(lhs) + int(rhs) - 1) // int(rhs)
            elif opname == "var_mod":
                if int(rhs) == 0:
                    return
                value = int(lhs) % int(rhs)
            elif opname == "Min":
                value = min(lhs, rhs)
            else:
                value = max(lhs, rhs)
            self.resolved_vars[out.name] = value
            return

        if opname == "scalar_sqrt":
            out = _out_var()
            value = self._resolve_build_time_value(getattr(inst, "a", None))
            if out is not None and value is not None:
                self.resolved_vars[out.name] = float(value) ** 0.5
            return

        if opname.startswith("Align"):
            out = _out_var()
            value = self._resolve_build_time_value(getattr(inst, "a", None))
            if out is None or value is None:
                return
            align = int(opname.replace("Align", ""))
            self.resolved_vars[out.name] = _align_to(int(value), align)
            return

        if opname in ("GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx"):
            out = _out_var()
            if out is None:
                return
            core_count = self._build_time_core_count()
            if opname == "GetCubeNum":
                self.resolved_vars[out.name] = core_count
            elif opname == "GetCubeIdx":
                self.resolved_vars[out.name] = 0
            elif opname == "GetVecNum":
                self.resolved_vars[out.name] = core_count * 2
            elif opname == "GetVecIdx":
                self.resolved_vars[out.name] = 0
            else:
                self.resolved_vars[out.name] = 0

    def _resolve_numel_best_effort(self, shape: Any) -> int:
        """Try to compute numel from shape, falling back to 1 if vars are unresolvable."""
        if shape is None:
            return 1
        if not isinstance(shape, (list, tuple)):
            return 1
        total = 1
        for dim in shape:
            if isinstance(dim, (int, float)):
                total *= max(int(dim), 0)
            elif isinstance(dim, Var):
                if dim.name in self.resolved_vars:
                    v = self.resolved_vars[dim.name]
                else:
                    v = dim.value
                if isinstance(v, (int, float)):
                    total *= max(int(v), 0)
                else:
                    return 1  # can't resolve
            else:
                return 1
        return total

    def _resolve_int_best_effort(self, value: Any) -> int:
        """Resolve a dimension value to int, returning 0 if unresolvable."""
        if isinstance(value, (int, float)):
            return int(value)
        if isinstance(value, Var):
            if value.name in self.resolved_vars:
                v = self.resolved_vars[value.name]
            else:
                v = value.value
            if isinstance(v, (int, float)):
                return int(v)
            return 0
        if isinstance(value, str):
            if value in self.resolved_vars:
                resolved = self.resolved_vars[value]
                if isinstance(resolved, (int, float)):
                    return int(resolved)
            try:
                return int(value)
            except ValueError:
                return 0
        return 0

    def _storage_numel_padded(self, tensor: Tensor, base_numel: int) -> int:
        """Add NZ-layout alignment padding for L1/L0 positions."""
        shape = tensor.shape
        if not isinstance(shape, (list, tuple)) or len(shape) != 2:
            return base_numel
        rows_raw = shape[0]
        cols_raw = shape[1]
        rows = int(rows_raw.value if isinstance(rows_raw, Var) else rows_raw) if isinstance(rows_raw, (int, float, Var)) else 0
        cols = int(cols_raw.value if isinstance(cols_raw, Var) else cols_raw) if isinstance(cols_raw, (int, float, Var)) else 0
        if rows <= 0 or cols <= 0:
            return base_numel
        elem_size = int(tensor.dtype.size) if hasattr(tensor.dtype, "size") else 2
        if elem_size <= 0:
            return base_numel
        if tensor.position == Position.UB:
            return rows * cols
        if tensor.position == Position.L1:
            c0 = 32 // elem_size
            return ((cols + c0 - 1) // c0) * _align_to(rows, 16) * c0
        if tensor.position == Position.L0C:
            return ((cols + 15) // 16) * _align_to(rows, 16) * 16
        if tensor.position in (Position.L0A, Position.L0B):
            c0 = 32 // elem_size
            return ((cols + c0 - 1) // c0) * _align_to(rows, 16) * c0
        return base_numel

    def _shared_dtype_name(self, dtype: Any) -> str:
        if not isinstance(dtype, DataTypeValue):
            return "float16"
        name = str(dtype)
        return _SHARED_DTYPE_NAMES.get(name, name)

    def _raw_kwargs(self, inst: Instruction) -> Dict[str, Any]:
        """Extract kwargs with basic deferred resolution."""
        return {k: self._deferred_value(v) for k, v in inst.kwargs.items()}

    def _event_args(self, event: Any) -> Dict[str, Any]:
        return {
            "event_name": str(getattr(event, "name", "")),
            "src_pipe": str(getattr(event, "src_pipe", "")),
            "dst_pipe": str(getattr(event, "dst_pipe", "")),
            "preset": bool(getattr(event, "preset", False)),
        }

    # ------------------------------------------------------------------
    # Micro call support
    # ------------------------------------------------------------------

    def _collect_micro_defs(self) -> Dict[str, Any]:
        used_micros = getattr(self.kernel, "used_micros", None)
        if not used_micros:
            return {}
        defs: Dict[str, Any] = {}
        for micro in used_micros:
            name = str(getattr(micro, "name", ""))
            if not name:
                continue
            defs[name] = {
                "instructions": list(getattr(micro, "instructions", [])),
                "input_list": list(getattr(micro, "input_list", [])),
            }
        return defs

    def _emit_call_micro(self, inst: Instruction, target: List[ControlInstruction]) -> None:
        name = str(inst.kwargs.get("name", ""))
        args = inst.kwargs.get("args", [])
        if not isinstance(args, (list, tuple)):
            args = []
        call_bindings: List[Dict[str, Any]] = []
        for actual in args:
            if isinstance(actual, Tensor):
                call_bindings.append({
                    "kind": "tensor",
                    "actual_name": str(actual.name),
                })
            elif isinstance(actual, Var):
                call_bindings.append({
                    "kind": "var",
                    "actual_ref": self._deferred_value(actual),
                })
            else:
                call_bindings.append({
                    "kind": "var",
                    "actual_ref": self._deferred_value(actual),
                })
        target.append(ControlInstruction("call_micro", pipe_name="V", args={
            "name": name,
            "call_bindings": call_bindings,
        }))


def build_control_flow_program(kernel: Any) -> KernelProgram:
    """Build a V2 KernelProgram with full control flow from legacy instructions."""
    return ControlFlowKernelBridge(kernel=kernel).build()


__all__ = ["ControlFlowKernelBridge", "build_control_flow_program"]
