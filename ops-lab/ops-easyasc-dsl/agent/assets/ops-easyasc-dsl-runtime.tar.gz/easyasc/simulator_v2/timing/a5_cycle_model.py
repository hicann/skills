# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Dict, Optional, Tuple

import torch

from ..memory.shared_tensor_store import SharedTensorStore
from ..program.task import PipeTask


def _ceil_div(value: int, divisor: int) -> int:
    if divisor <= 0:
        raise ValueError("divisor must be positive, got: " + str(divisor))
    if value <= 0:
        return 0
    return (int(value) + int(divisor) - 1) // int(divisor)


def _align_to(value: int, align: int) -> int:
    if align <= 0:
        raise ValueError("align must be positive, got: " + str(align))
    return ((int(value) + align - 1) // align) * align


def _span_for_strided_rows(rows: int, row_pitch: int, active_cols: int) -> int:
    if rows <= 0 or active_cols <= 0:
        return 0
    return (int(rows) - 1) * int(row_pitch) + int(active_cols)


def _span_for_repeated_region(count: int, step: int, payload: int) -> int:
    if count <= 0 or payload <= 0:
        return 0
    return (int(count) - 1) * int(step) + int(payload)


def _resolve_int(value: Any, default: int = 0) -> int:
    if value is None:
        return int(default)
    if isinstance(value, bool):
        return int(value)
    if not isinstance(value, (int, float)):
        raise TypeError("expected int/float-compatible value, got: " + str(type(value)))
    return int(value)


def _tensor_ref(tensor_store: SharedTensorStore, ref: Any) -> Tuple[Optional[str], Optional[torch.Tensor]]:
    if tensor_store is None:
        return None, None
    if isinstance(ref, str) and tensor_store.contains(ref):
        tensor = tensor_store.tensor(ref)
        if isinstance(tensor, torch.Tensor):
            return ref, tensor
    return None, None


def _tensor_bytes(tensor: Optional[torch.Tensor]) -> int:
    if not isinstance(tensor, torch.Tensor):
        return 0
    return int(tensor.numel()) * int(tensor.element_size())


def _max_tensor_bytes(task: PipeTask, tensor_store: SharedTensorStore) -> int:
    names = ("dst", "src", "src1", "src2", "selmask", "offset", "idx")
    max_bytes = 0
    for name in names:
        _, tensor = _tensor_ref(tensor_store, task.args.get(name))
        max_bytes = max(max_bytes, _tensor_bytes(tensor))
    return max_bytes


@dataclass(frozen=True)
class A5CycleModel:
    profile_name: str
    time_domain: str
    gm_bandwidth_bytes_per_cycle: int
    l0_bandwidth_bytes_per_cycle: int
    ub_to_l1_bandwidth_bytes_per_cycle: int
    l0c_to_ub_bandwidth_bytes_per_cycle: int
    l0c_to_gm_bandwidth_bytes_per_cycle: int
    l0c_to_l1_bandwidth_bytes_per_cycle: int
    set_constant_to_l1_bandwidth_bytes_per_cycle: int
    mmad_macs_per_cycle: int
    vpipe_bytes_per_instruction: int
    vpipe_default_instruction_cycles: int
    vpipe_instruction_cycles: Dict[str, int]
    sync_marker_cycles: int


@dataclass(frozen=True)
class CycleEstimate:
    cycles: int
    details: Dict[str, Any]


def _default_profile_path(device_type: str) -> Optional[str]:
    lowered = str(device_type).lower()
    if lowered == "950":
        return os.path.join(os.path.dirname(__file__), "a5_cycle_model.json")
    return None


@lru_cache(maxsize=8)
def _load_cycle_model(path: str) -> A5CycleModel:
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    return A5CycleModel(
        profile_name=str(payload.get("profile_name", "a5_cycle_model")),
        time_domain=str(payload.get("time_domain", "cycle")),
        gm_bandwidth_bytes_per_cycle=int(payload.get("gm_bandwidth_bytes_per_cycle", 32)),
        l0_bandwidth_bytes_per_cycle=int(payload.get("l0_bandwidth_bytes_per_cycle", 128)),
        ub_to_l1_bandwidth_bytes_per_cycle=int(payload.get("ub_to_l1_bandwidth_bytes_per_cycle", 256)),
        l0c_to_ub_bandwidth_bytes_per_cycle=int(payload.get("l0c_to_ub_bandwidth_bytes_per_cycle", 256)),
        l0c_to_gm_bandwidth_bytes_per_cycle=int(payload.get("l0c_to_gm_bandwidth_bytes_per_cycle", 128)),
        l0c_to_l1_bandwidth_bytes_per_cycle=int(payload.get("l0c_to_l1_bandwidth_bytes_per_cycle", 128)),
        set_constant_to_l1_bandwidth_bytes_per_cycle=int(payload.get("set_constant_to_l1_bandwidth_bytes_per_cycle", 32)),
        mmad_macs_per_cycle=int(payload.get("mmad_macs_per_cycle", 4096)),
        vpipe_bytes_per_instruction=int(payload.get("vpipe_bytes_per_instruction", 256)),
        vpipe_default_instruction_cycles=int(payload.get("vpipe_default_instruction_cycles", 1)),
        vpipe_instruction_cycles={str(k): int(v) for k, v in dict(payload.get("vpipe_instruction_cycles", {})).items()},
        sync_marker_cycles=int(payload.get("sync_marker_cycles", 1)),
    )


def load_cycle_model_for_device(device_type: str, profile_path: str = "") -> Optional[A5CycleModel]:
    chosen_path = profile_path or _default_profile_path(device_type)
    if not chosen_path:
        return None
    if not os.path.isfile(chosen_path):
        raise FileNotFoundError("cycle model profile not found: " + str(chosen_path))
    return _load_cycle_model(os.path.abspath(chosen_path))


def _cycles_from_bandwidth(bytes_count: int, bytes_per_cycle: int) -> int:
    if bytes_count <= 0:
        return 0
    return max(1, _ceil_div(bytes_count, bytes_per_cycle))


def _estimate_gm_to_l1_nd2nz(task: PipeTask, tensor_store: SharedTensorStore, model: A5CycleModel) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
    if src is None or dst is None:
        return CycleEstimate(0, {"model_kind": "gm_to_l1_nd2nz"})
    h = _resolve_int(task.args.get("M"))
    w = _resolve_int(task.args.get("N"))
    w_src = _resolve_int(task.args.get("N_src"))
    h_dst = _resolve_int(task.args.get("M_dst"), h)
    elem_size = int(dst.element_size())
    c0 = 32 // elem_size if elem_size > 0 else 1
    src_bytes = _span_for_strided_rows(h, w_src, w) * int(src.element_size())
    dst_bytes = ((w + c0 - 1) // c0) * _align_to(h_dst, 16) * c0 * elem_size
    cycles = _cycles_from_bandwidth(src_bytes, model.gm_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "gm_bandwidth_bytes_per_cycle",
            "payload_bytes": src_bytes,
            "layout_bytes": dst_bytes,
            "modeled_cycles": cycles,
        },
    )


def _estimate_gm_to_ub_pad(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    n_burst = _resolve_int(task.args.get("n_burst"))
    burst_len_byte = _resolve_int(task.args.get("burst_len_byte"))
    payload_bytes = max(0, n_burst) * max(0, burst_len_byte)
    cycles = _cycles_from_bandwidth(payload_bytes, model.gm_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "gm_bandwidth_bytes_per_cycle",
            "payload_bytes": payload_bytes,
            "modeled_cycles": cycles,
        },
    )


def _estimate_ub_to_gm_pad(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    n_burst = _resolve_int(task.args.get("n_burst"))
    burst_len_byte = _resolve_int(task.args.get("burst_len_byte"))
    payload_bytes = max(0, n_burst) * max(0, burst_len_byte)
    cycles = _cycles_from_bandwidth(payload_bytes, model.gm_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "gm_bandwidth_bytes_per_cycle",
            "payload_bytes": payload_bytes,
            "modeled_cycles": cycles,
        },
    )


def _estimate_set_constant_to_l1(task: PipeTask, tensor_store: SharedTensorStore, model: A5CycleModel) -> CycleEstimate:
    tensor_name, tensor = _tensor_ref(tensor_store, task.args.get("tensor", task.args.get("dst")))
    if tensor_name is None or tensor is None:
        return CycleEstimate(0, {"model_kind": "set_constant_to_l1"})
    n_blocks = _resolve_int(task.args.get("n_blocks"))
    elem_size = int(tensor.element_size())
    c0 = 32 // elem_size if elem_size > 0 else 1
    payload_bytes = max(0, n_blocks) * c0 * elem_size
    cycles = _cycles_from_bandwidth(payload_bytes, model.set_constant_to_l1_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "set_constant_to_l1_bandwidth_bytes_per_cycle",
            "payload_bytes": payload_bytes,
            "tensor": tensor_name,
            "modeled_cycles": cycles,
        },
    )


def _estimate_l1_to_l0(task: PipeTask, tensor_store: SharedTensorStore, model: A5CycleModel) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
    if src is None or dst is None:
        return CycleEstimate(0, {"model_kind": "l1_to_l0"})
    m_dst = _resolve_int(task.args.get("m_dst"))
    n_dst = _resolve_int(task.args.get("n_dst"))
    m_src = _resolve_int(task.args.get("m_src"))
    n_src = _resolve_int(task.args.get("n_src"))
    src_is_transpose = bool(task.args.get("src_is_transpose", False))
    src_layout = str(task.args.get("src_layout", "NZ")).upper()
    dst_layout = str(task.args.get("dst_layout", "ZN" if src_is_transpose else "NZ")).upper()
    src_row0 = _resolve_int(task.args.get("src_row0"), 0)
    src_col0 = _resolve_int(task.args.get("src_col0"), 0)
    elem_size = int(dst.element_size())
    c0 = 32 // elem_size if elem_size > 0 else 1
    required_src_rows = src_row0 + max(m_dst, 0)
    required_src_cols = src_col0 + max(n_dst, 0)
    src_n_align = _align_to(required_src_cols, c0)
    if src_layout == "ZZ":
        src_elems = ((required_src_rows + 15) // 16) * src_n_align * 16
    else:
        src_elems = ((required_src_cols + c0 - 1) // c0) * _align_to(required_src_rows, 16) * c0
    if src_is_transpose:
        if dst_layout == "ZZ":
            out_rows = n_dst
            out_cols = m_dst
            dst_elems = ((out_rows + 15) // 16) * _align_to(out_cols, c0) * 16
        else:
            row_block = 32 if elem_size == 1 else 16
            n_align = _align_to(n_dst, 32 if elem_size == 1 else c0)
            m_blocks = (m_dst + row_block - 1) // row_block
            dst_elems = m_blocks * row_block * n_align
    elif dst_layout == "ZZ":
        dst_elems = ((m_dst + 15) // 16) * _align_to(n_dst, c0) * 16
    else:
        dst_elems = ((n_dst + c0 - 1) // c0) * _align_to(m_dst, 16) * c0
    bytes_count = max(src_elems * int(src.element_size()), dst_elems * elem_size, 0)
    cycles = _cycles_from_bandwidth(bytes_count, model.l0_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "l0_bandwidth_bytes_per_cycle",
            "src_bytes": src_elems * int(src.element_size()),
            "dst_bytes": dst_elems * elem_size,
            "src_row0": src_row0,
            "src_col0": src_col0,
            "required_src_rows": required_src_rows,
            "required_src_cols": required_src_cols,
            "src_backing_rows": m_src,
            "src_backing_cols": n_src,
            "modeled_cycles": cycles,
        },
    )


def _estimate_mmad(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    m = _resolve_int(task.args.get("M"))
    n = _resolve_int(task.args.get("N"))
    k = _resolve_int(task.args.get("K"))
    macs = max(0, m) * max(0, n) * max(0, k)
    cycles = _cycles_from_bandwidth(macs, model.mmad_macs_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "compute",
            "compute_source": "mmad_macs_per_cycle",
            "macs": macs,
            "modeled_cycles": cycles,
        },
    )


def _estimate_l0c_to_gm(task: PipeTask, tensor_store: SharedTensorStore, model: A5CycleModel) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
    if src is None or dst is None:
        return CycleEstimate(0, {"model_kind": "l0c_to_gm_nz2nd"})
    m = _resolve_int(task.args.get("M"))
    n = _resolve_int(task.args.get("N"))
    n_dst = _resolve_int(task.args.get("N_dst"))
    m_src = _resolve_int(task.args.get("M_src"))
    src_bytes = ((n + 15) // 16) * _align_to(m_src, 16) * 16 * int(src.element_size())
    dst_bytes = _span_for_strided_rows(m, n_dst, n) * int(dst.element_size())
    bytes_count = max(src_bytes, dst_bytes, 0)
    cycles = _cycles_from_bandwidth(bytes_count, model.l0c_to_gm_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "l0c_to_gm_bandwidth_bytes_per_cycle",
            "src_bytes": src_bytes,
            "dst_bytes": dst_bytes,
            "modeled_cycles": cycles,
        },
    )


def _estimate_l0c_to_l1(task: PipeTask, tensor_store: SharedTensorStore, model: A5CycleModel) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
    if src is None or dst is None:
        return CycleEstimate(0, {"model_kind": "l0c_to_l1"})
    m = _resolve_int(task.args.get("M"))
    n = _resolve_int(task.args.get("N"))
    m_dst = _resolve_int(task.args.get("M_dst"))
    m_src = _resolve_int(task.args.get("M_src"))
    elem_size = int(dst.element_size())
    c0 = 32 // elem_size if elem_size > 0 else 1
    src_bytes = ((n + 15) // 16) * _align_to(m_src, 16) * 16 * int(src.element_size())
    dst_bytes = ((n + c0 - 1) // c0) * _align_to(m_dst, 16) * c0 * elem_size
    bytes_count = max(src_bytes, dst_bytes, 0)
    cycles = _cycles_from_bandwidth(bytes_count, model.l0c_to_l1_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "l0c_to_l1_bandwidth_bytes_per_cycle",
            "src_bytes": src_bytes,
            "dst_bytes": dst_bytes,
            "modeled_cycles": cycles,
        },
    )


def _estimate_l0c_to_ub(task: PipeTask, tensor_store: SharedTensorStore, model: A5CycleModel) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    if src is None:
        return CycleEstimate(0, {"model_kind": "l0c_to_ub"})
    m = _resolve_int(task.args.get("M"))
    n = _resolve_int(task.args.get("N"))
    m_src = _resolve_int(task.args.get("M_src"))
    dual_mode = _resolve_int(task.args.get("dual_mode"), 1)
    src_bytes = ((n + 15) // 16) * _align_to(m_src, 16) * 16 * int(src.element_size())
    payload_elems = m * n
    if dual_mode == 1:
        payload_elems = (m // 2) * n
    elif dual_mode == 2:
        payload_elems = m * (n // 2)
    dst_tensor = None
    if isinstance(task.args.get("dst"), str):
        _, dst_tensor = _tensor_ref(tensor_store, task.args.get("dst"))
    elif isinstance(task.args.get("dst_vec0"), str):
        _, dst_tensor = _tensor_ref(tensor_store, task.args.get("dst_vec0"))
    dst_bytes = payload_elems * int(dst_tensor.element_size()) if dst_tensor is not None else payload_elems * 4
    bytes_count = max(src_bytes, dst_bytes, 0)
    cycles = _cycles_from_bandwidth(bytes_count, model.l0c_to_ub_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "l0c_to_ub_bandwidth_bytes_per_cycle",
            "src_bytes": src_bytes,
            "dst_bytes": dst_bytes,
            "dual_mode": dual_mode,
            "modeled_cycles": cycles,
        },
    )


def _estimate_ub_to_l1(task: PipeTask, tensor_store: SharedTensorStore, model: A5CycleModel, nz_mode: bool) -> CycleEstimate:
    _, src = _tensor_ref(tensor_store, task.args.get("src"))
    _, dst = _tensor_ref(tensor_store, task.args.get("dst"))
    if src is None or dst is None:
        return CycleEstimate(0, {"model_kind": "ub_to_l1"})
    m_dst = _resolve_int(task.args.get("m_dst"))
    n_dst = _resolve_int(task.args.get("n_dst"))
    m_src = _resolve_int(task.args.get("m_src"))
    n_src = _resolve_int(task.args.get("n_src"))
    elem_size = int(dst.element_size())
    c0 = 32 // elem_size if elem_size > 0 else 1
    block_count = (n_src + c0 - 1) // c0
    if nz_mode:
        src_elems = block_count * (m_src * c0)
    else:
        src_elems = m_src * n_src
    dst_elems = _span_for_repeated_region(block_count, _align_to(m_dst, 16) * c0, m_src * c0)
    src_bytes = src_elems * int(src.element_size())
    dst_bytes = dst_elems * elem_size
    bytes_count = max(src_bytes, dst_bytes, 0)
    cycles = _cycles_from_bandwidth(bytes_count, model.ub_to_l1_bandwidth_bytes_per_cycle)
    return CycleEstimate(
        cycles,
        {
            "model_kind": "bandwidth",
            "bandwidth_source": "ub_to_l1_bandwidth_bytes_per_cycle",
            "src_bytes": src_bytes,
            "dst_bytes": dst_bytes,
            "nz_mode": nz_mode,
            "modeled_cycles": cycles,
        },
    )


_MICRO_NON_EXEC_OPS = frozenset([
    "create_var",
    "var_add",
    "var_sub",
    "var_mul",
    "start_micro_loop",
    "end_loop",
    "create_reg",
    "create_reglist",
    "create_maskreg",
    "micro_ub2reg",
    "micro_reg2ub",
    "micro_ub2regcont",
    "micro_reg2ubcont",
])


def _resolve_micro_scalar(value: Any, env: Dict[str, Any]) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    if isinstance(value, str) and value in env:
        return int(env[value])
    name = getattr(value, "name", None)
    if isinstance(name, str) and name in env:
        return int(env[name])
    value_attr = getattr(value, "value", None)
    if isinstance(value_attr, (int, float)):
        return int(value_attr)
    return 0


def _find_matching_end_loop(instructions: list, start_idx: int) -> int:
    depth = 0
    for idx in range(start_idx, len(instructions)):
        opname = str(instructions[idx].opname)
        if opname == "start_micro_loop":
            depth += 1
        elif opname == "end_loop":
            depth -= 1
            if depth == 0:
                return idx
    return len(instructions) - 1


def _count_micro_instructions(instructions: list, env: Dict[str, Any]) -> int:
    total = 0
    idx = 0
    while idx < len(instructions):
        inst = instructions[idx]
        opname = str(inst.opname)
        if opname == "start_micro_loop":
            loop_end = _find_matching_end_loop(instructions, idx)
            loop_env = dict(env)
            var = inst.kwargs.get("var")
            var_name = str(getattr(var, "name", var))
            start = _resolve_micro_scalar(inst.kwargs.get("start", 0), loop_env)
            stop = _resolve_micro_scalar(inst.kwargs.get("stop", 0), loop_env)
            step = _resolve_micro_scalar(inst.kwargs.get("step", 1), loop_env)
            if step == 0:
                step = 1
            body = instructions[idx + 1 : loop_end]
            for value in range(start, stop, step):
                loop_env[var_name] = value
                total += _count_micro_instructions(body, loop_env)
            idx = loop_end + 1
            continue
        if opname not in _MICRO_NON_EXEC_OPS:
            total += 1
        idx += 1
    return total


def _estimate_call_micro(task: PipeTask, model: A5CycleModel) -> CycleEstimate:
    micro_def = task.args.get("micro_def", {})
    instructions = micro_def.get("instructions", []) if isinstance(micro_def, dict) else []
    var_values = dict(task.args.get("var_values", {}))
    inst_count = _count_micro_instructions(list(instructions), var_values)
    cycles_per_inst = int(model.vpipe_instruction_cycles.get("call_micro", model.vpipe_default_instruction_cycles))
    cycles = max(1, inst_count * max(cycles_per_inst, 1)) if inst_count > 0 else 0
    return CycleEstimate(
        cycles,
        {
            "model_kind": "vpipe_micro",
            "instruction_count": inst_count,
            "cycles_per_instruction": cycles_per_inst,
            "modeled_cycles": cycles,
        },
    )


def _estimate_vpipe(task: PipeTask, tensor_store: SharedTensorStore, model: A5CycleModel) -> CycleEstimate:
    if task.opname == "call_micro":
        return _estimate_call_micro(task, model)
    if task.opname in (
        "wait_vec",
        "wait_cube",
        "waitflag",
        "event_wait",
        "event_set",
        "event_setall",
        "event_release",
        "allcube_wait",
        "allvec_wait",
        "vec_ready",
        "cube_ready",
        "setflag",
        "allcube_ready",
        "allvec_ready",
    ):
        cycles = max(1, model.sync_marker_cycles)
        return CycleEstimate(cycles, {"model_kind": "sync_marker", "modeled_cycles": cycles})
    repeat = _resolve_int(task.args.get("repeat"), 0)
    cycles_per_inst = int(model.vpipe_instruction_cycles.get(task.opname, model.vpipe_instruction_cycles.get("default", model.vpipe_default_instruction_cycles)))
    if repeat > 0:
        inst_count = repeat
        processed_bytes = 0
    else:
        processed_bytes = _max_tensor_bytes(task, tensor_store)
        granularity = max(1, int(model.vpipe_bytes_per_instruction))
        inst_count = max(1, _ceil_div(processed_bytes, granularity)) if processed_bytes > 0 else 1
    cycles = max(1, inst_count * max(cycles_per_inst, 1))
    return CycleEstimate(
        cycles,
        {
            "model_kind": "vpipe_compute",
            "instruction_count": inst_count,
            "cycles_per_instruction": cycles_per_inst,
            "processed_bytes": processed_bytes,
            "modeled_cycles": cycles,
        },
    )


def estimate_task_cycles(task: PipeTask, tensor_store: Optional[SharedTensorStore], model: A5CycleModel) -> CycleEstimate:
    if tensor_store is None:
        return CycleEstimate(0, {"model_kind": "no_tensor_store"})
    if task.opname == "gm_to_l1_nd2nz":
        return _estimate_gm_to_l1_nd2nz(task, tensor_store, model)
    if task.opname == "gm_to_ub_pad":
        return _estimate_gm_to_ub_pad(task, model)
    if task.opname == "ub_to_gm_pad":
        return _estimate_ub_to_gm_pad(task, model)
    if task.opname == "set_constant_to_l1":
        return _estimate_set_constant_to_l1(task, tensor_store, model)
    if task.opname == "l1_to_l0":
        return _estimate_l1_to_l0(task, tensor_store, model)
    if task.opname == "mmad":
        return _estimate_mmad(task, model)
    if task.opname == "l0c_to_gm_nz2nd":
        return _estimate_l0c_to_gm(task, tensor_store, model)
    if task.opname == "l0c_to_l1":
        return _estimate_l0c_to_l1(task, tensor_store, model)
    if task.opname == "l0c_to_ub":
        return _estimate_l0c_to_ub(task, tensor_store, model)
    if task.opname == "ub_to_l1_nd2nz":
        return _estimate_ub_to_l1(task, tensor_store, model, nz_mode=False)
    if task.opname == "ub_to_l1_nz":
        return _estimate_ub_to_l1(task, tensor_store, model, nz_mode=True)
    if task.pipe_name == "V":
        return _estimate_vpipe(task, tensor_store, model)
    if task.opname in ("copy_shared", "fill_shared", "cube_m_copy", "cube_m_scale"):
        bytes_count = _max_tensor_bytes(task, tensor_store)
        cycles = _cycles_from_bandwidth(bytes_count, model.l0_bandwidth_bytes_per_cycle)
        return CycleEstimate(
            cycles,
            {
                "model_kind": "bandwidth",
                "bandwidth_source": "l0_bandwidth_bytes_per_cycle",
                "payload_bytes": bytes_count,
                "modeled_cycles": cycles,
            },
        )
    return CycleEstimate(max(1, model.sync_marker_cycles), {"model_kind": "fallback", "modeled_cycles": max(1, model.sync_marker_cycles)})
