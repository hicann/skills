# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
import multiprocessing
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

from .events import SyncEvent, SyncEventType


def _participant_key(name: str, participant_idx: int) -> Tuple[str, int]:
    return (str(name), int(participant_idx))


@dataclass
class CollectiveSync:
    """Global collective synchronization coordinator."""

    phases: Dict[str, int] = field(default_factory=dict)
    parties: Dict[str, int] = field(default_factory=dict)
    ready_counts: Dict[str, int] = field(default_factory=dict)
    participant_ready_counts: Dict[Tuple[str, int], int] = field(default_factory=dict)
    participant_wait_counts: Dict[Tuple[str, int], int] = field(default_factory=dict)
    phase_cycles: Dict[Tuple[str, int], float] = field(default_factory=dict)
    event_log: List[SyncEvent] = field(default_factory=list)
    _condition: Any = field(default_factory=threading.Condition, init=False, repr=False)
    _sync_manager: Any = field(default=None, init=False, repr=False)
    _owns_manager: bool = field(default=False, init=False, repr=False)

    def _acquire(self) -> None:
        self._condition.acquire()

    def _release(self) -> None:
        self._condition.release()

    def _clear_mapping(self, mapping: Any) -> None:
        for key in list(mapping.keys()):
            del mapping[key]

    def _publish_event(self, event: SyncEvent) -> None:
        self.event_log.append(event)

    def prepare_shared(self) -> None:
        if self._sync_manager is None:
            self._sync_manager = multiprocessing.Manager()
            self._owns_manager = True
            self._condition = self._sync_manager.Condition()
            self.phases = self._sync_manager.dict()
            self.parties = self._sync_manager.dict()
            self.ready_counts = self._sync_manager.dict()
            self.participant_ready_counts = self._sync_manager.dict()
            self.participant_wait_counts = self._sync_manager.dict()
            self.phase_cycles = self._sync_manager.dict()
        else:
            self._clear_mapping(self.phases)
            self._clear_mapping(self.parties)
            self._clear_mapping(self.ready_counts)
            self._clear_mapping(self.participant_ready_counts)
            self._clear_mapping(self.participant_wait_counts)
            self._clear_mapping(self.phase_cycles)
        self.event_log = []

    def shared_snapshot(self) -> Dict[str, Any]:
        if self._sync_manager is None:
            self.prepare_shared()
        return {
            "phases": self.phases,
            "parties": self.parties,
            "ready_counts": self.ready_counts,
            "participant_ready_counts": self.participant_ready_counts,
            "participant_wait_counts": self.participant_wait_counts,
            "phase_cycles": self.phase_cycles,
            "condition": self._condition,
        }

    def load_shared_snapshot(self, snapshot: Dict[str, Any]) -> None:
        self.phases = snapshot.get("phases", {})
        self.parties = snapshot.get("parties", {})
        self.ready_counts = snapshot.get("ready_counts", {})
        self.participant_ready_counts = snapshot.get("participant_ready_counts", {})
        self.participant_wait_counts = snapshot.get("participant_wait_counts", {})
        self.phase_cycles = snapshot.get("phase_cycles", {})
        self._condition = snapshot.get("condition", threading.Condition())
        self.event_log = []
        self._sync_manager = None
        self._owns_manager = False

    def shutdown(self) -> None:
        self.event_log = []
        self.phases = {}
        self.parties = {}
        self.ready_counts = {}
        self.participant_ready_counts = {}
        self.participant_wait_counts = {}
        self.phase_cycles = {}
        self._condition = threading.Condition()
        if self._owns_manager and self._sync_manager is not None:
            try:
                self._sync_manager.shutdown()
            except Exception:
                pass
        self._sync_manager = None
        self._owns_manager = False

    def configure(self, name: str, parties: int) -> None:
        if parties <= 0:
            raise ValueError("collective parties must be positive")
        self._acquire()
        try:
            self.parties[name] = int(parties)
            if name not in self.ready_counts:
                self.ready_counts[name] = 0
            if name not in self.phases:
                self.phases[name] = 0
        finally:
            self._release()

    def _check_participant_idx(self, name: str, participant_idx: int) -> None:
        if not isinstance(participant_idx, int):
            raise TypeError("participant_idx must be int, got: " + str(type(participant_idx)))
        parties = self.parties.get(name, 1)
        if participant_idx < 0 or participant_idx >= parties:
            raise ValueError(
                "participant_idx out of range for "
                + str(name)
                + ": "
                + str(participant_idx)
                + ", expected [0, "
                + str(parties)
                + ")"
            )

    def _participant_phase(self, counts: Any, name: str, participant_idx: int) -> int:
        return int(counts.get(_participant_key(name, participant_idx), 0))

    def _set_participant_phase(self, counts: Any, name: str, participant_idx: int, phase: int) -> None:
        counts[_participant_key(name, participant_idx)] = int(phase)

    def _can_wait_locked(self, name: str, participant_idx: int) -> bool:
        self._check_participant_idx(name, participant_idx)
        parties = self.parties.get(name, 1)
        wait_phase = self._participant_phase(self.participant_wait_counts, name, participant_idx)
        for idx in range(parties):
            if self._participant_phase(self.participant_ready_counts, name, idx) <= wait_phase:
                return False
        return True

    def publish_ready(self, name: str, participant_idx: Optional[int] = None, ready_cycle: Optional[float] = None) -> int:
        self._acquire()
        try:
            if participant_idx is not None:
                self._check_participant_idx(name, participant_idx)
                ready_phase = self._participant_phase(self.participant_ready_counts, name, participant_idx) + 1
                self._set_participant_phase(self.participant_ready_counts, name, participant_idx, ready_phase)
                current_phase = self.phases.get(name, 0)
                parties = self.parties.get(name, 1)
                released_phase = current_phase
                if parties > 0:
                    released_phase = min(
                        self._participant_phase(self.participant_ready_counts, name, idx) for idx in range(parties)
                    )
                self._publish_event(
                    SyncEvent(
                        name=name,
                        event_type=SyncEventType.READY,
                        scope="collective",
                        phase=ready_phase,
                    )
                )
                if released_phase > current_phase:
                    self.phases[name] = released_phase
                    if ready_cycle is not None:
                        self.phase_cycles[_participant_key(name, released_phase)] = float(ready_cycle)
                    self._condition.notify_all()
                return ready_phase
            parties = self.parties.get(name, 1)
            count = self.ready_counts.get(name, 0) + 1
            target_phase = self.phases.get(name, 0) + 1
            self.ready_counts[name] = count
            self._publish_event(
                SyncEvent(name=name, event_type=SyncEventType.READY, scope="collective", phase=target_phase)
            )
            if count >= parties:
                self.phases[name] = target_phase
                self.ready_counts[name] = 0
                if ready_cycle is not None:
                    self.phase_cycles[_participant_key(name, target_phase)] = float(ready_cycle)
                self._condition.notify_all()
                return target_phase
            return target_phase
        finally:
            self._release()

    def current(self, name: str) -> int:
        self._acquire()
        try:
            return self.phases.get(name, 0)
        finally:
            self._release()

    def phase_cycle(self, name: str, phase: int) -> Optional[float]:
        self._acquire()
        try:
            return self.phase_cycles.get(_participant_key(name, phase))
        finally:
            self._release()

    def can_wait(self, name: str, participant_idx: int) -> bool:
        self._acquire()
        try:
            return self._can_wait_locked(name, participant_idx)
        finally:
            self._release()

    def consume_wait(self, name: str, participant_idx: int) -> bool:
        self._acquire()
        try:
            if not self._can_wait_locked(name, participant_idx):
                return False
            next_phase = self._participant_phase(self.participant_wait_counts, name, participant_idx) + 1
            self._set_participant_phase(self.participant_wait_counts, name, participant_idx, next_phase)
            self._publish_event(
                SyncEvent(
                    name=name,
                    event_type=SyncEventType.WAIT,
                    scope="collective",
                    phase=next_phase,
                )
            )
            return True
        finally:
            self._release()

    def wait_for(self, name: str, phase: int, timeout: Optional[float] = None) -> bool:
        deadline = None
        if timeout is not None:
            deadline = time.monotonic() + float(timeout)
        self._acquire()
        try:
            while self.phases.get(name, 0) < phase:
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                self._condition.wait(timeout=remaining)
            self._publish_event(
                SyncEvent(name=name, event_type=SyncEventType.WAIT, scope="collective", phase=phase)
            )
            return True
        finally:
            self._release()

    def snapshot(self) -> Dict[str, Dict[str, int]]:
        self._acquire()
        try:
            return {
                "phases": dict(self.phases),
                "parties": dict(self.parties),
                "ready_counts": dict(self.ready_counts),
            }
        finally:
            self._release()

    def participant_snapshot(self, name: str) -> Dict[str, Dict[int, int]]:
        self._acquire()
        try:
            ready_counts = {}
            wait_counts = {}
            for key, phase in dict(self.participant_ready_counts).items():
                sync_name, participant_idx = key
                if sync_name == name:
                    ready_counts[int(participant_idx)] = int(phase)
            for key, phase in dict(self.participant_wait_counts).items():
                sync_name, participant_idx = key
                if sync_name == name:
                    wait_counts[int(participant_idx)] = int(phase)
            return {
                "ready_counts": ready_counts,
                "wait_counts": wait_counts,
            }
        finally:
            self._release()

    def timeout_diagnostic(self, name: str, phase: int, participant_idx: Optional[int] = None) -> Dict[str, Any]:
        snapshot = self.snapshot()
        diagnostic = {
            "scope": "collective",
            "name": name,
            "target_phase": phase,
            "current_phase": snapshot["phases"].get(name, 0),
            "parties": snapshot["parties"].get(name, 1),
            "ready_count": snapshot["ready_counts"].get(name, 0),
        }
        if participant_idx is not None:
            participant_state = self.participant_snapshot(name)
            diagnostic["participant_idx"] = participant_idx
            diagnostic["participant_ready_count"] = participant_state["ready_counts"].get(participant_idx, 0)
            diagnostic["participant_wait_count"] = participant_state["wait_counts"].get(participant_idx, 0)
        return diagnostic
