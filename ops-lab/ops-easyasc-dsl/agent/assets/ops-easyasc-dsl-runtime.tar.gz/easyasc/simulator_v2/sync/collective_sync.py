from __future__ import annotations

from dataclasses import dataclass, field
import threading
import time
from typing import Any, Dict, List, Optional

from .events import SyncEvent, SyncEventType


@dataclass
class CollectiveSync:
    """Global collective synchronization coordinator."""

    phases: Dict[str, int] = field(default_factory=dict)
    parties: Dict[str, int] = field(default_factory=dict)
    ready_counts: Dict[str, int] = field(default_factory=dict)
    participant_ready_counts: Dict[str, Dict[int, int]] = field(default_factory=dict)
    participant_wait_counts: Dict[str, Dict[int, int]] = field(default_factory=dict)
    event_log: List[SyncEvent] = field(default_factory=list)
    _condition: threading.Condition = field(
        default_factory=threading.Condition,
        init=False,
        repr=False,
    )

    def configure(self, name: str, parties: int) -> None:
        if parties <= 0:
            raise ValueError("collective parties must be positive")
        with self._condition:
            self.parties[name] = int(parties)
            self.ready_counts.setdefault(name, 0)
            self.phases.setdefault(name, 0)
            self.participant_ready_counts.setdefault(name, {})
            self.participant_wait_counts.setdefault(name, {})

    def _check_participant_idx(self, name: str, participant_idx: int) -> None:
        if not isinstance(participant_idx, int):
            raise TypeError("participant_idx must be int, got: " + str(type(participant_idx)))
        parties = self.parties.get(name, 1)
        if participant_idx < 0 or participant_idx >= parties:
            raise ValueError(
                "participant_idx out of range for "
                + str(name)
                + ": "
                + str(participant_idx)
                + ", expected [0, "
                + str(parties)
                + ")"
            )

    def publish_ready(self, name: str, participant_idx: Optional[int] = None) -> int:
        with self._condition:
            if participant_idx is not None:
                self._check_participant_idx(name, participant_idx)
                ready_by_participant = self.participant_ready_counts.setdefault(name, {})
                ready_phase = ready_by_participant.get(participant_idx, 0) + 1
                ready_by_participant[participant_idx] = ready_phase
                current_phase = self.phases.get(name, 0)
                parties = self.parties.get(name, 1)
                released_phase = current_phase
                if parties > 0:
                    released_phase = min(ready_by_participant.get(idx, 0) for idx in range(parties))
                self.event_log.append(
                    SyncEvent(
                        name=name,
                        event_type=SyncEventType.READY,
                        scope="collective",
                        phase=ready_phase,
                    )
                )
                if released_phase > current_phase:
                    self.phases[name] = released_phase
                    self._condition.notify_all()
                return ready_phase
            parties = self.parties.get(name, 1)
            count = self.ready_counts.get(name, 0) + 1
            target_phase = self.phases.get(name, 0) + 1
            self.ready_counts[name] = count
            self.event_log.append(
                SyncEvent(name=name, event_type=SyncEventType.READY, scope="collective", phase=target_phase)
            )
            if count >= parties:
                self.phases[name] = target_phase
                self.ready_counts[name] = 0
                self._condition.notify_all()
                return target_phase
            return target_phase

    def current(self, name: str) -> int:
        with self._condition:
            return self.phases.get(name, 0)

    def can_wait(self, name: str, participant_idx: int) -> bool:
        with self._condition:
            self._check_participant_idx(name, participant_idx)
            parties = self.parties.get(name, 1)
            ready_by_participant = self.participant_ready_counts.setdefault(name, {})
            wait_by_participant = self.participant_wait_counts.setdefault(name, {})
            wait_phase = wait_by_participant.get(participant_idx, 0)
            for idx in range(parties):
                if ready_by_participant.get(idx, 0) <= wait_phase:
                    return False
            return True

    def consume_wait(self, name: str, participant_idx: int) -> bool:
        with self._condition:
            if not self.can_wait(name, participant_idx):
                return False
            wait_by_participant = self.participant_wait_counts.setdefault(name, {})
            next_phase = wait_by_participant.get(participant_idx, 0) + 1
            wait_by_participant[participant_idx] = next_phase
            self.event_log.append(
                SyncEvent(
                    name=name,
                    event_type=SyncEventType.WAIT,
                    scope="collective",
                    phase=next_phase,
                )
            )
            return True

    def wait_for(self, name: str, phase: int, timeout: Optional[float] = None) -> bool:
        deadline = None
        if timeout is not None:
            deadline = time.monotonic() + float(timeout)
        with self._condition:
            while self.phases.get(name, 0) < phase:
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                self._condition.wait(timeout=remaining)
            self.event_log.append(
                SyncEvent(name=name, event_type=SyncEventType.WAIT, scope="collective", phase=phase)
            )
            return True

    def snapshot(self) -> Dict[str, Dict[str, int]]:
        with self._condition:
            return {
                "phases": dict(self.phases),
                "parties": dict(self.parties),
                "ready_counts": dict(self.ready_counts),
            }

    def participant_snapshot(self, name: str) -> Dict[str, Dict[int, int]]:
        with self._condition:
            return {
                "ready_counts": dict(self.participant_ready_counts.get(name, {})),
                "wait_counts": dict(self.participant_wait_counts.get(name, {})),
            }

    def timeout_diagnostic(self, name: str, phase: int, participant_idx: Optional[int] = None) -> Dict[str, Any]:
        snapshot = self.snapshot()
        diagnostic = {
            "scope": "collective",
            "name": name,
            "target_phase": phase,
            "current_phase": snapshot["phases"].get(name, 0),
            "parties": snapshot["parties"].get(name, 1),
            "ready_count": snapshot["ready_counts"].get(name, 0),
        }
        if participant_idx is not None:
            participant_state = self.participant_snapshot(name)
            diagnostic["participant_idx"] = participant_idx
            diagnostic["participant_ready_count"] = participant_state["ready_counts"].get(participant_idx, 0)
            diagnostic["participant_wait_count"] = participant_state["wait_counts"].get(participant_idx, 0)
        return diagnostic
