from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class SyncEventType(Enum):
    READY = "ready"
    WAIT = "wait"
    RELEASE = "release"


@dataclass(frozen=True)
class SyncEvent:
    """A synchronization event description."""

    name: str
    event_type: SyncEventType
    scope: str
    phase: int = 0

