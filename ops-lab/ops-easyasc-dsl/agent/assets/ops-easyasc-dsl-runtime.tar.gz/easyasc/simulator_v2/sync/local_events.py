# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
import threading
import time
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class LocalEventDescriptor:
    name: str
    event_kind: str
    src_pipe: str
    dst_pipe: str
    flag_ids: Tuple[int, ...]
    preset: bool = False
    set_count: int = 0
    wait_count: int = 0


@dataclass(frozen=True)
class LocalEventRecord:
    name: str
    action: str
    src_pipe: str
    dst_pipe: str
    flag_id: int
    slot_index: int


@dataclass
class LocalEventBank:
    """Per-lane lane-local event bank with real flag-id allocation."""

    descriptors: Dict[str, LocalEventDescriptor] = field(default_factory=dict)
    next_flag_id_by_pair: Dict[Tuple[str, str], int] = field(default_factory=dict)
    flag_values: Dict[Tuple[str, str, int], bool] = field(default_factory=dict)
    flag_cycles: Dict[Tuple[str, str, int], float] = field(default_factory=dict)
    event_log: List[LocalEventRecord] = field(default_factory=list)
    _condition: threading.Condition = field(default_factory=threading.Condition, init=False, repr=False)

    @staticmethod
    def _pair_key(src_pipe: str, dst_pipe: str) -> Tuple[str, str]:
        return (str(src_pipe), str(dst_pipe))

    @staticmethod
    def _flag_key(src_pipe: str, dst_pipe: str, flag_id: int) -> Tuple[str, str, int]:
        return (str(src_pipe), str(dst_pipe), int(flag_id))

    def create_event(
        self,
        name: str,
        event_kind: str,
        src_pipe: str,
        dst_pipe: str,
        preset: bool = False,
        ready_cycle: Optional[float] = None,
    ) -> LocalEventDescriptor:
        if event_kind not in ("s", "d"):
            raise ValueError("event_kind must be 's' or 'd', got: " + repr(event_kind))
        pair = self._pair_key(src_pipe, dst_pipe)
        with self._condition:
            existing = self.descriptors.get(str(name))
            if existing is not None:
                if (
                    existing.event_kind != event_kind
                    or existing.src_pipe != pair[0]
                    or existing.dst_pipe != pair[1]
                    or bool(existing.preset) != bool(preset)
                ):
                    raise ValueError(
                        "conflicting local event creation for "
                        + repr(name)
                        + ": existing="
                        + repr(existing)
                    )
                return existing

            width = 1 if event_kind == "s" else 2
            next_flag_id = int(self.next_flag_id_by_pair.get(pair, 0))
            flag_ids = tuple(range(next_flag_id, next_flag_id + width))
            self.next_flag_id_by_pair[pair] = next_flag_id + width
            descriptor = LocalEventDescriptor(
                name=str(name),
                event_kind=event_kind,
                src_pipe=pair[0],
                dst_pipe=pair[1],
                flag_ids=flag_ids,
                preset=bool(preset),
            )
            self.descriptors[descriptor.name] = descriptor
            if preset:
                for slot_index, flag_id in enumerate(flag_ids):
                    flag_key = self._flag_key(pair[0], pair[1], flag_id)
                    self.flag_values[flag_key] = True
                    if ready_cycle is not None:
                        self.flag_cycles[flag_key] = float(ready_cycle)
                    self.event_log.append(
                        LocalEventRecord(
                            name=descriptor.name,
                            action="preset",
                            src_pipe=pair[0],
                            dst_pipe=pair[1],
                            flag_id=flag_id,
                            slot_index=slot_index,
                        )
                    )
                descriptor.set_count = len(flag_ids)
                self._condition.notify_all()
            return descriptor

    def descriptor(self, name: str) -> LocalEventDescriptor:
        with self._condition:
            descriptor = self.descriptors.get(str(name))
            if descriptor is None:
                raise KeyError("unknown local event: " + repr(name))
            return descriptor

    def _current_slot(self, descriptor: LocalEventDescriptor, counter_name: str) -> Tuple[int, int]:
        counter_value = int(getattr(descriptor, counter_name))
        slot_index = counter_value % len(descriptor.flag_ids)
        return slot_index, int(descriptor.flag_ids[slot_index])

    def current_set_target(self, name: str) -> Dict[str, Any]:
        with self._condition:
            descriptor = self.descriptor(name)
            slot_index, flag_id = self._current_slot(descriptor, "set_count")
            return self._event_info(descriptor, flag_id, slot_index)

    def current_wait_target(self, name: str) -> Dict[str, Any]:
        with self._condition:
            descriptor = self.descriptor(name)
            slot_index, flag_id = self._current_slot(descriptor, "wait_count")
            return self._event_info(descriptor, flag_id, slot_index)

    def _event_info(self, descriptor: LocalEventDescriptor, flag_id: int, slot_index: int) -> Dict[str, Any]:
        flag_key = self._flag_key(descriptor.src_pipe, descriptor.dst_pipe, flag_id)
        return {
            "event_name": descriptor.name,
            "event_kind": descriptor.event_kind,
            "src_pipe": descriptor.src_pipe,
            "dst_pipe": descriptor.dst_pipe,
            "flag_id": int(flag_id),
            "slot_index": int(slot_index),
            "flag_value": bool(self.flag_values.get(flag_key, False)),
            "ready_cycle": self.flag_cycles.get(flag_key),
            "set_count": int(descriptor.set_count),
            "wait_count": int(descriptor.wait_count),
        }

    def set_event(self, name: str, ready_cycle: Optional[float] = None, set_all: bool = False) -> List[Dict[str, Any]]:
        with self._condition:
            descriptor = self.descriptor(name)
            infos: List[Dict[str, Any]] = []
            repeat_count = 2 if set_all else 1
            for _ in range(repeat_count):
                slot_index, flag_id = self._current_slot(descriptor, "set_count")
                flag_id = int(descriptor.flag_ids[slot_index])
                flag_key = self._flag_key(descriptor.src_pipe, descriptor.dst_pipe, flag_id)
                if bool(self.flag_values.get(flag_key, False)):
                    raise RuntimeError(
                        "event_set on already-set flag: "
                        + descriptor.name
                        + " src="
                        + descriptor.src_pipe
                        + " dst="
                        + descriptor.dst_pipe
                        + " flag_id="
                        + str(flag_id)
                    )
                info = self._event_info(descriptor, flag_id, slot_index)
                flag_key = self._flag_key(info["src_pipe"], info["dst_pipe"], info["flag_id"])
                self.flag_values[flag_key] = True
                if ready_cycle is not None:
                    self.flag_cycles[flag_key] = float(ready_cycle)
                self.event_log.append(
                    LocalEventRecord(
                        name=descriptor.name,
                        action="set",
                        src_pipe=info["src_pipe"],
                        dst_pipe=info["dst_pipe"],
                        flag_id=info["flag_id"],
                        slot_index=info["slot_index"],
                    )
                )
                descriptor.set_count += 1
                infos.append(self._event_info(descriptor, info["flag_id"], info["slot_index"]))
            self._condition.notify_all()
            return infos

    def wait_and_consume(self, name: str, timeout: Optional[float] = None) -> Optional[Dict[str, Any]]:
        deadline = None
        if timeout is not None:
            deadline = time.monotonic() + float(timeout)
        with self._condition:
            descriptor = self.descriptor(name)
            slot_index, flag_id = self._current_slot(descriptor, "wait_count")
            flag_key = self._flag_key(descriptor.src_pipe, descriptor.dst_pipe, flag_id)
            while not bool(self.flag_values.get(flag_key, False)):
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return None
                self._condition.wait(timeout=remaining)
            self.event_log.append(
                LocalEventRecord(
                    name=descriptor.name,
                    action="wait",
                    src_pipe=descriptor.src_pipe,
                    dst_pipe=descriptor.dst_pipe,
                    flag_id=flag_id,
                    slot_index=slot_index,
                )
            )
            self.flag_values[flag_key] = False
            descriptor.wait_count += 1
            self.event_log.append(
                LocalEventRecord(
                    name=descriptor.name,
                    action="consume",
                    src_pipe=descriptor.src_pipe,
                    dst_pipe=descriptor.dst_pipe,
                    flag_id=flag_id,
                    slot_index=slot_index,
                )
            )
            return self._event_info(descriptor, flag_id, slot_index)

    def pending_count(self, name: str) -> int:
        with self._condition:
            descriptor = self.descriptor(name)
            return max(int(descriptor.set_count) - int(descriptor.wait_count), 0)

    def timeout_diagnostic(self, name: str) -> Dict[str, Any]:
        with self._condition:
            descriptor = self.descriptors.get(str(name))
            if descriptor is None:
                return {"scope": "lane_local_event", "name": name, "error": "unknown_event"}
            slot_index, flag_id = self._current_slot(descriptor, "wait_count")
            flag_key = self._flag_key(descriptor.src_pipe, descriptor.dst_pipe, flag_id)
            return {
                "scope": "lane_local_event",
                "name": descriptor.name,
                "event_kind": descriptor.event_kind,
                "src_pipe": descriptor.src_pipe,
                "dst_pipe": descriptor.dst_pipe,
                "flag_id": flag_id,
                "slot_index": slot_index,
                "flag_value": bool(self.flag_values.get(flag_key, False)),
                "set_count": int(descriptor.set_count),
                "wait_count": int(descriptor.wait_count),
            }
