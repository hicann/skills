from __future__ import annotations

from dataclasses import dataclass, field
from queue import Empty, Queue
from typing import Any, Optional, Union

from ..program.task import PipeTask

# Sentinel value to signal workers to stop.
_STOP = "stop"


@dataclass
class MailboxMessage:
    """Envelope for worker communication (kept for backward compat)."""

    kind: str
    payload: Any = None


@dataclass
class Mailbox:
    """Thread-friendly mailbox for pipe task delivery."""

    maxsize: int = 0
    _queue: Queue = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self._queue = Queue(maxsize=self.maxsize)

    def put(self, message: Union[PipeTask, str, MailboxMessage]) -> None:
        self._queue.put(message)

    def put_stop(self) -> None:
        self._queue.put(_STOP)

    def get(self, block: bool = False, timeout: Optional[float] = None) -> Optional[Union[PipeTask, str, MailboxMessage]]:
        try:
            if timeout is None:
                return self._queue.get(block=block)
            return self._queue.get(block=block, timeout=timeout)
        except Empty:
            return None

    def qsize(self) -> int:
        return int(self._queue.qsize())
