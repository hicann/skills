# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

from .events import SyncEvent, SyncEventType


@dataclass
class LocalFlagTable:
    """Per-lane phase-based flag table."""

    phases: Dict[str, int] = field(default_factory=dict)
    consumed: Dict[str, int] = field(default_factory=dict)
    phase_cycles: Dict[Tuple[str, int], float] = field(default_factory=dict)
    event_log: List[SyncEvent] = field(default_factory=list)
    _condition: threading.Condition = field(
        default_factory=threading.Condition,
        init=False,
        repr=False,
    )

    def publish(self, name: str, ready_cycle: Optional[float] = None) -> int:
        with self._condition:
            phase = self.phases.get(name, 0) + 1
            self.phases[name] = phase
            if ready_cycle is not None:
                self.phase_cycles[(str(name), int(phase))] = float(ready_cycle)
            self.event_log.append(
                SyncEvent(name=name, event_type=SyncEventType.READY, scope="lane_local", phase=phase)
            )
            self._condition.notify_all()
            return phase

    def current(self, name: str) -> int:
        with self._condition:
            return self.phases.get(name, 0)

    def consumed_phase(self, name: str) -> int:
        with self._condition:
            return self.consumed.get(name, 0)

    def phase_cycle(self, name: str, phase: int) -> Optional[float]:
        with self._condition:
            return self.phase_cycles.get((str(name), int(phase)))

    def can_wait(self, name: str, phase: int) -> bool:
        with self._condition:
            return self.phases.get(name, 0) >= phase

    def wait_for(self, name: str, phase: int, timeout: Optional[float] = None) -> bool:
        deadline = None
        if timeout is not None:
            deadline = time.monotonic() + float(timeout)
        with self._condition:
            while self.phases.get(name, 0) < phase:
                remaining = None
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                self._condition.wait(timeout=remaining)
            self.event_log.append(
                SyncEvent(name=name, event_type=SyncEventType.WAIT, scope="lane_local", phase=phase)
            )
            return True

    def consume(self, name: str, phase: int) -> bool:
        with self._condition:
            if self.phases.get(name, 0) < phase:
                return False
            self.consumed[name] = max(self.consumed.get(name, 0), phase)
            self.event_log.append(
                SyncEvent(name=name, event_type=SyncEventType.RELEASE, scope="lane_local", phase=phase)
            )
            return True

    def snapshot(self) -> Dict[str, Dict[str, int]]:
        with self._condition:
            return {
                "phases": dict(self.phases),
                "consumed": dict(self.consumed),
                "phase_cycles": dict(self.phase_cycles),
            }

    def timeout_diagnostic(self, name: str, phase: int) -> Dict[str, Any]:
        snapshot = self.snapshot()
        return {
            "scope": "lane_local",
            "name": name,
            "target_phase": phase,
            "current_phase": snapshot["phases"].get(name, 0),
            "consumed_phase": snapshot["consumed"].get(name, 0),
        }
