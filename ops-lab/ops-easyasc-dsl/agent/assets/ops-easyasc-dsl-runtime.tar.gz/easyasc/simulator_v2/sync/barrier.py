from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class BarrierState:
    """Barrier phase marker."""

    name: str
    phase: int = 0

