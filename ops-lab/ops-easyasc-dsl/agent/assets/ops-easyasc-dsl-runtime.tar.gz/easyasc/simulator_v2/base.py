from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .config import SimulatorV2Config
from .program.kernel_program import KernelProgram
from .program.planner import ProgramPlanner
from .runtime.global_runtime import GlobalRuntime


@dataclass
class SimulatorV2Base:
    """High-level entry point for the V2 simulator scaffold."""

    config: SimulatorV2Config
    planner: ProgramPlanner
    runtime: Optional[GlobalRuntime] = None

    def build_runtime(self, program: KernelProgram) -> GlobalRuntime:
        self.runtime = GlobalRuntime(self.config, program)
        return self.runtime

    def run(self, program: KernelProgram) -> None:
        runtime = self.runtime or self.build_runtime(program)
        runtime.run()

