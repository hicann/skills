# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from typing import Optional

from .base import SimulatorV2Base
from .config import SimulatorV2Config
from .program.planner import ProgramPlanner


def build_simulator_v2(config: Optional[SimulatorV2Config] = None) -> SimulatorV2Base:
    """Create a minimal V2 simulator facade."""

    if config is None:
        config = SimulatorV2Config()
    return SimulatorV2Base(config=config, planner=ProgramPlanner(config))

