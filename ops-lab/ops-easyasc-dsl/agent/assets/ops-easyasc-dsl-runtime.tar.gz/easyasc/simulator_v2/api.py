from __future__ import annotations

from typing import Optional

from .base import SimulatorV2Base
from .config import SimulatorV2Config
from .program.planner import ProgramPlanner


def build_simulator_v2(config: Optional[SimulatorV2Config] = None) -> SimulatorV2Base:
    """Create a minimal V2 simulator facade."""

    if config is None:
        config = SimulatorV2Config()
    return SimulatorV2Base(config=config, planner=ProgramPlanner(config))

