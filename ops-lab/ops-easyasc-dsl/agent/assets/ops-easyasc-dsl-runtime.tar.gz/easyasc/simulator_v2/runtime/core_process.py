# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import multiprocessing
import queue
import sys
import time
import traceback
from typing import Any, Dict, List, Optional

from ..config import SimulatorV2Config
from ..memory.shared_tensor_store import SharedTensorStore
from ..program.kernel_program import KernelProgram
from ..sync.collective_sync import CollectiveSync
from .core_runtime import CoreRuntime, CoreRuntimeState
from .execution_plan import ExecutionPlan


class CoreProcessState(Enum):
    IDLE = "idle"
    RUNNING = "running"
    STOPPED = "stopped"
    FAILED = "failed"


def _configure_child_runtime(config: SimulatorV2Config) -> None:
    try:
        import torch
    except ImportError:
        return
    try:
        torch.set_num_threads(int(config.torch_num_threads))
    except Exception as exc:
        import warnings
        warnings.warn("simulator_v2: failed to set torch num_threads: " + str(exc), stacklevel=2)
    if hasattr(torch, "set_num_interop_threads"):
        try:
            torch.set_num_interop_threads(1)
        except Exception as exc:
            import warnings
            warnings.warn("simulator_v2: failed to set torch interop_threads: " + str(exc), stacklevel=2)


def _runtime_result(
    core_idx: int,
    runtime: Optional[CoreRuntime],
    state: CoreProcessState,
    failure: str = "",
    execution_plan: Optional[ExecutionPlan] = None,
) -> Dict[str, Any]:
    if runtime is None:
        return {
            "core_idx": core_idx,
            "state": state.value,
            "failure": failure,
            "completed_tasks": 0,
            "lane_names": [],
            "shared_tensor_ids": [],
            "workspace_tensor_ids": [],
            "trace_buffer": [],
            "execution_plan": execution_plan.to_dict() if execution_plan is not None else {},
        }
    return {
        "core_idx": core_idx,
        "state": state.value,
        "failure": failure,
        "completed_tasks": runtime.completed_task_count(),
        "lane_names": runtime.lane_names(),
        "shared_tensor_ids": runtime.shared_tensor_ids(),
        "workspace_tensor_ids": runtime.workspace_tensor_ids(),
        "trace_buffer": [event.to_dict() for event in runtime.trace_events()],
        "execution_plan": runtime.execution_plan_dict(),
    }


def _build_tensor_store(snapshot: Optional[Dict[str, Any]]) -> SharedTensorStore:
    store = SharedTensorStore(auto_allocate=False)
    if snapshot:
        store.load_snapshot(snapshot)
    return store


def _build_collective_sync(snapshot: Optional[Dict[str, Any]]) -> CollectiveSync:
    sync = CollectiveSync()
    if snapshot:
        sync.load_shared_snapshot(snapshot)
    return sync


def _core_process_entry(
    core_idx: int,
    config: SimulatorV2Config,
    program: KernelProgram,
    execution_plan: Optional[ExecutionPlan],
    tensor_snapshot: Optional[Dict[str, Any]],
    collective_snapshot: Optional[Dict[str, Any]],
    status_conn: Any,
    device_type: str = "",
    trace_event: bool = False,
) -> None:
    runtime: Optional[CoreRuntime] = None
    try:
        # Detach from the parent's resource-tracker so child shm
        # registrations do not leak into the parent's tracker daemon.
        try:
            from multiprocessing import resource_tracker as _child_rt
            _child_rt._resource_tracker._fd = None
            _child_rt._resource_tracker._pid = None
        except Exception:
            pass
        from ... import globvars
        globvars.trace_event = bool(trace_event)
        if device_type:
            globvars.device_type = device_type
        _configure_child_runtime(config)
        runtime = CoreRuntime(
            core_idx=core_idx,
            config=config,
            program=program,
            tensor_store=_build_tensor_store(tensor_snapshot),
            collective_sync=_build_collective_sync(collective_snapshot),
            execution_plan=execution_plan,
        )
        runtime.start()
        runtime.join()
        status_conn.send(
            _runtime_result(
                core_idx,
                runtime,
                CoreProcessState.STOPPED,
                execution_plan=execution_plan,
            )
        )
    except BaseException:
        status_conn.send(
            _runtime_result(
                core_idx,
                runtime,
                CoreProcessState.FAILED,
                failure=traceback.format_exc(),
                execution_plan=execution_plan,
            )
        )
    finally:
        if runtime is not None and runtime.state != CoreRuntimeState.STOPPED:
            runtime.terminate()
        if runtime is not None:
            runtime.tensor_store.clear()
        try:
            status_conn.close()
        except Exception:
            pass


@dataclass
class CoreProcess:
    """Process wrapper for one simulated core."""

    core_idx: int
    config: SimulatorV2Config
    program: KernelProgram
    execution_plan: Optional[ExecutionPlan] = None
    tensor_snapshot: Dict[str, Any] = field(default_factory=dict)
    collective_snapshot: Dict[str, Any] = field(default_factory=dict)
    collective_sync: Optional[CollectiveSync] = None
    state: CoreProcessState = CoreProcessState.IDLE
    failure: Optional[str] = None
    result: Dict[str, Any] = field(default_factory=dict, init=False)
    _process: Optional[Any] = field(default=None, init=False, repr=False)
    _status_conn: Optional[Any] = field(default=None, init=False, repr=False)

    def _resolve_context(self) -> Any:
        method = self.config.process_start_method
        if method == "auto":
            available = multiprocessing.get_all_start_methods()
            preferred = ["fork", "spawn"]
            if sys.platform == "darwin":
                preferred = ["spawn", "forkserver", "fork"]
            for candidate in preferred:
                if candidate in available:
                    method = candidate
                    break
            else:
                method = multiprocessing.get_start_method()
        try:
            return multiprocessing.get_context(method)
        except ValueError:
            return multiprocessing.get_context()

    def start(self) -> None:
        from ... import globvars
        self.failure = None
        self.result = {}
        if self._status_conn is not None:
            try:
                self._status_conn.close()
            except Exception:
                pass
            self._status_conn = None
        ctx = self._resolve_context()
        parent_conn, child_conn = ctx.Pipe(duplex=False)
        self._status_conn = parent_conn
        self._process = ctx.Process(
            target=_core_process_entry,
            args=(
                self.core_idx,
                self.config,
                self.program,
                self.execution_plan,
                self.tensor_snapshot,
                self.collective_snapshot,
                child_conn,
                str(getattr(globvars, "device_type", "")),
                bool(getattr(globvars, "trace_event", False)),
            ),
            daemon=False,
        )
        self._process.start()
        child_conn.close()
        self.state = CoreProcessState.RUNNING

    def _consume_status(self) -> None:
        if self._status_conn is None:
            return
        latest: Optional[Dict[str, Any]] = None
        while True:
            try:
                if not self._status_conn.poll():
                    break
                latest = self._status_conn.recv()
            except (EOFError, OSError, queue.Empty):
                break
        if latest is None:
            return
        self.result = dict(latest)
        state_value = str(latest.get("state", CoreProcessState.STOPPED.value))
        try:
            self.state = CoreProcessState(state_value)
        except ValueError:
            self.state = CoreProcessState.FAILED
        failure = latest.get("failure", "")
        if isinstance(failure, str) and failure != "":
            self.failure = failure

    def join(self, timeout: Optional[float] = None) -> None:
        if self._process is None:
            return
        poll_interval = 0.01
        if timeout is not None and timeout <= 0.0:
            self._consume_status()
            self._process.join(timeout=0.0)
            self._consume_status()
            if self._process.is_alive():
                return
        else:
            deadline = None if timeout is None else time.monotonic() + timeout
            while True:
                self._consume_status()
                remaining = None if deadline is None else max(deadline - time.monotonic(), 0.0)
                if remaining is not None and remaining <= 0.0:
                    return
                join_timeout = poll_interval if remaining is None else min(poll_interval, remaining)
                self._process.join(timeout=join_timeout)
                self._consume_status()
                if not self._process.is_alive():
                    break
        if self.state == CoreProcessState.RUNNING:
            exitcode = self._process.exitcode
            if exitcode not in (0, None):
                self.state = CoreProcessState.FAILED
                if not self.failure:
                    self.failure = "child process exited with code " + str(exitcode)
            else:
                self.state = CoreProcessState.STOPPED
        if not self.result:
            self.result = {
                "core_idx": self.core_idx,
                "state": self.state.value,
                "failure": self.failure or "",
                "completed_tasks": 0,
                "lane_names": [],
                "shared_tensor_ids": [],
                "workspace_tensor_ids": [],
                "trace_buffer": [],
                "execution_plan": self.execution_plan_dict(),
            }
        else:
            self.result["state"] = self.state.value
            self.result["failure"] = self.failure or ""
        if self._status_conn is not None:
            try:
                self._status_conn.close()
            except Exception:
                pass
            self._status_conn = None

    def terminate(self) -> None:
        if self._process is None:
            return
        if self._process.is_alive():
            self._process.terminate()
            self._process.join()
        self._consume_status()
        if self._status_conn is not None:
            try:
                self._status_conn.close()
            except Exception:
                pass
            self._status_conn = None
        self.state = CoreProcessState.STOPPED
        if not self.result:
            self.result = {
                "core_idx": self.core_idx,
                "state": self.state.value,
                "failure": self.failure or "",
                "completed_tasks": 0,
                "lane_names": [],
                "shared_tensor_ids": [],
                "workspace_tensor_ids": [],
                "trace_buffer": [],
                "execution_plan": self.execution_plan_dict(),
            }
        else:
            self.result["state"] = self.state.value
            self.result["failure"] = self.failure or ""

    def summary(self) -> Dict[str, Any]:
        return {
            "core_idx": self.core_idx,
            "state": self.state.value,
            "failure": self.failure or "",
            "completed_tasks": self.completed_task_count(),
            "lane_names": self.lane_names(),
            "shared_tensor_ids": self.shared_tensor_ids(),
            "workspace_tensor_ids": self.workspace_tensor_ids(),
            "launch_mode": "process",
            "trace_event_count": len(self.trace_buffer()),
            "execution_plan": self.execution_plan_dict(),
        }

    def completed_task_count(self) -> int:
        value = self.result.get("completed_tasks", 0)
        return int(value)

    def lane_names(self) -> List[str]:
        value = self.result.get("lane_names", [])
        if not isinstance(value, list):
            return []
        return [str(item) for item in value]

    def shared_tensor_ids(self) -> List[str]:
        value = self.result.get("shared_tensor_ids", [])
        if not isinstance(value, list):
            return []
        return sorted(str(item) for item in value)

    def workspace_tensor_ids(self) -> List[str]:
        value = self.result.get("workspace_tensor_ids", [])
        if not isinstance(value, list):
            return []
        return sorted(str(item) for item in value)

    def trace_buffer(self) -> List[Dict[str, Any]]:
        value = self.result.get("trace_buffer", [])
        if not isinstance(value, list):
            return []
        return [dict(item) for item in value if isinstance(item, dict)]

    def execution_plan_dict(self) -> Dict[str, Any]:
        value = self.result.get("execution_plan", {})
        if isinstance(value, dict):
            return dict(value)
        if self.execution_plan is None:
            return {}
        return self.execution_plan.to_dict()
