from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from ... import globvars
from ..helpers import resolve_simulator_core_num
from ..config import SimulatorV2Config
from ..program.kernel_program import KernelProgram


_ALLCUBE_OPS = frozenset(["allcube_ready", "allcube_wait"])
_ALLVEC_OPS = frozenset(["allvec_ready", "allvec_wait"])


def _lane_task_counts(program: KernelProgram) -> Dict[str, int]:
    counts = {}
    for lane_program in program.lane_programs:
        counts[lane_program.lane_name] = lane_program.task_count()
    return counts


def _lane_has_work(program: KernelProgram) -> Dict[str, bool]:
    """Return True for each lane that has tasks or control instructions."""
    result = {}
    for lane_program in program.lane_programs:
        result[lane_program.lane_name] = (
            lane_program.task_count() > 0 or lane_program.has_instructions()
        )
    return result


def resolve_target_core_count(program: KernelProgram, config: SimulatorV2Config) -> int:
    if isinstance(program.core_count, int) and program.core_count > 0:
        return int(program.core_count)
    if isinstance(config.core_count, int) and config.core_count > 0:
        return int(config.core_count)
    device_type = str(getattr(globvars, "device_type", "")).lower()
    core_num = getattr(globvars, "core_num", None)
    return resolve_simulator_core_num(core_num, device_type)


@dataclass(frozen=True)
class ExecutionPlan:
    """Resolved runtime activation plan for one V2 program."""

    core_count: int
    lane_names: List[str] = field(default_factory=list)
    active_lane_names: List[str] = field(default_factory=list)
    skipped_lane_names: List[str] = field(default_factory=list)
    lane_task_counts: Dict[str, int] = field(default_factory=dict)
    run_cube: bool = False
    run_vec: bool = False
    uses_allcube: bool = False
    uses_allvec: bool = False
    cube_core_count: int = 0
    vec_lane_count: int = 0

    def to_dict(self) -> Dict[str, object]:
        return {
            "core_count": self.core_count,
            "lane_names": list(self.lane_names),
            "active_lane_names": list(self.active_lane_names),
            "skipped_lane_names": list(self.skipped_lane_names),
            "lane_task_counts": dict(self.lane_task_counts),
            "run_cube": self.run_cube,
            "run_vec": self.run_vec,
            "uses_allcube": self.uses_allcube,
            "uses_allvec": self.uses_allvec,
            "cube_core_count": self.cube_core_count,
            "vec_lane_count": self.vec_lane_count,
        }


def build_execution_plan(program: KernelProgram, config: SimulatorV2Config) -> ExecutionPlan:
    lane_names = [lane_program.lane_name for lane_program in program.lane_programs]
    lane_task_counts = _lane_task_counts(program)
    lane_work = _lane_has_work(program)
    vec_lane_names = [name for name in lane_names if name.startswith("vec")]
    uses_allcube = False
    uses_allvec = False
    for lane_program in program.lane_programs:
        for task in lane_program.tasks:
            if task.opname in _ALLCUBE_OPS:
                uses_allcube = True
            if task.opname in _ALLVEC_OPS:
                uses_allvec = True
        # Also check ControlInstructions for collective ops
        for ci in lane_program.instructions:
            if ci.opname in _ALLCUBE_OPS:
                uses_allcube = True
            if ci.opname in _ALLVEC_OPS:
                uses_allvec = True
    run_cube = "cube" in lane_names and (
        lane_work.get("cube", False) or uses_allcube
    )
    has_vec_work = any(lane_work.get(name, False) for name in vec_lane_names)
    run_vec = bool(vec_lane_names) and (has_vec_work or uses_allvec)
    if uses_allcube and not uses_allvec and run_cube and not has_vec_work:
        run_vec = False

    active_lane_names = []
    if run_cube and "cube" in lane_names:
        active_lane_names.append("cube")
    if run_vec:
        if uses_allvec:
            active_lane_names.extend(vec_lane_names)
        else:
            active_lane_names.extend(
                [name for name in vec_lane_names if lane_work.get(name, False)]
            )
    skipped_lane_names = [name for name in lane_names if name not in active_lane_names]
    core_count = resolve_target_core_count(program, config)
    return ExecutionPlan(
        core_count=core_count,
        lane_names=lane_names,
        active_lane_names=active_lane_names,
        skipped_lane_names=skipped_lane_names,
        lane_task_counts=lane_task_counts,
        run_cube=run_cube,
        run_vec=run_vec,
        uses_allcube=uses_allcube,
        uses_allvec=uses_allvec,
        cube_core_count=core_count,
        vec_lane_count=core_count * len(vec_lane_names),
    )
