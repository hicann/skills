# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

import math
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from ... import globvars
from ..config import SimulatorV2Config
from ..memory.shared_tensor import SharedTensorSpec, torch_dtype_from_shared_name
from ..memory.shared_tensor_store import SharedTensorStore
from ..program.control_instruction import ControlInstruction
from ..program.kernel_program import KernelProgram
from ..program.lane_program import LaneProgram
from ..program.task import PipeTask, TaskStatus
from ..sync.collective_sync import CollectiveSync
from ..sync.intra_core_sync import IntraCoreSync
from ..sync.local_events import LocalEventBank
from ..sync.local_flags import LocalFlagTable
from ..sync.mailbox import Mailbox
from ..timing import estimate_task_cycles
from ..trace.event_types import TraceEventKind
from ..trace.recorder import TraceRecorderV2
from .pipe_worker import PipeWorker


class _BreakSignal(BaseException):
    pass


class _ContinueSignal(BaseException):
    pass


# Opnames that are handled as variable / scalar operations inside the actor.
_VAR_OPS = frozenset([
    "create_var", "create_varlist", "var_add", "var_sub", "var_mul", "var_div", "var_mod",
    "var_assign", "scalar_sqrt",
    "CeilDiv", "Min", "Max",
    "Align8", "Align16", "Align32", "Align64", "Align128", "Align256",
    "GetCubeNum", "GetCubeIdx", "GetVecNum", "GetVecIdx", "GetSubBlockIdx",
])

# Opnames that are control-flow or sync markers and need no pipe dispatch.
_CONTROL_NOOP_OPS = frozenset([
    "reset_cache", "inline", "start_auto_sync", "end_auto_sync",
    "set_atomic_type", "atomic_add", "atomic_max", "atomic_min", "atomic_end",
    "clean_dcache", "kernel_print", "kernel_dump_tensor",
])
_ATOMIC_PIPE_OPS = frozenset(["l0c_to_gm_nz2nd", "ub_to_gm_pad"])
_EVENT_SYNC_OPS = frozenset([
    "create_sevent", "create_devent", "event_wait", "event_set", "event_setall", "event_release",
])
_TRACEABLE_SYNC_OPS = frozenset([
    "event_wait", "event_set", "event_setall", "event_release",
    "setflag", "waitflag",
    "cube_ready", "vec_ready", "wait_cube", "wait_vec",
    "allcube_ready", "allcube_wait", "allvec_ready", "allvec_wait",
])

_LOCAL_TENSOR_ROLES = frozenset(["ub", "l1", "l0a", "l0b", "l0c"])
_VARLIST_REF_RE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\[(.+)\]$")


def _align_to(value: int, align: int) -> int:
    return ((int(value) + align - 1) // align) * align


def _should_trace_sync_op(name: str) -> bool:
    if str(name) not in _TRACEABLE_SYNC_OPS:
        return True
    return bool(getattr(globvars, "trace_event", False))


@dataclass
class ControlActor:
    """Lane-level control interpreter with full control flow support."""

    core_idx: int
    lane_name: str
    program: KernelProgram
    config: SimulatorV2Config = field(default_factory=SimulatorV2Config)
    sync: IntraCoreSync = field(default_factory=IntraCoreSync)
    collective_sync: CollectiveSync = field(default_factory=CollectiveSync)
    local_flags: LocalFlagTable = field(default_factory=LocalFlagTable)
    local_events: LocalEventBank = field(default_factory=LocalEventBank)
    trace_recorder: Optional[TraceRecorderV2] = None
    pipe_names: List[str] = field(default_factory=list)
    pipe_workers: Dict[str, PipeWorker] = field(default_factory=dict)
    worker_mailboxes: Dict[str, Mailbox] = field(default_factory=dict)
    mailbox: Mailbox = field(default_factory=Mailbox)
    tensor_store: Optional[SharedTensorStore] = None
    # Topology info (set during build)
    core_count: int = 1
    vec_count: int = 2
    sub_block_idx: int = 0
    # Runtime state
    running: bool = field(default=False, init=False)
    dispatched_tasks: int = field(default=0, init=False)
    submitted_tasks: List[PipeTask] = field(default_factory=list, init=False)
    var_values: Dict[str, Any] = field(default_factory=dict, init=False)
    active_atomic_mode: Optional[str] = field(default=None, init=False)
    active_atomic_dtype: Optional[str] = field(default=None, init=False)
    lane_local_tensor_names: Dict[str, str] = field(default_factory=dict, init=False)
    completed_submit_count: int = field(default=0, init=False)
    has_explicit_event_sync: bool = field(default=False, init=False)
    varlist_lengths: Dict[str, int] = field(default_factory=dict, init=False)
    current_cycle: int = field(default=0, init=False)
    completed_cycle_max: int = field(default=0, init=False)
    control_block_until: int = field(default=0, init=False)
    sync_channel_cycles: Dict[Tuple[str, str], int] = field(default_factory=dict, init=False)
    cycle_model: Optional[object] = field(default=None, init=False, repr=False)
    tensor_busy_until: Dict[str, int] = field(default_factory=dict, init=False)
    completed_cycle_by_pipe: Dict[str, int] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        if not self.pipe_names:
            self.pipe_names = self.program.get_pipe_names(self.lane_name)
        if self.core_count <= 0:
            self.core_count = max(1, int(self.program.core_count))
        self._mixed_lane = self._detect_mixed_lane()
        self._ub_tensor_names = self._collect_ub_tensor_names()
        self.lane_local_tensor_names = self._build_lane_local_tensor_map()
        self.has_explicit_event_sync = any(
            inst.opname in _EVENT_SYNC_OPS for inst in self.lane_program().instructions
        )
        for worker in self.pipe_workers.values():
            if getattr(worker, "cycle_model", None) is not None:
                self.cycle_model = worker.cycle_model
                break

    def lane_program(self) -> LaneProgram:
        return self.program.get_lane_program(self.lane_name)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        self.running = True
        self.current_cycle = 0
        self.completed_cycle_max = 0
        self.control_block_until = 0
        self.sync_channel_cycles = {}
        self.submitted_tasks = []
        self.var_values = {}
        self.varlist_lengths = {}
        self.active_atomic_mode = None
        self.active_atomic_dtype = None
        self.completed_submit_count = 0
        self.tensor_busy_until = {}
        self.completed_cycle_by_pipe = {}
        self._ensure_lane_local_tensors()

        lp = self.lane_program()
        if lp.has_instructions():
            self._execute_instructions(lp.instructions)
        else:
            self._execute_flat_tasks(lp.tasks)

    def _execute_flat_tasks(self, tasks: List[PipeTask]) -> None:
        """Legacy path: dispatch pre-built PipeTasks linearly."""
        for task in tasks:
            runtime_task = PipeTask(
                pipe_name=task.pipe_name,
                opname=task.opname,
                args=self._resolve_pipe_args(task.args),
            )
            self.submit_task(runtime_task)
            self.submitted_tasks.append(runtime_task)
            self._trace_dispatch(runtime_task)
            self._maybe_enforce_program_order()
        self.dispatched_tasks = len(tasks)

    def join(self) -> None:
        return None

    def terminate(self) -> None:
        self.running = False

    def _record_sync_event(
        self,
        name: str,
        trace_phase: str,
        ts: float,
        dur: float = 0.0,
        pipe_name: str = "S",
        extra_args: Optional[Dict[str, Any]] = None,
    ) -> None:
        if self.trace_recorder is None:
            return
        if not _should_trace_sync_op(name):
            return
        payload = {
            "lane_name": self.lane_name,
            "pipe_name": pipe_name,
            "trace_phase": trace_phase,
        }
        if self.cycle_model is not None:
            payload["time_domain"] = getattr(self.cycle_model, "time_domain", "cycle")
        if extra_args:
            payload.update(extra_args)
        self.trace_recorder.record_event(
            TraceEventKind.SYNC,
            name,
            dur=max(float(dur), 0.0),
            args=payload,
            ts=ts,
        )

    def has_cycle_model(self) -> bool:
        return self.cycle_model is not None

    def _cycle_time_args(self) -> Dict[str, object]:
        if self.cycle_model is None:
            return {}
        return {
            "time_domain": getattr(self.cycle_model, "time_domain", "cycle"),
            "cycle_model_profile": getattr(self.cycle_model, "profile_name", "cycle_model"),
        }

    def _sync_channel_key(self, domain: str, name: str) -> Tuple[str, str]:
        return (str(domain), str(name))

    def _sync_channel_cycle(self, domain: str, name: str) -> int:
        return int(self.sync_channel_cycles.get(self._sync_channel_key(domain, name), 0))

    def _set_sync_channel_cycle(self, domain: str, name: str, cycle: int) -> None:
        key = self._sync_channel_key(domain, name)
        self.sync_channel_cycles[key] = max(int(cycle), int(self.sync_channel_cycles.get(key, 0)))

    @staticmethod
    def _event_channel_name(src_pipe: str, dst_pipe: str, flag_id: int) -> str:
        return "event:" + str(src_pipe) + "->" + str(dst_pipe) + ":" + str(int(flag_id))

    def max_cycle(self) -> int:
        max_sync_cycle = max(self.sync_channel_cycles.values()) if self.sync_channel_cycles else 0
        return max(int(self.current_cycle), int(self.completed_cycle_max), int(max_sync_cycle))

    def _completed_cycle_for_pipe(self, pipe_name: str) -> int:
        return int(self.completed_cycle_by_pipe.get(str(pipe_name), 0))

    def _mark_task_completion_cycle(self, task: PipeTask, advance_control: bool = True) -> None:
        if self.cycle_model is None:
            return
        end_cycle = int(getattr(task, "end_cycle", 0.0))
        self.completed_cycle_max = max(self.completed_cycle_max, end_cycle)
        self.completed_cycle_by_pipe[str(task.pipe_name)] = max(
            self.completed_cycle_by_pipe.get(str(task.pipe_name), 0),
            end_cycle,
        )
        if advance_control:
            self.current_cycle = max(self.current_cycle, end_cycle)

    # ------------------------------------------------------------------
    # Task submission
    # ------------------------------------------------------------------

    def submit_task(self, task: PipeTask) -> None:
        if not isinstance(task, PipeTask):
            raise TypeError("submit_task requires PipeTask, got: " + str(type(task)))
        earliest_cycle = float(max(getattr(task, "earliest_start_cycle", 0.0), self.current_cycle))
        if self.cycle_model is not None:
            for tensor_name in self._task_tensor_names(task):
                earliest_cycle = max(earliest_cycle, float(self.tensor_busy_until.get(tensor_name, 0)))
            task.earliest_start_cycle = earliest_cycle
            estimate = estimate_task_cycles(task, self.tensor_store, self.cycle_model)
            predicted_end = int(task.earliest_start_cycle) + int(estimate.cycles)
            for tensor_name in self._task_tensor_names(task):
                self.tensor_busy_until[tensor_name] = max(self.tensor_busy_until.get(tensor_name, 0), predicted_end)
        else:
            task.earliest_start_cycle = earliest_cycle
        worker_mailbox = self.worker_mailboxes.get(task.pipe_name)
        if worker_mailbox is None:
            raise KeyError(
                "lane " + self.lane_name + " has no mailbox for pipe " + repr(task.pipe_name)
            )
        worker_mailbox.put(task)

    @staticmethod
    def _task_tensor_names(task: PipeTask) -> List[str]:
        names: List[str] = []
        for key in ("dst", "src", "src_a", "src_b", "src1", "src2", "selmask", "offset", "idx", "tensor", "dst_vec0", "dst_vec1"):
            value = task.args.get(key)
            if isinstance(value, str) and value != "":
                names.append(value)
        tensor_view_names = task.args.get("tensor_view_names", {})
        if isinstance(tensor_view_names, dict):
            for value in tensor_view_names.values():
                if isinstance(value, str) and value != "":
                    names.append(value)
        deduped: List[str] = []
        seen = set()
        for name in names:
            if name in seen:
                continue
            seen.add(name)
            deduped.append(name)
        return deduped

    def _detect_mixed_lane(self) -> bool:
        """True when the kernel has both cube and vec lanes with instructions."""
        try:
            cube_lp = self.program.get_lane_program("cube")
            vec0_lp = self.program.get_lane_program("vec0")
            return cube_lp.has_instructions() and vec0_lp.has_instructions()
        except KeyError:
            return False

    def _collect_ub_tensor_names(self) -> frozenset:
        """Collect logical names of UB-position tensors from program metadata."""
        metadata = getattr(self.program, "metadata", None)
        if not isinstance(metadata, dict):
            return frozenset()
        shared_tensors = metadata.get("shared_tensors")
        if not isinstance(shared_tensors, list):
            return frozenset()
        names = set()
        for item in shared_tensors:
            spec = SharedTensorSpec.from_any(item)
            if str(spec.role) == "ub":
                names.add(spec.name)
        return frozenset(names)

    def _scoped_local_tensor_name(self, name: str) -> str:
        if self._mixed_lane:
            if name in self._ub_tensor_names:
                # UB tensors are per-lane even in mixed-lane mode: each vec
                # subblock has its own UB half (l0c_to_ub SPLITM writes both).
                return "__local_c%d_%s__%s" % (int(self.core_idx), self.lane_name, name)
            # Non-UB local tensors (L1, L0C, etc.) are shared across lanes.
            return "__local_c%d__%s" % (int(self.core_idx), name)
        return "__local_c%d_%s__%s" % (int(self.core_idx), self.lane_name, name)

    def _build_lane_local_tensor_map(self) -> Dict[str, str]:
        metadata = getattr(self.program, "metadata", None)
        if not isinstance(metadata, dict):
            return {}
        shared_tensors = metadata.get("shared_tensors")
        if not isinstance(shared_tensors, list):
            return {}
        mapping = {}
        for item in shared_tensors:
            spec = SharedTensorSpec.from_any(item)
            if str(spec.role) not in _LOCAL_TENSOR_ROLES:
                continue
            # In mixed-lane mode, the cube lane does not own UB tensors.
            # l0c_to_ub writes directly to both vec lanes' UBs.
            if self._mixed_lane and self.lane_name == "cube" and str(spec.role) == "ub":
                continue
            mapping[spec.name] = self._scoped_local_tensor_name(spec.name)
        return mapping

    def _ensure_lane_local_tensors(self) -> None:
        if self.tensor_store is None or not self.lane_local_tensor_names:
            return
        metadata = getattr(self.program, "metadata", None)
        if not isinstance(metadata, dict):
            return
        shared_tensors = metadata.get("shared_tensors")
        if not isinstance(shared_tensors, list):
            return

        local_specs = []
        for item in shared_tensors:
            spec = SharedTensorSpec.from_any(item)
            if str(spec.role) in _LOCAL_TENSOR_ROLES:
                local_specs.append(spec)
        if not local_specs:
            return

        local_names = set(self.lane_local_tensor_names.keys())
        ordered_specs = []
        for spec in local_specs:
            if spec.source_name in (None, "", spec.name) or spec.source_name not in local_names:
                ordered_specs.append(spec)
        for spec in local_specs:
            if spec not in ordered_specs:
                ordered_specs.append(spec)

        for spec in ordered_specs:
            if spec.name not in self.lane_local_tensor_names:
                continue
            scoped_name = self.lane_local_tensor_names[spec.name]
            scoped_source = spec.source_name
            if scoped_source in self.lane_local_tensor_names:
                scoped_source = self.lane_local_tensor_names[scoped_source]
            scoped_spec = SharedTensorSpec(
                name=scoped_name,
                shape=spec.shape,
                dtype=spec.dtype,
                mutable=spec.mutable,
                role=spec.role,
                tags=spec.tags,
                storage_offset=spec.storage_offset,
                source_name=scoped_source,
                view_shape=spec.view_shape,
                view_strides=spec.view_strides,
            )
            self.tensor_store.register(scoped_spec)
            # Threaded worker mode must not race on first-use tensor allocation.
            self.tensor_store.tensor(scoped_name)

    # ------------------------------------------------------------------
    # Control flow interpreter
    # ------------------------------------------------------------------

    def _execute_instructions(self, instructions: List[ControlInstruction]) -> None:
        self._execute_block(instructions, 0, len(instructions))
        self.dispatched_tasks = len(self.submitted_tasks)

    def _execute_block(self, instructions: List[ControlInstruction], start: int, end: int) -> None:
        idx = start
        while idx < end:
            inst = instructions[idx]
            opname = inst.opname

            if opname == "break_loop":
                raise _BreakSignal()
            if opname == "continue_loop":
                raise _ContinueSignal()

            if opname == "start_loop":
                loop_end = self._find_loop_end(instructions, idx, end)
                self._execute_loop(instructions, idx, loop_end)
                idx = loop_end + 1
                continue

            if opname == "start_micro_loop":
                # Micro loops have same structure as regular loops
                loop_end = self._find_loop_end(instructions, idx, end)
                self._execute_loop(instructions, idx, loop_end)
                idx = loop_end + 1
                continue

            if opname == "end_loop":
                return

            if opname == "start_if":
                idx = self._execute_if_chain(instructions, idx, end)
                continue

            if opname in ("start_elif", "start_else", "end_if"):
                return

            # Scope instructions — enter/exit scope context
            if opname in ("enter_vec_scope", "end_vec_scope",
                          "enter_cube_scope", "end_cube_scope"):
                # Scopes are structural markers that affect which lane runs.
                # In V2, lane assignment is already done at program-build time.
                idx += 1
                continue

            self._execute_inst(inst)
            idx += 1

    def _execute_loop(self, instructions: List[ControlInstruction], start: int, loop_end: int) -> None:
        inst = instructions[start]
        args = inst.args
        var_name = str(args.get("var", args.get("var_name", "")))
        loop_start = self._resolve_int(args.get("start", 0), "loop start")
        loop_stop = self._resolve_int(args.get("stop", 0), "loop stop")
        loop_step = self._resolve_int(args.get("step", 1), "loop step")
        if loop_step == 0:
            raise ValueError("loop step cannot be zero")
        for value in range(loop_start, loop_stop, loop_step):
            if var_name:
                self.var_values[var_name] = value
            should_break = False
            try:
                self._execute_block(instructions, start + 1, loop_end)
            except _ContinueSignal:
                pass
            except _BreakSignal:
                should_break = True
            if should_break:
                break

    def _find_loop_end(self, instructions: List[ControlInstruction], start: int, end: int) -> int:
        depth = 1
        idx = start + 1
        while idx < end:
            opname = instructions[idx].opname
            if opname in ("start_loop", "start_micro_loop"):
                depth += 1
            elif opname == "end_loop":
                depth -= 1
                if depth == 0:
                    return idx
            idx += 1
        raise ValueError("start_loop at index " + str(start) + " without matching end_loop")

    def _find_if_end(self, instructions: List[ControlInstruction], start: int, end: int) -> int:
        depth = 1
        idx = start + 1
        while idx < end:
            opname = instructions[idx].opname
            if opname == "start_if":
                depth += 1
            elif opname == "end_if":
                depth -= 1
                if depth == 0:
                    return idx
            idx += 1
        raise ValueError("start_if at index " + str(start) + " without matching end_if")

    def _execute_if_chain(self, instructions: List[ControlInstruction], start: int, end: int) -> int:
        if_end = self._find_if_end(instructions, start, end)
        segments: List[Tuple[int, int, int]] = []
        seg_header = start
        seg_body_start = start + 1
        nested_if = 0
        nested_loop = 0
        idx = start + 1
        while idx < if_end:
            opname = instructions[idx].opname
            if opname in ("start_loop", "start_micro_loop"):
                nested_loop += 1
            elif opname == "end_loop":
                nested_loop -= 1
            elif opname == "start_if":
                nested_if += 1
            elif opname == "end_if":
                nested_if -= 1
            elif opname in ("start_elif", "start_else") and nested_if == 0 and nested_loop == 0:
                segments.append((seg_header, seg_body_start, idx))
                seg_header = idx
                seg_body_start = idx + 1
            idx += 1
        segments.append((seg_header, seg_body_start, if_end))

        for header_idx, body_start, body_end in segments:
            header = instructions[header_idx]
            if header.opname == "start_else":
                self._execute_block(instructions, body_start, body_end)
                break
            cond = header.args.get("cond")
            if self._resolve_bool(cond):
                self._execute_block(instructions, body_start, body_end)
                break
        return if_end + 1

    # ------------------------------------------------------------------
    # Single instruction handler
    # ------------------------------------------------------------------

    def _execute_inst(self, inst: ControlInstruction) -> None:
        opname = inst.opname
        if os.environ.get("SIMV2_DEBUG_TRACE"):
            import sys
            print("[%s] exec: %s pipe=%s args=%s" % (self.lane_name, opname, inst.pipe_name or "", {k: v for k, v in inst.args.items() if k in ("flag_id", "cond", "var_name")}), file=sys.stderr, flush=True)

        # Variable and scalar ops
        if opname in _VAR_OPS:
            self._execute_var_op(inst)
            return

        # Control/sync no-ops
        if opname in _CONTROL_NOOP_OPS:
            self._execute_control_noop(inst)
            return

        # Sync instructions
        if opname in _EVENT_SYNC_OPS:
            self._handle_local_event(inst)
            return
        if opname == "setflag":
            self._handle_setflag(inst)
            return
        if opname == "waitflag":
            self._handle_waitflag(inst)
            return
        if opname in ("cube_ready", "vec_ready", "wait_cube", "wait_vec"):
            self._handle_cross_lane_sync(inst)
            return
        if opname in ("allcube_ready", "allcube_wait", "allvec_ready", "allvec_wait"):
            self._handle_collective_sync(inst)
            return
        if opname == "barrier":
            pipe = str(inst.args.get("pipe", "ALL"))
            if pipe == "" or pipe == "ALL":
                self._complete_submitted_tasks()
            return

        # Tensor/memory declarations (tracked but no pipe dispatch)
        if opname in ("create_gm_tensor", "reshape_gm_tensor",
                       "create_tensor", "create_dbuf", "create_tbuf", "create_qbuf",
                       "reinterpret", "split_workspace"):
            # These are handled at program-build time by the bridge.
            # At runtime they are no-ops.
            return

        if opname == "get_buf":
            self._update_local_buf_alias(inst)
            return

        if opname == "slice_tensor":
            self._update_local_slice(inst)
            return

        if opname == "GetValueFrom":
            self._handle_get_value_from(inst)
            return

        if opname == "SetValueTo":
            self._handle_set_value_to(inst)
            return

        if opname == "sim_dump_tensor":
            self._execute_sim_dump_tensor(inst)
            return

        if opname == "sim_print":
            self._execute_sim_print(inst)
            return

        # Dynamic GM slice — update view offset at runtime
        if opname == "slice_gm_tensor":
            self._update_gm_slice(inst)
            return

        # call_micro — resolve bindings and submit as a V pipe task
        if opname == "call_micro":
            self._handle_call_micro(inst)
            return

        # l0c_to_ub in mixed-lane mode: write to both vec UBs
        if opname == "l0c_to_ub" and self._mixed_lane and self.lane_name == "cube":
            self._handle_l0c_to_ub_mixed(inst)
            return

        # Pipe operation — convert to PipeTask and submit
        if inst.is_pipe_op():
            task_args = self._resolve_pipe_args(inst.args)
            task_args = self._inject_atomic_state(opname, task_args)
            task = PipeTask(
                pipe_name=inst.pipe_name,
                opname=opname,
                args=task_args,
            )
            self.submit_task(task)
            self.submitted_tasks.append(task)
            self._trace_dispatch(task)
            self._maybe_enforce_program_order()
            return

        # Unknown instruction — if it has no pipe_name, treat as no-op with warning
        return

    # ------------------------------------------------------------------
    # Dynamic GM slice update
    # ------------------------------------------------------------------

    def _update_local_buf_alias(self, inst: ControlInstruction) -> None:
        args = inst.args
        view_name = str(args.get("view_name", ""))
        slot_names = args.get("slot_names", [])
        if not view_name or not isinstance(slot_names, list) or not slot_names:
            return
        idx = self._resolve_int(args.get("index", 0), "get_buf index")
        self.var_values[view_name] = slot_names[idx % len(slot_names)]

    def _update_gm_slice(self, inst: ControlInstruction) -> None:
        """Register a new ephemeral GM view with the current loop offsets.

        When a ``slice_gm_tensor`` appears inside a loop, its offset
        depends on loop variables (e.g. ``q_row``, ``n_offset``).  Each
        iteration resolves to a different region. If later pipe tasks
        still reference the same mutable view object, they could all observe
        the last loop-carried offset instead of their own snapshot.

        Instead, we create a unique view name for each (view_name, offset)
        combination.  The original view name is aliased via ``var_values``
        so that subsequent pipe ops use the snapshot name.
        """
        if self.tensor_store is None:
            return
        args = inst.args
        view_name = str(args.get("view_name", ""))
        source_name = str(args.get("source_name", ""))
        source_position = str(args.get("source_position", ""))
        ndim = int(self._try_resolve(args.get("ndim", 0)))
        if not view_name or not source_name or ndim <= 0:
            return
        # Resolve offsets, source dimensions, and spans
        offsets = []
        src_dims = []
        spans = []
        for i in range(ndim):
            offsets.append(int(self._try_resolve(args.get("offset_" + str(i), 0))))
            src_dims.append(int(self._try_resolve(args.get("src_dim_" + str(i), 1))))
            spans.append(int(self._try_resolve(args.get("span_" + str(i), 1))))
        # Compute flat storage offset: row-major linearization
        flat_offset = 0
        for i in range(ndim):
            stride = 1
            for j in range(i + 1, ndim):
                stride *= src_dims[j]
            flat_offset += offsets[i] * stride
        # Compute view numel: for strided access patterns (like NZ→ND
        # writeback), the view needs enough elements for the full stride.
        if ndim == 2 and spans[0] > 0:
            view_numel = (spans[0] - 1) * src_dims[1] + spans[1]
        else:
            view_numel = 1
            for sp in spans:
                view_numel *= max(sp, 0)
        # Create a unique snapshot name for this (view, offset) combination
        # so each pipe task refers to a frozen view.
        snapshot_name = view_name + "@" + str(flat_offset)
        from ..memory.shared_tensor import SharedTensorHandle, SharedTensorSpec
        if not self.tensor_store.contains(view_name):
            return
        old_handle = self.tensor_store.get(view_name)
        new_spec = SharedTensorSpec(
            name=snapshot_name,
            shape=(view_numel,),
            dtype=old_handle.spec.dtype,
            role=old_handle.spec.role,
            storage_offset=flat_offset,
            source_name=source_name,
        )
        new_handle = SharedTensorHandle(
            tensor_id=snapshot_name,
            spec=new_spec,
            runtime_name=snapshot_name,
        )
        self.tensor_store.tensors[snapshot_name] = new_handle
        # Alias: pipe ops that reference view_name will now get snapshot_name
        self.var_values[view_name] = snapshot_name

    def _update_local_slice(self, inst: ControlInstruction) -> None:
        if self.tensor_store is None:
            return
        args = inst.args
        view_name = str(args.get("view_name", ""))
        source_name = str(args.get("source_name", ""))
        source_position = str(args.get("source_position", ""))
        ndim = int(self._try_resolve(args.get("ndim", 0)))
        if not view_name or not source_name or ndim <= 0:
            return
        offsets = []
        spans = []
        steps = []
        src_dims = []
        for i in range(ndim):
            offsets.append(int(self._try_resolve(args.get("offset_" + str(i), 0))))
            spans.append(int(self._try_resolve(args.get("span_" + str(i), 0))))
            steps.append(int(self._try_resolve(args.get("step_" + str(i), 1))))
            src_dims.append(int(self._try_resolve(args.get("src_dim_" + str(i), 0))))
        if any(step != 1 for step in steps):
            raise ValueError("slice_tensor only supports step=1 in simulator_v2 runtime")

        resolved_source_name = self._try_resolve(source_name)
        if isinstance(resolved_source_name, str) and resolved_source_name in self.lane_local_tensor_names:
            resolved_source_name = self.lane_local_tensor_names[resolved_source_name]
        if not isinstance(resolved_source_name, str) or not self.tensor_store.contains(resolved_source_name):
            return

        source_handle = self.tensor_store.get(resolved_source_name)
        root_name = resolved_source_name
        # Root local tensors are allocated as standalone shared tensors in the
        # runtime store. Their spec.storage_offset is only for bank bookkeeping
        # and must not be re-applied as an element offset when materializing a
        # slice view. Only nested views carry a real logical base offset.
        base_offset = 0
        row_stride = src_dims[1] if ndim >= 2 and len(src_dims) > 1 else 1
        col_stride = 1
        if source_handle.spec.source_name:
            base_offset = int(source_handle.spec.storage_offset)
            if source_handle.spec.view_strides and len(source_handle.spec.view_strides) >= 2:
                root_name = str(source_handle.spec.source_name)
                row_stride = int(source_handle.spec.view_strides[0])
                col_stride = int(source_handle.spec.view_strides[1])
            elif source_handle.spec.view_shape and len(source_handle.spec.view_shape) >= 2:
                root_name = str(source_handle.spec.source_name)
                row_stride = int(source_handle.spec.view_shape[1])
                col_stride = 1
            else:
                root_name = str(source_handle.spec.source_name)
        root_handle = self.tensor_store.get(root_name)

        if ndim == 2:
            if source_position in ("UB", "Position.UB"):
                storage_offset = base_offset + offsets[0] * row_stride + offsets[1] * col_stride
            elif source_position in ("L1", "Position.L1", "L0A", "Position.L0A", "L0B", "Position.L0B", "L0C", "Position.L0C"):
                elem_size = int(self.tensor_store.tensor(root_name).element_size())
                c0 = 32 // max(elem_size, 1)
                if source_position in ("L0C", "Position.L0C"):
                    c0 = 16
                align_rows = ((max(src_dims[0], 0) + 15) // 16) * 16
                storage_offset = (
                    base_offset
                    + (offsets[1] // c0) * align_rows * c0
                    + offsets[0] * c0
                    + (offsets[1] % c0)
                )
            else:
                storage_offset = base_offset + offsets[0] * row_stride + offsets[1] * col_stride
            if str(source_handle.spec.role) == "ub":
                view_shape = [max(spans[0], 0), max(spans[1], 0)]
                view_strides = [row_stride, col_stride]
                view_numel = max(spans[0], 0) * max(spans[1], 0)
            else:
                view_shape = []
                view_strides = []
                view_numel = max(int(root_handle.spec.numel) - storage_offset, 0)
        else:
            storage_offset = base_offset + offsets[0]
            if str(source_handle.spec.role) == "ub":
                view_shape = [max(spans[0], 0)]
                view_strides = []
                view_numel = max(spans[0], 0)
            else:
                view_shape = []
                view_strides = []
                view_numel = max(int(root_handle.spec.numel) - storage_offset, 0)

        scoped_view_name = self.lane_local_tensor_names.get(view_name, view_name)
        snapshot_name = (
            scoped_view_name
            + "@off"
            + "_".join(str(v) for v in offsets)
            + "@span"
            + "_".join(str(v) for v in spans)
        )
        from ..memory.shared_tensor import SharedTensorHandle, SharedTensorSpec
        view_spec = SharedTensorSpec(
            name=snapshot_name,
            shape=(view_numel,),
            dtype=source_handle.spec.dtype,
            role=source_handle.spec.role,
            storage_offset=storage_offset,
            source_name=root_name,
            view_shape=view_shape,
            view_strides=view_strides,
        )
        new_handle = SharedTensorHandle(
            tensor_id=snapshot_name,
            spec=view_spec,
            runtime_name=snapshot_name,
        )
        self.tensor_store.tensors[snapshot_name] = new_handle
        self.var_values[view_name] = snapshot_name

    # ------------------------------------------------------------------
    # Variable / scalar operations
    # ------------------------------------------------------------------

    def _execute_var_op(self, inst: ControlInstruction) -> None:
        opname = inst.opname
        args = inst.args

        if opname == "create_var":
            var_name = self._normalize_var_name(str(args.get("var_name", args.get("name", ""))))
            value = args.get("value", 0)
            if var_name:
                self.var_values[var_name] = self._try_resolve(value)
            return

        if opname == "create_varlist":
            varlist_name = str(args.get("varlist_name", args.get("name", "")))
            length = self._resolve_int(args.get("length", 0), "create_varlist length")
            if varlist_name == "" or length <= 0:
                return
            self.varlist_lengths[varlist_name] = length
            for idx in range(length):
                self.var_values["%s[%d]" % (varlist_name, idx)] = 0
            return

        if opname == "var_assign":
            out_name = self._normalize_var_name(str(args.get("out_name", args.get("out", ""))))
            src = args.get("src", 0)
            if out_name:
                self.var_values[out_name] = self._try_resolve(src)
            return

        # Binary var ops: var_add, var_sub, var_mul, var_div, var_mod
        if opname in ("var_add", "var_sub", "var_mul", "var_div", "var_mod"):
            out_name = self._normalize_var_name(str(args.get("out_name", args.get("out", ""))))
            if not out_name:
                return
            a = self._resolve_numeric(args.get("a", 0), opname + " a")
            b = self._resolve_numeric(args.get("b", 0), opname + " b")
            if opname == "var_add":
                self.var_values[out_name] = a + b
            elif opname == "var_sub":
                self.var_values[out_name] = a - b
            elif opname == "var_mul":
                self.var_values[out_name] = a * b
            elif opname == "var_div":
                if b == 0:
                    raise ZeroDivisionError("var_div: divide by zero")
                if isinstance(a, float) or isinstance(b, float):
                    self.var_values[out_name] = a / b
                else:
                    self.var_values[out_name] = a // b
            elif opname == "var_mod":
                a = int(a)
                b = int(b)
                if b == 0:
                    raise ZeroDivisionError("var_mod: divide by zero")
                self.var_values[out_name] = a % b
            return

        if opname == "scalar_sqrt":
            out_name = self._normalize_var_name(str(args.get("out_name", args.get("out", ""))))
            if out_name:
                a = self._resolve_scalar(args.get("a", 0), "scalar_sqrt a")
                self.var_values[out_name] = math.sqrt(float(a))
            return

        # Builtins: CeilDiv, Min, Max, AlignN
        if opname in ("CeilDiv", "Min", "Max"):
            out_name = self._normalize_var_name(str(args.get("out_name", args.get("out", ""))))
            if not out_name:
                return
            a = self._resolve_int(args.get("a", 0), opname + " a")
            b = self._resolve_int(args.get("b", 0), opname + " b")
            if opname == "CeilDiv":
                if b == 0:
                    raise ZeroDivisionError("CeilDiv: divide by zero")
                self.var_values[out_name] = (a + b - 1) // b
            elif opname == "Min":
                self.var_values[out_name] = min(a, b)
            elif opname == "Max":
                self.var_values[out_name] = max(a, b)
            return

        if opname.startswith("Align"):
            out_name = self._normalize_var_name(str(args.get("out_name", args.get("out", ""))))
            if out_name:
                align = int(opname.replace("Align", ""))
                a = self._resolve_int(args.get("a", 0), opname + " a")
                self.var_values[out_name] = _align_to(a, align)
            return

        # Topology queries
        if opname == "GetCubeNum":
            out_name = self._normalize_var_name(str(args.get("out_name", args.get("out", ""))))
            if out_name:
                self.var_values[out_name] = self.core_count
            return
        if opname == "GetCubeIdx":
            out_name = self._normalize_var_name(str(args.get("out_name", args.get("out", ""))))
            if out_name:
                self.var_values[out_name] = self.core_idx
            return
        if opname == "GetVecNum":
            out_name = self._normalize_var_name(str(args.get("out_name", args.get("out", ""))))
            if out_name:
                self.var_values[out_name] = self.core_count * self.vec_count
            return
        if opname == "GetVecIdx":
            out_name = self._normalize_var_name(str(args.get("out_name", args.get("out", ""))))
            if out_name:
                self.var_values[out_name] = self.core_idx * self.vec_count + self.sub_block_idx
            return
        if opname == "GetSubBlockIdx":
            out_name = self._normalize_var_name(str(args.get("out_name", args.get("out", ""))))
            if out_name:
                self.var_values[out_name] = self.sub_block_idx
            return

    def _execute_control_noop(self, inst: ControlInstruction) -> None:
        opname = inst.opname
        if opname == "atomic_add":
            self.active_atomic_mode = "add"
            self.active_atomic_dtype = "float"
        elif opname == "atomic_max":
            self.active_atomic_mode = "max"
            self.active_atomic_dtype = "float"
        elif opname == "atomic_min":
            self.active_atomic_mode = "min"
            self.active_atomic_dtype = "float"
        elif opname == "set_atomic_type":
            dtype_ref = inst.args.get("dtype")
            if dtype_ref is not None:
                self.active_atomic_dtype = str(dtype_ref)
        elif opname == "atomic_end":
            self.active_atomic_mode = None
            self.active_atomic_dtype = None

    def _handle_get_value_from(self, inst: ControlInstruction) -> None:
        if self.tensor_store is None:
            return
        args = inst.args
        var_name = self._normalize_var_name(str(args.get("var_name", "")))
        tensor_name = self._resolve_runtime_tensor_name(args.get("tensor_name", ""), "GetValueFrom src")
        tensor_kind = str(args.get("tensor_kind", ""))
        tensor_position = str(args.get("tensor_position", ""))
        if tensor_kind == "local":
            if self.lane_name == "cube":
                raise ValueError("GetValueFrom on Tensor is only valid in vec simulator pass")
            if tensor_position not in ("UB", "Position.UB"):
                raise ValueError(
                    "GetValueFrom on Tensor only supports UB position, current position: " + tensor_position
                )
        elif tensor_kind != "gm":
            raise TypeError("GetValueFrom requires Tensor/GMTensor src, got kind: " + tensor_kind)
        src_view = self.tensor_store.tensor(tensor_name)
        if int(src_view.numel()) <= 0:
            raise ValueError("GetValueFrom source tensor must have non-zero numel")
        value = src_view.reshape(-1)[0].item()
        if not isinstance(value, (int, float, bool)):
            raise TypeError("GetValueFrom source value must be numeric, got: " + str(type(value)))
        self.var_values[var_name] = self._cast_scalar_to_shared_dtype(value, args.get("var_dtype", "float32"))

    def _handle_set_value_to(self, inst: ControlInstruction) -> None:
        if self.tensor_store is None:
            return
        args = inst.args
        tensor_name = self._resolve_runtime_tensor_name(args.get("tensor_name", ""), "SetValueTo src")
        tensor_kind = str(args.get("tensor_kind", ""))
        tensor_position = str(args.get("tensor_position", ""))
        if tensor_kind == "local":
            if self.lane_name == "cube":
                raise ValueError("SetValueTo on cube side only supports GMTensor src")
            if tensor_position not in ("UB", "Position.UB"):
                raise ValueError("SetValueTo only supports UB Tensor src, current position: " + tensor_position)
        elif tensor_kind != "gm":
            raise TypeError("SetValueTo requires Tensor/GMTensor src, got kind: " + tensor_kind)
        dst_view = self.tensor_store.tensor(tensor_name)
        if int(dst_view.numel()) <= 0:
            raise ValueError("SetValueTo source tensor must have non-zero numel")
        value = self._resolve_scalar(args.get("var_name", 0), "SetValueTo dst")
        casted = self._cast_scalar_to_shared_dtype(value, args.get("var_dtype", "float32"))
        import torch

        dst_view.reshape(-1)[0] = torch.tensor(casted, dtype=dst_view.dtype, device=dst_view.device)

    # ------------------------------------------------------------------
    # sim_print / sim_dump_tensor
    # ------------------------------------------------------------------

    def _execute_sim_dump_tensor(self, inst: ControlInstruction) -> None:
        import torch

        self._complete_submitted_tasks()
        if self.tensor_store is None:
            return
        args = inst.args
        tensor_name = self._resolve_runtime_tensor_name(
            args.get("tensor_name", ""), "sim_dump_tensor tensor_name"
        )
        filename = str(args.get("filename", ""))
        if filename == "":
            raise ValueError("sim_dump_tensor requires non-empty filename")
        tensor = self.tensor_store.tensor(tensor_name)
        torch.save(tensor.detach().clone(), filename)

    def _execute_sim_print(self, inst: ControlInstruction) -> None:
        from ..helpers import _SIM_LOGGER

        self._complete_submitted_tasks()
        args = inst.args
        payload_count = self._resolve_int(args.get("payload_count", 0), "sim_print payload_count")
        parts: List[str] = []
        for i in range(payload_count):
            kind = str(args.get("payload_kind_" + str(i), "literal"))
            value = args.get("payload_" + str(i), "")
            parts.append(str(self._resolve_sim_print_item(kind, value)))
        message = " ".join(parts)
        pipe = str(args.get("pipe", "S"))
        prefix = self._sim_print_prefix(pipe)
        _SIM_LOGGER.info(prefix + " " + message)

    def _resolve_sim_print_item(self, kind: str, value: Any) -> Any:
        if kind == "var":
            return self._try_resolve(value)
        if kind == "expr":
            resolved = self._try_resolve(value)
            if isinstance(resolved, (int, float, bool)):
                return resolved
            return value
        if self.tensor_store is None:
            return value
        if kind == "gm_tensor":
            return self.tensor_store.tensor(str(value))
        if kind == "local_tensor":
            name = self._resolve_runtime_tensor_name(str(value), "sim_print local tensor")
            return self.tensor_store.tensor(name)
        return value

    def _sim_print_prefix(self, pipe: str) -> str:
        if self.lane_name == "cube":
            prefix = "[cube][core=" + str(self.core_idx) + "]"
        else:
            prefix = (
                "[vec][core="
                + str(self.core_idx)
                + "][subblock="
                + str(self.sub_block_idx)
                + "]"
            )
        if pipe != "" and pipe != "S":
            prefix = prefix + "[pipe=" + pipe + "]"
        return prefix

    # ------------------------------------------------------------------
    # Sync instruction handlers
    # ------------------------------------------------------------------

    @staticmethod
    def _flag_sync_key(src: str, dst: str, event_id: str) -> str:
        return "flag:" + src + ":" + dst + ":" + str(event_id)

    def _handle_setflag(self, inst: ControlInstruction) -> None:
        src = str(inst.args.get("src", ""))
        dst = str(inst.args.get("dst", ""))
        event_id = str(self._resolve_int(inst.args.get("event_id", "0"), "setflag event_id"))
        flag_key = self._flag_sync_key(src, dst, event_id)
        if src == "S" or src == "" or src not in self.worker_mailboxes:
            raise ValueError(
                "setflag requires a valid src pipe with a worker, got: " + repr(src)
                + " (available: " + ", ".join(sorted(self.worker_mailboxes)) + ")"
            )
        task = PipeTask(pipe_name=src, opname="setflag",
                        args={"flag_key": flag_key, "src": src, "dst": dst,
                              "event_id": event_id})
        self.submit_task(task)
        self.submitted_tasks.append(task)

    def _handle_waitflag(self, inst: ControlInstruction) -> None:
        src = str(inst.args.get("src", ""))
        dst = str(inst.args.get("dst", ""))
        event_id = str(self._resolve_int(inst.args.get("event_id", "0"), "waitflag event_id"))
        flag_key = self._flag_sync_key(src, dst, event_id)
        timeout = self.config.sync_wait_timeout_s
        if dst != "S" and dst != "" and dst in self.worker_mailboxes:
            task = PipeTask(pipe_name=dst, opname="waitflag",
                            args={"flag_key": flag_key, "src": src, "dst": dst,
                                  "event_id": event_id, "timeout": timeout})
            self.submit_task(task)
            self.submitted_tasks.append(task)
        else:
            # dst is Pipe.S or absent: block control actor directly
            target_phase = self.local_flags.consumed_phase(flag_key) + 1
            if not self._wait_with_worker_checks(
                lambda slice_timeout: self.local_flags.wait_for(flag_key, target_phase, timeout=slice_timeout),
                timeout,
            ):
                diag = self.local_flags.timeout_diagnostic(flag_key, target_phase)
                raise RuntimeError("waitflag timeout: " + str(diag))
            if not self.local_flags.consume(flag_key, target_phase):
                raise RuntimeError(
                    "waitflag failed to consume flag: " + flag_key
                    + " phase=" + str(target_phase)
                )

    def _handle_cross_lane_sync(self, inst: ControlInstruction) -> None:
        opname = inst.opname
        flag_id = str(inst.args.get("flag_id", inst.args.get("id", "0")))
        timeout = self.config.sync_wait_timeout_s

        if opname == "cube_ready":
            pipe = str(inst.args.get("pipe", "FIX"))
            if pipe == "S" or pipe == "" or pipe not in self.worker_mailboxes:
                raise ValueError(
                    "cube_ready requires a valid pipe with a worker, got: " + repr(pipe)
                    + " (available: " + ", ".join(sorted(self.worker_mailboxes)) + ")"
                )
            sync_names = ["cube_to_vec_" + flag_id + "_" + str(vi) for vi in range(self.vec_count)]
            task = PipeTask(pipe_name=pipe, opname="cube_ready",
                            args={"flag_id": flag_id, "sync_names": sync_names})
            self.submit_task(task)
            self.submitted_tasks.append(task)
        elif opname == "vec_ready":
            pipe = str(inst.args.get("pipe", "MTE3"))
            if pipe == "S" or pipe == "" or pipe not in self.worker_mailboxes:
                raise ValueError(
                    "vec_ready requires a valid pipe with a worker, got: " + repr(pipe)
                    + " (available: " + ", ".join(sorted(self.worker_mailboxes)) + ")"
                )
            sync_names = ["vec_to_cube_" + flag_id + "_" + str(self.sub_block_idx)]
            task = PipeTask(pipe_name=pipe, opname="vec_ready",
                            args={"flag_id": flag_id, "sync_names": sync_names})
            self.submit_task(task)
            self.submitted_tasks.append(task)
        elif opname == "wait_vec":
            pipe = str(inst.args.get("pipe", "S"))
            sync_names = ["vec_to_cube_" + flag_id + "_" + str(vi) for vi in range(self.vec_count)]
            if pipe != "S" and pipe != "" and pipe in self.worker_mailboxes:
                task = PipeTask(pipe_name=pipe, opname="wait_vec",
                                args={"flag_id": flag_id, "sync_names": sync_names,
                                      "timeout": timeout})
                self.submit_task(task)
                self.submitted_tasks.append(task)
            else:
                # Pipe.S or absent: block control actor directly
                for sync_name in sync_names:
                    target_phase = self.sync.consumed_phase(sync_name) + 1
                    wait_start_cycle = max(self.current_cycle, self._sync_channel_cycle("intra_core", sync_name))
                    wait_start_ts = float(wait_start_cycle) if self.cycle_model is not None else time.monotonic()
                    if not self._wait_with_worker_checks(
                        lambda slice_timeout, _sync_name=sync_name, _target_phase=target_phase:
                            self.sync.wait_for(_sync_name, _target_phase, timeout=slice_timeout),
                        timeout,
                    ):
                        diag = self.sync.timeout_diagnostic(sync_name, target_phase)
                        self._record_sync_event(
                            opname,
                            "wait_timeout",
                            ts=wait_start_ts,
                            dur=(time.monotonic() - wait_start_ts) if self.cycle_model is None else 0.0,
                            extra_args={"sync_name": sync_name, "phase": target_phase, **self._cycle_time_args()},
                        )
                        raise RuntimeError("wait_vec timeout: " + str(diag))
                    if not self.sync.consume_wait(sync_name, target_phase):
                        raise RuntimeError(
                            "wait_vec failed to consume intra-core token: "
                            + sync_name + " phase=" + str(target_phase)
                        )
                    wait_dur = time.monotonic() - wait_start_ts
                    if self.cycle_model is not None:
                        ready_cycle = self.sync.phase_cycle(sync_name, target_phase)
                        wait_end_cycle = max(wait_start_cycle, int(ready_cycle or wait_start_cycle))
                        wait_dur = max(wait_end_cycle - wait_start_cycle, 0)
                        self._set_sync_channel_cycle("intra_core", sync_name, wait_end_cycle)
                        self.current_cycle = max(self.current_cycle, wait_end_cycle)
                    self._record_sync_event(
                        opname,
                        "wait",
                        ts=wait_start_ts,
                        dur=wait_dur,
                        extra_args={"sync_name": sync_name, "phase": target_phase, **self._cycle_time_args()},
                    )
        elif opname == "wait_cube":
            pipe = str(inst.args.get("pipe", "S"))
            sync_names = ["cube_to_vec_" + flag_id + "_" + str(self.sub_block_idx)]
            if pipe != "S" and pipe != "" and pipe in self.worker_mailboxes:
                task = PipeTask(pipe_name=pipe, opname="wait_cube",
                                args={"flag_id": flag_id, "sync_names": sync_names,
                                      "timeout": timeout})
                self.submit_task(task)
                self.submitted_tasks.append(task)
            else:
                sync_name = sync_names[0]
                target_phase = self.sync.consumed_phase(sync_name) + 1
                wait_start_cycle = max(self.current_cycle, self._sync_channel_cycle("intra_core", sync_name))
                wait_start_ts = float(wait_start_cycle) if self.cycle_model is not None else time.monotonic()
                if not self._wait_with_worker_checks(
                    lambda slice_timeout: self.sync.wait_for(sync_name, target_phase, timeout=slice_timeout),
                    timeout,
                ):
                    diag = self.sync.timeout_diagnostic(sync_name, target_phase)
                    self._record_sync_event(
                        opname,
                        "wait_timeout",
                        ts=wait_start_ts,
                        dur=(time.monotonic() - wait_start_ts) if self.cycle_model is None else 0.0,
                        extra_args={"sync_name": sync_name, "phase": target_phase, **self._cycle_time_args()},
                    )
                    raise RuntimeError("wait_cube timeout: " + str(diag))
                if not self.sync.consume_wait(sync_name, target_phase):
                    raise RuntimeError(
                        "wait_cube failed to consume intra-core token: "
                        + sync_name + " phase=" + str(target_phase)
                    )
                wait_dur = time.monotonic() - wait_start_ts
                if self.cycle_model is not None:
                    ready_cycle = self.sync.phase_cycle(sync_name, target_phase)
                    wait_end_cycle = max(wait_start_cycle, int(ready_cycle or wait_start_cycle))
                    wait_dur = max(wait_end_cycle - wait_start_cycle, 0)
                    self._set_sync_channel_cycle("intra_core", sync_name, wait_end_cycle)
                    self.current_cycle = max(self.current_cycle, wait_end_cycle)
                self._record_sync_event(
                    opname,
                    "wait",
                    ts=wait_start_ts,
                    dur=wait_dur,
                    extra_args={"sync_name": sync_name, "phase": target_phase, **self._cycle_time_args()},
                )

    def _handle_collective_sync(self, inst: ControlInstruction) -> None:
        opname = inst.opname
        flag_id = str(inst.args.get("flag_id", inst.args.get("id", "0")))
        timeout = self.config.sync_wait_timeout_s

        if opname in ("allcube_ready", "allcube_wait"):
            parties = max(1, int(self.core_count))
            participant_idx = int(self.core_idx)
            sync_name = "allcube_" + flag_id
        else:
            vec_per_core = max(1, int(self.vec_count))
            parties = max(1, int(self.core_count)) * vec_per_core
            participant_idx = int(self.core_idx) * vec_per_core + int(self.sub_block_idx)
            sync_name = "allvec_" + flag_id

        self.collective_sync.configure(sync_name, parties)

        if opname in ("allcube_ready", "allvec_ready"):
            default_pipe = "FIX" if opname == "allcube_ready" else "MTE3"
            pipe = str(inst.args.get("pipe", default_pipe))
            if pipe == "S" or pipe == "" or pipe not in self.worker_mailboxes:
                raise ValueError(
                    opname + " requires a valid pipe with a worker, got: " + repr(pipe)
                    + " (available: " + ", ".join(sorted(self.worker_mailboxes)) + ")"
                )
            task = PipeTask(pipe_name=pipe, opname=opname,
                            args={"flag_id": flag_id, "sync_name": sync_name,
                                  "participant_idx": participant_idx})
            self.submit_task(task)
            self.submitted_tasks.append(task)
            return

        # Wait path
        default_wait_pipe = "FIX" if opname == "allcube_wait" else "MTE3"
        pipe = str(inst.args.get("pipe", "S"))
        if pipe != "S" and pipe != "" and pipe in self.worker_mailboxes:
            task = PipeTask(pipe_name=pipe, opname=opname,
                            args={"flag_id": flag_id, "sync_name": sync_name,
                                  "participant_idx": participant_idx,
                                  "timeout": timeout})
            self.submit_task(task)
            self.submitted_tasks.append(task)
        else:
            # Pipe.S or absent: block control actor directly
            snapshot = self.collective_sync.participant_snapshot(sync_name)
            wait_counts = snapshot.get("wait_counts", {})
            target_phase = int(wait_counts.get(participant_idx, 0)) + 1
            wait_start_cycle = max(self.current_cycle, self._sync_channel_cycle("collective", sync_name))
            wait_start_ts = float(wait_start_cycle) if self.cycle_model is not None else time.monotonic()
            if not self._wait_with_worker_checks(
                lambda slice_timeout: self.collective_sync.wait_for(sync_name, target_phase, timeout=slice_timeout),
                timeout,
            ):
                diag = self.collective_sync.timeout_diagnostic(
                    sync_name, target_phase, participant_idx=participant_idx
                )
                self._record_sync_event(
                    opname,
                    "wait_timeout",
                    ts=wait_start_ts,
                    dur=(time.monotonic() - wait_start_ts) if self.cycle_model is None else 0.0,
                    extra_args={
                        "sync_name": sync_name,
                        "participant_idx": participant_idx,
                        "phase": target_phase,
                        **self._cycle_time_args(),
                    },
                )
                raise RuntimeError(opname + " timeout: " + str(diag))
            if not self.collective_sync.consume_wait(sync_name, participant_idx):
                raise RuntimeError(
                    opname + " failed to consume collective token: "
                    + sync_name + " participant=" + str(participant_idx)
                    + " phase=" + str(target_phase)
                )
            wait_dur = time.monotonic() - wait_start_ts
            if self.cycle_model is not None:
                ready_cycle = self.collective_sync.phase_cycle(sync_name, target_phase)
                wait_end_cycle = max(wait_start_cycle, int(ready_cycle or wait_start_cycle))
                wait_dur = max(wait_end_cycle - wait_start_cycle, 0)
                self._set_sync_channel_cycle("collective", sync_name, wait_end_cycle)
                self.current_cycle = max(self.current_cycle, wait_end_cycle)
            self._record_sync_event(
                opname,
                "wait",
                ts=wait_start_ts,
                dur=wait_dur,
                extra_args={
                    "sync_name": sync_name,
                    "participant_idx": participant_idx,
                    "phase": target_phase,
                    **self._cycle_time_args(),
                },
            )

    def _handle_local_event(self, inst: ControlInstruction) -> None:
        opname = inst.opname
        event_name = str(inst.args.get("event_name", inst.args.get("name", "")))
        if event_name == "":
            raise ValueError(opname + " requires event_name")

        if opname in ("create_sevent", "create_devent"):
            event_kind = "s" if opname == "create_sevent" else "d"
            preset = bool(inst.args.get("preset", False))
            preset_cycle = None
            if self.cycle_model is not None and preset:
                preset_cycle = float(self.current_cycle)
            descriptor = self.local_events.create_event(
                event_name,
                event_kind=event_kind,
                src_pipe=str(inst.args.get("src_pipe", "")),
                dst_pipe=str(inst.args.get("dst_pipe", "")),
                preset=preset,
                ready_cycle=preset_cycle,
            )
            if self.cycle_model is not None and preset_cycle is not None:
                for flag_id in descriptor.flag_ids:
                    channel_name = self._event_channel_name(descriptor.src_pipe, descriptor.dst_pipe, flag_id)
                    self._set_sync_channel_cycle("event", channel_name, int(preset_cycle))
            return

        if opname in ("event_set", "event_setall"):
            descriptor = self.local_events.descriptor(event_name)
            src_pipe = descriptor.src_pipe
            if os.environ.get("SIMV2_DEBUG_TRACE"):
                import sys
                print("[%s] event_set %s src_pipe=%s pending_tasks=%d" % (
                    self.lane_name, event_name, src_pipe, len(self.submitted_tasks)), file=sys.stderr, flush=True)
            if src_pipe != "":
                self._complete_pipe_tasks(src_pipe, advance_control=False)
            else:
                self._complete_submitted_tasks(advance_control=False)
            if os.environ.get("SIMV2_DEBUG_TRACE"):
                import sys
                print("[%s] event_set %s pipe_tasks_done, publishing" % (self.lane_name, event_name), file=sys.stderr, flush=True)
            ready_cycle = None
            if self.cycle_model is not None:
                src_ready_cycle = (
                    self._completed_cycle_for_pipe(src_pipe)
                    if src_pipe != ""
                    else self.completed_cycle_max
                )
                ready_cycle = max(int(self.current_cycle), int(src_ready_cycle))
            event_infos = self.local_events.set_event(
                event_name,
                ready_cycle=ready_cycle,
                set_all=(opname == "event_setall"),
            )
            if self.cycle_model is not None and ready_cycle is not None:
                for event_info in event_infos:
                    channel_name = self._event_channel_name(
                        event_info["src_pipe"], event_info["dst_pipe"], event_info["flag_id"]
                    )
                    self._set_sync_channel_cycle("event", channel_name, int(ready_cycle))
            first_info = event_infos[0]
            self._record_sync_event(
                opname,
                "ready",
                ts=float(ready_cycle or 0) if self.cycle_model is not None else time.monotonic(),
                extra_args={
                    "event_name": event_name,
                    "event_kind": descriptor.event_kind,
                    "src_pipe": descriptor.src_pipe,
                    "dst_pipe": descriptor.dst_pipe,
                    "flag_id": first_info["flag_id"],
                    "slot_index": first_info["slot_index"],
                    "flag_ids": [info["flag_id"] for info in event_infos],
                    **self._cycle_time_args(),
                },
            )
            return

        wait_target = self.local_events.current_wait_target(event_name)
        dst_pipe = str(wait_target["dst_pipe"])
        timeout = self.config.sync_wait_timeout_s
        if dst_pipe != "S" and dst_pipe != "" and dst_pipe in self.worker_mailboxes:
            task = PipeTask(
                pipe_name=dst_pipe,
                opname=opname,
                args={
                    "event_name": event_name,
                    "event_kind": wait_target["event_kind"],
                    "src_pipe": wait_target["src_pipe"],
                    "dst_pipe": wait_target["dst_pipe"],
                    "timeout": timeout,
                },
            )
            self.submit_task(task)
            self.submitted_tasks.append(task)
            self._trace_dispatch(task)
            return
        if os.environ.get("SIMV2_DEBUG_TRACE"):
            import sys
            print("[%s] event_wait %s flag_id=%d value=%s" % (
                self.lane_name, event_name, int(wait_target["flag_id"]), str(bool(wait_target["flag_value"]))), file=sys.stderr, flush=True)
        first_channel_name = self._event_channel_name(wait_target["src_pipe"], wait_target["dst_pipe"], wait_target["flag_id"])
        wait_start_cycle = max(self.current_cycle, self._sync_channel_cycle("event", first_channel_name))
        wait_start_ts = float(wait_start_cycle) if self.cycle_model is not None else time.monotonic()
        consumed_infos: List[Dict[str, Any]] = []

        def _consume_one(timeout_budget: float) -> bool:
            info = self.local_events.wait_and_consume(event_name, timeout=timeout_budget)
            if info is None:
                return False
            consumed_infos.append(dict(info))
            return True

        release_deadline = time.monotonic() + float(timeout)

        def _raise_event_timeout() -> None:
            diag = self.local_events.timeout_diagnostic(event_name)
            self._record_sync_event(
                opname,
                "wait_timeout",
                ts=wait_start_ts,
                dur=(time.monotonic() - wait_start_ts) if self.cycle_model is None else 0.0,
                extra_args={
                    "event_name": event_name,
                    "event_kind": wait_target["event_kind"],
                    "src_pipe": wait_target["src_pipe"],
                    "dst_pipe": wait_target["dst_pipe"],
                    "flag_id": wait_target["flag_id"],
                    "slot_index": wait_target["slot_index"],
                    **self._cycle_time_args(),
                },
            )
            raise RuntimeError(opname + " timeout: " + str(diag))

        if not self._wait_with_worker_checks(_consume_one, timeout):
            _raise_event_timeout()

        if opname == "event_release" and wait_target["event_kind"] == "d" and self.local_events.pending_count(event_name) > 0:
            remaining_timeout = max(release_deadline - time.monotonic(), 0.0)
            if not self._wait_with_worker_checks(_consume_one, remaining_timeout):
                _raise_event_timeout()

        consumed_info = consumed_infos[-1]
        wait_dur = time.monotonic() - wait_start_ts
        if self.cycle_model is not None:
            ready_cycle = max(int(info.get("ready_cycle") or wait_start_cycle) for info in consumed_infos)
            wait_end_cycle = max(wait_start_cycle, ready_cycle)
            wait_dur = max(wait_end_cycle - wait_start_cycle, 0)
            for info in consumed_infos:
                channel_name = self._event_channel_name(info["src_pipe"], info["dst_pipe"], info["flag_id"])
                self._set_sync_channel_cycle("event", channel_name, int(info.get("ready_cycle") or wait_end_cycle))
            self.current_cycle = max(self.current_cycle, wait_end_cycle)
        self._record_sync_event(
            opname,
            "release" if opname == "event_release" else "wait",
            ts=wait_start_ts,
            dur=wait_dur,
            extra_args={
                "event_name": event_name,
                "event_kind": consumed_info.get("event_kind"),
                "src_pipe": consumed_info.get("src_pipe"),
                "dst_pipe": consumed_info.get("dst_pipe"),
                "flag_id": consumed_info.get("flag_id"),
                "slot_index": consumed_info.get("slot_index"),
                "flag_ids": [info.get("flag_id") for info in consumed_infos],
                **self._cycle_time_args(),
            },
        )

    # ------------------------------------------------------------------
    # l0c_to_ub mixed-lane dual-write
    # ------------------------------------------------------------------

    def _handle_l0c_to_ub_mixed(self, inst: ControlInstruction) -> None:
        """Handle l0c_to_ub on the cube lane in mixed-lane mode.

        In SPLITM/SPLITN mode, the cube FIX pipe must write half of L0C
        to each vec lane's UB.  This mirrors the legacy simulator's
        dual-publish via L0CToUBState.
        """
        resolved = self._resolve_pipe_args(inst.args)
        # Resolve both vec lane UB tensor names from the logical dst name
        dst_logical = self._try_resolve(inst.args.get("dst", ""))
        if isinstance(dst_logical, str):
            # If dst_logical has @off...@span... suffix from a slice_tensor,
            # strip the suffix for the base name and re-register the view for
            # each vec lane.
            at_off_idx = dst_logical.find("@off")
            if at_off_idx >= 0:
                base_name = dst_logical[:at_off_idx]
                suffix = dst_logical[at_off_idx:]
            else:
                base_name = dst_logical
                suffix = ""
            vec0_name = "__local_c%d_vec0__%s" % (int(self.core_idx), base_name + suffix)
            vec1_name = "__local_c%d_vec1__%s" % (int(self.core_idx), base_name + suffix)
            # Mirror the unscoped snapshot for each vec lane.
            # _update_local_slice refreshes the unscoped snapshot every
            # loop iteration — its source_name points to the *current*
            # buffer slot (e.g. __bufslot__ub_qk_1 on iteration 1).
            # The vec mirror must use the vec-scoped version of that
            # concrete slot, NOT the vec-scoped alias chain (which is
            # static and always resolves to slot 0).
            if suffix and dst_logical in self.tensor_store.tensors:
                src_handle = self.tensor_store.tensors[dst_logical]
                from ..memory.shared_tensor import SharedTensorHandle, SharedTensorSpec
                for vec_name in (vec0_name, vec1_name):
                    lane_tag = "vec0" if vec_name == vec0_name else "vec1"
                    # Point directly at the vec-scoped buffer slot that
                    # the unscoped snapshot currently references.
                    vec_source = "__local_c%d_%s__%s" % (
                        int(self.core_idx), lane_tag,
                        src_handle.spec.source_name,
                    )
                    vec_spec = SharedTensorSpec(
                        name=vec_name,
                        shape=src_handle.spec.shape,
                        dtype=src_handle.spec.dtype,
                        role=src_handle.spec.role,
                        storage_offset=src_handle.spec.storage_offset,
                        source_name=vec_source,
                        view_shape=src_handle.spec.view_shape,
                        view_strides=src_handle.spec.view_strides,
                    )
                    self.tensor_store.tensors[vec_name] = SharedTensorHandle(
                        tensor_id=vec_name, spec=vec_spec, runtime_name=vec_name,
                    )
            resolved["dst_vec0"] = vec0_name
            resolved["dst_vec1"] = vec1_name
        task = PipeTask(pipe_name=inst.pipe_name or "FIX", opname="l0c_to_ub", args=resolved)
        self.submit_task(task)
        self.submitted_tasks.append(task)
        self._trace_dispatch(task)
        self._maybe_enforce_program_order()

    # ------------------------------------------------------------------
    # call_micro
    # ------------------------------------------------------------------

    def _handle_call_micro(self, inst: ControlInstruction) -> None:
        args = inst.args
        micro_name = str(args.get("name", ""))
        call_bindings = args.get("call_bindings", [])

        # Look up micro definition from program metadata
        metadata = getattr(self.program, "metadata", None) or {}
        micro_defs = metadata.get("micro_defs", {})
        micro_def = micro_defs.get(micro_name)
        if micro_def is None:
            raise ValueError("call_micro references unknown micro: " + micro_name)

        input_list = micro_def.get("input_list", [])
        if len(call_bindings) != len(input_list):
            raise ValueError(
                "call_micro argument mismatch for "
                + micro_name
                + ": expected="
                + str(len(input_list))
                + " got="
                + str(len(call_bindings))
            )

        # Resolve bindings at runtime
        tensor_views: Dict[str, Any] = {}
        tensor_view_names: Dict[str, str] = {}
        var_values: Dict[str, Any] = {}
        for formal, binding in zip(input_list, call_bindings):
            formal_name = str(formal.name) if hasattr(formal, "name") else str(formal)
            kind = str(binding.get("kind", ""))
            if kind == "tensor":
                actual_name = str(binding.get("actual_name", ""))
                resolved_name = self._resolve_runtime_tensor_name(actual_name, "call_micro tensor " + formal_name)
                if self.tensor_store is not None and self.tensor_store.contains(resolved_name):
                    tensor_views[formal_name] = self.tensor_store.tensor(resolved_name)
                    tensor_view_names[formal_name] = resolved_name
            elif kind == "var":
                actual_ref = binding.get("actual_ref", 0)
                var_values[formal_name] = self._try_resolve(actual_ref)

        # Build and submit PipeTask to V worker
        task = PipeTask(
            pipe_name=inst.pipe_name or "V",
            opname="call_micro",
            args={
                "name": micro_name,
                "tensor_views": tensor_views,
                "tensor_view_names": tensor_view_names,
                "var_values": var_values,
                "micro_def": micro_def,
            },
        )
        self.submit_task(task)
        self.submitted_tasks.append(task)
        self._trace_dispatch(task)
        self._maybe_enforce_program_order()

    def _complete_submitted_tasks(self, advance_control: bool = True) -> None:
        target_count = len(self.submitted_tasks)
        if os.environ.get("SIMV2_DEBUG_TRACE") and self.completed_submit_count < target_count:
            import sys
            print("[%s] _complete_submitted_tasks: waiting for %d tasks (from idx %d to %d)" % (
                self.lane_name, target_count - self.completed_submit_count,
                self.completed_submit_count, target_count - 1), file=sys.stderr, flush=True)
            for i in range(self.completed_submit_count, target_count):
                t = self.submitted_tasks[i]
                print("[%s]   task[%d]: op=%s pipe=%s status=%s" % (self.lane_name, i, t.opname, t.pipe_name, t.status), file=sys.stderr, flush=True)
        while self.completed_submit_count < target_count:
            task = self.submitted_tasks[self.completed_submit_count]
            self._complete_task(task, advance_control=advance_control)
            self.completed_submit_count += 1

    def _complete_pipe_tasks(self, pipe_name: str, advance_control: bool = True) -> None:
        for i, task in enumerate(self.submitted_tasks):
            if task.pipe_name != pipe_name:
                continue
            if os.environ.get("SIMV2_DEBUG_TRACE") and task.status not in (TaskStatus.DONE, TaskStatus.FAILED):
                import sys
                print("[%s] _complete_pipe_tasks(%s) waiting task[%d] op=%s status=%s" % (
                    self.lane_name, pipe_name, i, task.opname, task.status), file=sys.stderr, flush=True)
            self._complete_task(task, advance_control=advance_control)

    def _maybe_enforce_program_order(self) -> None:
        if not self.pipe_workers:
            return
        if self.has_explicit_event_sync:
            return
        # Until same-lane autosync/event families are modeled explicitly in V2,
        # preserve lane-local instruction order in threaded mode so cross-lane
        # overlap does not turn into same-lane data races.
        self._complete_submitted_tasks()

    def _complete_task(self, task: PipeTask, advance_control: bool = True) -> None:
        worker = self.pipe_workers.get(task.pipe_name)
        if worker is None:
            raise KeyError(
                "lane " + self.lane_name + " has no worker for pipe " + repr(task.pipe_name)
            )
        if task.status == TaskStatus.FAILED:
            raise RuntimeError(self._task_failure_message(task))
        if task.status == TaskStatus.DONE:
            self._mark_task_completion_cycle(task, advance_control=advance_control)
            return
        self._wait_for_task_completion(task, worker, advance_control=advance_control)
        if task.status == TaskStatus.FAILED:
            raise RuntimeError(self._task_failure_message(task))

    def _wait_for_task_completion(self, task: PipeTask, worker: PipeWorker, advance_control: bool = True) -> None:
        deadline = time.monotonic() + float(self.config.execution_timeout_s)
        while task.status not in (TaskStatus.DONE, TaskStatus.FAILED):
            self._raise_worker_failure_if_any()
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    "lane "
                    + self.lane_name
                    + " timed out waiting for pipe task "
                    + repr(task.opname)
                    + " on "
                    + repr(task.pipe_name)
                )
            time.sleep(0.0005)
        if task.status == TaskStatus.FAILED:
            raise RuntimeError(self._task_failure_message(task))
        self._mark_task_completion_cycle(task, advance_control=advance_control)

    def _raise_worker_failure_if_any(self) -> None:
        for pipe_name in self.pipe_names:
            worker = self.pipe_workers.get(pipe_name)
            if worker is None or not worker.thread_failure:
                continue
            raise RuntimeError(
                "lane "
                + self.lane_name
                + " worker "
                + repr(pipe_name)
                + " failed:\n"
                + worker.thread_failure
            )

    def _wait_with_worker_checks(self, wait_fn, timeout: float) -> bool:
        deadline = time.monotonic() + float(timeout)
        poll_interval = min(0.01, max(float(timeout), 0.001))
        while True:
            self._raise_worker_failure_if_any()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            if wait_fn(min(poll_interval, remaining)):
                return True
        return False

    @staticmethod
    def _task_failure_message(task: PipeTask) -> str:
        message = "pipe task failed: " + repr(task.opname) + " on " + repr(task.pipe_name)
        if task.error:
            message += " error=" + str(task.error)
        if task.args:
            keys = ("dst", "dst_vec0", "dst_vec1", "src", "M", "N", "M_src", "dual_mode", "sub_block_id")
            summary = {key: task.args[key] for key in keys if key in task.args}
            if summary:
                message += " args=" + repr(summary)
        details = getattr(task, "error_details", None)
        if details:
            tail = "\n".join(str(details).rstrip().splitlines()[-8:])
            if tail:
                message += "\ntraceback_tail:\n" + tail
        return message

    # ------------------------------------------------------------------
    # Value resolution
    # ------------------------------------------------------------------

    def _resolve_pipe_args(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Resolve all variable references in pipe task args to concrete values.

        The control-flow bridge stores Var references as string names so that
        they can be resolved at runtime when loop variables have their current
        iteration values.  This method walks the args dict and resolves every
        value through ``_try_resolve``, turning var-name strings into ints/floats
        before the pipe executor sees them.
        """
        resolved = {}
        for key, val in args.items():
            resolved_val = self._try_resolve(val)
            if isinstance(resolved_val, str) and resolved_val in self.lane_local_tensor_names:
                resolved_val = self.lane_local_tensor_names[resolved_val]
            resolved[key] = resolved_val
        return resolved

    def _inject_atomic_state(self, opname: str, args: Dict[str, Any]) -> Dict[str, Any]:
        if opname not in _ATOMIC_PIPE_OPS or self.active_atomic_mode is None:
            return args
        out = dict(args)
        out["atomic_enabled"] = True
        out["atomic_mode"] = self.active_atomic_mode
        if self.active_atomic_dtype is not None:
            out["atomic_dtype"] = self.active_atomic_dtype
        return out

    def _try_resolve(self, value: Any) -> Any:
        """Try to resolve a value; return as-is if not a known var reference."""
        if isinstance(value, (int, float, bool)):
            return value
        if isinstance(value, str):
            normalized_name = self._normalize_var_name(value)
            if normalized_name in self.var_values:
                return self.var_values[normalized_name]
            if value in self.var_values:
                return self.var_values[value]
            # Try parsing as a numeric literal
            try:
                return int(value)
            except ValueError:
                pass
            try:
                return float(value)
            except ValueError:
                pass
        return value

    def _resolve_int(self, value: Any, label: str) -> int:
        resolved = self._try_resolve(value)
        if isinstance(resolved, (int, float)):
            return int(resolved)
        raise TypeError(label + " must resolve to int, got: " + repr(value))

    def _resolve_scalar(self, value: Any, label: str) -> Any:
        resolved = self._try_resolve(value)
        if isinstance(resolved, (int, float)):
            return resolved
        raise TypeError(label + " must resolve to scalar, got: " + repr(value))

    def _resolve_numeric(self, value: Any, label: str) -> Any:
        resolved = self._try_resolve(value)
        if isinstance(resolved, bool):
            return int(resolved)
        if isinstance(resolved, (int, float)):
            return resolved
        raise TypeError(label + " must resolve to numeric, got: " + repr(value))

    def _resolve_bool(self, cond: Any) -> bool:
        """Resolve a condition value to bool."""
        if cond is None:
            return False
        if isinstance(cond, bool):
            return cond
        if isinstance(cond, (int, float)):
            return bool(cond)
        if isinstance(cond, str):
            resolved = self._try_resolve(cond)
            if isinstance(resolved, (int, float, bool)):
                return bool(resolved)
            # Try evaluating simple comparison expressions
            return self._eval_condition_expr(cond)
        return bool(cond)

    def _normalize_var_name(self, name: str) -> str:
        if not isinstance(name, str) or name == "":
            return name
        match = _VARLIST_REF_RE.match(name)
        if match is None:
            return name
        base_name = str(match.group(1))
        if base_name not in self.varlist_lengths:
            return name
        index_expr = str(match.group(2)).strip()
        resolved_index = self._try_resolve(index_expr)
        if not isinstance(resolved_index, (int, float, bool)):
            raise TypeError("VarList index must resolve to int, got: " + repr(index_expr))
        resolved_index = int(resolved_index)
        length = int(self.varlist_lengths[base_name])
        if resolved_index < 0 or resolved_index >= length:
            raise IndexError(
                "VarList index out of range for "
                + base_name
                + ": idx="
                + str(resolved_index)
                + ", length="
                + str(length)
            )
        return "%s[%d]" % (base_name, resolved_index)

    def _resolve_runtime_tensor_name(self, value: Any, label: str) -> str:
        resolved = self._try_resolve(value)
        if isinstance(resolved, str) and resolved in self.lane_local_tensor_names:
            resolved = self.lane_local_tensor_names[resolved]
        if not isinstance(resolved, str):
            raise TypeError(label + " must resolve to tensor name, got: " + repr(value))
        return resolved

    @staticmethod
    def _cast_scalar_to_shared_dtype(value: Any, dtype_name: Any) -> Any:
        import torch

        torch_dtype = torch_dtype_from_shared_name(dtype_name)
        casted = torch.tensor(value).to(torch_dtype).item()
        if not isinstance(casted, (int, float, bool)):
            raise TypeError("cast result must be numeric, got: " + str(type(casted)))
        return casted

    _COMPARE_OPS = (
        ("==", lambda a, b: a == b),
        ("!=", lambda a, b: a != b),
        ("<=", lambda a, b: a <= b),
        (">=", lambda a, b: a >= b),
        ("<",  lambda a, b: a < b),
        (">",  lambda a, b: a > b),
    )

    @staticmethod
    def _strip_outer_parens(expr: str) -> str:
        while len(expr) >= 2 and expr[0] == "(" and expr[-1] == ")":
            depth = 0
            matched = True
            for i, ch in enumerate(expr):
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0 and i != len(expr) - 1:
                        matched = False
                        break
            if not matched:
                break
            expr = expr[1:-1].strip()
        return expr

    @staticmethod
    def _split_top_level(expr: str, sep: str) -> list:
        parts: list = []
        depth = 0
        start = 0
        n = len(expr)
        seplen = len(sep)
        i = 0
        while i < n:
            ch = expr[i]
            if ch == "(":
                depth += 1
                i += 1
                continue
            if ch == ")":
                depth -= 1
                i += 1
                continue
            if depth == 0 and expr[i:i + seplen] == sep:
                parts.append(expr[start:i].strip())
                start = i + seplen
                i += seplen
                continue
            i += 1
        parts.append(expr[start:].strip())
        return parts

    @staticmethod
    def _find_top_level(expr: str, op: str) -> int:
        depth = 0
        n = len(expr)
        oplen = len(op)
        i = 0
        while i < n:
            ch = expr[i]
            if ch == "(":
                depth += 1
                i += 1
                continue
            if ch == ")":
                depth -= 1
                i += 1
                continue
            if depth == 0 and expr[i:i + oplen] == op:
                return i
            i += 1
        return -1

    def _eval_condition_expr(self, expr: str) -> bool:
        """Evaluate a condition expression with support for &&, ||, !, parens, and comparisons."""
        e = self._strip_outer_parens(expr.strip())
        if e == "":
            return False
        # precedence: || (lowest) -> && -> unary ! -> comparison -> leaf
        or_parts = self._split_top_level(e, "||")
        if len(or_parts) > 1:
            for part in or_parts:
                if self._resolve_bool(part):
                    return True
            return False
        and_parts = self._split_top_level(e, "&&")
        if len(and_parts) > 1:
            for part in and_parts:
                if not self._resolve_bool(part):
                    return False
            return True
        if e.startswith("!") and not e.startswith("!="):
            return not self._resolve_bool(e[1:].lstrip())
        for op, fn in self._COMPARE_OPS:
            idx = self._find_top_level(e, op)
            if idx >= 0:
                lhs_text = e[:idx].strip()
                rhs_text = e[idx + len(op):].strip()
                try:
                    lhs = self._resolve_scalar(lhs_text, "cond lhs")
                    rhs = self._resolve_scalar(rhs_text, "cond rhs")
                    return fn(lhs, rhs)
                except (TypeError, ValueError):
                    continue
        resolved = self._try_resolve(e)
        if isinstance(resolved, bool):
            return resolved
        if isinstance(resolved, (int, float)):
            return bool(resolved)
        return False

    # ------------------------------------------------------------------
    # Tracing
    # ------------------------------------------------------------------

    def _trace_dispatch(self, task: PipeTask) -> None:
        if self.trace_recorder is not None:
            if not _should_trace_sync_op(task.opname):
                return
            self.trace_recorder.record_event(
                TraceEventKind.CONTROL,
                "dispatch_task",
                ts=float(getattr(task, "earliest_start_cycle", 0.0)) if self.cycle_model is not None else None,
                args={
                    "lane_name": self.lane_name,
                    "pipe_name": task.pipe_name,
                    "opname": task.opname,
                    **self._cycle_time_args(),
                },
            )
