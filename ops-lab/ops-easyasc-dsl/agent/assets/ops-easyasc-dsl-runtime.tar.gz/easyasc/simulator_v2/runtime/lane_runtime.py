from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
from typing import Optional

from ..config import SimulatorV2Config
from ..memory.shared_tensor_store import SharedTensorStore
from ..ops.micro.runtime import MicroRuntime
from ..program.kernel_program import KernelProgram
from ..sync.collective_sync import CollectiveSync
from ..sync.intra_core_sync import IntraCoreSync
from ..sync.local_flags import LocalFlagTable
from ..sync.mailbox import Mailbox
from ..trace.recorder import TraceRecorderV2
from .control_actor import ControlActor
from .pipe_worker import PipeWorker


def _sub_block_idx_for_lane(lane_name: str) -> int:
    """Extract sub-block index from lane name (vec0->0, vec1->1, cube->0)."""
    if lane_name.startswith("vec"):
        suffix = lane_name[3:]
        if suffix.isdigit():
            return int(suffix)
    return 0


@dataclass
class LaneRuntime:
    """Runtime for one logical lane inside a core."""

    core_idx: int
    lane_name: str
    config: SimulatorV2Config
    program: KernelProgram
    sync: IntraCoreSync
    collective_sync: CollectiveSync = field(default_factory=CollectiveSync)
    tensor_store: SharedTensorStore = field(default_factory=lambda: SharedTensorStore(auto_allocate=False))
    micro_runtime: Optional[MicroRuntime] = None
    local_flags: LocalFlagTable = field(default_factory=LocalFlagTable)
    trace_recorder: Optional[TraceRecorderV2] = None
    core_count: int = 1
    vec_count: int = 2
    control_actor: ControlActor = field(init=False)
    pipe_workers: List[PipeWorker] = field(init=False)
    worker_mailboxes: Dict[str, Mailbox] = field(init=False)

    def __post_init__(self) -> None:
        self.worker_mailboxes = {}
        self.pipe_workers = []
        for pipe_name in self.program.get_pipe_names(self.lane_name):
            mailbox = Mailbox(maxsize=self.config.queue_maxsize)
            self.worker_mailboxes[pipe_name] = mailbox
            self.pipe_workers.append(
                PipeWorker(
                    core_idx=self.core_idx,
                    lane_name=self.lane_name,
                    pipe_name=pipe_name,
                    program=self.program,
                    mailbox=mailbox,
                    tensor_store=self.tensor_store,
                    micro_runtime=self.micro_runtime,
                    sync=self.sync,
                    collective_sync=self.collective_sync,
                    local_flags=self.local_flags,
                    trace_recorder=self.trace_recorder,
                )
            )
        self.control_actor = ControlActor(
            core_idx=self.core_idx,
            lane_name=self.lane_name,
            program=self.program,
            config=self.config,
            sync=self.sync,
            collective_sync=self.collective_sync,
            local_flags=self.local_flags,
            trace_recorder=self.trace_recorder,
            pipe_names=list(self.worker_mailboxes.keys()),
            pipe_workers={worker.pipe_name: worker for worker in self.pipe_workers},
            worker_mailboxes=self.worker_mailboxes,
            tensor_store=self.tensor_store,
            core_count=self.core_count,
            vec_count=self.vec_count,
            sub_block_idx=_sub_block_idx_for_lane(self.lane_name),
        )

    def start(self) -> None:
        for worker in self.pipe_workers:
            worker.start()
        self.control_actor.start()

    def join(self) -> None:
        self.control_actor.join()
        for worker in self.pipe_workers:
            worker.join()

    def terminate(self) -> None:
        self.control_actor.terminate()
        for worker in self.pipe_workers:
            worker.terminate()
