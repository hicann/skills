# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import List
from typing import Optional

from ..config import SimulatorV2Config
from ... import globvars
from ..memory.local_memory import LocalMemoryAllocator
from ..memory.local_memory import LocalMemoryBank
from ..memory.shared_tensor_store import SharedTensorStore
from ..ops.micro.runtime import MicroRuntime
from ..program.kernel_program import KernelProgram
from ..program.task import PipeTask
from ..sync.collective_sync import CollectiveSync
from ..sync.intra_core_sync import IntraCoreSync
from ..trace.event_types import TraceEvent, TraceEventKind
from ..trace.recorder import TraceRecorderV2
from .execution_plan import ExecutionPlan, build_execution_plan
from .lane_runtime import LaneRuntime
from .worker_pool import WorkerPool


class CoreRuntimeState(Enum):
    IDLE = "idle"
    RUNNING = "running"
    STOPPED = "stopped"


def _runtime_tensor_store() -> SharedTensorStore:
    return SharedTensorStore(auto_allocate=False)


def _capacity_kb_to_bytes(value: object) -> int:
    if isinstance(value, bool):
        return int(value) * 1024
    if not isinstance(value, (int, float)):
        return 0
    return max(int(value), 0) * 1024


def _default_local_memory_banks() -> List[LocalMemoryBank]:
    return [
        LocalMemoryBank(name="L1", size_bytes=_capacity_kb_to_bytes(getattr(globvars, "l1_cap", 0)), role="l1"),
        LocalMemoryBank(name="L0A", size_bytes=_capacity_kb_to_bytes(getattr(globvars, "l0a_cap", 0)), role="l0a"),
        LocalMemoryBank(name="L0B", size_bytes=_capacity_kb_to_bytes(getattr(globvars, "l0b_cap", 0)), role="l0b"),
        LocalMemoryBank(name="L0C", size_bytes=_capacity_kb_to_bytes(getattr(globvars, "l0c_cap", 0)), role="l0c"),
        LocalMemoryBank(name="UB0", size_bytes=_capacity_kb_to_bytes(getattr(globvars, "ub_cap", 0)), role="ub"),
        LocalMemoryBank(name="UB1", size_bytes=_capacity_kb_to_bytes(getattr(globvars, "ub_cap", 0)), role="ub"),
    ]


@dataclass
class CoreRuntime:
    """In-process runtime for one simulated core."""

    core_idx: int
    config: SimulatorV2Config
    program: KernelProgram
    tensor_store: SharedTensorStore = field(default_factory=_runtime_tensor_store)
    local_memory: List[LocalMemoryBank] = field(default_factory=list)
    intra_core_sync: IntraCoreSync = field(default_factory=IntraCoreSync)
    collective_sync: CollectiveSync = field(default_factory=CollectiveSync)
    micro_runtime: MicroRuntime = field(default_factory=MicroRuntime)
    trace_recorder: Optional[TraceRecorderV2] = None
    execution_plan: Optional[ExecutionPlan] = None
    lane_runtimes: List[LaneRuntime] = field(default_factory=list)
    worker_pool: WorkerPool = field(default_factory=WorkerPool)
    state: CoreRuntimeState = field(default=CoreRuntimeState.IDLE, init=False)
    executed_tasks: List[PipeTask] = field(default_factory=list, init=False)

    def __post_init__(self) -> None:
        # Child-core allocations only need thread-local sharing inside one process.
        # Keep parent GM snapshots on shm, but avoid creating extra per-core shm.
        self.tensor_store.prefer_shared_memory = False
        if not self.local_memory:
            self.local_memory = _default_local_memory_banks()
        self.tensor_store.local_allocator = LocalMemoryAllocator.from_banks(self.local_memory)
        if self.trace_recorder is None and self.config.trace_enabled:
            self.trace_recorder = TraceRecorderV2(core_idx=self.core_idx)
        if self.execution_plan is None:
            self.execution_plan = build_execution_plan(self.program, self.config)
        if not self.lane_runtimes:
            vec_count = len([n for n in self.execution_plan.active_lane_names if n.startswith("vec")])
            vec_count = max(vec_count, 1)
            self.lane_runtimes = []
            for lane_name in self.execution_plan.active_lane_names:
                self.lane_runtimes.append(
                    LaneRuntime(
                        core_idx=self.core_idx,
                        lane_name=lane_name,
                        config=self.config,
                        program=self.program,
                        sync=self.intra_core_sync,
                        collective_sync=self.collective_sync,
                        tensor_store=self.tensor_store,
                        micro_runtime=MicroRuntime(),
                        trace_recorder=self.trace_recorder,
                        core_count=self.execution_plan.core_count,
                        vec_count=vec_count,
                    )
                )
        # Multi-lane kernels (cube + vec) require concurrent control actors
        # and threaded pipe workers so cross-lane sync and data flow work.
        self._needs_concurrent = len(self.lane_runtimes) > 1
        self.worker_pool = WorkerPool(
            workers=[worker for lane_runtime in self.lane_runtimes for worker in lane_runtime.pipe_workers],
        )

    def start(self) -> None:
        if self.state == CoreRuntimeState.RUNNING:
            return
        if self.trace_recorder is not None:
            trace_args = {"lane_names": self.lane_names()}
            trace_ts = None
            if any(lane_runtime.has_cycle_model() for lane_runtime in self.lane_runtimes):
                trace_args["time_domain"] = "cycle"
                trace_ts = 0.0
            self.trace_recorder.record_event(
                TraceEventKind.CONTROL,
                "core_start",
                args=trace_args,
                ts=trace_ts,
            )
        self.worker_pool.start()
        if self._needs_concurrent:
            # Multi-lane: run ControlActors in threads for cross-lane sync
            self._actor_threads = []
            self._actor_errors = []  # type: List[Optional[BaseException]]
            for lane_runtime in self.lane_runtimes:
                def _run_actor(actor=lane_runtime.control_actor, errs=self._actor_errors, idx=len(self._actor_errors)):
                    try:
                        actor.start()
                    except BaseException as exc:
                        errs[idx] = exc
                self._actor_errors.append(None)
                t = threading.Thread(
                    target=_run_actor,
                    name="simv2-core%d-%s-actor" % (self.core_idx, lane_runtime.lane_name),
                    daemon=False,
                )
                self._actor_threads.append(t)
                t.start()
        else:
            for lane_runtime in self.lane_runtimes:
                lane_runtime.control_actor.start()
        self.state = CoreRuntimeState.RUNNING

    def join(self) -> None:
        if self._needs_concurrent:
            # Wait for all ControlActor threads to complete
            for t in getattr(self, "_actor_threads", []):
                t.join()
            # Re-raise the first actor error if any
            actor_errors = [err for err in getattr(self, "_actor_errors", []) if err is not None]
            if actor_errors:
                raise self._select_actor_error(actor_errors)
            self.worker_pool.join()
            self.executed_tasks = self.worker_pool.executed_tasks()
        else:
            for lane_runtime in self.lane_runtimes:
                lane_runtime.control_actor.join()
            self.worker_pool.join()
            self.executed_tasks = self.worker_pool.executed_tasks()
        if self.state == CoreRuntimeState.RUNNING:
            self.state = CoreRuntimeState.STOPPED
        if self.trace_recorder is not None:
            trace_args = {"completed_tasks": self.completed_task_count()}
            trace_ts = None
            if any(lane_runtime.has_cycle_model() for lane_runtime in self.lane_runtimes):
                trace_args["time_domain"] = "cycle"
                trace_ts = float(max(lane_runtime.max_cycle() for lane_runtime in self.lane_runtimes) if self.lane_runtimes else 0)
            self.trace_recorder.record_event(
                TraceEventKind.CONTROL,
                "core_stop",
                args=trace_args,
                ts=trace_ts,
            )

    @staticmethod
    def _select_actor_error(actor_errors: List[BaseException]) -> BaseException:
        def _score(err: BaseException) -> int:
            text = str(err)
            if "worker " in text and " failed" in text:
                return 3
            if "pipe task failed:" in text:
                return 2
            if "timeout" in text:
                return 0
            return 1

        best = actor_errors[0]
        best_score = _score(best)
        for err in actor_errors[1:]:
            score = _score(err)
            if score > best_score:
                best = err
                best_score = score
        return best

    def terminate(self) -> None:
        for lane_runtime in self.lane_runtimes:
            lane_runtime.control_actor.terminate()
        self.worker_pool.terminate()
        self.state = CoreRuntimeState.STOPPED

    def lane_names(self) -> List[str]:
        return [lane_runtime.lane_name for lane_runtime in self.lane_runtimes]

    def completed_task_count(self) -> int:
        return len(self.executed_tasks)

    def shared_tensor_ids(self) -> List[str]:
        return sorted(handle.tensor_id for handle in self.tensor_store.values())

    def workspace_tensor_ids(self) -> List[str]:
        return sorted(
            handle.tensor_id
            for handle in self.tensor_store.values()
            if handle.spec.role == "workspace"
        )

    def trace_events(self) -> List[TraceEvent]:
        if self.trace_recorder is None:
            return []
        return self.trace_recorder.snapshot()

    def execution_plan_dict(self) -> dict:
        if self.execution_plan is None:
            return {}
        return self.execution_plan.to_dict()
