from __future__ import annotations

import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import List
from typing import Optional

from ..config import SimulatorV2Config
from ..memory.local_memory import LocalMemoryBank
from ..memory.shared_tensor_store import SharedTensorStore
from ..ops.micro.runtime import MicroRuntime
from ..program.kernel_program import KernelProgram
from ..program.task import PipeTask
from ..sync.collective_sync import CollectiveSync
from ..sync.intra_core_sync import IntraCoreSync
from ..trace.event_types import TraceEvent, TraceEventKind
from ..trace.recorder import TraceRecorderV2
from .execution_plan import ExecutionPlan, build_execution_plan
from .lane_runtime import LaneRuntime
from .worker_pool import WorkerPool


class CoreRuntimeState(Enum):
    IDLE = "idle"
    RUNNING = "running"
    STOPPED = "stopped"


def _runtime_tensor_store() -> SharedTensorStore:
    return SharedTensorStore(auto_allocate=False)


@dataclass
class CoreRuntime:
    """In-process runtime for one simulated core."""

    core_idx: int
    config: SimulatorV2Config
    program: KernelProgram
    tensor_store: SharedTensorStore = field(default_factory=_runtime_tensor_store)
    local_memory: List[LocalMemoryBank] = field(default_factory=list)
    intra_core_sync: IntraCoreSync = field(default_factory=IntraCoreSync)
    collective_sync: CollectiveSync = field(default_factory=CollectiveSync)
    micro_runtime: MicroRuntime = field(default_factory=MicroRuntime)
    trace_recorder: Optional[TraceRecorderV2] = None
    execution_plan: Optional[ExecutionPlan] = None
    lane_runtimes: List[LaneRuntime] = field(default_factory=list)
    worker_pool: WorkerPool = field(default_factory=WorkerPool)
    state: CoreRuntimeState = field(default=CoreRuntimeState.IDLE, init=False)
    executed_tasks: List[PipeTask] = field(default_factory=list, init=False)

    def __post_init__(self) -> None:
        # Child-core allocations only need thread-local sharing inside one process.
        # Keep parent GM snapshots on shm, but avoid creating extra per-core shm.
        self.tensor_store.prefer_shared_memory = False
        if not self.local_memory:
            self.local_memory = [
                LocalMemoryBank(name="L1"),
                LocalMemoryBank(name="L0A"),
                LocalMemoryBank(name="L0B"),
                LocalMemoryBank(name="L0C"),
                LocalMemoryBank(name="UB0"),
                LocalMemoryBank(name="UB1"),
            ]
        if self.trace_recorder is None and self.config.trace_enabled:
            self.trace_recorder = TraceRecorderV2(core_idx=self.core_idx)
        if self.execution_plan is None:
            self.execution_plan = build_execution_plan(self.program, self.config)
        if not self.lane_runtimes:
            vec_count = len([n for n in self.execution_plan.active_lane_names if n.startswith("vec")])
            vec_count = max(vec_count, 1)
            self.lane_runtimes = []
            for lane_name in self.execution_plan.active_lane_names:
                self.lane_runtimes.append(
                    LaneRuntime(
                        core_idx=self.core_idx,
                        lane_name=lane_name,
                        config=self.config,
                        program=self.program,
                        sync=self.intra_core_sync,
                        collective_sync=self.collective_sync,
                        tensor_store=self.tensor_store,
                        micro_runtime=MicroRuntime(),
                        trace_recorder=self.trace_recorder,
                        core_count=self.execution_plan.core_count,
                        vec_count=vec_count,
                    )
                )
        # Multi-lane kernels (cube + vec) require concurrent control actors
        # and threaded pipe workers so cross-lane sync and data flow work.
        self._needs_concurrent = len(self.lane_runtimes) > 1
        self.worker_pool = WorkerPool(
            workers=[worker for lane_runtime in self.lane_runtimes for worker in lane_runtime.pipe_workers],
        )

    def start(self) -> None:
        if self.state == CoreRuntimeState.RUNNING:
            return
        if self.trace_recorder is not None:
            self.trace_recorder.record_event(
                TraceEventKind.CONTROL,
                "core_start",
                args={"lane_names": self.lane_names()},
            )
        self.worker_pool.start()
        if self._needs_concurrent:
            # Multi-lane: run ControlActors in threads for cross-lane sync
            self._actor_threads = []
            self._actor_errors = []  # type: List[Optional[BaseException]]
            for lane_runtime in self.lane_runtimes:
                def _run_actor(actor=lane_runtime.control_actor, errs=self._actor_errors, idx=len(self._actor_errors)):
                    try:
                        actor.start()
                    except BaseException as exc:
                        errs[idx] = exc
                self._actor_errors.append(None)
                t = threading.Thread(
                    target=_run_actor,
                    name="simv2-core%d-%s-actor" % (self.core_idx, lane_runtime.lane_name),
                    daemon=False,
                )
                self._actor_threads.append(t)
                t.start()
        else:
            for lane_runtime in self.lane_runtimes:
                lane_runtime.control_actor.start()
        self.state = CoreRuntimeState.RUNNING

    def join(self) -> None:
        if self._needs_concurrent:
            # Wait for all ControlActor threads to complete
            for t in getattr(self, "_actor_threads", []):
                t.join()
            # Re-raise the first actor error if any
            for err in getattr(self, "_actor_errors", []):
                if err is not None:
                    raise err
            self.worker_pool.join()
            self.executed_tasks = self.worker_pool.executed_tasks()
        else:
            for lane_runtime in self.lane_runtimes:
                lane_runtime.control_actor.join()
            self.worker_pool.join()
            self.executed_tasks = self.worker_pool.executed_tasks()
        if self.state == CoreRuntimeState.RUNNING:
            self.state = CoreRuntimeState.STOPPED
        if self.trace_recorder is not None:
            self.trace_recorder.record_event(
                TraceEventKind.CONTROL,
                "core_stop",
                args={"completed_tasks": self.completed_task_count()},
            )

    def terminate(self) -> None:
        for lane_runtime in self.lane_runtimes:
            lane_runtime.control_actor.terminate()
        self.worker_pool.terminate()
        self.state = CoreRuntimeState.STOPPED

    def lane_names(self) -> List[str]:
        return [lane_runtime.lane_name for lane_runtime in self.lane_runtimes]

    def completed_task_count(self) -> int:
        return len(self.executed_tasks)

    def shared_tensor_ids(self) -> List[str]:
        return sorted(handle.tensor_id for handle in self.tensor_store.values())

    def workspace_tensor_ids(self) -> List[str]:
        return sorted(
            handle.tensor_id
            for handle in self.tensor_store.values()
            if handle.spec.role == "workspace"
        )

    def trace_events(self) -> List[TraceEvent]:
        if self.trace_recorder is None:
            return []
        return self.trace_recorder.snapshot()

    def execution_plan_dict(self) -> dict:
        if self.execution_plan is None:
            return {}
        return self.execution_plan.to_dict()
