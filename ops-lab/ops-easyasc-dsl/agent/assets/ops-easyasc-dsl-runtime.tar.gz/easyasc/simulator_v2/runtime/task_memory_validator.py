# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from typing import Any
from typing import Dict
from typing import Optional
from typing import Tuple

import torch

from ... import globvars
from ..memory.shared_tensor import SharedTensorHandle
from ..ops.micro.runtime import MicroRuntime
from ..memory.shared_tensor_store import SharedTensorStore
from ..ops.vec.v import VPipeV2
from ..program.task import PipeTask


_VEC_DIRECT_UNARY_OPS = frozenset([
    "vec_v_abs", "vabs",
    "vec_v_exp", "exp",
    "vec_v_ln", "ln",
    "vec_v_rec", "rec",
    "vec_v_sqrt", "sqrt",
    "vec_v_rsqrt", "rsqrt",
    "vec_v_not", "vnot",
    "vec_v_relu",
])
_VEC_DIRECT_BINARY_OPS = frozenset([
    "vec_v_add", "add",
    "vec_v_sub", "sub",
    "vec_v_mul", "mul",
    "vec_v_div", "div",
    "vec_v_max", "vmax",
    "vec_v_min", "vmin",
    "vec_v_and", "vand",
    "vec_v_or", "vor",
    "muladddst", "vec_v_muladddst",
])
_VEC_DIRECT_SCALAR_OPS = frozenset([
    "vec_v_add_scalar", "adds",
    "vec_v_mul_scalar", "muls",
    "vmaxs", "vmins", "lrelu", "axpy",
])
_VEC_DIRECT_DUP_OPS = frozenset(["vec_v_dup", "dup"])
_VEC_DIRECT_COMPARE_OPS = frozenset(["vec_v_compare", "compare", "vec_v_compare_scalar", "compare_scalar"])
_VEC_DIRECT_SELECT_OPS = frozenset(["vec_v_select", "select"])
_VEC_DIRECT_GROUP_OPS = frozenset([
    "cmax", "cmin", "cadd", "cgmax", "cgmin", "cgadd",
    "vec_v_cmax", "vec_v_cmin", "vec_v_cadd",
    "vec_v_cgmax", "vec_v_cgmin", "vec_v_cgadd",
])
_VEC_DIRECT_BRCB_OPS = frozenset(["brcb", "vec_v_brcb"])
_VEC_DIRECT_CPADD_OPS = frozenset(["cpadd", "vec_v_cpadd"])
_VEC_MASK_OPS = frozenset(["set_mask", "reset_mask", "vec_v_set_mask", "vec_v_reset_mask"])
_VEC_LEGACY_UNARY_OPS = frozenset(["abs", "exp", "ln", "rec", "sqrt", "rsqrt", "relu", "vnot"])
_VEC_LEGACY_BINARY_OPS = frozenset(["add", "sub", "mul", "div", "vmax", "vmin", "vand", "vor", "muladddst"])
_VEC_LEGACY_SCALAR_OPS = frozenset(["adds", "muls", "vmaxs", "vmins", "lrelu", "axpy"])
_VEC_LEGACY_GROUP_OPS = frozenset(["cmax", "cmin", "cadd", "cgmax", "cgmin", "cgadd"])


def _resolve_int(value: Any, label: str) -> int:
    if isinstance(value, bool):
        return int(value)
    if not isinstance(value, (int, float)):
        raise TypeError(label + " must resolve to int/float, got: " + str(type(value)))
    return int(value)


def _align16(value: int) -> int:
    return ((value + 15) // 16) * 16


def _align32(value: int) -> int:
    return ((value + 31) // 32) * 32


def _align_to(value: int, alignment: int) -> int:
    if alignment <= 0:
        return int(value)
    return ((int(value) + alignment - 1) // alignment) * alignment


def _span_for_repeated_region(count: int, step: int, payload: int) -> int:
    if count <= 0 or payload <= 0:
        return 0
    return (int(count) - 1) * int(step) + int(payload)


def _span_for_strided_rows(rows: int, row_pitch: int, active_cols: int) -> int:
    if rows <= 0 or active_cols <= 0:
        return 0
    return (int(rows) - 1) * int(row_pitch) + int(active_cols)


def _available_pointer_bytes(tensor: torch.Tensor, label: str) -> int:
    elem_size = int(tensor.element_size())
    if elem_size <= 0:
        raise ValueError(label + " tensor element size must be positive, got: " + str(elem_size))
    storage_elems = int(tensor.untyped_storage().nbytes()) // elem_size
    available_elems = storage_elems - int(tensor.storage_offset())
    if available_elems < 0:
        raise MemoryError(
            label
            + " tensor storage offset exceeds storage capacity: "
            + "offset="
            + str(int(tensor.storage_offset()))
            + ", storage_elems="
            + str(storage_elems)
        )
    return available_elems * elem_size


def _total_storage_bytes(tensor: torch.Tensor, label: str) -> int:
    elem_size = int(tensor.element_size())
    if elem_size <= 0:
        raise ValueError(label + " tensor element size must be positive, got: " + str(elem_size))
    storage_elems = int(tensor.untyped_storage().nbytes()) // elem_size
    return storage_elems * elem_size


def _local_context_suffix(tensor_store: SharedTensorStore, tensor_name: str) -> str:
    alloc = tensor_store.local_allocation(tensor_name)
    if alloc is None:
        return ""
    return (
        ", bank="
        + str(alloc.bank_name)
        + ", alloc_offset="
        + str(int(alloc.offset_bytes))
        + ", alloc_size="
        + str(int(alloc.size_bytes))
    )


def _validate_tensor_region(
    tensor_store: SharedTensorStore,
    tensor_name: str,
    need_bytes: int,
    opname: str,
    operand: str,
    use_total_storage: bool = False,
) -> None:
    tensor = tensor_store.tensor(str(tensor_name))
    if not isinstance(tensor, torch.Tensor):
        raise TypeError(
            "task memory validation requires torch.Tensor for "
            + opname
            + " "
            + operand
            + ", got: "
            + str(type(tensor))
        )
    if use_total_storage:
        have_bytes = _total_storage_bytes(tensor, opname + " " + operand)
    else:
        have_bytes = _available_pointer_bytes(tensor, opname + " " + operand)
    if int(need_bytes) > int(have_bytes):
        raise MemoryError(
            "task memory validation failed for "
            + opname
            + " "
            + operand
            + ": tensor="
            + str(tensor_name)
            + ", need="
            + str(int(need_bytes))
            + " bytes, have="
            + str(int(have_bytes))
            + " bytes"
            + _local_context_suffix(tensor_store, str(tensor_name))
        )


def _resolve_tensor_ref(tensor_store: SharedTensorStore, ref: Any, opname: str, operand: str) -> Tuple[str, torch.Tensor]:
    if isinstance(ref, SharedTensorHandle):
        tensor = tensor_store.resolve_handle(ref)
        name = str(ref.tensor_id)
    elif isinstance(ref, dict) and "tensor_id" in ref:
        name = str(ref["tensor_id"])
        tensor = tensor_store.tensor(name)
    elif isinstance(ref, str):
        name = str(ref)
        tensor = tensor_store.tensor(name)
    else:
        raise TypeError(
            "task memory validation requires tensor ref for "
            + opname
            + " "
            + operand
            + ", got: "
            + str(type(ref))
        )
    if not isinstance(tensor, torch.Tensor):
        raise TypeError(
            "task memory validation requires torch.Tensor for "
            + opname
            + " "
            + operand
            + ", got: "
            + str(type(tensor))
        )
    return name, tensor


def _validate_tensor_ref_region(
    tensor_store: SharedTensorStore,
    ref: Any,
    need_elems: int,
    opname: str,
    operand: str,
    use_total_storage: bool = False,
) -> None:
    name, tensor = _resolve_tensor_ref(tensor_store, ref, opname, operand)
    _validate_tensor_region(
        tensor_store,
        name,
        int(need_elems) * int(tensor.element_size()),
        opname,
        operand,
        use_total_storage=use_total_storage,
    )


def _tensor_numel(tensor: torch.Tensor) -> int:
    return int(tensor.numel())


def _vec_calc_need(repeat: int, rep_stride: int, blk_stride: int, elems_per_block: int) -> int:
    if repeat <= 0:
        return 0
    max_block_idx = (int(repeat) - 1) * int(rep_stride) + 7 * int(blk_stride)
    return (max_block_idx + 1) * int(elems_per_block)


def _vec_elems_per_block(tensor: torch.Tensor, opname: str, operand: str) -> int:
    elem_size = int(tensor.element_size())
    if elem_size <= 0 or (32 % elem_size) != 0:
        raise ValueError(
            opname
            + " unsupported "
            + operand
            + " element size for 32-byte datablock: "
            + str(elem_size)
        )
    return 32 // elem_size


def _resolve_vec_layout_args(task: PipeTask, *labels: str) -> Tuple[int, Dict[str, int]]:
    repeat = _resolve_int(task.args.get("repeat"), task.opname + " repeat")
    strides = {}
    for label in labels:
        value = _resolve_int(task.args.get(label), task.opname + " " + label)
        if value < 0:
            raise ValueError(task.opname + " requires non-negative " + label + ", got: " + str(value))
        strides[str(label)] = int(value)
    if repeat < 0:
        raise ValueError(task.opname + " requires non-negative repeat, got: " + str(repeat))
    return int(repeat), strides


def _validate_whole_tensor_ref(tensor_store: SharedTensorStore, ref: Any, opname: str, operand: str) -> None:
    name, tensor = _resolve_tensor_ref(tensor_store, ref, opname, operand)
    _validate_tensor_region(
        tensor_store,
        name,
        _tensor_numel(tensor) * int(tensor.element_size()),
        opname,
        operand,
    )


def _ceil_div(value: int, divisor: int) -> int:
    if divisor <= 0:
        raise ValueError("divisor must be positive, got: " + str(divisor))
    if value <= 0:
        return 0
    return (int(value) + int(divisor) - 1) // int(divisor)


def _validate_gm_to_ub_pad(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    n_burst = _resolve_int(task.args.get("n_burst"), "gm_to_ub_pad n_burst")
    burst_len_byte = _resolve_int(task.args.get("burst_len_byte"), "gm_to_ub_pad burst_len_byte")
    src_stride_byte = _resolve_int(task.args.get("src_stride_byte"), "gm_to_ub_pad src_stride_byte")
    dst_stride = _resolve_int(task.args.get("dst_stride"), "gm_to_ub_pad dst_stride")
    if n_burst < 0 or burst_len_byte < 0 or src_stride_byte < 0 or dst_stride < 0:
        return
    dst_stride_byte = dst_stride * 32
    aligned_burst_len_byte = _align32(burst_len_byte)
    src_step = burst_len_byte + src_stride_byte
    dst_step = aligned_burst_len_byte + dst_stride_byte
    src_need = _span_for_repeated_region(n_burst, src_step, burst_len_byte)
    dst_need = _span_for_repeated_region(n_burst, dst_step, burst_len_byte)
    _validate_tensor_region(tensor_store, str(task.args["src"]), src_need, task.opname, "src")
    _validate_tensor_region(tensor_store, str(task.args["dst"]), dst_need, task.opname, "dst")


def _validate_ub_to_gm_pad(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    n_burst = _resolve_int(task.args.get("n_burst"), "ub_to_gm_pad n_burst")
    burst_len_byte = _resolve_int(task.args.get("burst_len_byte"), "ub_to_gm_pad burst_len_byte")
    dst_stride_byte = _resolve_int(task.args.get("dst_stride_byte"), "ub_to_gm_pad dst_stride_byte")
    src_stride = _resolve_int(task.args.get("src_stride"), "ub_to_gm_pad src_stride")
    if n_burst < 0 or burst_len_byte < 0 or dst_stride_byte < 0 or src_stride < 0:
        return
    src_stride_byte = src_stride * 32
    aligned_burst_len_byte = _align32(burst_len_byte)
    src_step = aligned_burst_len_byte + src_stride_byte
    dst_step = burst_len_byte + dst_stride_byte
    src_need = _span_for_repeated_region(n_burst, src_step, burst_len_byte)
    dst_need = _span_for_repeated_region(n_burst, dst_step, burst_len_byte)
    _validate_tensor_region(tensor_store, str(task.args["src"]), src_need, task.opname, "src")
    _validate_tensor_region(tensor_store, str(task.args["dst"]), dst_need, task.opname, "dst")


def _validate_ub_to_ub(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    n_burst = _resolve_int(task.args.get("n_burst"), "ub_to_ub n_burst")
    burst_len = _resolve_int(task.args.get("burst_len"), "ub_to_ub burst_len")
    src_stride = _resolve_int(task.args.get("src_stride"), "ub_to_ub src_stride")
    dst_stride = _resolve_int(task.args.get("dst_stride"), "ub_to_ub dst_stride")
    if n_burst < 0 or burst_len < 0 or src_stride < 0 or dst_stride < 0:
        return
    burst_len_byte = burst_len * 32
    src_step = burst_len_byte + src_stride * 32
    dst_step = burst_len_byte + dst_stride * 32
    src_need = _span_for_repeated_region(n_burst, src_step, burst_len_byte)
    dst_need = _span_for_repeated_region(n_burst, dst_step, burst_len_byte)
    _validate_tensor_region(tensor_store, str(task.args["src"]), src_need, task.opname, "src")
    _validate_tensor_region(tensor_store, str(task.args["dst"]), dst_need, task.opname, "dst")


def _validate_gm_to_l1_nd2nz(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    src_name = str(task.args["src"])
    dst_name = str(task.args["dst"])
    src_tensor = tensor_store.tensor(src_name)
    dst_tensor = tensor_store.tensor(dst_name)
    if not isinstance(src_tensor, torch.Tensor) or not isinstance(dst_tensor, torch.Tensor):
        return
    h = _resolve_int(task.args.get("M"), "gm_to_l1_nd2nz M")
    w = _resolve_int(task.args.get("N"), "gm_to_l1_nd2nz N")
    w_src = _resolve_int(task.args.get("N_src"), "gm_to_l1_nd2nz N_src")
    h_dst = _resolve_int(task.args.get("M_dst", h), "gm_to_l1_nd2nz M_dst")
    if h < 0 or w < 0 or w_src < 0 or h_dst < 0:
        return
    elem_size = int(dst_tensor.element_size())
    if elem_size <= 0 or (32 % elem_size) != 0:
        raise ValueError(
            "gm_to_l1_nd2nz unsupported dst element size for C0=32-byte layout: "
            + str(elem_size)
            + " bytes"
        )
    c0 = 32 // elem_size
    dst_need_elems = ((w + c0 - 1) // c0) * _align16(h_dst) * c0
    src_need_elems = _span_for_strided_rows(h, w_src, w)
    _validate_tensor_region(tensor_store, src_name, src_need_elems * int(src_tensor.element_size()), task.opname, "src")
    _validate_tensor_region(tensor_store, dst_name, dst_need_elems * elem_size, task.opname, "dst")


def _validate_l0c_to_gm_nz2nd(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    src_name = str(task.args["src"])
    dst_name = str(task.args["dst"])
    src_tensor = tensor_store.tensor(src_name)
    dst_tensor = tensor_store.tensor(dst_name)
    if not isinstance(src_tensor, torch.Tensor) or not isinstance(dst_tensor, torch.Tensor):
        return
    m = _resolve_int(task.args.get("M"), "l0c_to_gm_nz2nd M")
    n = _resolve_int(task.args.get("N"), "l0c_to_gm_nz2nd N")
    n_dst = _resolve_int(task.args.get("N_dst"), "l0c_to_gm_nz2nd N_dst")
    m_src = _resolve_int(task.args.get("M_src"), "l0c_to_gm_nz2nd M_src")
    if m < 0 or n < 0 or n_dst < 0 or m_src < 0:
        return
    src_need_elems = ((n + 15) // 16) * _align16(m_src) * 16
    dst_need_elems = _span_for_strided_rows(m, n_dst, n)
    _validate_tensor_region(
        tensor_store,
        src_name,
        src_need_elems * int(src_tensor.element_size()),
        task.opname,
        "src",
    )
    _validate_tensor_region(
        tensor_store,
        dst_name,
        dst_need_elems * int(dst_tensor.element_size()),
        task.opname,
        "dst",
    )


def _validate_l0c_to_l1(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    src_name = str(task.args["src"])
    dst_name = str(task.args["dst"])
    src_tensor = tensor_store.tensor(src_name)
    dst_tensor = tensor_store.tensor(dst_name)
    if not isinstance(src_tensor, torch.Tensor) or not isinstance(dst_tensor, torch.Tensor):
        return
    m = _resolve_int(task.args.get("M"), "l0c_to_l1 M")
    n = _resolve_int(task.args.get("N"), "l0c_to_l1 N")
    m_dst = _resolve_int(task.args.get("M_dst"), "l0c_to_l1 M_dst")
    m_src = _resolve_int(task.args.get("M_src"), "l0c_to_l1 M_src")
    if m < 0 or n < 0 or m_dst < 0 or m_src < 0:
        return
    src_need_elems = ((n + 15) // 16) * _align16(m_src) * 16
    elem_size = int(dst_tensor.element_size())
    if elem_size <= 0 or (32 % elem_size) != 0:
        raise ValueError(
            "l0c_to_l1 unsupported dst element size for C0=32-byte layout: "
            + str(elem_size)
            + " bytes"
        )
    c0_dst = 32 // elem_size
    dst_need_elems = ((n + c0_dst - 1) // c0_dst) * _align16(m_dst) * c0_dst
    _validate_tensor_region(tensor_store, src_name, src_need_elems * int(src_tensor.element_size()), task.opname, "src")
    _validate_tensor_region(tensor_store, dst_name, dst_need_elems * elem_size, task.opname, "dst")


def _resolve_dual_mode(value: Any) -> int:
    if isinstance(value, bool):
        mode = int(value)
    elif isinstance(value, (int, float)):
        mode = int(value)
    else:
        raise TypeError("dual_mode must resolve to int/float, got: " + str(type(value)))
    if mode not in (0, 1, 2):
        raise ValueError("dual_mode must be 0, 1, or 2, got: " + str(mode))
    return mode


def _validate_l0c_to_ub(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    src_name = str(task.args["src"])
    src_tensor = tensor_store.tensor(src_name)
    if not isinstance(src_tensor, torch.Tensor):
        return
    m = _resolve_int(task.args.get("M"), "l0c_to_ub M")
    n = _resolve_int(task.args.get("N"), "l0c_to_ub N")
    m_src = _resolve_int(task.args.get("M_src"), "l0c_to_ub M_src")
    dual_mode = _resolve_dual_mode(task.args.get("dual_mode", 1))
    if m < 0 or n < 0 or m_src < 0:
        return
    src_need_elems = ((n + 15) // 16) * _align16(m_src) * 16
    _validate_tensor_region(tensor_store, src_name, src_need_elems * int(src_tensor.element_size()), task.opname, "src")

    payload_elems = m * n
    if dual_mode == 1:
        if m % 2 != 0:
            raise ValueError("l0c_to_ub SPLITM mode requires even M, got: " + str(m))
        payload_elems = (m // 2) * n
    elif dual_mode == 2:
        if n % 2 != 0:
            raise ValueError("l0c_to_ub SPLITN mode requires even N, got: " + str(n))
        payload_elems = m * (n // 2)

    dst_vec0 = task.args.get("dst_vec0")
    dst_vec1 = task.args.get("dst_vec1")
    if isinstance(dst_vec0, str) and isinstance(dst_vec1, str):
        dst0_tensor = tensor_store.tensor(dst_vec0)
        dst1_tensor = tensor_store.tensor(dst_vec1)
        if isinstance(dst0_tensor, torch.Tensor):
            _validate_tensor_region(tensor_store, dst_vec0, payload_elems * int(dst0_tensor.element_size()), task.opname, "dst_vec0")
        if isinstance(dst1_tensor, torch.Tensor):
            _validate_tensor_region(tensor_store, dst_vec1, payload_elems * int(dst1_tensor.element_size()), task.opname, "dst_vec1")
        return

    dst_name = str(task.args["dst"])
    dst_tensor = tensor_store.tensor(dst_name)
    if not isinstance(dst_tensor, torch.Tensor):
        return
    _validate_tensor_region(tensor_store, dst_name, payload_elems * int(dst_tensor.element_size()), task.opname, "dst")


def _validate_ub_to_l1_nd2nz(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    src_name = str(task.args["src"])
    dst_name = str(task.args["dst"])
    src_tensor = tensor_store.tensor(src_name)
    dst_tensor = tensor_store.tensor(dst_name)
    if not isinstance(src_tensor, torch.Tensor) or not isinstance(dst_tensor, torch.Tensor):
        return
    m_dst = _resolve_int(task.args.get("m_dst"), "ub_to_l1_nd2nz m_dst")
    n_dst = _resolve_int(task.args.get("n_dst"), "ub_to_l1_nd2nz n_dst")
    m_src = _resolve_int(task.args.get("m_src"), "ub_to_l1_nd2nz m_src")
    n_src = _resolve_int(task.args.get("n_src"), "ub_to_l1_nd2nz n_src")
    if m_dst < 0 or n_dst < 0 or m_src < 0 or n_src < 0:
        return
    elem_size = int(dst_tensor.element_size())
    if elem_size <= 0 or (32 % elem_size) != 0:
        raise ValueError(
            "ub_to_l1_nd2nz unsupported dst element size for C0=32-byte layout: "
            + str(elem_size)
            + " bytes"
        )
    c0 = 32 // elem_size
    block_count = (n_src + c0 - 1) // c0
    src_need_elems = m_src * n_src
    dst_need_elems = _span_for_repeated_region(block_count, _align16(m_dst) * c0, m_src * c0)
    _validate_tensor_region(tensor_store, src_name, src_need_elems * int(src_tensor.element_size()), task.opname, "src")
    _validate_tensor_region(tensor_store, dst_name, dst_need_elems * elem_size, task.opname, "dst")


def _validate_ub_to_l1_nz(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    src_name = str(task.args["src"])
    dst_name = str(task.args["dst"])
    src_tensor = tensor_store.tensor(src_name)
    dst_tensor = tensor_store.tensor(dst_name)
    if not isinstance(src_tensor, torch.Tensor) or not isinstance(dst_tensor, torch.Tensor):
        return
    m_dst = _resolve_int(task.args.get("m_dst"), "ub_to_l1_nz m_dst")
    n_dst = _resolve_int(task.args.get("n_dst"), "ub_to_l1_nz n_dst")
    m_src = _resolve_int(task.args.get("m_src"), "ub_to_l1_nz m_src")
    n_src = _resolve_int(task.args.get("n_src"), "ub_to_l1_nz n_src")
    if m_dst < 0 or n_dst < 0 or m_src < 0 or n_src < 0:
        return
    elem_size = int(dst_tensor.element_size())
    if elem_size <= 0 or (32 % elem_size) != 0:
        raise ValueError(
            "ub_to_l1_nz unsupported dst element size for C0=32-byte layout: "
            + str(elem_size)
            + " bytes"
        )
    c0 = 32 // elem_size
    block_count = (n_src + c0 - 1) // c0
    copy_len_per_block = m_src * c0
    src_need_elems = block_count * copy_len_per_block
    dst_need_elems = _span_for_repeated_region(block_count, _align16(m_dst) * c0, copy_len_per_block)
    _validate_tensor_region(tensor_store, src_name, src_need_elems * int(src_tensor.element_size()), task.opname, "src")
    _validate_tensor_region(tensor_store, dst_name, dst_need_elems * elem_size, task.opname, "dst")


def _validate_set_constant_to_l1(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    tensor_name = task.args.get("tensor", task.args.get("dst"))
    if tensor_name is None:
        return
    tensor_name = str(tensor_name)
    tensor = tensor_store.tensor(tensor_name)
    if not isinstance(tensor, torch.Tensor):
        return
    n_blocks = _resolve_int(task.args.get("n_blocks"), "set_constant_to_l1 n_blocks")
    if n_blocks < 0:
        return
    elem_size = int(tensor.element_size())
    if elem_size <= 0 or (32 % elem_size) != 0:
        raise ValueError(
            "set_constant_to_l1 unsupported tensor element size for 32-byte block layout: "
            + str(elem_size)
        )
    c0 = 32 // elem_size
    need_elems = n_blocks * c0
    _validate_tensor_region(tensor_store, tensor_name, need_elems * elem_size, task.opname, "dst")


def _layout_name(value: Any, default: str) -> str:
    if value is None:
        return default
    return str(value).upper()


def _validate_l1_to_l0(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    src_name = str(task.args["src"])
    dst_name = str(task.args["dst"])
    src_tensor = tensor_store.tensor(src_name)
    dst_tensor = tensor_store.tensor(dst_name)
    if not isinstance(src_tensor, torch.Tensor) or not isinstance(dst_tensor, torch.Tensor):
        return
    m_dst = _resolve_int(task.args.get("m_dst"), "l1_to_l0 m_dst")
    n_dst = _resolve_int(task.args.get("n_dst"), "l1_to_l0 n_dst")
    m_src = _resolve_int(task.args.get("m_src"), "l1_to_l0 m_src")
    n_src = _resolve_int(task.args.get("n_src"), "l1_to_l0 n_src")
    src_is_transpose = bool(task.args.get("src_is_transpose", False))
    src_layout = _layout_name(task.args.get("src_layout"), "NZ")
    dst_layout = _layout_name(task.args.get("dst_layout"), "ZN" if src_is_transpose else "NZ")
    src_row0 = _resolve_int(task.args.get("src_row0", 0), "l1_to_l0 src_row0")
    src_col0 = _resolve_int(task.args.get("src_col0", 0), "l1_to_l0 src_col0")
    if m_dst < 0 or n_dst < 0 or m_src < 0 or n_src < 0 or src_row0 < 0 or src_col0 < 0:
        return
    required_src_rows = src_row0 + m_dst if m_dst > 0 else src_row0
    required_src_cols = src_col0 + n_dst if n_dst > 0 else src_col0
    if required_src_rows > m_src or required_src_cols > n_src:
        return

    elem_size = int(dst_tensor.element_size())
    if elem_size <= 0 or (32 % elem_size) != 0:
        raise ValueError(
            "l1_to_l0 unsupported dst element size for C0=32-byte layout: "
            + str(elem_size)
            + " bytes"
        )
    c0 = 32 // elem_size
    device_type = str(getattr(globvars, "device_type", "")).lower()
    dst_position = str(task.args.get("dst_position", ""))
    src_position = str(task.args.get("src_position", ""))
    use_zz_src = device_type.startswith("b") and src_position == "L1" and src_tensor.dtype == torch.float32
    use_zz_dst = device_type.startswith("b") and dst_position == "L0A"
    src_n_align = _align_to(n_src, c0)

    src_use_total_storage = False
    if use_zz_src or src_layout == "ZZ":
        src_need_elems = ((m_src + 15) // 16) * src_n_align * 16
    else:
        src_need_elems = ((n_src + c0 - 1) // c0) * _align16(m_src) * c0
        src_use_total_storage = int(src_tensor.storage_offset()) > 0
    _validate_tensor_region(
        tensor_store,
        src_name,
        src_need_elems * int(src_tensor.element_size()),
        task.opname,
        "src",
        use_total_storage=src_use_total_storage,
    )

    if not src_is_transpose and use_zz_dst:
        dst_need_elems = ((m_dst + 15) // 16) * _align_to(n_dst, c0) * 16
    elif src_is_transpose:
        if use_zz_dst or dst_layout == "ZZ":
            out_rows = n_dst
            out_cols = m_dst
            dst_need_elems = ((out_rows + 15) // 16) * _align_to(out_cols, c0) * 16
        else:
            row_block = 32 if elem_size == 1 else 16
            n_align = _align_to(n_dst, 32 if elem_size == 1 else c0)
            m_blocks = (m_dst + row_block - 1) // row_block
            dst_need_elems = m_blocks * row_block * n_align
    elif dst_layout == "ZZ":
        dst_need_elems = ((m_dst + 15) // 16) * _align_to(n_dst, c0) * 16
    else:
        dst_need_elems = ((n_dst + c0 - 1) // c0) * _align16(m_dst) * c0

    _validate_tensor_region(
        tensor_store,
        dst_name,
        dst_need_elems * elem_size,
        task.opname,
        "dst",
    )


def _validate_mmad(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    dst_name = str(task.args["dst"])
    src_a_name = str(task.args["src_a"])
    src_b_name = str(task.args["src_b"])
    dst_tensor = tensor_store.tensor(dst_name)
    src_a_tensor = tensor_store.tensor(src_a_name)
    src_b_tensor = tensor_store.tensor(src_b_name)
    if not isinstance(dst_tensor, torch.Tensor) or not isinstance(src_a_tensor, torch.Tensor) or not isinstance(src_b_tensor, torch.Tensor):
        return

    m = _resolve_int(task.args.get("M"), "mmad M")
    n = _resolve_int(task.args.get("N"), "mmad N")
    k = _resolve_int(task.args.get("K"), "mmad K")
    dst_row0 = _resolve_int(task.args.get("dst_row0", 0), "mmad dst_row0")
    dst_col0 = _resolve_int(task.args.get("dst_col0", 0), "mmad dst_col0")
    dst_rows = _resolve_int(task.args.get("dst_rows", m), "mmad dst_rows")
    dst_cols = _resolve_int(task.args.get("dst_cols", n), "mmad dst_cols")
    if m < 0 or n < 0 or k < 0 or dst_row0 < 0 or dst_col0 < 0:
        return
    if dst_row0 + m > dst_rows or dst_col0 + n > dst_cols:
        return

    src_a_layout = _layout_name(task.args.get("src_a_layout"), "NZ")
    src_b_layout = _layout_name(task.args.get("src_b_layout"), "NZ")
    elem_a = int(src_a_tensor.element_size())
    elem_b = int(src_b_tensor.element_size())
    elem_dst = int(dst_tensor.element_size())
    if elem_a <= 0 or (32 % elem_a) != 0:
        raise ValueError("mmad unsupported src_a element size: " + str(elem_a))
    if elem_b <= 0 or (32 % elem_b) != 0:
        raise ValueError("mmad unsupported src_b element size: " + str(elem_b))
    if elem_dst <= 0:
        raise ValueError("mmad unsupported dst element size: " + str(elem_dst))

    c0_a = 32 // elem_a
    c0_b = 32 // elem_b
    c0_dst = 16
    device_type = str(getattr(globvars, "device_type", "")).lower()
    src_a_position = str(task.args.get("src_a_position", ""))
    use_b_device_zz_a = device_type.startswith("b") and src_a_position == "L0A"
    if use_b_device_zz_a or src_a_layout == "ZZ":
        need_src_a = ((m + 15) // 16) * _align_to(k, c0_a) * 16
    else:
        need_src_a = ((k + c0_a - 1) // c0_a) * _align16(m) * c0_a
    if src_b_layout == "ZZ":
        need_src_b = ((n + 15) // 16) * _align_to(k, c0_b) * 16
    else:
        need_src_b = ((k + c0_b - 1) // c0_b) * _align16(n) * c0_b
    need_dst = ((dst_cols + c0_dst - 1) // c0_dst) * _align16(dst_rows) * c0_dst

    _validate_tensor_region(tensor_store, src_a_name, need_src_a * elem_a, task.opname, "src_a")
    _validate_tensor_region(tensor_store, src_b_name, need_src_b * elem_b, task.opname, "src_b")
    _validate_tensor_region(tensor_store, dst_name, need_dst * elem_dst, task.opname, "dst")


def _validate_copy_like(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    _validate_whole_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    _validate_whole_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")


def _validate_fill_shared(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    _validate_whole_tensor_ref(tensor_store, task.args["tensor"], task.opname, "tensor")


def _validate_vec_whole_tensor_args(task: PipeTask, tensor_store: SharedTensorStore, operand_names: Tuple[str, ...]) -> None:
    for operand in operand_names:
        _validate_whole_tensor_ref(tensor_store, task.args[operand], task.opname, operand)


def _validate_vec_compare_nonrepeat(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    src1_name, src1 = _resolve_tensor_ref(tensor_store, task.args["src1"], task.opname, "src1")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    lhs_elems = _tensor_numel(src1)
    _validate_tensor_region(tensor_store, src1_name, lhs_elems * int(src1.element_size()), task.opname, "src1")
    if task.opname in ("vec_v_compare", "compare"):
        src2_name, src2 = _resolve_tensor_ref(tensor_store, task.args["src2"], task.opname, "src2")
        _validate_tensor_region(tensor_store, src2_name, _tensor_numel(src2) * int(src2.element_size()), task.opname, "src2")
    dst_need_elems = _ceil_div(lhs_elems, 8)
    _validate_tensor_region(tensor_store, dst_name, dst_need_elems * int(dst.element_size()), task.opname, "dst")


def _validate_vec_compare_repeat(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat = _resolve_int(task.args.get("repeat"), task.opname + " repeat")
    if repeat < 0:
        return
    src1_name, src1 = _resolve_tensor_ref(tensor_store, task.args["src1"], task.opname, "src1")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    src1_blk_stride = _resolve_int(task.args.get("src1_blk_stride"), task.opname + " src1_blk_stride")
    src1_rep_stride = _resolve_int(task.args.get("src1_rep_stride"), task.opname + " src1_rep_stride")
    if src1_blk_stride < 0 or src1_rep_stride < 0:
        return
    elems_per_block = _vec_elems_per_block(src1, task.opname, "src1")
    elems_per_repeat = elems_per_block * 8
    bytes_per_repeat = elems_per_repeat // 8
    src1_need = _vec_calc_need(repeat, src1_rep_stride, src1_blk_stride, elems_per_block)
    dst_need = repeat * bytes_per_repeat
    _validate_tensor_region(tensor_store, src1_name, src1_need * int(src1.element_size()), task.opname, "src1")
    _validate_tensor_region(tensor_store, dst_name, dst_need * int(dst.element_size()), task.opname, "dst")
    if task.opname in ("vec_v_compare", "compare"):
        src2_name, src2 = _resolve_tensor_ref(tensor_store, task.args["src2"], task.opname, "src2")
        src2_blk_stride = _resolve_int(task.args.get("src2_blk_stride"), task.opname + " src2_blk_stride")
        src2_rep_stride = _resolve_int(task.args.get("src2_rep_stride"), task.opname + " src2_rep_stride")
        if src2_blk_stride < 0 or src2_rep_stride < 0:
            return
        src2_need = _vec_calc_need(repeat, src2_rep_stride, src2_blk_stride, elems_per_block)
        _validate_tensor_region(tensor_store, src2_name, src2_need * int(src2.element_size()), task.opname, "src2")


def _validate_vec_select_nonrepeat(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    src1_name, src1 = _resolve_tensor_ref(tensor_store, task.args["src1"], task.opname, "src1")
    selmask_name, selmask = _resolve_tensor_ref(tensor_store, task.args["selmask"], task.opname, "selmask")
    src2_name, src2 = _resolve_tensor_ref(tensor_store, task.args["src2"], task.opname, "src2")
    n = _tensor_numel(src1)
    _validate_tensor_region(tensor_store, src1_name, n * int(src1.element_size()), task.opname, "src1")
    _validate_tensor_region(tensor_store, dst_name, n * int(dst.element_size()), task.opname, "dst")
    _validate_tensor_region(tensor_store, selmask_name, _ceil_div(n, 8) * int(selmask.element_size()), task.opname, "selmask")
    mode_name = _layout_name(task.args.get("mode"), "")
    src2_need = 1 if mode_name == "TENSOR_SCALAR" else _tensor_numel(src2)
    _validate_tensor_region(tensor_store, src2_name, src2_need * int(src2.element_size()), task.opname, "src2")


def _validate_vec_select_repeat(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat, strides = _resolve_vec_layout_args(
        task,
        "dst_blk_stride",
        "src1_blk_stride",
        "src2_blk_stride",
        "dst_rep_stride",
        "src1_rep_stride",
        "src2_rep_stride",
    )
    if repeat == 0:
        return
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    src1_name, src1 = _resolve_tensor_ref(tensor_store, task.args["src1"], task.opname, "src1")
    src2_name, src2 = _resolve_tensor_ref(tensor_store, task.args["src2"], task.opname, "src2")
    selmask_name, selmask = _resolve_tensor_ref(tensor_store, task.args["selmask"], task.opname, "selmask")
    elems_per_block = _vec_elems_per_block(src1, task.opname, "src1")
    elems_per_repeat = elems_per_block * 8
    dst_need = _vec_calc_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
    src1_need = _vec_calc_need(repeat, strides["src1_rep_stride"], strides["src1_blk_stride"], elems_per_block)
    mask_need = repeat * _ceil_div(elems_per_repeat, 8)
    _validate_tensor_region(tensor_store, dst_name, dst_need * int(dst.element_size()), task.opname, "dst")
    _validate_tensor_region(tensor_store, src1_name, src1_need * int(src1.element_size()), task.opname, "src1")
    _validate_tensor_region(tensor_store, selmask_name, mask_need * int(selmask.element_size()), task.opname, "selmask")
    mode_name = _layout_name(task.args.get("mode"), "")
    if mode_name != "TENSOR_SCALAR":
        src2_need = _vec_calc_need(repeat, strides["src2_rep_stride"], strides["src2_blk_stride"], elems_per_block)
        _validate_tensor_region(tensor_store, src2_name, src2_need * int(src2.element_size()), task.opname, "src2")
    else:
        _validate_tensor_region(tensor_store, src2_name, int(src2.element_size()), task.opname, "src2")


def _validate_vec_direct_group(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    _validate_tensor_region(tensor_store, src_name, _tensor_numel(src) * int(src.element_size()), task.opname, "src")
    if task.opname in ("cmax", "cmin", "cadd", "vec_v_cmax", "vec_v_cmin", "vec_v_cadd"):
        _validate_tensor_region(tensor_store, dst_name, int(dst.element_size()), task.opname, "dst")


def _validate_vec_direct_cpadd(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    _validate_tensor_region(tensor_store, src_name, _tensor_numel(src) * int(src.element_size()), task.opname, "src")
    if _tensor_numel(src) > 0:
        dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
        _validate_tensor_region(tensor_store, dst_name, int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_unary(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat, strides = _resolve_vec_layout_args(task, "dst_blk_stride", "src_blk_stride", "dst_rep_stride", "src_rep_stride")
    if repeat == 0:
        return
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    elems_per_block = _vec_elems_per_block(src, task.opname, "src")
    src_need = _vec_calc_need(repeat, strides["src_rep_stride"], strides["src_blk_stride"], elems_per_block)
    dst_need = _vec_calc_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
    _validate_tensor_region(tensor_store, src_name, src_need * int(src.element_size()), task.opname, "src")
    _validate_tensor_region(tensor_store, dst_name, dst_need * int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_binary(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat, strides = _resolve_vec_layout_args(
        task,
        "dst_blk_stride",
        "src1_blk_stride",
        "src2_blk_stride",
        "dst_rep_stride",
        "src1_rep_stride",
        "src2_rep_stride",
    )
    if repeat == 0:
        return
    src1_name, src1 = _resolve_tensor_ref(tensor_store, task.args["src1"], task.opname, "src1")
    src2_name, src2 = _resolve_tensor_ref(tensor_store, task.args["src2"], task.opname, "src2")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    elems_per_block = _vec_elems_per_block(dst, task.opname, "dst")
    src1_need = _vec_calc_need(repeat, strides["src1_rep_stride"], strides["src1_blk_stride"], elems_per_block)
    src2_need = _vec_calc_need(repeat, strides["src2_rep_stride"], strides["src2_blk_stride"], elems_per_block)
    dst_need = _vec_calc_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
    _validate_tensor_region(tensor_store, src1_name, src1_need * int(src1.element_size()), task.opname, "src1")
    _validate_tensor_region(tensor_store, src2_name, src2_need * int(src2.element_size()), task.opname, "src2")
    _validate_tensor_region(tensor_store, dst_name, dst_need * int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_scalar(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat, strides = _resolve_vec_layout_args(task, "dst_blk_stride", "src_blk_stride", "dst_rep_stride", "src_rep_stride")
    if repeat == 0:
        return
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    elems_per_block = _vec_elems_per_block(dst, task.opname, "dst")
    src_need = _vec_calc_need(repeat, strides["src_rep_stride"], strides["src_blk_stride"], elems_per_block)
    dst_need = _vec_calc_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
    _validate_tensor_region(tensor_store, src_name, src_need * int(src.element_size()), task.opname, "src")
    _validate_tensor_region(tensor_store, dst_name, dst_need * int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_dup(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat, strides = _resolve_vec_layout_args(task, "dst_blk_stride", "dst_rep_stride")
    if repeat == 0:
        return
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    elems_per_block = _vec_elems_per_block(dst, task.opname, "dst")
    dst_need = _vec_calc_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
    _validate_tensor_region(tensor_store, dst_name, dst_need * int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_brcb(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat, strides = _resolve_vec_layout_args(task, "dst_blk_stride", "dst_rep_stride")
    if repeat == 0:
        return
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    elems_per_block = _vec_elems_per_block(dst, task.opname, "dst")
    _validate_tensor_region(tensor_store, src_name, repeat * 8 * int(src.element_size()), task.opname, "src")
    dst_need = _vec_calc_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
    _validate_tensor_region(tensor_store, dst_name, dst_need * int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_cast(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat, strides = _resolve_vec_layout_args(task, "dst_blk_stride", "src_blk_stride", "dst_rep_stride", "src_rep_stride")
    if repeat == 0:
        return
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    dst_elem_size = int(dst.element_size())
    src_elem_size = int(src.element_size())
    dst_c0 = 32 // dst_elem_size
    src_c0 = 32 // src_elem_size
    elems_per_repeat_dst = strides["dst_rep_stride"] * dst_c0
    elems_per_repeat_src = strides["src_rep_stride"] * src_c0
    logical_elem_size = max(dst_elem_size, src_elem_size)
    logical_elems_per_repeat = elems_per_repeat_dst if dst_elem_size == logical_elem_size else elems_per_repeat_src
    if elems_per_repeat_dst != logical_elems_per_repeat or elems_per_repeat_src != logical_elems_per_repeat:
        return
    _validate_tensor_region(tensor_store, src_name, repeat * elems_per_repeat_src * src_elem_size, task.opname, "src")
    _validate_tensor_region(tensor_store, dst_name, repeat * elems_per_repeat_dst * dst_elem_size, task.opname, "dst")


def _validate_legacy_vec_group(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat, strides = _resolve_vec_layout_args(task, "dst_rep_stride", "src_blk_stride", "src_rep_stride")
    if repeat == 0:
        return
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    elems_per_block = _vec_elems_per_block(src, task.opname, "src")
    src_need = _vec_calc_need(repeat, strides["src_rep_stride"], strides["src_blk_stride"], elems_per_block)
    if task.opname in ("cmax", "cmin", "cadd"):
        dst_need_elems = (repeat - 1) * strides["dst_rep_stride"] + 1
    else:
        dst_need_elems = (repeat - 1) * strides["dst_rep_stride"] * 8 + 8
    _validate_tensor_region(tensor_store, src_name, src_need * int(src.element_size()), task.opname, "src")
    _validate_tensor_region(tensor_store, dst_name, dst_need_elems * int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_cpadd(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat, strides = _resolve_vec_layout_args(task, "dst_rep_stride", "src_blk_stride", "src_rep_stride")
    if repeat == 0:
        return
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    elems_per_block = _vec_elems_per_block(src, task.opname, "src")
    elems_per_repeat_src = elems_per_block * 8
    out_elems_per_repeat = elems_per_repeat_src // 2
    src_need = _vec_calc_need(repeat, strides["src_rep_stride"], strides["src_blk_stride"], elems_per_block)
    dst_need = (repeat - 1) * strides["dst_rep_stride"] * out_elems_per_repeat + out_elems_per_repeat
    _validate_tensor_region(tensor_store, src_name, src_need * int(src.element_size()), task.opname, "src")
    _validate_tensor_region(tensor_store, dst_name, dst_need * int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_sort32(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat = _resolve_int(task.args.get("repeat"), task.opname + " repeat")
    if repeat < 0:
        return
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    idx_name, idx = _resolve_tensor_ref(tensor_store, task.args["idx"], task.opname, "idx")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    _validate_tensor_region(tensor_store, src_name, repeat * 32 * int(src.element_size()), task.opname, "src")
    _validate_tensor_region(tensor_store, idx_name, repeat * 32 * int(idx.element_size()), task.opname, "idx")
    _validate_tensor_region(tensor_store, dst_name, repeat * 64 * int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_mergesort4(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    repeat = _resolve_int(task.args.get("repeat"), task.opname + " repeat")
    length_per_seq = _resolve_int(task.args.get("length_per_seq"), task.opname + " length_per_seq")
    if repeat < 0 or length_per_seq <= 0:
        return
    total_need = repeat * 8 * length_per_seq
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    _validate_tensor_region(tensor_store, src_name, total_need * int(src.element_size()), task.opname, "src")
    _validate_tensor_region(tensor_store, dst_name, total_need * int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_mergesort_2seq(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    size1 = _resolve_int(task.args.get("size1"), task.opname + " size1")
    size2 = _resolve_int(task.args.get("size2"), task.opname + " size2")
    if size1 <= 0 or size2 <= 0:
        return
    src1_name, src1 = _resolve_tensor_ref(tensor_store, task.args["src1"], task.opname, "src1")
    src2_name, src2 = _resolve_tensor_ref(tensor_store, task.args["src2"], task.opname, "src2")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    _validate_tensor_region(tensor_store, src1_name, 2 * size1 * int(src1.element_size()), task.opname, "src1")
    _validate_tensor_region(tensor_store, src2_name, 2 * size2 * int(src2.element_size()), task.opname, "src2")
    _validate_tensor_region(tensor_store, dst_name, 2 * (size1 + size2) * int(dst.element_size()), task.opname, "dst")


def _validate_legacy_vec_gather_scatter(task: PipeTask, tensor_store: SharedTensorStore, is_scatter: bool) -> None:
    repeat = _resolve_int(task.args.get("repeat"), task.opname + " repeat")
    start_idx = _resolve_int(task.args.get("start_idx", 0), task.opname + " start_idx")
    stride_label = "src_rep_stride" if is_scatter else "dst_rep_stride"
    rep_stride = _resolve_int(task.args.get(stride_label), task.opname + " " + stride_label)
    if repeat < 0 or start_idx < 0 or rep_stride < 0:
        return
    src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
    dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
    offset_name, offset = _resolve_tensor_ref(tensor_store, task.args["offset"], task.opname, "offset")
    elem_size = int(src.element_size())
    elems_per_repeat = _vec_elems_per_block(src, task.opname, "src") * 8
    offset_need = repeat * elems_per_repeat
    _validate_tensor_region(tensor_store, offset_name, offset_need * int(offset.element_size()), task.opname, "offset")
    if is_scatter:
        src_need = (repeat - 1) * rep_stride * (32 // elem_size) + elems_per_repeat if repeat > 0 else 0
        _validate_tensor_region(tensor_store, src_name, src_need * elem_size, task.opname, "src")
    else:
        dst_need = (repeat - 1) * rep_stride * (32 // elem_size) + elems_per_repeat if repeat > 0 else 0
        _validate_tensor_region(tensor_store, dst_name, dst_need * int(dst.element_size()), task.opname, "dst")
    offset_flat = offset.reshape(-1)
    src_limit = _tensor_numel(src)
    dst_limit = _tensor_numel(dst)
    for i in range(min(offset_need, _tensor_numel(offset))):
        byte_addr = start_idx + int(offset_flat[i].item())
        if elem_size > 0 and (byte_addr % elem_size) != 0:
            raise MemoryError(
                "task memory validation failed for "
                + task.opname
                + " offset: tensor="
                + offset_name
                + ", byte_addr="
                + str(byte_addr)
                + " is not aligned to elem_size="
                + str(elem_size)
            )
        index = byte_addr // elem_size if elem_size > 0 else 0
        if is_scatter:
            if index < 0 or index >= dst_limit:
                raise MemoryError(
                    "task memory validation failed for "
                    + task.opname
                    + " dst: tensor="
                    + dst_name
                    + ", index="
                    + str(index)
                    + ", have="
                    + str(dst_limit)
                )
        else:
            if index < 0 or index >= src_limit:
                raise MemoryError(
                    "task memory validation failed for "
                    + task.opname
                    + " src: tensor="
                    + src_name
                    + ", index="
                    + str(index)
                    + ", have="
                    + str(src_limit)
                )


def _validate_legacy_vec_task(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    normalized = VPipeV2._normalize_legacy_opname(task.opname)
    legacy_task = task if normalized == task.opname else PipeTask(pipe_name=task.pipe_name, opname=normalized, args=dict(task.args))
    if normalized in _VEC_LEGACY_UNARY_OPS:
        _validate_legacy_vec_unary(legacy_task, tensor_store)
        return
    if normalized in _VEC_LEGACY_BINARY_OPS:
        _validate_legacy_vec_binary(legacy_task, tensor_store)
        return
    if normalized in _VEC_LEGACY_SCALAR_OPS:
        _validate_legacy_vec_scalar(legacy_task, tensor_store)
        return
    if normalized == "dup":
        _validate_legacy_vec_dup(legacy_task, tensor_store)
        return
    if normalized == "brcb":
        _validate_legacy_vec_brcb(legacy_task, tensor_store)
        return
    if normalized == "cast":
        _validate_legacy_vec_cast(legacy_task, tensor_store)
        return
    if normalized in _VEC_LEGACY_GROUP_OPS:
        _validate_legacy_vec_group(legacy_task, tensor_store)
        return
    if normalized == "cpadd":
        _validate_legacy_vec_cpadd(legacy_task, tensor_store)
        return
    if normalized == "sort32":
        _validate_legacy_vec_sort32(legacy_task, tensor_store)
        return
    if normalized == "mergesort4":
        _validate_legacy_vec_mergesort4(legacy_task, tensor_store)
        return
    if normalized == "mergesort_2seq":
        _validate_legacy_vec_mergesort_2seq(legacy_task, tensor_store)
        return
    if normalized == "gather":
        _validate_legacy_vec_gather_scatter(legacy_task, tensor_store, is_scatter=False)
        return
    if normalized == "scatter":
        _validate_legacy_vec_gather_scatter(legacy_task, tensor_store, is_scatter=True)
        return
    if normalized == "ub_to_ub":
        _validate_ub_to_ub(legacy_task, tensor_store)


def _validate_v_task(task: PipeTask, tensor_store: SharedTensorStore) -> None:
    if task.opname in _VEC_MASK_OPS:
        return
    if task.opname in _VEC_DIRECT_COMPARE_OPS:
        if "repeat" in task.args:
            _validate_vec_compare_repeat(task, tensor_store)
        else:
            _validate_vec_compare_nonrepeat(task, tensor_store)
        return
    if task.opname in _VEC_DIRECT_SELECT_OPS:
        if "repeat" in task.args:
            _validate_vec_select_repeat(task, tensor_store)
        else:
            _validate_vec_select_nonrepeat(task, tensor_store)
        return
    if VPipeV2._should_use_legacy_layout(task):
        _validate_legacy_vec_task(task, tensor_store)
        return
    if task.opname in _VEC_DIRECT_UNARY_OPS:
        _validate_vec_whole_tensor_args(task, tensor_store, ("src", "dst"))
        return
    if task.opname in _VEC_DIRECT_BINARY_OPS:
        _validate_vec_whole_tensor_args(task, tensor_store, ("src1", "src2", "dst"))
        return
    if task.opname in _VEC_DIRECT_SCALAR_OPS:
        _validate_vec_whole_tensor_args(task, tensor_store, ("src", "dst"))
        return
    if task.opname in _VEC_DIRECT_DUP_OPS:
        _validate_vec_whole_tensor_args(task, tensor_store, ("dst",))
        return
    if task.opname in _VEC_DIRECT_GROUP_OPS:
        _validate_vec_direct_group(task, tensor_store)
        return
    if task.opname in _VEC_DIRECT_BRCB_OPS:
        _validate_vec_whole_tensor_args(task, tensor_store, ("src", "dst"))
        return
    if task.opname in _VEC_DIRECT_CPADD_OPS:
        _validate_vec_direct_cpadd(task, tensor_store)


def _validate_micro_dispatch_task(
    task: PipeTask,
    tensor_store: SharedTensorStore,
    micro_runtime: Optional[MicroRuntime],
) -> None:
    if task.opname == "micro_load_shared_to_reg":
        src_name, src = _resolve_tensor_ref(tensor_store, task.args["src"], task.opname, "src")
        index = int(task.args.get("index", 0))
        if index < 0:
            return
        if "count" in task.args:
            count = int(task.args.get("count", 1))
            if count < 0:
                return
            need_elems = index + count
        elif "index" in task.args:
            need_elems = index + 1
        else:
            need_elems = _tensor_numel(src)
        _validate_tensor_region(tensor_store, src_name, need_elems * int(src.element_size()), task.opname, "src")
        return
    if task.opname == "micro_store_reg_to_shared":
        dst_name, dst = _resolve_tensor_ref(tensor_store, task.args["dst"], task.opname, "dst")
        index = int(task.args.get("index", 0))
        if index < 0:
            return
        if "count" in task.args:
            count = int(task.args.get("count", 0))
            if count < 0:
                return
            need_elems = index + count
        elif "index" in task.args:
            need_elems = index + 1
        else:
            need_elems = _tensor_numel(dst)
        _validate_tensor_region(tensor_store, dst_name, need_elems * int(dst.element_size()), task.opname, "dst")
        if micro_runtime is None:
            return
        reg_name = str(task.args["reg"])
        if reg_name not in micro_runtime.bindings:
            return
        value = micro_runtime.bindings[reg_name]
        if isinstance(value, torch.Tensor) and "count" in task.args:
            count = int(task.args.get("count", int(value.numel())))
            if count > int(value.numel()):
                raise MemoryError(
                    "task memory validation failed for "
                    + task.opname
                    + " reg: reg="
                    + reg_name
                    + ", need="
                    + str(count)
                    + " elems, have="
                    + str(int(value.numel()))
                )
        return
    if task.opname == "call_micro":
        micro_def = task.args.get("micro_def")
        if micro_def is None:
            return
        tensor_views = task.args.get("tensor_views", {})
        if not isinstance(tensor_views, dict):
            raise TypeError("call_micro tensor_views must be dict, got: " + str(type(tensor_views)))
        cloned_views = {}
        for name, value in tensor_views.items():
            if not isinstance(value, torch.Tensor):
                raise TypeError("call_micro tensor view must be torch.Tensor, got: " + str(type(value)))
            cloned_views[str(name)] = value.clone()
        temp_runtime = MicroRuntime()
        try:
            temp_runtime.execute_call_micro(
                micro_def,
                cloned_views,
                dict(task.args.get("var_values", {})),
                tensor_store,
            )
        except (MemoryError, ValueError, TypeError, KeyError) as exc:
            raise MemoryError("task memory validation failed for call_micro: " + str(exc))


def validate_pipe_task_memory(
    task: PipeTask,
    tensor_store: Optional[SharedTensorStore],
    micro_runtime: Optional[MicroRuntime] = None,
) -> None:
    if tensor_store is None:
        return
    if task.opname == "vec_mte2_load" or task.opname == "vec_mte3_store":
        _validate_copy_like(task, tensor_store)
        return
    if task.opname.startswith("micro_") or task.opname == "call_micro":
        _validate_micro_dispatch_task(task, tensor_store, micro_runtime)
        if task.opname == "call_micro":
            return
    if task.opname == "fill_shared":
        _validate_fill_shared(task, tensor_store)
        return
    if task.opname == "copy_shared":
        _validate_copy_like(task, tensor_store)
        return
    if task.opname == "gm_to_ub_pad":
        _validate_gm_to_ub_pad(task, tensor_store)
        return
    if task.opname == "gm_to_l1_nd2nz":
        _validate_gm_to_l1_nd2nz(task, tensor_store)
        return
    if task.opname == "ub_to_gm_pad":
        _validate_ub_to_gm_pad(task, tensor_store)
        return
    if task.opname == "ub_to_ub":
        _validate_ub_to_ub(task, tensor_store)
        return
    if task.opname == "ub_to_l1_nd2nz":
        _validate_ub_to_l1_nd2nz(task, tensor_store)
        return
    if task.opname == "ub_to_l1_nz":
        _validate_ub_to_l1_nz(task, tensor_store)
        return
    if task.opname == "set_constant_to_l1":
        _validate_set_constant_to_l1(task, tensor_store)
        return
    if task.opname == "l1_to_l0":
        _validate_l1_to_l0(task, tensor_store)
        return
    if task.opname == "mmad":
        _validate_mmad(task, tensor_store)
        return
    if task.opname == "l0c_to_gm_nz2nd":
        _validate_l0c_to_gm_nz2nd(task, tensor_store)
        return
    if task.opname == "l0c_to_l1":
        _validate_l0c_to_l1(task, tensor_store)
        return
    if task.opname == "l0c_to_ub":
        _validate_l0c_to_ub(task, tensor_store)
        return
    if task.opname == "cube_m_copy" or task.opname == "cube_m_scale":
        _validate_copy_like(task, tensor_store)
        return
    if task.pipe_name == "V":
        _validate_v_task(task, tensor_store)
