# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import time
from typing import Dict, List, Optional

from ..config import SimulatorV2Config
from ..memory.shared_tensor_store import SharedTensorStore
from ..program.kernel_program import KernelProgram
from ..sync.collective_sync import CollectiveSync
from ..trace.event_types import TraceEvent
from ..trace.merge import merge_trace_buffers
from ..trace.chrome import dump_chrome_trace as dump_v2_chrome_trace
from ..trace.chrome import export_chrome_trace
from .core_process import CoreProcess, CoreProcessState
from .execution_plan import ExecutionPlan, build_execution_plan


class GlobalRuntimeState(Enum):
    IDLE = "idle"
    PREPARED = "prepared"
    RUNNING = "running"
    STOPPED = "stopped"
    FAILED = "failed"


@dataclass
class GlobalRuntime:
    """Parent-process runtime coordinator for simulator V2."""

    config: SimulatorV2Config
    program: KernelProgram
    tensor_store: SharedTensorStore = field(default_factory=SharedTensorStore)
    collective_sync: CollectiveSync = field(default_factory=CollectiveSync)
    core_processes: List[CoreProcess] = field(default_factory=list)
    execution_plan: Optional[ExecutionPlan] = field(default=None, init=False)
    merged_trace: List[TraceEvent] = field(default_factory=list, init=False)
    state: GlobalRuntimeState = field(default=GlobalRuntimeState.IDLE, init=False)
    failure: str = field(default="", init=False)

    def _refresh_core_process_snapshots(self) -> None:
        tensor_snapshot = self.tensor_store.snapshot()
        collective_snapshot = self.collective_sync.shared_snapshot()
        for core_process in self.core_processes:
            core_process.tensor_snapshot = tensor_snapshot
            core_process.collective_snapshot = collective_snapshot

    def prepare(self) -> None:
        self.execution_plan = build_execution_plan(self.program, self.config)
        target_core_count = self.execution_plan.core_count
        self.tensor_store.auto_allocate = True
        self.tensor_store.prefer_shared_memory = True
        self.tensor_store.prepare(self.program)
        self.collective_sync.prepare_shared()
        if len(self.core_processes) != target_core_count:
            self.core_processes = [
                CoreProcess(
                    core_idx=i,
                    config=self.config,
                    program=self.program,
                    execution_plan=self.execution_plan,
                    collective_sync=self.collective_sync,
                )
                for i in range(target_core_count)
            ]
        else:
            for core_process in self.core_processes:
                core_process.execution_plan = self.execution_plan
                core_process.collective_sync = self.collective_sync
        self._refresh_core_process_snapshots()
        self.state = GlobalRuntimeState.PREPARED

    def run(self) -> None:
        if self.state != GlobalRuntimeState.PREPARED:
            self.prepare()
        else:
            self._refresh_core_process_snapshots()
        self.merged_trace = []
        self.state = GlobalRuntimeState.RUNNING
        try:
            for core_process in self.core_processes:
                core_process.start()
            deadline = time.monotonic() + float(self.config.execution_timeout_s)
            while True:
                running = []
                for core_process in self.core_processes:
                    if core_process.state == CoreProcessState.RUNNING:
                        core_process.join(timeout=0.0)
                    if core_process.state == CoreProcessState.RUNNING:
                        running.append(core_process)
                if not running:
                    break
                if time.monotonic() >= deadline:
                    timed_out = [cp.core_idx for cp in running]
                    for cp in self.core_processes:
                        cp.terminate()
                    self.state = GlobalRuntimeState.FAILED
                    self.failure = (
                        "execution timeout after "
                        + str(self.config.execution_timeout_s)
                        + "s: cores still running: "
                        + str(timed_out)
                    )
                    raise RuntimeError(self.failure)
                time.sleep(0.01)
            failures = [
                core_process for core_process in self.core_processes
                if core_process.state == CoreProcessState.FAILED
            ]
            if failures:
                for cp in self.core_processes:
                    if cp.state == CoreProcessState.RUNNING:
                        cp.terminate()
            self.merged_trace = merge_trace_buffers(
                [
                    [TraceEvent.from_dict(item) for item in core_process.trace_buffer()]
                    for core_process in self.core_processes
                ]
            )
            if failures:
                self.state = GlobalRuntimeState.FAILED
                self.failure = "\n\n".join(
                    "core "
                    + str(core_process.core_idx)
                    + " failed:\n"
                    + (core_process.failure or "unknown failure")
                    for core_process in failures
                )
                raise RuntimeError(self.failure)
        except Exception as exc:
            self.state = GlobalRuntimeState.FAILED
            if not self.failure:
                self.failure = str(exc)
            raise
        if self.state != GlobalRuntimeState.FAILED:
            self.state = GlobalRuntimeState.STOPPED

    def shutdown(self) -> None:
        for core_process in self.core_processes:
            core_process.terminate()
        self.tensor_store.clear()
        self.collective_sync.shutdown()
        self.state = GlobalRuntimeState.STOPPED

    def chrome_trace(self) -> Dict[str, object]:
        return export_chrome_trace(self.program.name, self.merged_trace)

    def dump_chrome_trace(self, trace_path: str) -> None:
        dump_v2_chrome_trace(trace_path, self.program.name, self.merged_trace)

    def summary(self) -> Dict[str, object]:
        return {
            "program": self.program.name,
            "core_count": len(self.core_processes),
            "state": self.state.value,
            "failure": self.failure,
            "trace_enabled": self.config.trace_enabled,
            "trace_event_count": len(self.merged_trace),
            "shared_tensors": self.tensor_store.summary(),
            "execution_plan": {} if self.execution_plan is None else self.execution_plan.to_dict(),
            "cores": [core_process.summary() for core_process in self.core_processes],
        }
