from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from ..config import SimulatorV2Config
from ..memory.shared_tensor_store import SharedTensorStore
from ..program.kernel_program import KernelProgram
from ..sync.collective_sync import CollectiveSync
from ..trace.event_types import TraceEvent
from ..trace.merge import merge_trace_buffers
from ..trace.chrome import dump_chrome_trace as dump_v2_chrome_trace
from ..trace.chrome import export_chrome_trace
from .core_process import CoreProcess, CoreProcessState
from .execution_plan import ExecutionPlan, build_execution_plan


class GlobalRuntimeState(Enum):
    IDLE = "idle"
    PREPARED = "prepared"
    RUNNING = "running"
    STOPPED = "stopped"
    FAILED = "failed"


@dataclass
class GlobalRuntime:
    """Parent-process runtime coordinator for simulator V2."""

    config: SimulatorV2Config
    program: KernelProgram
    tensor_store: SharedTensorStore = field(default_factory=SharedTensorStore)
    collective_sync: CollectiveSync = field(default_factory=CollectiveSync)
    core_processes: List[CoreProcess] = field(default_factory=list)
    execution_plan: Optional[ExecutionPlan] = field(default=None, init=False)
    merged_trace: List[TraceEvent] = field(default_factory=list, init=False)
    state: GlobalRuntimeState = field(default=GlobalRuntimeState.IDLE, init=False)
    failure: str = field(default="", init=False)

    def _refresh_core_process_snapshots(self) -> None:
        tensor_snapshot = self.tensor_store.snapshot()
        for core_process in self.core_processes:
            core_process.tensor_snapshot = tensor_snapshot

    def prepare(self) -> None:
        self.execution_plan = build_execution_plan(self.program, self.config)
        target_core_count = self.execution_plan.core_count
        self.tensor_store.auto_allocate = True
        self.tensor_store.prefer_shared_memory = True
        self.tensor_store.prepare(self.program)
        if len(self.core_processes) != target_core_count:
            self.core_processes = [
                CoreProcess(
                    core_idx=i,
                    config=self.config,
                    program=self.program,
                    execution_plan=self.execution_plan,
                    collective_sync=self.collective_sync,
                )
                for i in range(target_core_count)
            ]
        else:
            for core_process in self.core_processes:
                core_process.execution_plan = self.execution_plan
                core_process.collective_sync = self.collective_sync
        self._refresh_core_process_snapshots()
        self.state = GlobalRuntimeState.PREPARED

    def run(self) -> None:
        if self.state != GlobalRuntimeState.PREPARED:
            self.prepare()
        else:
            self._refresh_core_process_snapshots()
        self.merged_trace = []
        self.state = GlobalRuntimeState.RUNNING
        try:
            for core_process in self.core_processes:
                core_process.start()
            for core_process in self.core_processes:
                core_process.join(timeout=self.config.execution_timeout_s)
            timed_out = [
                cp for cp in self.core_processes
                if cp.state == CoreProcessState.RUNNING
            ]
            if timed_out:
                for cp in self.core_processes:
                    cp.terminate()
                self.state = GlobalRuntimeState.FAILED
                self.failure = "execution timeout after " + str(self.config.execution_timeout_s) + "s: cores still running: " + str([cp.core_idx for cp in timed_out])
                raise RuntimeError(self.failure)
            self.merged_trace = merge_trace_buffers(
                [
                    [TraceEvent.from_dict(item) for item in core_process.trace_buffer()]
                    for core_process in self.core_processes
                ]
            )
            failures = [
                core_process for core_process in self.core_processes
                if core_process.state == CoreProcessState.FAILED
            ]
            if failures:
                self.state = GlobalRuntimeState.FAILED
                self.failure = "\n\n".join(
                    "core "
                    + str(core_process.core_idx)
                    + " failed:\n"
                    + (core_process.failure or "unknown failure")
                    for core_process in failures
                )
                raise RuntimeError("one or more core processes failed")
        except Exception as exc:
            self.state = GlobalRuntimeState.FAILED
            if not self.failure:
                self.failure = str(exc)
            raise
        if self.state != GlobalRuntimeState.FAILED:
            self.state = GlobalRuntimeState.STOPPED

    def shutdown(self) -> None:
        for core_process in self.core_processes:
            core_process.terminate()
        self.tensor_store.clear()
        self.state = GlobalRuntimeState.STOPPED

    def chrome_trace(self) -> Dict[str, object]:
        return export_chrome_trace(self.program.name, self.merged_trace)

    def dump_chrome_trace(self, trace_path: str) -> None:
        dump_v2_chrome_trace(trace_path, self.program.name, self.merged_trace)

    def summary(self) -> Dict[str, object]:
        return {
            "program": self.program.name,
            "core_count": len(self.core_processes),
            "state": self.state.value,
            "failure": self.failure,
            "trace_enabled": self.config.trace_enabled,
            "trace_event_count": len(self.merged_trace),
            "shared_tensors": self.tensor_store.summary(),
            "execution_plan": {} if self.execution_plan is None else self.execution_plan.to_dict(),
            "cores": [core_process.summary() for core_process in self.core_processes],
        }
