from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
import traceback
import threading
from typing import List
from typing import Optional

from ..memory.shared_tensor_store import SharedTensorStore
from ..ops.micro.runtime import MicroRuntime
from ..ops.dispatch import build_pipe_executor, execute_pipe_task
from ..ops.pipe_base import PipeBaseV2
from ..program.kernel_program import KernelProgram
from ..program.task import PipeTask
from ..program.task import TaskStatus
from ..sync.collective_sync import CollectiveSync
from ..sync.intra_core_sync import IntraCoreSync
from ..sync.local_flags import LocalFlagTable
from ..sync.mailbox import Mailbox, MailboxMessage
from ..trace.event_types import TraceEventKind
from ..trace.recorder import TraceRecorderV2

_CROSS_LANE_READY_OPS = frozenset(["vec_ready", "cube_ready"])
_CROSS_LANE_WAIT_OPS = frozenset(["wait_vec", "wait_cube"])
_COLLECTIVE_READY_OPS = frozenset(["allcube_ready", "allvec_ready"])
_COLLECTIVE_WAIT_OPS = frozenset(["allcube_wait", "allvec_wait"])


@dataclass
class PipeWorker:
    """Worker that owns one logical pipe."""

    core_idx: int
    lane_name: str
    pipe_name: str
    program: KernelProgram
    mailbox: Mailbox = field(default_factory=Mailbox)
    tensor_store: Optional[SharedTensorStore] = None
    micro_runtime: Optional[MicroRuntime] = None
    sync: Optional[IntraCoreSync] = None
    collective_sync: Optional[CollectiveSync] = None
    local_flags: Optional[LocalFlagTable] = None
    trace_recorder: Optional[TraceRecorderV2] = None
    running: bool = field(default=False, init=False)
    last_task: Optional[PipeTask] = field(default=None, init=False)
    completed_tasks: int = field(default=0, init=False)
    failed_tasks: int = field(default=0, init=False)
    executed_tasks: List[PipeTask] = field(default_factory=list, init=False)
    thread_failure: Optional[str] = field(default=None, init=False)
    pipe_executor: Optional[PipeBaseV2] = field(default=None, init=False, repr=False)
    _thread: Optional[threading.Thread] = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        try:
            self.pipe_executor = build_pipe_executor(self.lane_name, self.pipe_name)
        except KeyError:
            self.pipe_executor = None

    def start(self) -> None:
        if self.running:
            return
        self.running = True
        self.thread_failure = None
        self._thread = threading.Thread(
            target=self._run_loop,
            name="simv2-core%s-%s-%s" % (self.core_idx, self.lane_name, self.pipe_name),
            daemon=True,
        )
        self._thread.start()

    def join(self) -> None:
        if self._thread is None:
            return
        self._thread.join()
        self._thread = None

    def terminate(self) -> None:
        self.running = False
        self.stop()

    def stop(self) -> None:
        self.mailbox.put_stop()

    def _run_loop(self) -> None:
        while self.running:
            try:
                task = self.poll_once(block=True, timeout=0.05)
            except BaseException:
                self.thread_failure = traceback.format_exc()
                self.running = False
                break
            if task is None:
                continue
            try:
                self.execute_task(task)
            except BaseException:
                self.thread_failure = traceback.format_exc()
                self.running = False
                break

    def poll_once(self, block: bool = False, timeout: Optional[float] = None) -> Optional[PipeTask]:
        message = self.mailbox.get(block=block, timeout=timeout)
        if message is None:
            return None
        # Handle stop sentinel
        if message == "stop" or (isinstance(message, str) and message == "stop"):
            self.running = False
            return None
        # Backward compat: unwrap MailboxMessage if someone still sends one
        if isinstance(message, MailboxMessage):
            if message.kind == "stop":
                self.running = False
                return None
            message = message.payload
        if not isinstance(message, PipeTask):
            raise TypeError(
                "pipe worker payload must be PipeTask, got: " + str(type(message))
            )
        task = message
        task.status = TaskStatus.RUNNING
        self.last_task = task
        return task

    def execute_task(self, task: PipeTask) -> PipeTask:
        if not isinstance(task, PipeTask):
            raise TypeError("execute_task requires PipeTask, got: " + str(type(task)))
        if task.pipe_name != self.pipe_name:
            raise ValueError(
                "task pipe mismatch for worker " + self.pipe_name + ": " + task.pipe_name
            )
        try:
            import os
            if os.environ.get("SIMV2_DEBUG_TRACE"):
                import sys
                print("[worker %s/%s] exec %s args_keys=%s" % (self.lane_name, self.pipe_name, task.opname, list(task.args.keys())), file=sys.stderr, flush=True)
            if self.tensor_store is not None:
                execute_pipe_task(
                    task,
                    self.tensor_store,
                    lane_name=self.lane_name,
                    pipe_name=self.pipe_name,
                    micro_runtime=self.micro_runtime,
                    pipe_executor=self.pipe_executor,
                )
            if os.environ.get("SIMV2_DEBUG_TRACE"):
                import sys
                print("[worker %s/%s] done %s" % (self.lane_name, self.pipe_name, task.opname), file=sys.stderr, flush=True)
            # setflag: publish flag (error if already set)
            if task.opname == "setflag" and self.local_flags is not None:
                flag_key = task.args.get("flag_key", "")
                cur = self.local_flags.current(flag_key)
                consumed = self.local_flags.consumed_phase(flag_key)
                if cur > consumed:
                    raise RuntimeError(
                        "setflag: flag already set: " + flag_key
                        + " (current=" + str(cur) + ", consumed=" + str(consumed) + ")"
                    )
                self.local_flags.publish(flag_key)
            # waitflag: block pipe until flag ready, then consume
            if task.opname == "waitflag" and self.local_flags is not None:
                flag_key = task.args.get("flag_key", "")
                wait_timeout = task.args.get("timeout", 5.0)
                target_phase = self.local_flags.consumed_phase(flag_key) + 1
                if not self.local_flags.wait_for(flag_key, target_phase, timeout=wait_timeout):
                    diag = self.local_flags.timeout_diagnostic(flag_key, target_phase)
                    raise RuntimeError("waitflag timeout on pipe " + self.pipe_name + ": " + str(diag))
                if not self.local_flags.consume(flag_key, target_phase):
                    raise RuntimeError(
                        "waitflag failed to consume flag: " + flag_key
                        + " phase=" + str(target_phase)
                    )
            # Cross-lane wait: block pipe until flag ready, then consume
            if task.opname in _CROSS_LANE_WAIT_OPS and self.sync is not None:
                wait_timeout = task.args.get("timeout", 5.0)
                for name in task.args.get("sync_names", []):
                    target_phase = self.sync.consumed_phase(name) + 1
                    if not self.sync.wait_for(name, target_phase, timeout=wait_timeout):
                        diag = self.sync.timeout_diagnostic(name, target_phase)
                        raise RuntimeError(task.opname + " timeout on pipe " + self.pipe_name + ": " + str(diag))
                    if not self.sync.consume_wait(name, target_phase):
                        raise RuntimeError(
                            task.opname + " failed to consume intra-core token: "
                            + name + " phase=" + str(target_phase)
                        )
            # Collective wait: block pipe until all participants ready
            if task.opname in _COLLECTIVE_WAIT_OPS and self.collective_sync is not None:
                wait_timeout = task.args.get("timeout", 5.0)
                sync_name = task.args.get("sync_name", "")
                participant_idx = task.args.get("participant_idx", 0)
                snapshot = self.collective_sync.participant_snapshot(sync_name)
                wait_counts = snapshot.get("wait_counts", {})
                target_phase = int(wait_counts.get(participant_idx, 0)) + 1
                if not self.collective_sync.wait_for(sync_name, target_phase, timeout=wait_timeout):
                    diag = self.collective_sync.timeout_diagnostic(
                        sync_name, target_phase, participant_idx=participant_idx)
                    raise RuntimeError(task.opname + " timeout on pipe " + self.pipe_name + ": " + str(diag))
                if not self.collective_sync.consume_wait(sync_name, participant_idx):
                    raise RuntimeError(
                        task.opname + " failed to consume collective token: "
                        + sync_name + " participant=" + str(participant_idx)
                        + " phase=" + str(target_phase)
                    )
            task.status = TaskStatus.DONE
            task.error = None
            # Cross-lane ready: publish flag after task reaches this point
            if task.opname in _CROSS_LANE_READY_OPS and self.sync is not None:
                for name in task.args.get("sync_names", []):
                    self.sync.publish_ready(name)
            if task.opname in _COLLECTIVE_READY_OPS and self.collective_sync is not None:
                sync_name = task.args.get("sync_name", "")
                participant_idx = task.args.get("participant_idx", 0)
                self.collective_sync.publish_ready(sync_name, participant_idx=participant_idx)
            self.completed_tasks += 1
            self.executed_tasks.append(task)
            if self.trace_recorder is not None:
                self.trace_recorder.record_event(
                    TraceEventKind.PIPE,
                    "execute_task",
                    args={
                        "lane_name": self.lane_name,
                        "pipe_name": self.pipe_name,
                        "opname": task.opname,
                        "status": task.status.value,
                    },
                )
        except Exception as exc:
            task.status = TaskStatus.FAILED
            task.error = str(exc)
            self.failed_tasks += 1
            if self.trace_recorder is not None:
                self.trace_recorder.record_event(
                    TraceEventKind.PIPE,
                    "execute_task",
                    args={
                        "lane_name": self.lane_name,
                        "pipe_name": self.pipe_name,
                        "opname": task.opname,
                        "status": task.status.value,
                        "error": task.error,
                    },
                )
            raise
        self.last_task = task
        return task
