# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
import sys
import traceback
import threading
import time
from typing import List
from typing import Dict
from typing import Optional

from ... import globvars
from ..config import SimulatorV2Config
from ..memory.shared_tensor_store import SharedTensorStore
from ..ops.micro.runtime import MicroRuntime
from ..ops.dispatch import build_pipe_executor, execute_pipe_task
from ..ops.pipe_base import PipeBaseV2
from ..program.kernel_program import KernelProgram
from ..program.task import PipeTask
from ..program.task import TaskStatus
from ..sync.collective_sync import CollectiveSync
from ..sync.intra_core_sync import IntraCoreSync
from ..sync.local_events import LocalEventBank
from ..sync.local_flags import LocalFlagTable
from ..sync.mailbox import Mailbox, MailboxMessage
from ..timing import estimate_task_cycles, load_cycle_model_for_device
from ..trace.event_types import TraceEventKind
from ..trace.recorder import TraceRecorderV2
from .task_memory_validator import validate_pipe_task_memory

_CROSS_LANE_READY_OPS = frozenset(["vec_ready", "cube_ready"])
_CROSS_LANE_WAIT_OPS = frozenset(["wait_vec", "wait_cube"])
_COLLECTIVE_READY_OPS = frozenset(["allcube_ready", "allvec_ready"])
_COLLECTIVE_WAIT_OPS = frozenset(["allcube_wait", "allvec_wait"])
_LOCAL_EVENT_OPS = frozenset(["event_wait", "event_set", "event_setall", "event_release"])
_TRACEABLE_SYNC_OPS = frozenset([
    "event_wait", "event_set", "event_setall", "event_release",
    "setflag", "waitflag",
    "vec_ready", "cube_ready", "wait_vec", "wait_cube",
    "allcube_ready", "allcube_wait", "allvec_ready", "allvec_wait",
])


@dataclass
class PipeWorker:
    """Worker that owns one logical pipe."""

    core_idx: int
    lane_name: str
    pipe_name: str
    program: KernelProgram
    config: SimulatorV2Config = field(default_factory=SimulatorV2Config)
    mailbox: Mailbox = field(default_factory=Mailbox)
    tensor_store: Optional[SharedTensorStore] = None
    micro_runtime: Optional[MicroRuntime] = None
    sync: Optional[IntraCoreSync] = None
    collective_sync: Optional[CollectiveSync] = None
    local_flags: Optional[LocalFlagTable] = None
    local_events: Optional[LocalEventBank] = None
    trace_recorder: Optional[TraceRecorderV2] = None
    running: bool = field(default=False, init=False)
    last_task: Optional[PipeTask] = field(default=None, init=False)
    completed_tasks: int = field(default=0, init=False)
    failed_tasks: int = field(default=0, init=False)
    executed_tasks: List[PipeTask] = field(default_factory=list, init=False)
    thread_failure: Optional[str] = field(default=None, init=False)
    pipe_executor: Optional[PipeBaseV2] = field(default=None, init=False, repr=False)
    _thread: Optional[threading.Thread] = field(default=None, init=False, repr=False)
    current_cycle: int = field(default=0, init=False)
    cycle_model: Optional[object] = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        try:
            self.pipe_executor = build_pipe_executor(self.lane_name, self.pipe_name)
        except KeyError:
            self.pipe_executor = None
        if getattr(self.config, "cycle_model_enabled", True):
            self.cycle_model = load_cycle_model_for_device(
                str(getattr(globvars, "device_type", "")),
                profile_path=str(getattr(self.config, "cycle_profile_path", "")),
            )

    def start(self) -> None:
        if self.running:
            return
        self.running = True
        self.thread_failure = None
        self.current_cycle = 0
        self._thread = threading.Thread(
            target=self._run_loop,
            name="simv2-core%s-%s-%s" % (self.core_idx, self.lane_name, self.pipe_name),
            daemon=True,
        )
        self._thread.start()

    def join(self) -> None:
        if self._thread is None:
            return
        self._thread.join()
        self._thread = None

    def terminate(self) -> None:
        self.running = False
        self.stop()

    def stop(self) -> None:
        self.mailbox.put_stop()

    def _record_sync_event(
        self,
        name: str,
        trace_phase: str,
        ts: float,
        dur: float = 0.0,
        extra_args: Optional[dict] = None,
    ) -> None:
        if self.trace_recorder is None:
            return
        if name in _TRACEABLE_SYNC_OPS and not bool(getattr(globvars, "trace_event", False)):
            return
        payload = {
            "lane_name": self.lane_name,
            "pipe_name": self.pipe_name,
            "trace_phase": trace_phase,
        }
        if self.cycle_model is not None:
            payload["time_domain"] = getattr(self.cycle_model, "time_domain", "cycle")
        if extra_args:
            payload.update(extra_args)
        self.trace_recorder.record_event(
            TraceEventKind.SYNC,
            name,
            dur=max(float(dur), 0.0),
            args=payload,
            ts=ts,
        )

    def has_cycle_model(self) -> bool:
        return self.cycle_model is not None

    def _cycle_time_args(self) -> Dict[str, object]:
        if self.cycle_model is None:
            return {}
        return {
            "time_domain": getattr(self.cycle_model, "time_domain", "cycle"),
            "cycle_model_profile": getattr(self.cycle_model, "profile_name", "cycle_model"),
        }

    def _estimate_task(self, task: PipeTask) -> Dict[str, object]:
        if self.cycle_model is None:
            return {"cycles": 0, "details": {}}
        estimate = estimate_task_cycles(task, self.tensor_store, self.cycle_model)
        return {"cycles": int(estimate.cycles), "details": dict(estimate.details)}

    def _run_loop(self) -> None:
        while self.running:
            try:
                task = self.poll_once(block=True, timeout=0.05)
            except BaseException:
                self.thread_failure = traceback.format_exc()
                self.running = False
                break
            if task is None:
                continue
            try:
                self.execute_task(task)
            except BaseException:
                self.thread_failure = traceback.format_exc()
                self.running = False
                break

    def poll_once(self, block: bool = False, timeout: Optional[float] = None) -> Optional[PipeTask]:
        message = self.mailbox.get(block=block, timeout=timeout)
        if message is None:
            return None
        # Handle stop sentinel
        if message == "stop" or (isinstance(message, str) and message == "stop"):
            self.running = False
            return None
        # Backward compat: unwrap MailboxMessage if someone still sends one
        if isinstance(message, MailboxMessage):
            if message.kind == "stop":
                self.running = False
                return None
            message = message.payload
        if not isinstance(message, PipeTask):
            raise TypeError(
                "pipe worker payload must be PipeTask, got: " + str(type(message))
            )
        task = message
        task.status = TaskStatus.RUNNING
        task.start_cycle = float(max(self.current_cycle, int(getattr(task, "earliest_start_cycle", 0.0))))
        self.last_task = task
        return task

    def execute_task(self, task: PipeTask) -> PipeTask:
        if not isinstance(task, PipeTask):
            raise TypeError("execute_task requires PipeTask, got: " + str(type(task)))
        if task.pipe_name != self.pipe_name:
            raise ValueError(
                "task pipe mismatch for worker " + self.pipe_name + ": " + task.pipe_name
            )
        task_start_ts = time.monotonic()
        estimate_info = self._estimate_task(task)
        estimate_cycles = int(estimate_info.get("cycles", 0))
        estimate_details = dict(estimate_info.get("details", {}))
        cycle_start = int(task.start_cycle)
        cycle_wait_start = cycle_start + max(estimate_cycles, 0)
        is_local_event_task = task.opname in _LOCAL_EVENT_OPS
        if is_local_event_task:
            cycle_wait_start = cycle_start
        try:
            import os
            if os.environ.get("SIMV2_DEBUG_TRACE"):
                import sys
                print("[worker %s/%s] exec %s args_keys=%s" % (self.lane_name, self.pipe_name, task.opname, list(task.args.keys())), file=sys.stderr, flush=True)
            if is_local_event_task:
                self._execute_local_event_task(task, cycle_wait_start, task_start_ts)
            elif self.tensor_store is not None:
                validate_pipe_task_memory(task, self.tensor_store, self.micro_runtime)
                execute_pipe_task(
                    task,
                    self.tensor_store,
                    lane_name=self.lane_name,
                    pipe_name=self.pipe_name,
                    micro_runtime=self.micro_runtime,
                    pipe_executor=self.pipe_executor,
                )
            if os.environ.get("SIMV2_DEBUG_TRACE"):
                import sys
                print("[worker %s/%s] done %s" % (self.lane_name, self.pipe_name, task.opname), file=sys.stderr, flush=True)
            # setflag: publish flag (error if already set)
            if task.opname == "setflag" and self.local_flags is not None:
                flag_key = task.args.get("flag_key", "")
                cur = self.local_flags.current(flag_key)
                consumed = self.local_flags.consumed_phase(flag_key)
                if cur > consumed:
                    raise RuntimeError(
                        "setflag: flag already set: " + flag_key
                        + " (current=" + str(cur) + ", consumed=" + str(consumed) + ")"
                    )
                phase = self.local_flags.publish(flag_key, ready_cycle=cycle_wait_start)
                self._record_sync_event(
                    task.opname,
                    "ready",
                    ts=float(cycle_wait_start) if self.cycle_model is not None else time.monotonic(),
                    extra_args={"flag_key": flag_key, "phase": phase, **self._cycle_time_args()},
                )
            # waitflag: block pipe until flag ready, then consume
            if task.opname == "waitflag" and self.local_flags is not None:
                flag_key = task.args.get("flag_key", "")
                wait_timeout = task.args.get("timeout", 5.0)
                target_phase = self.local_flags.consumed_phase(flag_key) + 1
                wait_start_ts = float(cycle_wait_start) if self.cycle_model is not None else time.monotonic()
                if not self.local_flags.wait_for(flag_key, target_phase, timeout=wait_timeout):
                    diag = self.local_flags.timeout_diagnostic(flag_key, target_phase)
                    self._record_sync_event(
                        task.opname,
                        "wait_timeout",
                        ts=wait_start_ts,
                        dur=(time.monotonic() - task_start_ts) if self.cycle_model is None else 0.0,
                        extra_args={"flag_key": flag_key, "phase": target_phase, **self._cycle_time_args()},
                    )
                    raise RuntimeError("waitflag timeout on pipe " + self.pipe_name + ": " + str(diag))
                if not self.local_flags.consume(flag_key, target_phase):
                    raise RuntimeError(
                        "waitflag failed to consume flag: " + flag_key
                        + " phase=" + str(target_phase)
                    )
                wait_dur = time.monotonic() - task_start_ts
                if self.cycle_model is not None:
                    ready_cycle = self.local_flags.phase_cycle(flag_key, target_phase)
                    wait_end_cycle = max(cycle_wait_start, int(ready_cycle or cycle_wait_start))
                    wait_dur = max(wait_end_cycle - cycle_wait_start, 0)
                    self.current_cycle = wait_end_cycle
                self._record_sync_event(
                    task.opname,
                    "wait",
                    ts=wait_start_ts,
                    dur=wait_dur,
                    extra_args={"flag_key": flag_key, "phase": target_phase, **self._cycle_time_args()},
                )
            # Cross-lane wait: block pipe until flag ready, then consume
            if task.opname in _CROSS_LANE_WAIT_OPS and self.sync is not None:
                wait_timeout = task.args.get("timeout", 5.0)
                for name in task.args.get("sync_names", []):
                    target_phase = self.sync.consumed_phase(name) + 1
                    wait_start_ts = float(cycle_wait_start) if self.cycle_model is not None else time.monotonic()
                    if not self.sync.wait_for(name, target_phase, timeout=wait_timeout):
                        diag = self.sync.timeout_diagnostic(name, target_phase)
                        self._record_sync_event(
                            task.opname,
                            "wait_timeout",
                            ts=wait_start_ts,
                            dur=(time.monotonic() - task_start_ts) if self.cycle_model is None else 0.0,
                            extra_args={"sync_name": name, "phase": target_phase, **self._cycle_time_args()},
                        )
                        raise RuntimeError(task.opname + " timeout on pipe " + self.pipe_name + ": " + str(diag))
                    if not self.sync.consume_wait(name, target_phase):
                        raise RuntimeError(
                            task.opname + " failed to consume intra-core token: "
                            + name + " phase=" + str(target_phase)
                        )
                    wait_dur = time.monotonic() - task_start_ts
                    if self.cycle_model is not None:
                        ready_cycle = self.sync.phase_cycle(name, target_phase)
                        wait_end_cycle = max(cycle_wait_start, int(ready_cycle or cycle_wait_start))
                        wait_dur = max(wait_end_cycle - cycle_wait_start, 0)
                        self.current_cycle = wait_end_cycle
                    self._record_sync_event(
                        task.opname,
                        "wait",
                        ts=wait_start_ts,
                        dur=wait_dur,
                        extra_args={"sync_name": name, "phase": target_phase, **self._cycle_time_args()},
                    )
            # Collective wait: block pipe until all participants ready
            if task.opname in _COLLECTIVE_WAIT_OPS and self.collective_sync is not None:
                wait_timeout = task.args.get("timeout", 5.0)
                sync_name = task.args.get("sync_name", "")
                participant_idx = task.args.get("participant_idx", 0)
                snapshot = self.collective_sync.participant_snapshot(sync_name)
                wait_counts = snapshot.get("wait_counts", {})
                target_phase = int(wait_counts.get(participant_idx, 0)) + 1
                wait_start_ts = float(cycle_wait_start) if self.cycle_model is not None else time.monotonic()
                if not self.collective_sync.wait_for(sync_name, target_phase, timeout=wait_timeout):
                    diag = self.collective_sync.timeout_diagnostic(
                        sync_name, target_phase, participant_idx=participant_idx)
                    self._record_sync_event(
                        task.opname,
                        "wait_timeout",
                        ts=wait_start_ts,
                        dur=(time.monotonic() - task_start_ts) if self.cycle_model is None else 0.0,
                        extra_args={
                            "sync_name": sync_name,
                            "participant_idx": participant_idx,
                            "phase": target_phase,
                            **self._cycle_time_args(),
                        },
                    )
                    raise RuntimeError(task.opname + " timeout on pipe " + self.pipe_name + ": " + str(diag))
                if not self.collective_sync.consume_wait(sync_name, participant_idx):
                    raise RuntimeError(
                        task.opname + " failed to consume collective token: "
                        + sync_name + " participant=" + str(participant_idx)
                        + " phase=" + str(target_phase)
                    )
                wait_dur = time.monotonic() - task_start_ts
                if self.cycle_model is not None:
                    ready_cycle = self.collective_sync.phase_cycle(sync_name, target_phase)
                    wait_end_cycle = max(cycle_wait_start, int(ready_cycle or cycle_wait_start))
                    wait_dur = max(wait_end_cycle - cycle_wait_start, 0)
                    self.current_cycle = wait_end_cycle
                self._record_sync_event(
                    task.opname,
                    "wait",
                    ts=wait_start_ts,
                    dur=wait_dur,
                    extra_args={
                        "sync_name": sync_name,
                        "participant_idx": participant_idx,
                        "phase": target_phase,
                        **self._cycle_time_args(),
                    },
                )
            task_end_cycle = self.current_cycle if self.cycle_model is not None else 0.0
            if (
                self.cycle_model is not None
                and task.opname not in _CROSS_LANE_WAIT_OPS
                and task.opname not in _COLLECTIVE_WAIT_OPS
                and task.opname != "waitflag"
                and not is_local_event_task
            ):
                task_end_cycle = cycle_start + max(estimate_cycles, 0)
                self.current_cycle = task_end_cycle
            task.start_cycle = float(cycle_start if self.cycle_model is not None else 0.0)
            task.estimated_cycles = float(estimate_cycles)
            task.end_cycle = float(task_end_cycle if self.cycle_model is not None else 0.0)
            task.status = TaskStatus.DONE
            task.error = None
            # Cross-lane ready: publish flag after task reaches this point
            if task.opname in _CROSS_LANE_READY_OPS and self.sync is not None:
                for name in task.args.get("sync_names", []):
                    ready_cycle = task.end_cycle if self.cycle_model is not None else None
                    phase = self.sync.publish_ready(name, ready_cycle=ready_cycle)
                    self._record_sync_event(
                        task.opname,
                        "ready",
                        ts=float(task.end_cycle) if self.cycle_model is not None else time.monotonic(),
                        extra_args={"sync_name": name, "phase": phase, **self._cycle_time_args()},
                    )
            if task.opname in _COLLECTIVE_READY_OPS and self.collective_sync is not None:
                sync_name = task.args.get("sync_name", "")
                participant_idx = task.args.get("participant_idx", 0)
                ready_cycle = task.end_cycle if self.cycle_model is not None else None
                target_phase = self.collective_sync.publish_ready(sync_name, participant_idx=participant_idx, ready_cycle=ready_cycle)
                self._record_sync_event(
                    task.opname,
                    "ready",
                    ts=float(task.end_cycle) if self.cycle_model is not None else time.monotonic(),
                    extra_args={
                        "sync_name": sync_name,
                        "participant_idx": participant_idx,
                        "phase": target_phase,
                        **self._cycle_time_args(),
                    },
                )
            self.completed_tasks += 1
            self.executed_tasks.append(task)
            if self.trace_recorder is not None:
                if task.opname in _TRACEABLE_SYNC_OPS and not bool(getattr(globvars, "trace_event", False)):
                    self.last_task = task
                    return task
                self.trace_recorder.record_event(
                    TraceEventKind.PIPE,
                    "execute_task",
                    dur=(task.end_cycle - task.start_cycle) if self.cycle_model is not None else time.monotonic() - task_start_ts,
                    args={
                        "lane_name": self.lane_name,
                        "pipe_name": self.pipe_name,
                        "opname": task.opname,
                        "status": task.status.value,
                        **self._cycle_time_args(),
                        **estimate_details,
                    },
                    ts=float(task.start_cycle) if self.cycle_model is not None else task_start_ts,
                )
        except Exception as exc:
            task.status = TaskStatus.FAILED
            task.error = str(exc)
            task.error_details = traceback.format_exc()
            self.failed_tasks += 1
            failure_text = task.error_details
            print(
                "[worker %s/%s] failed %s: %s\n%s" % (
                    self.lane_name, self.pipe_name, task.opname, str(exc), failure_text,
                ),
                file=sys.stderr,
                flush=True,
            )
            if self.trace_recorder is not None:
                if task.opname in _TRACEABLE_SYNC_OPS and not bool(getattr(globvars, "trace_event", False)):
                    raise
                self.trace_recorder.record_event(
                    TraceEventKind.PIPE,
                    "execute_task",
                    dur=(task.end_cycle - task.start_cycle) if self.cycle_model is not None else time.monotonic() - task_start_ts,
                    args={
                        "lane_name": self.lane_name,
                        "pipe_name": self.pipe_name,
                        "opname": task.opname,
                        "status": task.status.value,
                        "error": task.error,
                        **self._cycle_time_args(),
                        **estimate_details,
                    },
                    ts=float(task.start_cycle) if self.cycle_model is not None else task_start_ts,
                )
            raise
        self.last_task = task
        return task

    def _execute_local_event_task(self, task: PipeTask, cycle_wait_start: int, task_start_ts: float) -> None:
        if self.local_events is None:
            raise RuntimeError("local event task requires LocalEventBank")
        event_name = str(task.args.get("event_name", ""))
        if event_name == "":
            raise ValueError(task.opname + " requires event_name")
        descriptor = self.local_events.descriptor(event_name)
        event_kind = descriptor.event_kind
        if task.opname in ("event_set", "event_setall"):
            ready_cycle = float(cycle_wait_start) if self.cycle_model is not None else None
            event_infos = self.local_events.set_event(
                event_name,
                ready_cycle=ready_cycle,
                set_all=(task.opname == "event_setall"),
            )
            first_info = event_infos[0]
            self._record_sync_event(
                task.opname,
                "ready",
                ts=float(cycle_wait_start) if self.cycle_model is not None else time.monotonic(),
                extra_args={
                    "event_name": event_name,
                    "event_kind": event_kind,
                    "src_pipe": descriptor.src_pipe,
                    "dst_pipe": descriptor.dst_pipe,
                    "flag_id": first_info["flag_id"],
                    "slot_index": first_info["slot_index"],
                    "flag_ids": [info["flag_id"] for info in event_infos],
                    **self._cycle_time_args(),
                },
            )
            return

        wait_timeout = float(task.args.get("timeout", 5.0))
        wait_target = self.local_events.current_wait_target(event_name)
        wait_start_ts = float(cycle_wait_start) if self.cycle_model is not None else time.monotonic()
        consumed_infos: List[Dict[str, object]] = []

        def _consume_one(timeout_budget: float) -> bool:
            info = self.local_events.wait_and_consume(event_name, timeout=timeout_budget)
            if info is None:
                return False
            consumed_infos.append(dict(info))
            return True

        if not _consume_one(wait_timeout):
            self._record_sync_event(
                task.opname,
                "wait_timeout",
                ts=wait_start_ts,
                dur=(time.monotonic() - task_start_ts) if self.cycle_model is None else 0.0,
                extra_args={
                    "event_name": event_name,
                    "event_kind": event_kind,
                    "src_pipe": descriptor.src_pipe,
                    "dst_pipe": descriptor.dst_pipe,
                    "flag_id": wait_target["flag_id"],
                    "slot_index": wait_target["slot_index"],
                    **self._cycle_time_args(),
                },
            )
            raise RuntimeError(task.opname + " timeout: " + str(self.local_events.timeout_diagnostic(event_name)))

        if task.opname == "event_release" and event_kind == "d" and self.local_events.pending_count(event_name) > 0:
            remaining_timeout = max(wait_timeout - max(time.monotonic() - task_start_ts, 0.0), 0.0)
            if not _consume_one(remaining_timeout):
                self._record_sync_event(
                    task.opname,
                    "wait_timeout",
                    ts=wait_start_ts,
                    dur=(time.monotonic() - task_start_ts) if self.cycle_model is None else 0.0,
                    extra_args={
                        "event_name": event_name,
                        "event_kind": event_kind,
                        "src_pipe": descriptor.src_pipe,
                        "dst_pipe": descriptor.dst_pipe,
                        "flag_id": wait_target["flag_id"],
                        "slot_index": wait_target["slot_index"],
                        **self._cycle_time_args(),
                    },
                )
                raise RuntimeError(task.opname + " timeout: " + str(self.local_events.timeout_diagnostic(event_name)))

        wait_dur = time.monotonic() - task_start_ts
        if self.cycle_model is not None:
            ready_cycle = max(int(info.get("ready_cycle") or cycle_wait_start) for info in consumed_infos)
            wait_end_cycle = max(cycle_wait_start, ready_cycle)
            wait_dur = max(wait_end_cycle - cycle_wait_start, 0)
            self.current_cycle = wait_end_cycle
        consumed_info = consumed_infos[-1]
        self._record_sync_event(
            task.opname,
            "release" if task.opname == "event_release" else "wait",
            ts=wait_start_ts,
            dur=wait_dur,
            extra_args={
                "event_name": event_name,
                "event_kind": event_kind,
                "src_pipe": descriptor.src_pipe,
                "dst_pipe": descriptor.dst_pipe,
                "flag_id": consumed_info.get("flag_id"),
                "slot_index": consumed_info.get("slot_index"),
                "flag_ids": [info.get("flag_id") for info in consumed_infos],
                **self._cycle_time_args(),
            },
        )
