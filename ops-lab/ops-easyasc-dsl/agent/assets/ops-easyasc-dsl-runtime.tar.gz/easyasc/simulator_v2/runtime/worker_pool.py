from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List

from .pipe_worker import PipeWorker


class WorkerPoolState(Enum):
    IDLE = "idle"
    RUNNING = "running"
    STOPPED = "stopped"


@dataclass
class WorkerPool:
    """Container for pipe workers."""

    workers: List[PipeWorker] = field(default_factory=list)
    state: WorkerPoolState = field(default=WorkerPoolState.IDLE, init=False)

    def add(self, worker: PipeWorker) -> None:
        self.workers.append(worker)

    def start(self) -> None:
        for worker in self.workers:
            worker.start()
        self.state = WorkerPoolState.RUNNING

    def join(self) -> None:
        for worker in self.workers:
            worker.stop()
        for worker in self.workers:
            worker.join()
        self.state = WorkerPoolState.STOPPED
        failures = [worker.thread_failure for worker in self.workers if worker.thread_failure]
        if failures:
            raise RuntimeError("\n\n".join(failures))

    def terminate(self) -> None:
        for worker in self.workers:
            worker.terminate()
        self.state = WorkerPoolState.STOPPED

    def is_running(self) -> bool:
        return self.state == WorkerPoolState.RUNNING

    def executed_tasks(self) -> List[PipeTask]:
        executed = []
        for worker in self.workers:
            executed.extend(worker.executed_tasks)
        return executed
