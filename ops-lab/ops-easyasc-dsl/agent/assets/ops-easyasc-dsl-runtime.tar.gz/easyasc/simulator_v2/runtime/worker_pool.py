# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List

from .pipe_worker import PipeWorker


class WorkerPoolState(Enum):
    IDLE = "idle"
    RUNNING = "running"
    STOPPED = "stopped"


@dataclass
class WorkerPool:
    """Container for pipe workers."""

    workers: List[PipeWorker] = field(default_factory=list)
    state: WorkerPoolState = field(default=WorkerPoolState.IDLE, init=False)

    def add(self, worker: PipeWorker) -> None:
        self.workers.append(worker)

    def start(self) -> None:
        for worker in self.workers:
            worker.start()
        self.state = WorkerPoolState.RUNNING

    def join(self) -> None:
        for worker in self.workers:
            worker.stop()
        for worker in self.workers:
            worker.join()
        self.state = WorkerPoolState.STOPPED
        failures = [worker.thread_failure for worker in self.workers if worker.thread_failure]
        if failures:
            raise RuntimeError("\n\n".join(failures))

    def terminate(self) -> None:
        for worker in self.workers:
            worker.terminate()
        self.state = WorkerPoolState.STOPPED

    def is_running(self) -> bool:
        return self.state == WorkerPoolState.RUNNING

    def executed_tasks(self) -> List[PipeTask]:
        executed = []
        for worker in self.workers:
            executed.extend(worker.executed_tasks)
        return executed
