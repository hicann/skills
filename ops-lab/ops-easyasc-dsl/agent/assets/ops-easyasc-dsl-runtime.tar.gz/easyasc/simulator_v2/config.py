# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass


def _default_core_count() -> int:
    """Return the default core count based on the active device_type."""
    from .. import globvars
    device = getattr(globvars, "device_type", "b3")
    if device.startswith("950"):
        return 32
    return 20


@dataclass(frozen=True)
class SimulatorV2Config:
    """Configuration for the clean-slate simulator runtime."""

    core_count: int = 0
    process_start_method: str = "auto"
    trace_enabled: bool = False
    cycle_model_enabled: bool = True
    cycle_profile_path: str = ""
    queue_maxsize: int = 0
    pipe_workers_per_lane: int = 3
    torch_num_threads: int = 1
    execution_timeout_s: float = 120.0
    sync_wait_timeout_s: float = 30.0

    def __post_init__(self) -> None:
        if self.core_count == 0:
            object.__setattr__(self, "core_count", _default_core_count())
