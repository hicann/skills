from __future__ import annotations

from dataclasses import dataclass


def _default_core_count() -> int:
    """Return the default core count based on the active device_type."""
    from .. import globvars
    device = getattr(globvars, "device_type", "b3")
    if device.startswith("950"):
        return 32
    return 20


@dataclass(frozen=True)
class SimulatorV2Config:
    """Configuration for the clean-slate simulator runtime."""

    core_count: int = 0
    process_start_method: str = "auto"
    trace_enabled: bool = False
    queue_maxsize: int = 0
    pipe_workers_per_lane: int = 3
    torch_num_threads: int = 1
    execution_timeout_s: float = 120.0
    sync_wait_timeout_s: float = 30.0

    def __post_init__(self) -> None:
        if self.core_count == 0:
            object.__setattr__(self, "core_count", _default_core_count())
