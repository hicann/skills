from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Tuple

from ..memory.shared_tensor import SharedTensorHandle
from ..memory.shared_tensor_store import SharedTensorStore
from ..ops.cube.fix import FixPipeV2
from ..ops.cube.m import MPipeV2
from ..ops.cube.mte1 import MTE1PipeV2
from ..ops.cube.mte2 import MTE2PipeV2 as CubeMTE2PipeV2
from ..ops.micro.dispatch import MicroDispatch
from ..ops.micro.runtime import MicroRuntime
from ..program.task import PipeTask
from .pipe_base import PipeBaseV2
from .vec.mte2 import MTE2PipeV2 as VecMTE2PipeV2
from .vec.mte3 import MTE3PipeV2
from .vec.v import VPipeV2

# --- Op Registry ---
# Maps (lane_prefix, pipe_name) -> factory callable
_PIPE_REGISTRY: Dict[Tuple[str, str], Callable[[], PipeBaseV2]] = {}

# Maps opname -> (lane_prefix, pipe_name) for known ops
_OPNAME_REGISTRY: Dict[str, Tuple[str, str]] = {}


def register_pipe(lane_prefix: str, pipe_name: str, factory: Callable[[], PipeBaseV2], opnames: Optional[List[str]] = None) -> None:
    """Register a pipe executor factory and its supported opnames."""
    key = (lane_prefix, pipe_name)
    _PIPE_REGISTRY[key] = factory
    if opnames:
        for opname in opnames:
            _OPNAME_REGISTRY[opname] = key


def registered_opnames() -> List[str]:
    """Return all opnames known to the registry."""
    return sorted(_OPNAME_REGISTRY.keys())


def _resolve_tensor_ref(tensor_store: SharedTensorStore, ref: Any) -> Any:
    if isinstance(ref, SharedTensorHandle):
        return tensor_store.resolve_handle(ref)
    if isinstance(ref, dict) and "tensor_id" in ref:
        return tensor_store.tensor(str(ref["tensor_id"]))
    if isinstance(ref, str):
        return tensor_store.tensor(ref)
    raise TypeError("unsupported shared tensor reference: " + str(type(ref)))


def build_pipe_executor(lane_name: str, pipe_name: str) -> PipeBaseV2:
    # Try exact lane name first, then prefix match
    key = (lane_name, pipe_name)
    factory = _PIPE_REGISTRY.get(key)
    if factory is not None:
        return factory()
    # Prefix match: "vec0" -> "vec"
    for prefix in ("cube", "vec"):
        if lane_name.startswith(prefix):
            key = (prefix, pipe_name)
            factory = _PIPE_REGISTRY.get(key)
            if factory is not None:
                return factory()
    raise KeyError(
        "no simulator_v2 pipe executor for lane/pipe: " + lane_name + "/" + pipe_name
        + " (registered: " + ", ".join(k[0] + "/" + k[1] for k in sorted(_PIPE_REGISTRY.keys())) + ")"
    )


# --- Default registrations ---
register_pipe("cube", "MTE2", CubeMTE2PipeV2, opnames=["gm_to_l1_nd2nz", "set_constant_to_l1"])
register_pipe("cube", "MTE1", MTE1PipeV2, opnames=["l1_to_l0"])
register_pipe("cube", "M", MPipeV2, opnames=["mmad", "cube_m_scale"])
register_pipe("cube", "FIX", FixPipeV2, opnames=["l0c_to_gm_nz2nd", "l0c_to_l1", "l0c_to_ub"])
register_pipe("vec", "MTE2", VecMTE2PipeV2, opnames=["gm_to_ub_pad"])
register_pipe("vec", "MTE3", MTE3PipeV2, opnames=["ub_to_gm_pad", "ub_to_l1_nd2nz", "ub_to_l1_nz"])
register_pipe("vec", "V", VPipeV2, opnames=[
    "add", "sub", "mul", "div", "vmax", "vmin", "vabs", "vec_v_relu",
    "dup", "adds", "muls", "vmaxs", "vmins", "lrelu", "axpy",
    "compare", "compare_scalar", "select", "cast",
    "exp", "ln", "rec", "sqrt", "rsqrt", "vnot", "vand", "vor",
    "cmax", "cmin", "cadd", "cgmax", "cgmin", "cgadd", "brcb",
    "ub_to_ub",
    "vec_v_add", "vec_v_sub", "vec_v_mul", "vec_v_div",
    "vec_v_max", "vec_v_min", "vec_v_abs",
    "vec_v_add_scalar", "vec_v_mul_scalar", "vec_v_dup", "vec_v_cast",
    "vec_v_compare", "vec_v_compare_scalar", "vec_v_select",
    "vec_v_exp", "vec_v_ln", "vec_v_rec", "vec_v_sqrt", "vec_v_rsqrt",
    "vec_v_not", "vec_v_and", "vec_v_or",
    "vec_v_cmax", "vec_v_cmin", "vec_v_cadd",
    "vec_v_cgmax", "vec_v_cgmin", "vec_v_cgadd", "vec_v_brcb",
    "muladddst", "set_mask", "reset_mask",
    "vec_v_muladddst", "vec_v_set_mask", "vec_v_reset_mask",
    "cpadd", "vec_v_cpadd",
    "sort32", "mergesort4", "mergesort_2seq",
    "gather", "scatter",
])


def execute_pipe_task(
    task: PipeTask,
    tensor_store: SharedTensorStore,
    lane_name: str,
    pipe_name: str,
    micro_runtime: MicroRuntime = None,
    pipe_executor: PipeBaseV2 = None,
) -> None:
    if micro_runtime is None:
        micro_runtime = MicroRuntime()
    if pipe_executor is None:
        try:
            pipe_executor = build_pipe_executor(lane_name, pipe_name)
        except KeyError:
            pipe_executor = None
    # call_micro: full micro body execution via MicroRuntime
    if task.opname == "call_micro":
        micro_def = task.args.get("micro_def")
        tensor_views = task.args.get("tensor_views", {})
        var_values = task.args.get("var_values", {})
        if micro_def is not None:
            micro_runtime.execute_call_micro(micro_def, tensor_views, var_values, tensor_store)
        return

    if pipe_executor is not None and pipe_executor.execute(task, tensor_store, micro_runtime):
        return
    if MicroDispatch(micro_runtime).execute(task, tensor_store):
        return
    if task.opname in ("noop", "load", "compute", "vec_compute", "store"):
        return
    if task.opname == "fill_shared":
        tensor = _resolve_tensor_ref(tensor_store, task.args["tensor"])
        tensor.fill_(task.args.get("value", 0))
        return
    if task.opname == "copy_shared":
        src = _resolve_tensor_ref(tensor_store, task.args["src"])
        dst = _resolve_tensor_ref(tensor_store, task.args["dst"])
        if int(src.numel()) != int(dst.numel()):
            raise ValueError("copy_shared requires src and dst to have the same numel")
        dst.copy_(src.reshape(dst.shape))
        return
    # Unported simulator_v2 ops still behave like scaffold no-ops until their
    # pipe-family semantics are implemented.
    return
