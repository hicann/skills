from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
from ...memory.shared_tensor_store import SharedTensorStore
from ...program.task import PipeTask
from ..common import PipeDescriptor, PipeFamily
from ..pipe_base import PipeBaseV2


@dataclass
class MTE3PipeV2(PipeBaseV2):
    def __init__(self) -> None:
        super(MTE3PipeV2, self).__init__(PipeDescriptor(PipeFamily.VEC, "MTE3"))

    @staticmethod
    def _resolve_int(value: Any, label: str) -> int:
        if isinstance(value, bool):
            return int(value)
        if not isinstance(value, (int, float)):
            raise TypeError(label + " must resolve to int/float, got: " + str(type(value)))
        return int(value)

    @staticmethod
    def _align32(value: int) -> int:
        return ((value + 31) // 32) * 32

    @staticmethod
    def _align16(value: int) -> int:
        return ((value + 15) // 16) * 16

    @staticmethod
    def _linear_view_from_pointer(tensor: torch.Tensor) -> torch.Tensor:
        elem_size = int(tensor.element_size())
        if elem_size <= 0:
            raise ValueError("tensor element size must be positive, got: " + str(elem_size))
        storage_elems = int(tensor.untyped_storage().nbytes()) // elem_size
        available = storage_elems - int(tensor.storage_offset())
        if available < 0:
            raise MemoryError(
                "tensor storage offset exceeds storage capacity: "
                + "offset="
                + str(int(tensor.storage_offset()))
                + ", storage_elems="
                + str(storage_elems)
            )
        return tensor.as_strided((available,), (1,), storage_offset=int(tensor.storage_offset()))

    @staticmethod
    def _choose_atomic_compute_dtype(dtype: torch.dtype) -> torch.dtype:
        if dtype in (torch.float16, torch.bfloat16):
            return torch.float32
        if dtype in (torch.int8, torch.uint8, torch.int16):
            return torch.int32
        return dtype

    @staticmethod
    def _apply_atomic_op(dst_region: torch.Tensor, src_region: torch.Tensor, mode: str) -> torch.Tensor:
        if mode == "add":
            return dst_region.add(src_region)
        if mode == "max":
            return torch.maximum(dst_region, src_region)
        if mode == "min":
            return torch.minimum(dst_region, src_region)
        raise ValueError("unsupported atomic mode for ub_to_gm_pad: " + str(mode))

    def execute(self, task: PipeTask, tensor_store: SharedTensorStore, micro_runtime=None) -> bool:
        if task.opname == "vec_mte3_store":
            src = tensor_store.tensor(str(task.args["src"]))
            dst = tensor_store.tensor(str(task.args["dst"]))
            dst.copy_(src.reshape(dst.shape))
            return True
        if task.opname == "ub_to_gm_pad":
            dst = self._linear_view_from_pointer(tensor_store.tensor(str(task.args["dst"])))
            src = self._linear_view_from_pointer(tensor_store.tensor(str(task.args["src"])))
            if int(src.element_size()) != int(dst.element_size()):
                raise ValueError(
                    "ub_to_gm_pad requires src/dst tensor views with identical element size, got "
                    + "src="
                    + str(int(src.element_size()))
                    + ", dst="
                    + str(int(dst.element_size()))
                )
            n_burst = self._resolve_int(task.args.get("n_burst"), "ub_to_gm_pad n_burst")
            burst_len_byte = self._resolve_int(task.args.get("burst_len_byte"), "ub_to_gm_pad burst_len_byte")
            dst_stride_byte = self._resolve_int(task.args.get("dst_stride_byte"), "ub_to_gm_pad dst_stride_byte")
            src_stride = self._resolve_int(task.args.get("src_stride"), "ub_to_gm_pad src_stride")
            if n_burst < 0 or burst_len_byte < 0 or dst_stride_byte < 0 or src_stride < 0:
                raise ValueError(
                    "ub_to_gm_pad requires non-negative n_burst/burst_len_byte/dst_stride_byte/src_stride, "
                    + "got n_burst="
                    + str(n_burst)
                    + ", burst_len_byte="
                    + str(burst_len_byte)
                    + ", dst_stride_byte="
                    + str(dst_stride_byte)
                    + ", src_stride="
                    + str(src_stride)
                )
            src_stride_byte = src_stride * 32
            aligned_burst_len_byte = self._align32(burst_len_byte)
            src_step = aligned_burst_len_byte + src_stride_byte
            dst_step = burst_len_byte + dst_stride_byte
            src_bytes = src.view(torch.uint8)
            dst_bytes = dst.view(torch.uint8)
            src_need = 0
            dst_need = 0
            if n_burst > 0:
                src_need = (n_burst - 1) * src_step + burst_len_byte
                dst_need = (n_burst - 1) * dst_step + burst_len_byte
            if src_need > int(src_bytes.numel()):
                raise MemoryError(
                    "ub_to_gm_pad source view is too small: "
                    + "need="
                    + str(src_need)
                    + " bytes, have="
                    + str(int(src_bytes.numel()))
                    + " bytes"
                )
            if dst_need > int(dst_bytes.numel()):
                raise MemoryError(
                    "ub_to_gm_pad destination view is too small: "
                    + "need="
                    + str(dst_need)
                    + " bytes, have="
                    + str(int(dst_bytes.numel()))
                    + " bytes"
                )
            if n_burst == 0 or burst_len_byte == 0:
                return True

            atomic_enabled = bool(task.args.get("atomic_enabled", False))
            if atomic_enabled:
                atomic_mode = str(task.args.get("atomic_mode", "add") or "add")
                elem_size = int(src.element_size())
                if (burst_len_byte % elem_size) != 0:
                    raise ValueError(
                        "ub_to_gm_pad atomic path requires burst_len_byte aligned to element size, got: "
                        + "burst_len_byte="
                        + str(burst_len_byte)
                        + ", element_size="
                        + str(elem_size)
                    )
                if (dst_stride_byte % elem_size) != 0:
                    raise ValueError(
                        "ub_to_gm_pad atomic path requires dst_stride_byte aligned to element size, got: "
                        + "dst_stride_byte="
                        + str(dst_stride_byte)
                        + ", element_size="
                        + str(elem_size)
                    )
                if (src_stride_byte % elem_size) != 0:
                    raise ValueError(
                        "ub_to_gm_pad atomic path requires source stride aligned to element size, got: "
                        + "src_stride_byte="
                        + str(src_stride_byte)
                        + ", element_size="
                        + str(elem_size)
                    )
                if (src_step % elem_size) != 0:
                    raise ValueError(
                        "ub_to_gm_pad atomic path requires src step aligned to element size, got: "
                        + "src_step="
                        + str(src_step)
                        + ", element_size="
                        + str(elem_size)
                    )
                if (dst_step % elem_size) != 0:
                    raise ValueError(
                        "ub_to_gm_pad atomic path requires dst step aligned to element size, got: "
                        + "dst_step="
                        + str(dst_step)
                        + ", element_size="
                        + str(elem_size)
                    )
                elems_per_burst = burst_len_byte // elem_size
                src_step_elem = src_step // elem_size
                dst_step_elem = dst_step // elem_size
                compute_dtype = self._choose_atomic_compute_dtype(dst.dtype)
                for burst_idx in range(n_burst):
                    src_begin_elem = burst_idx * src_step_elem
                    dst_begin_elem = burst_idx * dst_step_elem
                    src_slice = src[src_begin_elem : src_begin_elem + elems_per_burst]
                    dst_slice = dst[dst_begin_elem : dst_begin_elem + elems_per_burst]
                    updated = self._apply_atomic_op(
                        dst_slice.to(compute_dtype),
                        src_slice.to(compute_dtype),
                        atomic_mode,
                    ).to(dst_slice.dtype)
                    dst_slice.copy_(updated)
                return True

            for burst_idx in range(n_burst):
                src_begin = burst_idx * src_step
                dst_begin = burst_idx * dst_step
                dst_bytes[dst_begin : dst_begin + burst_len_byte].copy_(
                    src_bytes[src_begin : src_begin + burst_len_byte]
                )
            return True
        if task.opname == "ub_to_l1_nd2nz":
            return self._execute_ub_to_l1_nd2nz(task, tensor_store)
        if task.opname == "ub_to_l1_nz":
            return self._execute_ub_to_l1_nz(task, tensor_store)
        return False

    def _execute_ub_to_l1_nd2nz(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        dst = tensor_store.tensor(str(task.args["dst"]))
        src = tensor_store.tensor(str(task.args["src"]))
        if not isinstance(dst, torch.Tensor):
            raise TypeError("ub_to_l1_nd2nz requires dst tensor view, got: " + str(type(dst)))
        if not isinstance(src, torch.Tensor):
            raise TypeError("ub_to_l1_nd2nz requires src tensor view, got: " + str(type(src)))
        m_dst = self._resolve_int(task.args.get("m_dst"), "ub_to_l1_nd2nz m_dst")
        n_dst = self._resolve_int(task.args.get("n_dst"), "ub_to_l1_nd2nz n_dst")
        m_src = self._resolve_int(task.args.get("m_src"), "ub_to_l1_nd2nz m_src")
        n_src = self._resolve_int(task.args.get("n_src"), "ub_to_l1_nd2nz n_src")
        if m_dst < 0 or n_dst < 0 or m_src < 0 or n_src < 0:
            raise ValueError(
                "ub_to_l1_nd2nz requires non-negative m_dst/n_dst/m_src/n_src, got: "
                + "m_dst="
                + str(m_dst)
                + ", n_dst="
                + str(n_dst)
                + ", m_src="
                + str(m_src)
                + ", n_src="
                + str(n_src)
            )
        if m_src > m_dst:
            raise ValueError("ub_to_l1_nd2nz m_src=" + str(m_src) + " cannot exceed m_dst=" + str(m_dst))
        if n_src > n_dst:
            raise ValueError("ub_to_l1_nd2nz n_src=" + str(n_src) + " cannot exceed n_dst=" + str(n_dst))
        if m_src == 0 or n_src == 0:
            return True
        if int(src.element_size()) != int(dst.element_size()):
            raise ValueError(
                "ub_to_l1_nd2nz requires src/dst tensor views with identical element size, got "
                + "src="
                + str(int(src.element_size()))
                + ", dst="
                + str(int(dst.element_size()))
            )
        elem_size = int(dst.element_size())
        if elem_size <= 0 or (32 % elem_size) != 0:
            raise ValueError(
                "ub_to_l1_nd2nz unsupported dst element size for C0=32-byte layout: "
                + str(elem_size)
                + " bytes"
            )
        c0 = 32 // elem_size
        dst_stride_m = self._align16(m_dst)
        block_count = (n_src + c0 - 1) // c0
        src_linear = self._linear_view_from_pointer(src)
        dst_linear = self._linear_view_from_pointer(dst)
        src_need = m_src * n_src
        if src_need > int(src_linear.numel()):
            raise MemoryError(
                "ub_to_l1_nd2nz source pointer region is too small: "
                + "need="
                + str(src_need)
                + ", have="
                + str(int(src_linear.numel()))
                + ", m_src="
                + str(m_src)
                + ", n_src="
                + str(n_src)
            )
        dst_need = 0
        if m_src > 0 and n_src > 0:
            dst_need = (block_count - 1) * dst_stride_m * c0 + m_src * c0
        if dst_need > int(dst_linear.numel()):
            raise MemoryError(
                "ub_to_l1_nd2nz destination pointer region is too small: "
                + "need="
                + str(dst_need)
                + ", have="
                + str(int(dst_linear.numel()))
                + ", m_dst="
                + str(m_dst)
                + ", n_src="
                + str(n_src)
                + ", C0="
                + str(c0)
                + ", aligned_m_dst="
                + str(dst_stride_m)
            )
        src_2d = src_linear[:src_need].reshape(m_src, n_src)
        full_blocks = n_src // c0
        for block_idx in range(full_blocks):
            src_begin = block_idx * c0
            dst_begin = block_idx * dst_stride_m * c0
            dst_end = dst_begin + m_src * c0
            dst_block = dst_linear[dst_begin:dst_end].reshape(m_src, c0)
            dst_block.copy_(src_2d[:, src_begin:src_begin + c0])
        tail = n_src - full_blocks * c0
        if tail > 0:
            src_begin = full_blocks * c0
            dst_begin = full_blocks * dst_stride_m * c0
            dst_end = dst_begin + m_src * c0
            dst_block = dst_linear[dst_begin:dst_end].reshape(m_src, c0)
            dst_block[:, :tail].copy_(src_2d[:, src_begin:src_begin + tail])
        return True

    def _execute_ub_to_l1_nz(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        dst = tensor_store.tensor(str(task.args["dst"]))
        src = tensor_store.tensor(str(task.args["src"]))
        if not isinstance(dst, torch.Tensor):
            raise TypeError("ub_to_l1_nz requires dst tensor view, got: " + str(type(dst)))
        if not isinstance(src, torch.Tensor):
            raise TypeError("ub_to_l1_nz requires src tensor view, got: " + str(type(src)))

        m_dst = self._resolve_int(task.args.get("m_dst"), "ub_to_l1_nz m_dst")
        n_dst = self._resolve_int(task.args.get("n_dst"), "ub_to_l1_nz n_dst")
        m_src = self._resolve_int(task.args.get("m_src"), "ub_to_l1_nz m_src")
        n_src = self._resolve_int(task.args.get("n_src"), "ub_to_l1_nz n_src")
        if m_dst < 0 or n_dst < 0 or m_src < 0 or n_src < 0:
            raise ValueError(
                "ub_to_l1_nz requires non-negative m_dst/n_dst/m_src/n_src, got: "
                + "m_dst="
                + str(m_dst)
                + ", n_dst="
                + str(n_dst)
                + ", m_src="
                + str(m_src)
                + ", n_src="
                + str(n_src)
            )
        if m_src > m_dst:
            raise ValueError("ub_to_l1_nz m_src=" + str(m_src) + " cannot exceed m_dst=" + str(m_dst))
        if n_src > n_dst:
            raise ValueError("ub_to_l1_nz n_src=" + str(n_src) + " cannot exceed n_dst=" + str(n_dst))
        if m_src == 0 or n_src == 0:
            return True

        if int(src.element_size()) != int(dst.element_size()):
            raise ValueError(
                "ub_to_l1_nz requires src/dst tensor views with identical element size, got "
                + "src="
                + str(int(src.element_size()))
                + ", dst="
                + str(int(dst.element_size()))
            )
        elem_size = int(dst.element_size())
        if elem_size <= 0 or (32 % elem_size) != 0:
            raise ValueError(
                "ub_to_l1_nz unsupported dst element size for C0=32-byte layout: "
                + str(elem_size)
                + " bytes"
            )
        c0 = 32 // elem_size
        block_count = (n_src + c0 - 1) // c0
        dst_stride_m = self._align16(m_dst)
        copy_len_per_block = m_src * c0
        src_linear = self._linear_view_from_pointer(src)
        dst_linear = self._linear_view_from_pointer(dst)

        for block_idx in range(block_count):
            src_begin = block_idx * copy_len_per_block
            src_end = src_begin + copy_len_per_block
            if src_end > int(src_linear.numel()):
                raise MemoryError(
                    "ub_to_l1_nz source pointer region is too small for packed NZ layout: "
                    + "need_end="
                    + str(src_end)
                    + ", have="
                    + str(int(src_linear.numel()))
                    + ", block="
                    + str(block_idx)
                    + ", m_src="
                    + str(m_src)
                    + ", n_src="
                    + str(n_src)
                    + ", C0="
                    + str(c0)
                )
            dst_begin = block_idx * dst_stride_m * c0
            dst_end = dst_begin + copy_len_per_block
            if dst_end > int(dst_linear.numel()):
                raise MemoryError(
                    "ub_to_l1_nz destination pointer region is too small for NZ layout: "
                    + "need_end="
                    + str(dst_end)
                    + ", have="
                    + str(int(dst_linear.numel()))
                    + ", block="
                    + str(block_idx)
                    + ", m_dst="
                    + str(m_dst)
                    + ", n_src="
                    + str(n_src)
                    + ", C0="
                    + str(c0)
                    + ", aligned_m_dst="
                    + str(dst_stride_m)
                )
            dst_linear[dst_begin:dst_end].copy_(src_linear[src_begin:src_end])
        return True
