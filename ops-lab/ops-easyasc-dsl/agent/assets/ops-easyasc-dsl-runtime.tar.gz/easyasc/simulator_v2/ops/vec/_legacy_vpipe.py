"""Legacy VPipe implementation migrated from V1 simulator.

This module is used by VPipeV2 to execute vec pipe instructions.
The original V1 simulator is archived in easyasc/resources/simulator_v1_archive.tar.gz.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import torch

def validate_core_idx(core_idx: int) -> int:
    if not isinstance(core_idx, int):
        raise TypeError(f"core_idx must be int, got: {type(core_idx)}")
    if core_idx < 0:
        raise ValueError(f"core_idx must be >= 0, got: {core_idx}")
    return core_idx



@dataclass
class SimInstruction:
    opname: str
    args: Dict[str, Any] = field(default_factory=dict)
    tensors: Dict[str, Any] = field(default_factory=dict)
    tensor_names: Dict[str, str] = field(default_factory=dict)
    tensor_dtypes: Dict[str, str] = field(default_factory=dict)
    atomic_enabled: Optional[bool] = None
    atomic_dtype: Optional[str] = None
    atomic_mode: Optional[str] = None
    seq: int = -1
    issue_time: float = 0.0


_SIM_LOGGER = logging.getLogger("easyasc.simulator.cube")
if not _SIM_LOGGER.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(message)s"))
    _SIM_LOGGER.addHandler(_handler)
_SIM_LOGGER.setLevel(logging.INFO)
_SIM_LOGGER.propagate = False


class PipeBase:
    pipe_name = ""

    def __init__(self, core_idx: int) -> None:
        self.core_idx = validate_core_idx(core_idx)
        self.instructions: List[SimInstruction] = []

    def issue(self, instruction: SimInstruction) -> None:
        if not isinstance(instruction, SimInstruction):
            raise TypeError(f"instruction must be SimInstruction, got: {type(instruction)}")
        self.instructions.append(instruction)

    @staticmethod
    def _zero_tensor_storage(tensor: torch.Tensor) -> None:
        if not isinstance(tensor, torch.Tensor):
            raise TypeError(f"tensor must be torch.Tensor, got: {type(tensor)}")
        tensor.reshape(-1).view(torch.uint8).zero_()

    def execute_instruction(self, instruction: SimInstruction) -> None:
        if instruction.opname == "sim_dump_tensor":
            tensor = instruction.tensors.get("tensor")
            filename = instruction.args.get("filename")
            if not isinstance(tensor, torch.Tensor):
                raise TypeError(
                    f"sim_dump_tensor requires tensor runtime view, got: {type(tensor)}"
                )
            if not isinstance(filename, str):
                raise TypeError(f"sim_dump_tensor requires filename str, got: {type(filename)}")
            torch.save(tensor.detach().clone(), filename)
            return
        if instruction.opname != "sim_print":
            return
        payload = instruction.args.get("payload", [])
        if not isinstance(payload, (list, tuple)):
            raise TypeError(f"sim_print payload must be list/tuple, got: {type(payload)}")
        message = " ".join(str(item) for item in payload)
        _SIM_LOGGER.info(f"[cube][core={self.core_idx}][pipe={self.pipe_name}] {message}")

    def execute_all(self) -> None:
        for instruction in self.instructions:
            self.execute_instruction(instruction)

    def clear(self) -> None:
        self.instructions = []

def linear_view_from_pointer(tensor: torch.Tensor) -> torch.Tensor:
    elem_size = int(tensor.element_size())
    if elem_size <= 0:
        raise ValueError("tensor element size must be positive, got: " + str(elem_size))
    storage_elems: Optional[int] = None
    if hasattr(tensor, "untyped_storage"):
        try:
            storage_elems = int(tensor.untyped_storage().nbytes()) // elem_size
        except Exception:
            storage_elems = None
    if storage_elems is None:
        storage = tensor.storage()
        if hasattr(storage, "nbytes"):
            storage_elems = int(storage.nbytes()) // elem_size
        else:
            storage_elems = int(storage.size())
    offset = int(tensor.storage_offset())
    available = int(storage_elems) - offset
    if available < 0:
        raise MemoryError(
            "tensor storage offset exceeds storage capacity: "
            + "offset="
            + str(offset)
            + ", storage_elems="
            + str(int(storage_elems))
        )
    return tensor.as_strided((available,), (1,), storage_offset=offset)




_VEC_UNARY_OPS = (
    "exp",
    "ln",
    "abs",
    "rec",
    "sqrt",
    "rsqrt",
    "vnot",
    "relu",
)

_VEC_BINARY_OPS = (
    "add",
    "sub",
    "mul",
    "div",
    "vmax",
    "vmin",
    "vand",
    "vor",
    "muladddst",
)

_VEC_UNARY_SCALAR_OPS = (
    "adds",
    "muls",
    "vmaxs",
    "vmins",
    "lrelu",
    "axpy",
)

_VEC_DUP_OPS = (
    "dup",
    "brcb",
)

_VEC_CAST_OPS = (
    "cast",
)

_VEC_GROUP_OPS = (
    "cmax",
    "cmin",
    "cadd",
    "cgmax",
    "cgmin",
    "cgadd",
)

_VEC_GROUP_PACKED_OPS = (
    "cpadd",
)

_VEC_GATHER_OPS = (
    "gather",
)

_VEC_SCATTER_OPS = (
    "scatter",
)

_VEC_COMPARE_OPS = (
    "compare",
    "compare_scalar",
)

_VEC_SELECT_OPS = (
    "select",
)

_VEC_VNOT_DTYPE_NAMES = (
    "int16_t",
    "uint16_t",
)

_VEC_VAND_DTYPE_NAMES = (
    "int16_t",
    "uint16_t",
)

_VEC_DUP_DTYPE_NAMES = (
    "float",
    "half",
    "int",
    "uint32_t",
)


class VPipe(PipeBase):
    pipe_name = "V"

    def __init__(
        self,
        core_idx: int,
        call_micro_executor: Callable[[SimInstruction], None],
        current_mask: torch.Tensor | None = None,
    ) -> None:
        super().__init__(core_idx)
        self._call_micro_executor = call_micro_executor
        self.current_mask = current_mask if current_mask is not None else torch.ones((256,), dtype=torch.uint8)
        self.vector_mode = "repeat"
        self.count_register = 0

    @staticmethod
    def _resolve_int(value: Any, label: str) -> int:
        if isinstance(value, bool):
            return int(value)
        if not isinstance(value, (int, float)):
            raise TypeError(f"{label} must resolve to int/float, got: {type(value)}")
        return int(value)

    @staticmethod
    def _linear_view_from_pointer(tensor: torch.Tensor) -> torch.Tensor:
        return linear_view_from_pointer(tensor)

    # sort ops intentionally ignore the current vector mask; they always process
    # their full logical payload.
    def _execute_sort32(self, instruction: SimInstruction) -> None:
        dst = instruction.tensors.get("dst")
        src = instruction.tensors.get("src")
        idx = instruction.tensors.get("idx")
        if not isinstance(dst, torch.Tensor):
            raise TypeError(f"sort32 requires dst tensor view, got: {type(dst)}")
        if not isinstance(src, torch.Tensor):
            raise TypeError(f"sort32 requires src tensor view, got: {type(src)}")
        if not isinstance(idx, torch.Tensor):
            raise TypeError(f"sort32 requires idx tensor view, got: {type(idx)}")
        if dst.dim() != 1:
            raise ValueError(f"sort32 dst must be 1D pointer view, got dim={dst.dim()}")
        if src.dim() != 1:
            raise ValueError(f"sort32 src must be 1D pointer view, got dim={src.dim()}")
        if idx.dim() != 1:
            raise ValueError(f"sort32 idx must be 1D pointer view, got dim={idx.dim()}")

        dst_dtype_name = instruction.tensor_dtypes.get("dst", "")
        src_dtype_name = instruction.tensor_dtypes.get("src", "")
        idx_dtype_name = instruction.tensor_dtypes.get("idx", "")
        if dst_dtype_name != "" and dst_dtype_name != "float":
            raise TypeError(f"sort32 requires dst dtype float, got: {dst_dtype_name}")
        if src_dtype_name != "" and src_dtype_name != "float":
            raise TypeError(f"sort32 requires src dtype float, got: {src_dtype_name}")
        if idx_dtype_name != "" and idx_dtype_name != "uint32_t":
            raise TypeError(f"sort32 requires idx dtype uint32_t, got: {idx_dtype_name}")

        if dst.dtype != torch.float32:
            raise TypeError(f"sort32 requires dst torch dtype float32, got: {dst.dtype}")
        if src.dtype != torch.float32:
            raise TypeError(f"sort32 requires src torch dtype float32, got: {src.dtype}")

        allowed_idx_dtypes = [torch.int32]
        if hasattr(torch, "uint32"):
            allowed_idx_dtypes.append(torch.uint32)  # type: ignore[attr-defined]
        if idx.dtype not in tuple(allowed_idx_dtypes):
            raise TypeError(
                "sort32 requires idx torch dtype uint32/int32-compatible bit layout, "
                f"got: {idx.dtype}"
            )

        repeat = self._resolve_int(instruction.args.get("repeat"), "sort32 repeat")
        if repeat < 0:
            raise ValueError(f"sort32 repeat must be non-negative, got: {repeat}")

        src_need = repeat * 32
        idx_need = repeat * 32
        dst_need = repeat * 64
        if src_need > int(src.numel()):
            raise MemoryError(
                "sort32 source view is too small: "
                f"need={src_need}, have={int(src.numel())}, repeat={repeat}"
            )
        if idx_need > int(idx.numel()):
            raise MemoryError(
                "sort32 index view is too small: "
                f"need={idx_need}, have={int(idx.numel())}, repeat={repeat}"
            )
        if dst_need > int(dst.numel()):
            raise MemoryError(
                "sort32 destination view is too small: "
                f"need={dst_need}, have={int(dst.numel())}, repeat={repeat}"
            )
        if repeat == 0:
            return

        for rep in range(repeat):
            src_start = rep * 32
            idx_start = rep * 32
            dst_start = rep * 64
            src_block = src[src_start : src_start + 32]
            idx_block = idx[idx_start : idx_start + 32]
            if idx_block.dtype != torch.int32:
                idx_block = idx_block.view(torch.int32)
            arg = torch.argsort(src_block, descending=True)
            src_sorted = src_block[arg]
            idx_sorted = idx_block[arg].contiguous()
            idx_as_float = idx_sorted.view(torch.float32)

            dst_block = dst[dst_start : dst_start + 64]
            dst_block[0::2] = src_sorted
            dst_block[1::2] = idx_as_float

    def _execute_mergesort4(self, instruction: SimInstruction) -> None:
        dst = instruction.tensors.get("dst")
        src = instruction.tensors.get("src")
        if not isinstance(dst, torch.Tensor):
            raise TypeError(f"mergesort4 requires dst tensor view, got: {type(dst)}")
        if not isinstance(src, torch.Tensor):
            raise TypeError(f"mergesort4 requires src tensor view, got: {type(src)}")
        if dst.dim() != 1:
            raise ValueError(f"mergesort4 dst must be 1D pointer view, got dim={dst.dim()}")
        if src.dim() != 1:
            raise ValueError(f"mergesort4 src must be 1D pointer view, got dim={src.dim()}")

        dst_dtype_name = instruction.tensor_dtypes.get("dst", "")
        src_dtype_name = instruction.tensor_dtypes.get("src", "")
        if dst_dtype_name != "" and dst_dtype_name != "float":
            raise TypeError(f"mergesort4 requires dst dtype float, got: {dst_dtype_name}")
        if src_dtype_name != "" and src_dtype_name != "float":
            raise TypeError(f"mergesort4 requires src dtype float, got: {src_dtype_name}")

        if dst.dtype != torch.float32:
            raise TypeError(f"mergesort4 requires dst torch dtype float32, got: {dst.dtype}")
        if src.dtype != torch.float32:
            raise TypeError(f"mergesort4 requires src torch dtype float32, got: {src.dtype}")

        length_per_seq = self._resolve_int(
            instruction.args.get("length_per_seq"),
            "mergesort4 length_per_seq",
        )
        repeat = self._resolve_int(instruction.args.get("repeat"), "mergesort4 repeat")
        if length_per_seq <= 0:
            raise ValueError(f"mergesort4 length_per_seq must be positive, got: {length_per_seq}")
        if repeat < 0:
            raise ValueError(f"mergesort4 repeat must be non-negative, got: {repeat}")

        elems_per_repeat = 8 * length_per_seq
        total_need = repeat * elems_per_repeat
        if total_need > int(src.numel()):
            raise MemoryError(
                "mergesort4 source view is too small: "
                f"need={total_need}, have={int(src.numel())}, repeat={repeat}"
            )
        if total_need > int(dst.numel()):
            raise MemoryError(
                "mergesort4 destination view is too small: "
                f"need={total_need}, have={int(dst.numel())}, repeat={repeat}"
            )
        if repeat == 0:
            return

        even_size = 4 * length_per_seq
        for rep in range(repeat):
            start = rep * elems_per_repeat
            block = src[start : start + elems_per_repeat].clone()
            even_val = block[0::2]
            odd_val = block[1::2]
            if int(even_val.numel()) != even_size or int(odd_val.numel()) != even_size:
                raise RuntimeError(
                    "mergesort4 internal shape mismatch: "
                    f"even={int(even_val.numel())}, odd={int(odd_val.numel())}, expected={even_size}"
                )

            for seq_idx in range(4):
                seq_start = seq_idx * length_per_seq
                seq_end = seq_start + length_per_seq
                seq = even_val[seq_start:seq_end]
                if int(seq.numel()) <= 1:
                    continue
                if bool(torch.any(seq[:-1] < seq[1:]).item()):
                    raise ValueError(
                        "mergesort4 requires descending even_val split, "
                        f"repeat={rep}, split={seq_idx}"
                    )

            arg = torch.argsort(even_val, descending=True)
            even_new = even_val[arg]
            odd_new = odd_val[arg]
            result = torch.empty_like(block)
            result[0::2] = even_new
            result[1::2] = odd_new
            dst[start : start + elems_per_repeat] = result

    def _execute_mergesort_2seq(self, instruction: SimInstruction) -> None:
        dst = instruction.tensors.get("dst")
        src1 = instruction.tensors.get("src1")
        src2 = instruction.tensors.get("src2")
        if not isinstance(dst, torch.Tensor):
            raise TypeError(f"mergesort_2seq requires dst tensor view, got: {type(dst)}")
        if not isinstance(src1, torch.Tensor):
            raise TypeError(f"mergesort_2seq requires src1 tensor view, got: {type(src1)}")
        if not isinstance(src2, torch.Tensor):
            raise TypeError(f"mergesort_2seq requires src2 tensor view, got: {type(src2)}")
        if dst.dim() != 1:
            raise ValueError(f"mergesort_2seq dst must be 1D pointer view, got dim={dst.dim()}")
        if src1.dim() != 1:
            raise ValueError(f"mergesort_2seq src1 must be 1D pointer view, got dim={src1.dim()}")
        if src2.dim() != 1:
            raise ValueError(f"mergesort_2seq src2 must be 1D pointer view, got dim={src2.dim()}")

        dst_dtype_name = instruction.tensor_dtypes.get("dst", "")
        src1_dtype_name = instruction.tensor_dtypes.get("src1", "")
        src2_dtype_name = instruction.tensor_dtypes.get("src2", "")
        if dst_dtype_name != "" and dst_dtype_name != "float":
            raise TypeError(f"mergesort_2seq requires dst dtype float, got: {dst_dtype_name}")
        if src1_dtype_name != "" and src1_dtype_name != "float":
            raise TypeError(f"mergesort_2seq requires src1 dtype float, got: {src1_dtype_name}")
        if src2_dtype_name != "" and src2_dtype_name != "float":
            raise TypeError(f"mergesort_2seq requires src2 dtype float, got: {src2_dtype_name}")

        if dst.dtype != torch.float32:
            raise TypeError(f"mergesort_2seq requires dst torch dtype float32, got: {dst.dtype}")
        if src1.dtype != torch.float32:
            raise TypeError(f"mergesort_2seq requires src1 torch dtype float32, got: {src1.dtype}")
        if src2.dtype != torch.float32:
            raise TypeError(f"mergesort_2seq requires src2 torch dtype float32, got: {src2.dtype}")

        size1 = self._resolve_int(instruction.args.get("size1"), "mergesort_2seq size1")
        size2 = self._resolve_int(instruction.args.get("size2"), "mergesort_2seq size2")
        if size1 <= 0:
            raise ValueError(f"mergesort_2seq size1 must be positive, got: {size1}")
        if size2 <= 0:
            raise ValueError(f"mergesort_2seq size2 must be positive, got: {size2}")

        src1_need = 2 * size1
        src2_need = 2 * size2
        dst_need = 2 * (size1 + size2)
        if src1_need > int(src1.numel()):
            raise MemoryError(
                "mergesort_2seq src1 view is too small: "
                f"need={src1_need}, have={int(src1.numel())}, size1={size1}"
            )
        if src2_need > int(src2.numel()):
            raise MemoryError(
                "mergesort_2seq src2 view is too small: "
                f"need={src2_need}, have={int(src2.numel())}, size2={size2}"
            )
        if dst_need > int(dst.numel()):
            raise MemoryError(
                "mergesort_2seq destination view is too small: "
                f"need={dst_need}, have={int(dst.numel())}, size1={size1}, size2={size2}"
            )

        src1_block = src1[:src1_need].clone()
        src2_block = src2[:src2_need].clone()
        even_1 = src1_block[0::2]
        odd_1 = src1_block[1::2]
        even_2 = src2_block[0::2]
        odd_2 = src2_block[1::2]

        if int(even_1.numel()) != size1 or int(odd_1.numel()) != size1:
            raise RuntimeError(
                "mergesort_2seq src1 deinterleave shape mismatch: "
                f"even={int(even_1.numel())}, odd={int(odd_1.numel())}, expected={size1}"
            )
        if int(even_2.numel()) != size2 or int(odd_2.numel()) != size2:
            raise RuntimeError(
                "mergesort_2seq src2 deinterleave shape mismatch: "
                f"even={int(even_2.numel())}, odd={int(odd_2.numel())}, expected={size2}"
            )

        if size1 > 1 and bool(torch.any(even_1[:-1] < even_1[1:]).item()):
            raise ValueError("mergesort_2seq requires even_1 in descending order")
        if size2 > 1 and bool(torch.any(even_2[:-1] < even_2[1:]).item()):
            raise ValueError("mergesort_2seq requires even_2 in descending order")

        even_cat = torch.cat((even_1, even_2))
        odd_cat = torch.cat((odd_1, odd_2))
        arg = torch.argsort(even_cat, descending=True)
        even_new = even_cat[arg]
        odd_new = odd_cat[arg]
        result = torch.empty((dst_need,), dtype=dst.dtype, device=dst.device)
        result[0::2] = even_new
        result[1::2] = odd_new
        dst[:dst_need] = result

    @staticmethod
    def _choose_vec_compute_dtype(dtype: torch.dtype) -> torch.dtype:
        if dtype in (torch.float16, torch.bfloat16):
            return torch.float32
        return dtype

    def _resolve_vec_layout(
        self,
        instruction: SimInstruction,
        opname: str,
        *labels: str,
    ) -> tuple[int, int, dict[str, int]]:
        repeat = self._resolve_int(instruction.args.get("repeat"), f"{opname} repeat")
        strides: dict[str, int] = {}
        for label in labels:
            value = self._resolve_int(instruction.args.get(label), f"{opname} {label}")
            if value < 0:
                raise ValueError(f"{opname} requires non-negative {label}, got: {value}")
            strides[label] = value
        if repeat < 0:
            raise ValueError(f"{opname} requires non-negative repeat, got: {repeat}")
        return repeat, 32, strides

    @staticmethod
    def _validate_vec_tensor_view(opname: str, label: str, tensor: Any) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            raise TypeError(f"{opname} requires {label} tensor view, got: {type(tensor)}")
        if tensor.dim() != 1:
            raise ValueError(f"{opname} {label} must be 1D pointer view, got dim={tensor.dim()}")
        return tensor

    @staticmethod
    def _validate_vec_dtype_match(opname: str, *tensors: torch.Tensor) -> None:
        first = tensors[0].dtype
        for tensor in tensors[1:]:
            if tensor.dtype != first:
                raise TypeError(f"{opname} requires matching torch dtypes, got: {[t.dtype for t in tensors]}")

    @staticmethod
    def _infer_vec_dtype_name(tensor: torch.Tensor) -> str:
        if tensor.dtype == torch.float16:
            return "half"
        if tensor.dtype == torch.float32:
            return "float"
        if tensor.dtype == torch.int8:
            return "int8_t"
        if tensor.dtype == torch.uint8:
            return "uint8_t"
        if tensor.dtype == torch.int16:
            return "int16_t"
        if tensor.dtype == torch.int32:
            return "int"
        if tensor.dtype == torch.int64:
            return "int64_t"
        if tensor.dtype == torch.bfloat16:
            return "bfloat16_t"
        if hasattr(torch, "uint16") and tensor.dtype == torch.uint16:  # type: ignore[attr-defined]
            return "uint16_t"
        if hasattr(torch, "uint32") and tensor.dtype == torch.uint32:  # type: ignore[attr-defined]
            return "uint32_t"
        if hasattr(torch, "uint64") and tensor.dtype == torch.uint64:  # type: ignore[attr-defined]
            return "uint64_t"
        return str(tensor.dtype)

    @staticmethod
    def _resolve_vec_dtype_name(instruction: SimInstruction, label: str, tensor: torch.Tensor) -> str:
        declared = instruction.tensor_dtypes.get(label, "")
        if declared not in ("", None):
            return str(declared)
        return VPipe._infer_vec_dtype_name(tensor)

    @staticmethod
    def _validate_vec_supported_dtypes(
        instruction: SimInstruction,
        opname: str,
        allowed_dtype_names: tuple,
        tensor_specs: tuple,
    ) -> None:
        allowed_text = ", ".join(allowed_dtype_names)
        for label, tensor in tensor_specs:
            dtype_name = VPipe._resolve_vec_dtype_name(instruction, label, tensor)
            if dtype_name not in allowed_dtype_names:
                raise TypeError(f"{opname} only supports {allowed_text}, got {label} dtype {dtype_name}")

    @staticmethod
    def _calc_vec_need(repeat: int, rep_stride: int, blk_stride: int, elems_per_block: int) -> int:
        if repeat == 0:
            return 0
        max_block_idx = (repeat - 1) * rep_stride + 7 * blk_stride
        return (max_block_idx + 1) * elems_per_block

    def _mask_block_slice(self, elems_per_block: int, blk: int) -> torch.Tensor:
        begin = blk * elems_per_block
        end = begin + elems_per_block
        if end > int(self.current_mask.numel()):
            raise ValueError(
                f"vector mask is too short for elems_per_block={elems_per_block}, blk={blk}, "
                f"have={int(self.current_mask.numel())}"
            )
        return self.current_mask[begin:end]

    def _mask_prefix_slice(self, elems: int) -> torch.Tensor:
        if elems > int(self.current_mask.numel()):
            raise ValueError(
                f"vector mask is too short for elems={elems}, have={int(self.current_mask.numel())}"
            )
        return self.current_mask[:elems]

    def _masked_write_block(self, dst_block: torch.Tensor, result: torch.Tensor, mask_block: torch.Tensor) -> None:
        if int(mask_block.numel()) != int(dst_block.numel()):
            raise ValueError(
                f"mask block length mismatch: mask={int(mask_block.numel())}, dst={int(dst_block.numel())}"
            )
        res = result.to(dst_block.dtype)
        mask_bool = mask_block.to(torch.bool)
        # Default simulator mask is all-ones; avoid per-block clone + where in the common case.
        if bool(mask_bool.all().item()):
            dst_block.copy_(res)
            return
        dst_snapshot = dst_block.clone()
        dst_block.copy_(torch.where(mask_bool, res, dst_snapshot))

    def _masked_write_chunk(
        self,
        dst_slice: torch.Tensor,
        result: torch.Tensor,
        elems_per_block: int,
    ) -> None:
        """Write one hardware repeat (8 C0 blocks) using mask current_mask[0 : 8*elems_per_block]."""
        chunk = 8 * elems_per_block
        if int(dst_slice.numel()) != chunk or int(result.numel()) != chunk:
            raise ValueError(
                f"masked chunk write size mismatch: dst={int(dst_slice.numel())}, "
                f"result={int(result.numel())}, chunk={chunk}"
            )
        if chunk > int(self.current_mask.numel()):
            raise ValueError(f"vector mask shorter than chunk={chunk}")
        mask_bool = self.current_mask[0:chunk].to(torch.bool)
        res = result.to(dst_slice.dtype)
        if bool(mask_bool.all().item()):
            dst_slice.copy_(res)
            return
        dst_snapshot = dst_slice.clone()
        dst_slice.copy_(torch.where(mask_bool, res, dst_snapshot))

    def _vec_mask_chunk_all_true(self, chunk: int) -> bool:
        if chunk > int(self.current_mask.numel()):
            return False
        return bool(self.current_mask[0:chunk].to(torch.bool).all().item())

    @staticmethod
    def _bitwise_not_with_fallback(src_block: torch.Tensor) -> torch.Tensor:
        if hasattr(torch, "uint16") and src_block.dtype == torch.uint16:  # type: ignore[attr-defined]
            return torch.bitwise_not(src_block.view(torch.int16)).view(torch.uint16)  # type: ignore[attr-defined]
        if hasattr(torch, "uint32") and src_block.dtype == torch.uint32:  # type: ignore[attr-defined]
            return torch.bitwise_not(src_block.view(torch.int32)).view(torch.uint32)  # type: ignore[attr-defined]
        if hasattr(torch, "uint64") and src_block.dtype == torch.uint64:  # type: ignore[attr-defined]
            return torch.bitwise_not(src_block.view(torch.int64)).view(torch.uint64)  # type: ignore[attr-defined]
        return torch.bitwise_not(src_block)

    @staticmethod
    def _apply_unary_op(opname: str, src_block: torch.Tensor, compute_dtype: torch.dtype) -> torch.Tensor:
        if opname == "vnot":
            return VPipe._bitwise_not_with_fallback(src_block)
        value = src_block.to(compute_dtype)
        if opname == "exp":
            return torch.exp(value)
        if opname == "ln":
            return torch.log(value)
        if opname == "abs":
            return torch.abs(value)
        if opname == "rec":
            return torch.reciprocal(value)
        if opname == "sqrt":
            return torch.sqrt(value)
        if opname == "rsqrt":
            return torch.rsqrt(value)
        if opname == "relu":
            return torch.clamp_min(value, 0)
        raise ValueError(f"unsupported unary vec opname: {opname}")

    @staticmethod
    def _apply_binary_op(
        opname: str,
        src1_block: torch.Tensor,
        src2_block: torch.Tensor,
        dst_block: torch.Tensor,
        compute_dtype: torch.dtype,
    ) -> torch.Tensor:
        if opname == "vand":
            return torch.bitwise_and(src1_block, src2_block)
        if opname == "vor":
            return torch.bitwise_or(src1_block, src2_block)
        lhs = src1_block.to(compute_dtype)
        rhs = src2_block.to(compute_dtype)
        if opname == "add":
            return lhs + rhs
        if opname == "sub":
            return lhs - rhs
        if opname == "mul":
            return lhs * rhs
        if opname == "div":
            return lhs / rhs
        if opname == "vmax":
            return torch.maximum(lhs, rhs)
        if opname == "vmin":
            return torch.minimum(lhs, rhs)
        if opname == "muladddst":
            return dst_block.to(compute_dtype) + lhs * rhs
        raise ValueError(f"unsupported binary vec opname: {opname}")

    @staticmethod
    def _apply_unary_scalar_op(
        opname: str,
        src_block: torch.Tensor,
        dst_block: torch.Tensor,
        value: Any,
        compute_dtype: torch.dtype,
    ) -> torch.Tensor:
        scalar = torch.tensor(value, dtype=compute_dtype, device=src_block.device)
        src_value = src_block.to(compute_dtype)
        if opname == "adds":
            return src_value + scalar
        if opname == "muls":
            return src_value * scalar
        if opname == "vmaxs":
            return torch.maximum(src_value, scalar)
        if opname == "vmins":
            return torch.minimum(src_value, scalar)
        if opname == "lrelu":
            return torch.where(src_value > 0, src_value, src_value * scalar)
        if opname == "axpy":
            return dst_block.to(compute_dtype) + src_value * scalar
        raise ValueError(f"unsupported unary-scalar vec opname: {opname}")

    @staticmethod
    def _apply_cast_round_mode(values: torch.Tensor, mode_name: str) -> torch.Tensor:
        if mode_name in ("CAST_NONE", "CAST_TRUNC"):
            return torch.trunc(values)
        if mode_name == "CAST_FLOOR":
            return torch.floor(values)
        if mode_name == "CAST_CEIL":
            return torch.ceil(values)
        if mode_name == "CAST_ROUND":
            return torch.sign(values) * torch.ceil(torch.abs(values))
        if mode_name == "CAST_RINT":
            return torch.round(values)
        raise ValueError(f"unsupported vec cast round mode: {mode_name}")

    @staticmethod
    def _apply_compare_mode(lhs: torch.Tensor, rhs: torch.Tensor, mode_name: str) -> torch.Tensor:
        if mode_name == "LT":
            return lhs < rhs
        if mode_name == "LE":
            return lhs <= rhs
        if mode_name == "GT":
            return lhs > rhs
        if mode_name == "GE":
            return lhs >= rhs
        if mode_name == "EQ":
            return lhs == rhs
        if mode_name == "NE":
            return lhs != rhs
        raise ValueError(f"unsupported vec compare mode: {mode_name}")

    def _execute_unary(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src = self._validate_vec_tensor_view(opname, "src", instruction.tensors.get("src"))
        self._validate_vec_dtype_match(opname, src, dst)
        if opname == "vnot":
            self._validate_vec_supported_dtypes(
                instruction,
                opname,
                _VEC_VNOT_DTYPE_NAMES,
                (("dst", dst), ("src", src)),
            )

        if self.vector_mode == "count":
            count = self.count_register
            if count == 0:
                return
            if count > int(src.numel()):
                raise MemoryError(f"{opname} src view is too small for counter mode: need={count}, have={int(src.numel())}")
            if count > int(dst.numel()):
                raise MemoryError(f"{opname} dst view is too small for counter mode: need={count}, have={int(dst.numel())}")
            compute_dtype = self._choose_vec_compute_dtype(src.dtype)
            src_h = src[0:count].clone()
            result = self._apply_unary_op(opname, src_h, compute_dtype)
            dst[0:count].copy_(result.to(dst.dtype))
            return

        repeat, datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_blk_stride",
            "src_blk_stride",
            "dst_rep_stride",
            "src_rep_stride",
        )
        elem_size = int(src.element_size())
        if elem_size <= 0 or (datablock_bytes % elem_size) != 0:
            raise ValueError(f"{opname} unsupported tensor element size for 32-byte datablock: {elem_size}")
        elems_per_block = datablock_bytes // elem_size
        if repeat == 0:
            return

        src_need = self._calc_vec_need(repeat, strides["src_rep_stride"], strides["src_blk_stride"], elems_per_block)
        dst_need = self._calc_vec_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
        if src_need > int(src.numel()):
            raise MemoryError(
                f"{opname} source view is too small: need={src_need}, have={int(src.numel())}, elems_per_block={elems_per_block}"
            )
        if dst_need > int(dst.numel()):
            raise MemoryError(
                f"{opname} destination view is too small: need={dst_need}, have={int(dst.numel())}, elems_per_block={elems_per_block}"
            )

        compute_dtype = self._choose_vec_compute_dtype(src.dtype)
        chunk = 8 * elems_per_block
        if (
            strides["src_blk_stride"] == 1
            and strides["dst_blk_stride"] == 1
            and strides["src_rep_stride"] == 8
            and strides["dst_rep_stride"] == 8
            and repeat > 0
            and src_need == repeat * chunk
            and dst_need == repeat * chunk
            and self._vec_mask_chunk_all_true(chunk)
        ):
            total = repeat * chunk
            src_h = src[0:total].clone()
            result = self._apply_unary_op(opname, src_h, compute_dtype)
            dst[0:total].copy_(result.to(dst.dtype))
            return
        if strides["src_blk_stride"] == 1 and strides["dst_blk_stride"] == 1:
            for rep in range(repeat):
                src_rep_base = rep * strides["src_rep_stride"] * elems_per_block
                dst_rep_base = rep * strides["dst_rep_stride"] * elems_per_block
                src_slice = src[src_rep_base : src_rep_base + chunk].clone()
                dst_slice = dst[dst_rep_base : dst_rep_base + chunk]
                result = self._apply_unary_op(opname, src_slice, compute_dtype)
                self._masked_write_chunk(dst_slice, result, elems_per_block)
            return
        for rep in range(repeat):
            src_rep_base = rep * strides["src_rep_stride"] * elems_per_block
            dst_rep_base = rep * strides["dst_rep_stride"] * elems_per_block
            for blk in range(8):
                src_begin = src_rep_base + blk * strides["src_blk_stride"] * elems_per_block
                dst_begin = dst_rep_base + blk * strides["dst_blk_stride"] * elems_per_block
                src_block = src[src_begin : src_begin + elems_per_block].clone()
                dst_block = dst[dst_begin : dst_begin + elems_per_block]
                result = self._apply_unary_op(opname, src_block, compute_dtype)
                self._masked_write_block(dst_block, result, self._mask_block_slice(elems_per_block, blk))

    def _execute_binary(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src1 = self._validate_vec_tensor_view(opname, "src1", instruction.tensors.get("src1"))
        src2 = self._validate_vec_tensor_view(opname, "src2", instruction.tensors.get("src2"))
        self._validate_vec_dtype_match(opname, dst, src1, src2)
        if opname == "vand":
            self._validate_vec_supported_dtypes(
                instruction,
                opname,
                _VEC_VAND_DTYPE_NAMES,
                (("dst", dst), ("src1", src1), ("src2", src2)),
            )

        if self.vector_mode == "count":
            count = self.count_register
            if count == 0:
                return
            if count > int(src1.numel()):
                raise MemoryError(f"{opname} src1 view is too small for counter mode: need={count}, have={int(src1.numel())}")
            if count > int(src2.numel()):
                raise MemoryError(f"{opname} src2 view is too small for counter mode: need={count}, have={int(src2.numel())}")
            if count > int(dst.numel()):
                raise MemoryError(f"{opname} dst view is too small for counter mode: need={count}, have={int(dst.numel())}")
            compute_dtype = self._choose_vec_compute_dtype(dst.dtype)
            src1_h = src1[0:count].clone()
            src2_h = src2[0:count].clone()
            if opname == "muladddst":
                dst_snap = dst[0:count].clone()
            else:
                dst_snap = dst[0:count]
            result = self._apply_binary_op(opname, src1_h, src2_h, dst_snap, compute_dtype)
            dst[0:count].copy_(result.to(dst.dtype))
            return

        repeat, datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_blk_stride",
            "src1_blk_stride",
            "src2_blk_stride",
            "dst_rep_stride",
            "src1_rep_stride",
            "src2_rep_stride",
        )
        elem_size = int(dst.element_size())
        if elem_size <= 0 or (datablock_bytes % elem_size) != 0:
            raise ValueError(f"{opname} unsupported tensor element size for 32-byte datablock: {elem_size}")
        elems_per_block = datablock_bytes // elem_size
        if repeat == 0:
            return

        src1_need = self._calc_vec_need(repeat, strides["src1_rep_stride"], strides["src1_blk_stride"], elems_per_block)
        src2_need = self._calc_vec_need(repeat, strides["src2_rep_stride"], strides["src2_blk_stride"], elems_per_block)
        dst_need = self._calc_vec_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
        if src1_need > int(src1.numel()):
            raise MemoryError(f"{opname} src1 view is too small: need={src1_need}, have={int(src1.numel())}")
        if src2_need > int(src2.numel()):
            raise MemoryError(f"{opname} src2 view is too small: need={src2_need}, have={int(src2.numel())}")
        if dst_need > int(dst.numel()):
            raise MemoryError(f"{opname} dst view is too small: need={dst_need}, have={int(dst.numel())}")

        compute_dtype = self._choose_vec_compute_dtype(dst.dtype)
        chunk = 8 * elems_per_block
        if (
            strides["src1_blk_stride"] == 1
            and strides["src2_blk_stride"] == 1
            and strides["dst_blk_stride"] == 1
            and strides["src1_rep_stride"] == 8
            and strides["src2_rep_stride"] == 8
            and strides["dst_rep_stride"] == 8
            and repeat > 0
            and src1_need == repeat * chunk
            and src2_need == repeat * chunk
            and dst_need == repeat * chunk
            and self._vec_mask_chunk_all_true(chunk)
        ):
            total = repeat * chunk
            src1_h = src1[0:total].clone()
            src2_h = src2[0:total].clone()
            if opname == "muladddst":
                dst_snap = dst[0:total].clone()
            else:
                dst_snap = dst[0:total]
            result = self._apply_binary_op(opname, src1_h, src2_h, dst_snap, compute_dtype)
            dst[0:total].copy_(result.to(dst.dtype))
            return
        if strides["src1_blk_stride"] == 1 and strides["src2_blk_stride"] == 1 and strides["dst_blk_stride"] == 1:
            for rep in range(repeat):
                src1_rep_base = rep * strides["src1_rep_stride"] * elems_per_block
                src2_rep_base = rep * strides["src2_rep_stride"] * elems_per_block
                dst_rep_base = rep * strides["dst_rep_stride"] * elems_per_block
                src1_chunk = src1[src1_rep_base : src1_rep_base + chunk].clone()
                src2_chunk = src2[src2_rep_base : src2_rep_base + chunk].clone()
                dst_chunk = dst[dst_rep_base : dst_rep_base + chunk]
                if opname == "muladddst":
                    dst_snap = dst_chunk.clone()
                else:
                    dst_snap = dst_chunk
                result = self._apply_binary_op(opname, src1_chunk, src2_chunk, dst_snap, compute_dtype)
                self._masked_write_chunk(dst_chunk, result, elems_per_block)
            return
        for rep in range(repeat):
            src1_rep_base = rep * strides["src1_rep_stride"] * elems_per_block
            src2_rep_base = rep * strides["src2_rep_stride"] * elems_per_block
            dst_rep_base = rep * strides["dst_rep_stride"] * elems_per_block
            for blk in range(8):
                src1_begin = src1_rep_base + blk * strides["src1_blk_stride"] * elems_per_block
                src2_begin = src2_rep_base + blk * strides["src2_blk_stride"] * elems_per_block
                dst_begin = dst_rep_base + blk * strides["dst_blk_stride"] * elems_per_block
                src1_block = src1[src1_begin : src1_begin + elems_per_block].clone()
                src2_block = src2[src2_begin : src2_begin + elems_per_block].clone()
                dst_block = dst[dst_begin : dst_begin + elems_per_block]
                dst_snapshot = dst_block.clone()
                result = self._apply_binary_op(opname, src1_block, src2_block, dst_snapshot, compute_dtype)
                self._masked_write_block(dst_block, result, self._mask_block_slice(elems_per_block, blk))

    def _execute_unary_scalar(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src = self._validate_vec_tensor_view(opname, "src", instruction.tensors.get("src"))
        self._validate_vec_dtype_match(opname, dst, src)
        value = instruction.args.get("val")

        if self.vector_mode == "count":
            count = self.count_register
            if count == 0:
                return
            if count > int(src.numel()):
                raise MemoryError(f"{opname} src view is too small for counter mode: need={count}, have={int(src.numel())}")
            if count > int(dst.numel()):
                raise MemoryError(f"{opname} dst view is too small for counter mode: need={count}, have={int(dst.numel())}")
            compute_dtype = self._choose_vec_compute_dtype(dst.dtype)
            src_h = src[0:count].clone()
            if opname == "axpy":
                dst_snap = dst[0:count].clone()
            else:
                dst_snap = dst[0:count]
            result = self._apply_unary_scalar_op(opname, src_h, dst_snap, value, compute_dtype)
            dst[0:count].copy_(result.to(dst.dtype))
            return

        repeat, datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_blk_stride",
            "src_blk_stride",
            "dst_rep_stride",
            "src_rep_stride",
        )
        elem_size = int(dst.element_size())
        if elem_size <= 0 or (datablock_bytes % elem_size) != 0:
            raise ValueError(f"{opname} unsupported tensor element size for 32-byte datablock: {elem_size}")
        elems_per_block = datablock_bytes // elem_size
        if repeat == 0:
            return

        src_need = self._calc_vec_need(repeat, strides["src_rep_stride"], strides["src_blk_stride"], elems_per_block)
        dst_need = self._calc_vec_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
        if src_need > int(src.numel()):
            raise MemoryError(f"{opname} src view is too small: need={src_need}, have={int(src.numel())}")
        if dst_need > int(dst.numel()):
            raise MemoryError(f"{opname} dst view is too small: need={dst_need}, have={int(dst.numel())}")

        compute_dtype = self._choose_vec_compute_dtype(dst.dtype)
        chunk = 8 * elems_per_block
        if (
            strides["src_blk_stride"] == 1
            and strides["dst_blk_stride"] == 1
            and strides["src_rep_stride"] == 8
            and strides["dst_rep_stride"] == 8
            and repeat > 0
            and src_need == repeat * chunk
            and dst_need == repeat * chunk
            and self._vec_mask_chunk_all_true(chunk)
        ):
            total = repeat * chunk
            src_h = src[0:total].clone()
            if opname == "axpy":
                dst_snap = dst[0:total].clone()
            else:
                dst_snap = dst[0:total]
            result = self._apply_unary_scalar_op(opname, src_h, dst_snap, value, compute_dtype)
            dst[0:total].copy_(result.to(dst.dtype))
            return
        if strides["src_blk_stride"] == 1 and strides["dst_blk_stride"] == 1:
            for rep in range(repeat):
                src_rep_base = rep * strides["src_rep_stride"] * elems_per_block
                dst_rep_base = rep * strides["dst_rep_stride"] * elems_per_block
                src_slice = src[src_rep_base : src_rep_base + chunk].clone()
                dst_slice = dst[dst_rep_base : dst_rep_base + chunk]
                if opname == "axpy":
                    dst_snap = dst_slice.clone()
                else:
                    dst_snap = dst_slice
                result = self._apply_unary_scalar_op(opname, src_slice, dst_snap, value, compute_dtype)
                self._masked_write_chunk(dst_slice, result, elems_per_block)
            return
        for rep in range(repeat):
            src_rep_base = rep * strides["src_rep_stride"] * elems_per_block
            dst_rep_base = rep * strides["dst_rep_stride"] * elems_per_block
            for blk in range(8):
                src_begin = src_rep_base + blk * strides["src_blk_stride"] * elems_per_block
                dst_begin = dst_rep_base + blk * strides["dst_blk_stride"] * elems_per_block
                src_block = src[src_begin : src_begin + elems_per_block].clone()
                dst_block = dst[dst_begin : dst_begin + elems_per_block]
                dst_snapshot = dst_block.clone()
                result = self._apply_unary_scalar_op(opname, src_block, dst_snapshot, value, compute_dtype)
                self._masked_write_block(dst_block, result, self._mask_block_slice(elems_per_block, blk))

    def _execute_dup(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        self._validate_vec_supported_dtypes(
            instruction,
            opname,
            _VEC_DUP_DTYPE_NAMES,
            (("dst", dst),),
        )
        value = instruction.args.get("src")

        if self.vector_mode == "count":
            count = self.count_register
            if count == 0:
                return
            if count > int(dst.numel()):
                raise MemoryError(f"{opname} dst view is too small for counter mode: need={count}, have={int(dst.numel())}")
            fill_value = torch.tensor(value, dtype=dst.dtype, device=dst.device).item()
            dst[0:count].fill_(fill_value)
            return

        repeat, datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_blk_stride",
            "dst_rep_stride",
        )
        elem_size = int(dst.element_size())
        if elem_size <= 0 or (datablock_bytes % elem_size) != 0:
            raise ValueError(f"{opname} unsupported tensor element size for 32-byte datablock: {elem_size}")
        elems_per_block = datablock_bytes // elem_size
        if repeat == 0:
            return

        dst_need = self._calc_vec_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
        if dst_need > int(dst.numel()):
            raise MemoryError(f"{opname} dst view is too small: need={dst_need}, have={int(dst.numel())}")

        fill_value = torch.tensor(value, dtype=dst.dtype, device=dst.device)
        fv = fill_value.item()
        chunk = 8 * elems_per_block
        if (
            strides["dst_blk_stride"] == 1
            and strides["dst_rep_stride"] == 8
            and repeat > 0
            and dst_need == repeat * chunk
            and self._vec_mask_chunk_all_true(chunk)
        ):
            total = repeat * chunk
            dst[0:total].fill_(fv)
            return
        if strides["dst_blk_stride"] == 1:
            for rep in range(repeat):
                dst_rep_base = rep * strides["dst_rep_stride"] * elems_per_block
                dst_slice = dst[dst_rep_base : dst_rep_base + chunk]
                result = torch.full((chunk,), fv, dtype=dst.dtype, device=dst.device)
                self._masked_write_chunk(dst_slice, result, elems_per_block)
            return
        for rep in range(repeat):
            dst_rep_base = rep * strides["dst_rep_stride"] * elems_per_block
            for blk in range(8):
                dst_begin = dst_rep_base + blk * strides["dst_blk_stride"] * elems_per_block
                dst_block = dst[dst_begin : dst_begin + elems_per_block]
                result = torch.full((elems_per_block,), fv, dtype=dst.dtype, device=dst.device)
                self._masked_write_block(dst_block, result, self._mask_block_slice(elems_per_block, blk))

    # brcb ignores the current vector mask; broadcasted blocks are always written
    # according to brcb stride semantics.
    def _execute_brcb(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src = self._validate_vec_tensor_view(opname, "src", instruction.tensors.get("src"))
        self._validate_vec_dtype_match(opname, dst, src)

        repeat, datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_blk_stride",
            "dst_rep_stride",
        )
        elem_size = int(dst.element_size())
        if elem_size <= 0 or (datablock_bytes % elem_size) != 0:
            raise ValueError(f"{opname} unsupported tensor element size for 32-byte datablock: {elem_size}")
        elems_per_block = datablock_bytes // elem_size
        if repeat == 0:
            return

        src_need = repeat * 8
        dst_need = self._calc_vec_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
        if src_need > int(src.numel()):
            raise MemoryError(f"{opname} src view is too small: need={src_need}, have={int(src.numel())}")
        if dst_need > int(dst.numel()):
            raise MemoryError(f"{opname} dst view is too small: need={dst_need}, have={int(dst.numel())}")

        for rep in range(repeat):
            src_rep_base = rep * 8
            dst_rep_base = rep * strides["dst_rep_stride"] * elems_per_block
            for blk in range(8):
                dst_begin = dst_rep_base + blk * strides["dst_blk_stride"] * elems_per_block
                scalar = src[src_rep_base + blk].item()
                fill_value = torch.tensor(scalar, dtype=dst.dtype, device=dst.device).item()
                dst[dst_begin : dst_begin + elems_per_block].fill_(fill_value)

    def _execute_cast(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src = self._validate_vec_tensor_view(opname, "src", instruction.tensors.get("src"))

        if self.vector_mode == "count":
            count = self.count_register
            if count == 0:
                return
            if count > int(src.numel()):
                raise MemoryError(f"{opname} src view is too small for counter mode: need={count}, have={int(src.numel())}")
            if count > int(dst.numel()):
                raise MemoryError(f"{opname} dst view is too small for counter mode: need={count}, have={int(dst.numel())}")
            mode_name = str(instruction.args.get("mode", "CAST_NONE"))
            src_chunk = src[0:count].clone()
            if src.dtype == dst.dtype:
                if src_chunk.dtype.is_floating_point:
                    compute_dtype = self._choose_vec_compute_dtype(src_chunk.dtype)
                    result = torch.round(src_chunk.to(compute_dtype)).to(dst.dtype)
                else:
                    result = src_chunk
            elif src_chunk.dtype.is_floating_point and not dst.dtype.is_floating_point:
                rounded = self._apply_cast_round_mode(src_chunk.to(torch.float32), mode_name)
                result = rounded.to(dst.dtype)
            else:
                result = src_chunk.to(dst.dtype)
            dst[0:count].copy_(result)
            return

        repeat, _datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_blk_stride",
            "src_blk_stride",
            "dst_rep_stride",
            "src_rep_stride",
        )
        if repeat == 0:
            return

        dst_elem_size = int(dst.element_size())
        src_elem_size = int(src.element_size())
        dst_c0 = 32 // dst_elem_size
        src_c0 = 32 // src_elem_size
        elems_per_repeat_dst = strides["dst_rep_stride"] * dst_c0
        elems_per_repeat_src = strides["src_rep_stride"] * src_c0
        logical_elem_size = max(dst_elem_size, src_elem_size)
        logical_elems_per_block = 32 // logical_elem_size
        logical_elems_per_repeat = (
            elems_per_repeat_dst if dst_elem_size == logical_elem_size else elems_per_repeat_src
        )
        if elems_per_repeat_dst != logical_elems_per_repeat or elems_per_repeat_src != logical_elems_per_repeat:
            raise ValueError(
                f"{opname} requires matching cast element count per repeat based on the wider dtype, got "
                f"logical={logical_elems_per_repeat} (elem_size={logical_elem_size}, logical_c0={logical_elems_per_block}), "
                f"dst={elems_per_repeat_dst} (rep_stride={strides['dst_rep_stride']}, c0={dst_c0}) vs "
                f"src={elems_per_repeat_src} (rep_stride={strides['src_rep_stride']}, c0={src_c0})"
            )

        src_need = repeat * elems_per_repeat_src
        dst_need = repeat * elems_per_repeat_dst
        if src_need > int(src.numel()):
            raise MemoryError(f"{opname} src view is too small: need={src_need}, have={int(src.numel())}")
        if dst_need > int(dst.numel()):
            raise MemoryError(f"{opname} dst view is too small: need={dst_need}, have={int(dst.numel())}")

        # Cast ignores block strides in practice: each repeat consumes one contiguous
        # logical span on both src and dst. Only repeat strides matter here.
        # The current vec mask is resolved on the cast element domain, whose length
        # per block/repeat is determined by the wider of src/dst dtypes.
        mode_name = str(instruction.args.get("mode", "CAST_NONE"))
        mask_prefix = self._mask_prefix_slice(logical_elems_per_repeat).to(torch.bool)
        mask_all = bool(mask_prefix.all().item())
        for rep in range(repeat):
            src_begin = rep * elems_per_repeat_src
            dst_begin = rep * elems_per_repeat_dst
            src_chunk = src[src_begin : src_begin + elems_per_repeat_src].clone()
            dst_chunk = dst[dst_begin : dst_begin + elems_per_repeat_dst]
            if src.dtype == dst.dtype:
                if src_chunk.dtype.is_floating_point:
                    compute_dtype = self._choose_vec_compute_dtype(src_chunk.dtype)
                    result = torch.round(src_chunk.to(compute_dtype)).to(dst.dtype)
                else:
                    result = src_chunk
            elif src_chunk.dtype.is_floating_point and not dst.dtype.is_floating_point:
                rounded = self._apply_cast_round_mode(src_chunk.to(torch.float32), mode_name)
                result = rounded.to(dst.dtype)
            else:
                result = src_chunk.to(dst.dtype)
            if mask_all:
                dst_chunk.copy_(result)
            else:
                dst_snapshot = dst_chunk.clone()
                dst_chunk.copy_(torch.where(mask_prefix, result, dst_snapshot))

    def _execute_group_reduce(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src = self._validate_vec_tensor_view(opname, "src", instruction.tensors.get("src"))
        self._validate_vec_dtype_match(opname, dst, src)

        repeat, datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_rep_stride",
            "src_blk_stride",
            "src_rep_stride",
        )
        elem_size = int(src.element_size())
        if elem_size <= 0 or (datablock_bytes % elem_size) != 0:
            raise ValueError(f"{opname} unsupported tensor element size for 32-byte datablock: {elem_size}")
        elems_per_block = datablock_bytes // elem_size
        elems_per_repeat_src = elems_per_block * 8
        if repeat == 0:
            return

        src_need = self._calc_vec_need(repeat, strides["src_rep_stride"], strides["src_blk_stride"], elems_per_block)
        if opname in ("cmax", "cmin", "cadd"):
            dst_need = (repeat - 1) * strides["dst_rep_stride"] + 1
        elif opname in ("cgmax", "cgmin", "cgadd"):
            dst_need = (repeat - 1) * strides["dst_rep_stride"] * 8 + 8
        else:
            raise ValueError(f"unsupported vec group reduction opname: {opname}")
        if src_need > int(src.numel()):
            raise MemoryError(f"{opname} src view is too small: need={src_need}, have={int(src.numel())}")
        if dst_need > int(dst.numel()):
            raise MemoryError(f"{opname} dst view is too small: need={dst_need}, have={int(dst.numel())}")

        compute_dtype = self._choose_vec_compute_dtype(src.dtype)
        for rep in range(repeat):
            src_rep_base = rep * strides["src_rep_stride"] * elems_per_block
            blocks = []
            block_masks = []
            for blk in range(8):
                src_begin = src_rep_base + blk * strides["src_blk_stride"] * elems_per_block
                block = src[src_begin : src_begin + elems_per_block].clone().to(compute_dtype)
                mask_block = self._mask_block_slice(elems_per_block, blk).to(torch.bool)
                block_masks.append(mask_block)
                if opname in ("cadd", "cgadd"):
                    block = torch.where(mask_block, block, torch.zeros_like(block))
                elif opname in ("cmax", "cgmax"):
                    neg_inf = torch.full_like(block, float("-inf"))
                    block = torch.where(mask_block, block, neg_inf)
                blocks.append(block)

            if opname == "cmax":
                dst_index = rep * strides["dst_rep_stride"]
                combined_mask = torch.cat(block_masks, dim=0)
                if bool(torch.any(combined_mask).item()):
                    reduced = torch.max(torch.cat(blocks, dim=0))
                    dst[dst_index] = reduced.to(dst.dtype)
            elif opname == "cmin":
                dst_index = rep * strides["dst_rep_stride"]
                combined_mask = torch.cat(block_masks, dim=0)
                if bool(torch.any(combined_mask).item()):
                    reduced = torch.min(torch.cat(blocks, dim=0))
                    dst[dst_index] = reduced.to(dst.dtype)
            elif opname == "cadd":
                dst_index = rep * strides["dst_rep_stride"]
                combined_mask = torch.cat(block_masks, dim=0)
                if bool(torch.any(combined_mask).item()):
                    reduced = torch.sum(torch.cat(blocks, dim=0))
                    dst[dst_index] = reduced.to(dst.dtype)
            elif opname == "cgmax":
                dst_base = rep * strides["dst_rep_stride"] * 8
                for blk, block in enumerate(blocks):
                    if bool(torch.any(block_masks[blk]).item()):
                        dst[dst_base + blk] = torch.max(block).to(dst.dtype)
            elif opname == "cgmin":
                dst_base = rep * strides["dst_rep_stride"] * 8
                for blk, block in enumerate(blocks):
                    if bool(torch.any(block_masks[blk]).item()):
                        dst[dst_base + blk] = torch.min(block).to(dst.dtype)
            elif opname == "cgadd":
                dst_base = rep * strides["dst_rep_stride"] * 8
                for blk, block in enumerate(blocks):
                    if bool(torch.any(block_masks[blk]).item()):
                        dst[dst_base + blk] = torch.sum(block).to(dst.dtype)
            else:
                raise ValueError(f"unsupported vec group reduction opname: {opname}")

    def _execute_cpadd(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src = self._validate_vec_tensor_view(opname, "src", instruction.tensors.get("src"))
        self._validate_vec_dtype_match(opname, dst, src)

        repeat, datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_rep_stride",
            "src_blk_stride",
            "src_rep_stride",
        )
        elem_size = int(src.element_size())
        if elem_size <= 0 or (datablock_bytes % elem_size) != 0:
            raise ValueError(f"{opname} unsupported tensor element size for 32-byte datablock: {elem_size}")
        elems_per_block = datablock_bytes // elem_size
        elems_per_repeat_src = elems_per_block * 8
        if (elems_per_repeat_src % 2) != 0:
            raise ValueError(f"{opname} requires even element count per repeat, got {elems_per_repeat_src}")
        out_elems_per_repeat = elems_per_repeat_src // 2
        if repeat == 0:
            return

        src_need = self._calc_vec_need(repeat, strides["src_rep_stride"], strides["src_blk_stride"], elems_per_block)
        dst_need = (repeat - 1) * strides["dst_rep_stride"] * out_elems_per_repeat + out_elems_per_repeat
        if src_need > int(src.numel()):
            raise MemoryError(f"{opname} src view is too small: need={src_need}, have={int(src.numel())}")
        if dst_need > int(dst.numel()):
            raise MemoryError(f"{opname} dst view is too small: need={dst_need}, have={int(dst.numel())}")

        compute_dtype = self._choose_vec_compute_dtype(src.dtype)
        for rep in range(repeat):
            src_rep_base = rep * strides["src_rep_stride"] * elems_per_block
            gathered = []
            for blk in range(8):
                src_begin = src_rep_base + blk * strides["src_blk_stride"] * elems_per_block
                block = src[src_begin : src_begin + elems_per_block].clone().to(compute_dtype)
                mask_block = self._mask_block_slice(elems_per_block, blk).to(torch.bool)
                block = torch.where(mask_block, block, torch.zeros_like(block))
                gathered.append(block)
            src_chunk = torch.cat(gathered, dim=0)
            flat_pair_sum = src_chunk.reshape(-1, 2).sum(dim=1)
            dst_base = rep * strides["dst_rep_stride"] * out_elems_per_repeat
            dst[dst_base : dst_base + out_elems_per_repeat].copy_(flat_pair_sum.to(dst.dtype))

    def _execute_gather(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src = self._validate_vec_tensor_view(opname, "src", instruction.tensors.get("src"))
        offset = self._validate_vec_tensor_view(opname, "offset", instruction.tensors.get("offset"))
        self._validate_vec_dtype_match(opname, dst, src)
        allowed_offset_dtypes = [torch.int32]
        if hasattr(torch, "uint32"):
            allowed_offset_dtypes.append(torch.uint32)  # type: ignore[attr-defined]
        if offset.dtype not in tuple(allowed_offset_dtypes):
            raise TypeError(
                f"{opname} requires offset view with uint32/int32-compatible bit layout, got: {offset.dtype}"
            )

        if self.vector_mode == "count":
            count = self.count_register
            if count == 0:
                return
            start_idx = self._resolve_int(instruction.args.get("start_idx", 0), f"{opname} start_idx")
            if start_idx < 0:
                raise ValueError(f"{opname} requires non-negative start_idx, got {start_idx}")
            if count > int(offset.numel()):
                raise MemoryError(f"{opname} offset view is too small for counter mode: need={count}, have={int(offset.numel())}")
            if count > int(dst.numel()):
                raise MemoryError(f"{opname} dst view is too small for counter mode: need={count}, have={int(dst.numel())}")
            elem_size = int(src.element_size())
            for i in range(count):
                byte_addr = start_idx + int(offset[i].item())
                if (byte_addr % elem_size) != 0:
                    raise ValueError(
                        f"{opname} offset byte address must align with element size {elem_size}, got {byte_addr}"
                    )
                src_index = byte_addr // elem_size
                if src_index < 0 or src_index >= int(src.numel()):
                    raise MemoryError(
                        f"{opname} source index out of range: src_index={src_index}, have={int(src.numel())}, "
                        f"byte_addr={byte_addr}, elem_size={elem_size}"
                    )
                dst[i] = src[src_index]
            return

        repeat = self._resolve_int(instruction.args.get("repeat"), f"{opname} repeat")
        dst_rep_stride = self._resolve_int(instruction.args.get("dst_rep_stride"), f"{opname} dst_rep_stride")
        start_idx = self._resolve_int(instruction.args.get("start_idx", 0), f"{opname} start_idx")
        if repeat < 0 or dst_rep_stride < 0 or start_idx < 0:
            raise ValueError(
                f"{opname} requires non-negative repeat/dst_rep_stride/start_idx, got repeat={repeat}, "
                f"dst_rep_stride={dst_rep_stride}, start_idx={start_idx}"
            )
        if repeat == 0:
            return

        elem_size = int(src.element_size())
        elems_per_block = 32 // elem_size
        elems_per_repeat = elems_per_block * 8
        offset_need = repeat * elems_per_repeat
        dst_need = (repeat - 1) * dst_rep_stride * elems_per_block + elems_per_repeat
        if offset_need > int(offset.numel()):
            raise MemoryError(f"{opname} offset view is too small: need={offset_need}, have={int(offset.numel())}")
        if dst_need > int(dst.numel()):
            raise MemoryError(f"{opname} dst view is too small: need={dst_need}, have={int(dst.numel())}")

        for rep in range(repeat):
            dst_base = rep * dst_rep_stride * elems_per_block
            off_base = rep * elems_per_repeat
            for i in range(elems_per_repeat):
                byte_addr = start_idx + int(offset[off_base + i].item())
                if (byte_addr % elem_size) != 0:
                    raise ValueError(
                        f"{opname} offset byte address must align with element size {elem_size}, got {byte_addr}"
                    )
                src_index = byte_addr // elem_size
                if src_index < 0 or src_index >= int(src.numel()):
                    raise MemoryError(
                        f"{opname} source index out of range: src_index={src_index}, have={int(src.numel())}, "
                        f"byte_addr={byte_addr}, elem_size={elem_size}"
                    )
                dst[dst_base + i] = src[src_index]

    def _execute_scatter(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src = self._validate_vec_tensor_view(opname, "src", instruction.tensors.get("src"))
        offset = self._validate_vec_tensor_view(opname, "offset", instruction.tensors.get("offset"))
        self._validate_vec_dtype_match(opname, dst, src)
        allowed_offset_dtypes = [torch.int32]
        if hasattr(torch, "uint32"):
            allowed_offset_dtypes.append(torch.uint32)  # type: ignore[attr-defined]
        if offset.dtype not in tuple(allowed_offset_dtypes):
            raise TypeError(
                f"{opname} requires offset view with uint32/int32-compatible bit layout, got: {offset.dtype}"
            )

        if self.vector_mode == "count":
            count = self.count_register
            if count == 0:
                return
            start_idx = self._resolve_int(instruction.args.get("start_idx", 0), f"{opname} start_idx")
            if start_idx < 0:
                raise ValueError(f"{opname} requires non-negative start_idx, got {start_idx}")
            if count > int(offset.numel()):
                raise MemoryError(f"{opname} offset view is too small for counter mode: need={count}, have={int(offset.numel())}")
            if count > int(src.numel()):
                raise MemoryError(f"{opname} src view is too small for counter mode: need={count}, have={int(src.numel())}")
            elem_size = int(src.element_size())
            for i in range(count):
                byte_addr = start_idx + int(offset[i].item())
                if (byte_addr % elem_size) != 0:
                    raise ValueError(
                        f"{opname} offset byte address must align with element size {elem_size}, got {byte_addr}"
                    )
                dst_index = byte_addr // elem_size
                if dst_index < 0 or dst_index >= int(dst.numel()):
                    raise MemoryError(
                        f"{opname} destination index out of range: dst_index={dst_index}, have={int(dst.numel())}, "
                        f"byte_addr={byte_addr}, elem_size={elem_size}"
                    )
                dst[dst_index] = src[i]
            return

        repeat = self._resolve_int(instruction.args.get("repeat"), f"{opname} repeat")
        src_rep_stride = self._resolve_int(instruction.args.get("src_rep_stride"), f"{opname} src_rep_stride")
        start_idx = self._resolve_int(instruction.args.get("start_idx", 0), f"{opname} start_idx")
        if repeat < 0 or src_rep_stride < 0 or start_idx < 0:
            raise ValueError(
                f"{opname} requires non-negative repeat/src_rep_stride/start_idx, got repeat={repeat}, "
                f"src_rep_stride={src_rep_stride}, start_idx={start_idx}"
            )
        if repeat == 0:
            return

        elem_size = int(src.element_size())
        elems_per_block = 32 // elem_size
        elems_per_repeat = elems_per_block * 8
        offset_need = repeat * elems_per_repeat
        src_need = (repeat - 1) * src_rep_stride * elems_per_block + elems_per_repeat
        if offset_need > int(offset.numel()):
            raise MemoryError(f"{opname} offset view is too small: need={offset_need}, have={int(offset.numel())}")
        if src_need > int(src.numel()):
            raise MemoryError(f"{opname} src view is too small: need={src_need}, have={int(src.numel())}")

        for rep in range(repeat):
            src_base = rep * src_rep_stride * elems_per_block
            off_base = rep * elems_per_repeat
            for i in range(elems_per_repeat):
                byte_addr = start_idx + int(offset[off_base + i].item())
                if (byte_addr % elem_size) != 0:
                    raise ValueError(
                        f"{opname} offset byte address must align with element size {elem_size}, got {byte_addr}"
                    )
                dst_index = byte_addr // elem_size
                if dst_index < 0 or dst_index >= int(dst.numel()):
                    raise MemoryError(
                        f"{opname} destination index out of range: dst_index={dst_index}, have={int(dst.numel())}, "
                        f"byte_addr={byte_addr}, elem_size={elem_size}"
                    )
                dst[dst_index] = src[src_base + i]

    def _execute_compare_common(
        self,
        opname: str,
        dst: torch.Tensor,
        src1: torch.Tensor,
        src2: torch.Tensor | None,
        scalar_rhs: Any,
        mode_name: str,
        repeat: int,
        src1_blk_stride: int,
        src1_rep_stride: int,
        src2_blk_stride: int | None = None,
        src2_rep_stride: int | None = None,
    ) -> None:
        elem_size = int(src1.element_size())
        elems_per_block = 32 // elem_size
        elems_per_repeat = elems_per_block * 8
        if repeat == 0:
            return

        src1_need = self._calc_vec_need(repeat, src1_rep_stride, src1_blk_stride, elems_per_block)
        dst_need = repeat * elems_per_repeat
        if src1_need > int(src1.numel()):
            raise MemoryError(f"{opname} src1 view is too small: need={src1_need}, have={int(src1.numel())}")
        if dst_need > int(dst.numel()):
            raise MemoryError(f"{opname} dst view is too small: need={dst_need}, have={int(dst.numel())}")
        if src2 is not None:
            assert src2_blk_stride is not None and src2_rep_stride is not None
            src2_need = self._calc_vec_need(repeat, src2_rep_stride, src2_blk_stride, elems_per_block)
            if src2_need > int(src2.numel()):
                raise MemoryError(f"{opname} src2 view is too small: need={src2_need}, have={int(src2.numel())}")

        for rep in range(repeat):
            src1_rep_base = rep * src1_rep_stride * elems_per_block
            lhs_blocks = []
            for blk in range(8):
                src1_begin = src1_rep_base + blk * src1_blk_stride * elems_per_block
                lhs_blocks.append(src1[src1_begin : src1_begin + elems_per_block].clone())
            lhs = torch.cat(lhs_blocks, dim=0)

            if src2 is not None:
                src2_rep_base = rep * src2_rep_stride * elems_per_block  # type: ignore[operator]
                rhs_blocks = []
                for blk in range(8):
                    src2_begin = src2_rep_base + blk * src2_blk_stride * elems_per_block  # type: ignore[operator]
                    rhs_blocks.append(src2[src2_begin : src2_begin + elems_per_block].clone())
                rhs = torch.cat(rhs_blocks, dim=0)
                compute_dtype = self._choose_vec_compute_dtype(lhs.dtype)
                lhs_cmp = lhs.to(compute_dtype)
                rhs_cmp = rhs.to(compute_dtype)
            else:
                if lhs.dtype.is_floating_point or isinstance(scalar_rhs, float):
                    compute_dtype = torch.float32 if lhs.dtype in (torch.float16, torch.bfloat16) or isinstance(scalar_rhs, float) else lhs.dtype
                    lhs_cmp = lhs.to(compute_dtype)
                    rhs_cmp = torch.full((int(lhs.numel()),), scalar_rhs, dtype=compute_dtype, device=lhs.device)
                else:
                    lhs_cmp = lhs
                    rhs_cmp = torch.full((int(lhs.numel()),), int(scalar_rhs), dtype=lhs.dtype, device=lhs.device)

            mask = self._apply_compare_mode(lhs_cmp, rhs_cmp, mode_name)
            dst_base = rep * elems_per_repeat
            dst[dst_base : dst_base + elems_per_repeat].copy_(mask.to(dst.dtype))

    def _execute_compare(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src1 = self._validate_vec_tensor_view(opname, "src1", instruction.tensors.get("src1"))
        src2 = self._validate_vec_tensor_view(opname, "src2", instruction.tensors.get("src2"))
        self._validate_vec_dtype_match(opname, src1, src2)
        repeat, _datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_blk_stride",
            "src1_blk_stride",
            "src2_blk_stride",
            "dst_rep_stride",
            "src1_rep_stride",
            "src2_rep_stride",
        )
        mode_name = str(instruction.args.get("mode", ""))
        self._execute_compare_common(
            opname,
            dst,
            src1,
            src2,
            None,
            mode_name,
            repeat,
            strides["src1_blk_stride"],
            strides["src1_rep_stride"],
            strides["src2_blk_stride"],
            strides["src2_rep_stride"],
        )

    def _execute_compare_scalar(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        src1 = self._validate_vec_tensor_view(opname, "src1", instruction.tensors.get("src1"))
        repeat, _datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_blk_stride",
            "src1_blk_stride",
            "dst_rep_stride",
            "src1_rep_stride",
        )
        mode_name = str(instruction.args.get("mode", ""))
        scalar_rhs = instruction.args.get("src2")
        self._execute_compare_common(
            opname,
            dst,
            src1,
            None,
            scalar_rhs,
            mode_name,
            repeat,
            strides["src1_blk_stride"],
            strides["src1_rep_stride"],
        )

    def _execute_select(self, instruction: SimInstruction) -> None:
        opname = instruction.opname
        dst = self._validate_vec_tensor_view(opname, "dst", instruction.tensors.get("dst"))
        selmask = self._validate_vec_tensor_view(opname, "selmask", instruction.tensors.get("selmask"))
        src1 = self._validate_vec_tensor_view(opname, "src1", instruction.tensors.get("src1"))
        src2_value = instruction.tensors.get("src2")
        src2_tensor = src2_value if isinstance(src2_value, torch.Tensor) else None
        if src2_tensor is not None:
            self._validate_vec_dtype_match(opname, dst, src1, src2_tensor)
        else:
            self._validate_vec_dtype_match(opname, dst, src1)
        if selmask.dtype != torch.uint8:
            raise TypeError(f"{opname} requires selmask tensor with torch.uint8 dtype, got: {selmask.dtype}")

        repeat, _datablock_bytes, strides = self._resolve_vec_layout(
            instruction,
            opname,
            "dst_blk_stride",
            "src1_blk_stride",
            "src2_blk_stride",
            "dst_rep_stride",
            "src1_rep_stride",
            "src2_rep_stride",
        )
        elem_size = int(dst.element_size())
        elems_per_block = 32 // elem_size
        elems_per_repeat = elems_per_block * 8
        if repeat == 0:
            return

        dst_need = self._calc_vec_need(repeat, strides["dst_rep_stride"], strides["dst_blk_stride"], elems_per_block)
        src1_need = self._calc_vec_need(repeat, strides["src1_rep_stride"], strides["src1_blk_stride"], elems_per_block)
        mask_need = repeat * elems_per_repeat
        if dst_need > int(dst.numel()):
            raise MemoryError(f"{opname} dst view is too small: need={dst_need}, have={int(dst.numel())}")
        if src1_need > int(src1.numel()):
            raise MemoryError(f"{opname} src1 view is too small: need={src1_need}, have={int(src1.numel())}")
        if mask_need > int(selmask.numel()):
            raise MemoryError(f"{opname} selmask view is too small: need={mask_need}, have={int(selmask.numel())}")
        if src2_tensor is not None:
            src2_need = self._calc_vec_need(repeat, strides["src2_rep_stride"], strides["src2_blk_stride"], elems_per_block)
            if src2_need > int(src2_tensor.numel()):
                raise MemoryError(f"{opname} src2 view is too small: need={src2_need}, have={int(src2_tensor.numel())}")

        scalar_rhs = instruction.args.get("src2") if src2_tensor is None else None
        for rep in range(repeat):
            mask_base = rep * elems_per_repeat
            src1_rep_base = rep * strides["src1_rep_stride"] * elems_per_block
            src2_rep_base = rep * strides["src2_rep_stride"] * elems_per_block if src2_tensor is not None else 0
            dst_rep_base = rep * strides["dst_rep_stride"] * elems_per_block
            for blk in range(8):
                blk_off = blk * elems_per_block
                mask_block = selmask[mask_base + blk_off : mask_base + blk_off + elems_per_block].clone()
                invalid_mask = (mask_block != 0) & (mask_block != 1)
                if bool(torch.any(invalid_mask).item()):
                    raise ValueError(f"{opname} selmask only supports 0/1 values")
                src1_begin = src1_rep_base + blk * strides["src1_blk_stride"] * elems_per_block
                src1_block = src1[src1_begin : src1_begin + elems_per_block].clone()
                if src2_tensor is not None:
                    src2_begin = src2_rep_base + blk * strides["src2_blk_stride"] * elems_per_block
                    rhs_block = src2_tensor[src2_begin : src2_begin + elems_per_block].clone()
                else:
                    rhs_block = torch.full((elems_per_block,), scalar_rhs, dtype=dst.dtype, device=dst.device)
                dst_begin = dst_rep_base + blk * strides["dst_blk_stride"] * elems_per_block
                dst_block = dst[dst_begin : dst_begin + elems_per_block]
                mask_bool = mask_block.to(torch.bool)
                dst_block.copy_(torch.where(mask_bool, src1_block, rhs_block.to(dst.dtype)))

    @staticmethod
    def _resolve_uint64(value: Any, label: str) -> int:
        if isinstance(value, bool):
            raise TypeError(f"{label} must resolve to uint64, got bool")
        if not isinstance(value, int):
            raise TypeError(f"{label} must resolve to uint64 int, got: {type(value)}")
        if value < 0 or value >= (1 << 64):
            raise ValueError(f"{label} must be in uint64 range, got: {value}")
        return int(value)

    def _execute_set_mask(self, instruction: SimInstruction) -> None:
        low = self._resolve_uint64(instruction.args.get("low", 0), "set_mask low")
        high = self._resolve_uint64(instruction.args.get("high", 0), "set_mask high")
        for bit in range(64):
            self.current_mask[bit] = (low >> bit) & 1
            self.current_mask[64 + bit] = (high >> bit) & 1

    def _execute_reset_mask(self, instruction: SimInstruction) -> None:
        self.current_mask.fill_(1)

    def _execute_set_mask_count(self, instruction: SimInstruction) -> None:
        self.vector_mode = "count"

    def _execute_set_mask_normal(self, instruction: SimInstruction) -> None:
        self.vector_mode = "repeat"

    def _execute_set_mask_counter(self, instruction: SimInstruction) -> None:
        count = self._resolve_int(instruction.args.get("count"), "set_mask_counter count")
        if count < 0:
            raise ValueError(f"set_mask_counter count must be non-negative, got: {count}")
        self.count_register = count

    # TODO(a2-sim): set_cmpmask is still pending. Keep it together with any
    # future cmpmask-consuming ops if hardware semantics turn out to be coupled.
    def _execute_ub_to_ub(self, instruction: SimInstruction) -> None:
        dst = instruction.tensors.get("dst")
        src = instruction.tensors.get("src")
        if not isinstance(dst, torch.Tensor):
            raise TypeError(f"ub_to_ub requires dst tensor view, got: {type(dst)}")
        if not isinstance(src, torch.Tensor):
            raise TypeError(f"ub_to_ub requires src tensor view, got: {type(src)}")
        if dst.dim() != 1:
            raise ValueError(f"ub_to_ub dst must be 1D pointer view, got dim={dst.dim()}")
        if src.dim() != 1:
            raise ValueError(f"ub_to_ub src must be 1D pointer view, got dim={src.dim()}")

        n_burst = self._resolve_int(instruction.args.get("n_burst"), "ub_to_ub n_burst")
        burst_len = self._resolve_int(instruction.args.get("burst_len"), "ub_to_ub burst_len")
        src_stride = self._resolve_int(instruction.args.get("src_stride"), "ub_to_ub src_stride")
        dst_stride = self._resolve_int(instruction.args.get("dst_stride"), "ub_to_ub dst_stride")
        if n_burst < 0 or burst_len < 0 or src_stride < 0 or dst_stride < 0:
            raise ValueError(
                "ub_to_ub requires non-negative n_burst/burst_len/src_stride/dst_stride, "
                f"got n_burst={n_burst}, burst_len={burst_len}, "
                f"src_stride={src_stride}, dst_stride={dst_stride}"
            )
        if int(src.element_size()) != int(dst.element_size()):
            raise ValueError(
                "ub_to_ub requires src/dst tensor views with identical element size, got "
                f"src={int(src.element_size())}, dst={int(dst.element_size())}"
            )

        burst_len_byte = burst_len * 32
        src_stride_byte = src_stride * 32
        dst_stride_byte = dst_stride * 32
        src_step = burst_len_byte + src_stride_byte
        dst_step = burst_len_byte + dst_stride_byte

        src_bytes = self._linear_view_from_pointer(src).view(torch.uint8)
        dst_bytes = self._linear_view_from_pointer(dst).view(torch.uint8)
        src_need = 0
        dst_need = 0
        if n_burst > 0:
            src_need = (n_burst - 1) * src_step + burst_len_byte
            dst_need = (n_burst - 1) * dst_step + burst_len_byte
        if src_need > int(src_bytes.numel()):
            raise MemoryError(
                "ub_to_ub source view is too small: "
                f"need={src_need} bytes, have={int(src_bytes.numel())} bytes"
            )
        if dst_need > int(dst_bytes.numel()):
            raise MemoryError(
                "ub_to_ub destination view is too small: "
                f"need={dst_need} bytes, have={int(dst_bytes.numel())} bytes"
            )
        if n_burst == 0 or burst_len == 0:
            return

        for burst_idx in range(n_burst):
            src_begin = burst_idx * src_step
            dst_begin = burst_idx * dst_step
            dst_bytes[dst_begin : dst_begin + burst_len_byte].copy_(
                src_bytes[src_begin : src_begin + burst_len_byte]
            )

    def execute_instruction(self, instruction: SimInstruction) -> None:
        if instruction.opname == "call_micro":
            self._call_micro_executor(instruction)
            return
        if instruction.opname in _VEC_UNARY_OPS:
            self._execute_unary(instruction)
            return
        if instruction.opname in _VEC_BINARY_OPS:
            self._execute_binary(instruction)
            return
        if instruction.opname in _VEC_UNARY_SCALAR_OPS:
            self._execute_unary_scalar(instruction)
            return
        if instruction.opname == "dup":
            self._execute_dup(instruction)
            return
        if instruction.opname == "brcb":
            self._execute_brcb(instruction)
            return
        if instruction.opname in _VEC_CAST_OPS:
            self._execute_cast(instruction)
            return
        if instruction.opname in _VEC_GROUP_OPS:
            self._execute_group_reduce(instruction)
            return
        if instruction.opname in _VEC_GROUP_PACKED_OPS:
            self._execute_cpadd(instruction)
            return
        if instruction.opname in _VEC_GATHER_OPS:
            self._execute_gather(instruction)
            return
        if instruction.opname in _VEC_SCATTER_OPS:
            self._execute_scatter(instruction)
            return
        if instruction.opname in _VEC_COMPARE_OPS:
            if instruction.opname == "compare":
                self._execute_compare(instruction)
            else:
                self._execute_compare_scalar(instruction)
            return
        if instruction.opname in _VEC_SELECT_OPS:
            self._execute_select(instruction)
            return
        if instruction.opname == "set_mask":
            self._execute_set_mask(instruction)
            return
        if instruction.opname == "reset_mask":
            self._execute_reset_mask(instruction)
            return
        if instruction.opname == "set_mask_count":
            self._execute_set_mask_count(instruction)
            return
        if instruction.opname == "set_mask_normal":
            self._execute_set_mask_normal(instruction)
            return
        if instruction.opname == "set_mask_counter":
            self._execute_set_mask_counter(instruction)
            return
        if instruction.opname == "ub_to_ub":
            self._execute_ub_to_ub(instruction)
            return
        if instruction.opname == "sort32":
            self._execute_sort32(instruction)
            return
        if instruction.opname == "mergesort4":
            self._execute_mergesort4(instruction)
            return
        if instruction.opname == "mergesort_2seq":
            self._execute_mergesort_2seq(instruction)
            return
        super().execute_instruction(instruction)
