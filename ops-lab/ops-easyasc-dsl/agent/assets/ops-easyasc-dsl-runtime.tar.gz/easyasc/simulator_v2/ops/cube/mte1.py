# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from .... import globvars
from ..layout_helpers import align16, align_to, decode_nz_to_nd, decode_zz_to_nd, encode_nd_to_nz, encode_nd_to_zz
from ...memory.shared_tensor_store import SharedTensorStore
from ...program.task import PipeTask
from ..common import PipeDescriptor, PipeFamily
from ..pipe_base import PipeBaseV2


@dataclass
class MTE1PipeV2(PipeBaseV2):
    def __init__(self) -> None:
        super(MTE1PipeV2, self).__init__(PipeDescriptor(PipeFamily.CUBE, "MTE1"))

    @staticmethod
    def _resolve_int(value: Any, label: str) -> int:
        if isinstance(value, bool):
            return int(value)
        if not isinstance(value, (int, float)):
            raise TypeError(label + " must resolve to int/float, got: " + str(type(value)))
        return int(value)

    @staticmethod
    def _flat_tensor(tensor: torch.Tensor, label: str) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            raise TypeError(label + " requires torch.Tensor, got: " + str(type(tensor)))
        return tensor.reshape(-1)

    @staticmethod
    def _layout_name(value: Any, default: str) -> str:
        if value is None:
            return default
        return str(value).upper()

    def execute(self, task: PipeTask, tensor_store: SharedTensorStore, micro_runtime=None) -> bool:
        if task.opname != "l1_to_l0":
            return False

        dst = self._flat_tensor(tensor_store.tensor(str(task.args["dst"])), "l1_to_l0 dst")
        src = self._flat_tensor(tensor_store.tensor(str(task.args["src"])), "l1_to_l0 src")

        m_dst = self._resolve_int(task.args.get("m_dst"), "l1_to_l0 m_dst")
        n_dst = self._resolve_int(task.args.get("n_dst"), "l1_to_l0 n_dst")
        m_src = self._resolve_int(task.args.get("m_src"), "l1_to_l0 m_src")
        n_src = self._resolve_int(task.args.get("n_src"), "l1_to_l0 n_src")
        src_is_transpose = bool(task.args.get("src_is_transpose", False))
        src_layout = self._layout_name(task.args.get("src_layout"), "NZ")
        dst_layout = self._layout_name(
            task.args.get("dst_layout"),
            "ZN" if src_is_transpose else "NZ",
        )
        src_row0 = self._resolve_int(task.args.get("src_row0", 0), "l1_to_l0 src_row0")
        src_col0 = self._resolve_int(task.args.get("src_col0", 0), "l1_to_l0 src_col0")

        if m_dst < 0 or n_dst < 0 or m_src < 0 or n_src < 0:
            raise ValueError(
                "l1_to_l0 requires non-negative m_dst/n_dst/m_src/n_src, got: "
                + "m_dst="
                + str(m_dst)
                + ", n_dst="
                + str(n_dst)
                + ", m_src="
                + str(m_src)
                + ", n_src="
                + str(n_src)
            )
        if m_dst > m_src:
            raise ValueError("l1_to_l0 m_dst=" + str(m_dst) + " cannot exceed m_src=" + str(m_src))
        if n_dst > n_src:
            raise ValueError("l1_to_l0 n_dst=" + str(n_dst) + " cannot exceed n_src=" + str(n_src))
        if src_row0 < 0 or src_col0 < 0:
            raise ValueError("l1_to_l0 requires non-negative slice offsets")

        required_src_rows = src_row0 + m_dst if m_dst > 0 else src_row0
        required_src_cols = src_col0 + n_dst if n_dst > 0 else src_col0
        if required_src_rows > m_src:
            raise ValueError("l1_to_l0 source row slice exceeds m_src")
        if required_src_cols > n_src:
            raise ValueError("l1_to_l0 source col slice exceeds n_src")

        elem_size = int(dst.element_size())
        if elem_size <= 0 or (32 % elem_size) != 0:
            raise ValueError(
                "l1_to_l0 unsupported dst element size for C0=32-byte layout: "
                + str(elem_size)
                + " bytes"
            )
        c0 = 32 // elem_size
        device_type = str(getattr(globvars, "device_type", "")).lower()
        dst_position = str(task.args.get("dst_position", ""))
        src_position = str(task.args.get("src_position", ""))
        use_zz_src = device_type.startswith("b") and src_position == "L1" and src.dtype == torch.float32
        use_zz_dst = device_type.startswith("b") and dst_position == "L0A"
        src_n_align = align_to(n_src, c0)

        if use_zz_src or src_layout == "ZZ":
            src_needed = ((m_src + 15) // 16) * src_n_align * 16
            if src_needed > int(src.numel()):
                raise MemoryError(
                    "l1_to_l0 source view is too small for ZZ layout: "
                    + "need="
                    + str(src_needed)
                    + ", have="
                    + str(int(src.numel()))
                )
            logical_full = decode_zz_to_nd(src, required_src_rows, required_src_cols, src_n_align)
        else:
            src_stride_m = align16(m_src)
            src_needed = ((n_src + c0 - 1) // c0) * src_stride_m * c0
            if src_needed > int(src.numel()):
                # src may be a sub-view of a larger NZ buffer (e.g. matmul
                # splitn/splitk creates an offset view into the full L1
                # allocation).  Recover the full parent buffer via
                # storage_offset so the NZ decoder sees the correct stride,
                # then adjust src_row0 and src_col0 from the NZ offset.
                src_off = src.storage_offset()
                if src_off > 0:
                    full_numel = src_off + int(src.numel())
                    src = src.as_strided((full_numel,), (1,), storage_offset=0)
                    # Decompose the flat NZ offset back into (row, col) using
                    # the NZ block structure: block_stride = stride_m * c0.
                    block_stride = src_stride_m * c0
                    block_idx = src_off // block_stride
                    remainder = src_off % block_stride
                    row_in_block = remainder // c0
                    col_in_block = remainder % c0
                    src_row0 += row_in_block
                    src_col0 += block_idx * c0 + col_in_block
                    required_src_rows = src_row0 + m_dst if m_dst > 0 else src_row0
                    required_src_cols = src_col0 + n_dst if n_dst > 0 else src_col0
                if src_needed > int(src.numel()):
                    raise MemoryError(
                        "l1_to_l0 source view is too small for NZ layout: "
                        + "need="
                        + str(src_needed)
                        + ", have="
                        + str(int(src.numel()))
                    )
            logical_full = decode_nz_to_nd(src, required_src_rows, required_src_cols, src_stride_m, c0)

        logical = logical_full[src_row0 : src_row0 + m_dst, src_col0 : src_col0 + n_dst].contiguous()
        dst.zero_()
        if m_dst == 0 or n_dst == 0:
            return True

        if not src_is_transpose and use_zz_dst:
            dst_n_align = align_to(n_dst, c0)
            dst_needed = ((m_dst + 15) // 16) * dst_n_align * 16
            if dst_needed > int(dst.numel()):
                raise MemoryError(
                    "l1_to_l0 dst view is too small for ZZ layout: "
                    + "need="
                    + str(dst_needed)
                    + ", have="
                    + str(int(dst.numel()))
                )
            encode_nd_to_zz(logical, dst, m_dst, n_dst, dst_n_align)
            return True

        if src_is_transpose:
            if use_zz_dst or dst_layout == "ZZ":
                logical_t = logical.transpose(0, 1).contiguous()
                out_rows = n_dst
                out_cols = m_dst
                dst_n_align = align_to(out_cols, c0)
                dst_needed = ((out_rows + 15) // 16) * dst_n_align * 16
                if dst_needed > int(dst.numel()):
                    raise MemoryError(
                        "l1_to_l0 dst view is too small for ZZ layout: "
                        + "need="
                        + str(dst_needed)
                        + ", have="
                        + str(int(dst.numel()))
                    )
                encode_nd_to_zz(logical_t, dst, out_rows, out_cols, dst_n_align)
                return True

            row_block = 32 if elem_size == 1 else 16
            n_align = align_to(n_dst, 32 if elem_size == 1 else c0)
            m_blocks = (m_dst + row_block - 1) // row_block
            dst_needed = m_blocks * row_block * n_align
            if dst_needed > int(dst.numel()):
                raise MemoryError(
                    "l1_to_l0 dst view is too small for ZN layout: "
                    + "need="
                    + str(dst_needed)
                        + ", have="
                        + str(int(dst.numel()))
                    )
            logical_pad = logical.new_zeros((m_blocks * row_block, n_align))
            logical_pad[:m_dst, :n_dst].copy_(logical)
            dst_zn = dst[:dst_needed].reshape(m_blocks, n_align, row_block)
            dst_zn.copy_(logical_pad.reshape(m_blocks, row_block, n_align).permute(0, 2, 1))
            return True

        if dst_layout == "ZZ":
            dst_n_align = align_to(n_dst, c0)
            dst_needed = ((m_dst + 15) // 16) * dst_n_align * 16
            if dst_needed > int(dst.numel()):
                raise MemoryError(
                    "l1_to_l0 dst view is too small for ZZ layout: "
                    + "need="
                    + str(dst_needed)
                    + ", have="
                    + str(int(dst.numel()))
                )
            encode_nd_to_zz(logical, dst, m_dst, n_dst, dst_n_align)
            return True

        dst_stride_m = align16(m_dst)
        dst_needed = ((n_dst + c0 - 1) // c0) * dst_stride_m * c0
        if dst_needed > int(dst.numel()):
            raise MemoryError(
                "l1_to_l0 dst view is too small for NZ layout: "
                + "need="
                + str(dst_needed)
                + ", have="
                + str(int(dst.numel()))
            )
        encode_nd_to_nz(logical, dst, m_dst, n_dst, dst_stride_m, c0)
        return True
