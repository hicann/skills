from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from ..layout_helpers import align16, decode_nz_to_nd, encode_nd_to_nz, gather_strided_region, scatter_strided_region
from ...memory.shared_tensor_store import SharedTensorStore
from ...program.task import PipeTask
from ..common import PipeDescriptor, PipeFamily
from ..pipe_base import PipeBaseV2


@dataclass
class FixPipeV2(PipeBaseV2):
    def __init__(self) -> None:
        super(FixPipeV2, self).__init__(PipeDescriptor(PipeFamily.CUBE, "FIX"))

    @staticmethod
    def _resolve_int(value: Any, label: str) -> int:
        if isinstance(value, bool):
            return int(value)
        if not isinstance(value, (int, float)):
            raise TypeError(label + " must resolve to int/float, got: " + str(type(value)))
        return int(value)

    @staticmethod
    def _flat_tensor(tensor: torch.Tensor, label: str) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            raise TypeError(label + " requires torch.Tensor, got: " + str(type(tensor)))
        return tensor.reshape(-1)

    @staticmethod
    def _choose_atomic_compute_dtype(dtype: torch.dtype) -> torch.dtype:
        if dtype in (torch.float16, torch.bfloat16):
            return torch.float32
        if dtype in (torch.int8, torch.uint8, torch.int16):
            return torch.int32
        return dtype

    @staticmethod
    def _clamp_relu(tensor: torch.Tensor) -> torch.Tensor:
        if tensor.numel() == 0:
            return tensor
        return torch.clamp(tensor, min=0)

    @staticmethod
    def _resolve_dual_mode(value: Any) -> int:
        if isinstance(value, bool):
            mode = int(value)
        elif isinstance(value, (int, float)):
            mode = int(value)
        else:
            raise TypeError("dual_mode must resolve to int/float, got: " + str(type(value)))
        if mode not in (0, 1, 2):
            raise ValueError("dual_mode must be 0, 1, or 2, got: " + str(mode))
        return mode

    @staticmethod
    def _apply_atomic_op(dst_region: torch.Tensor, src_region: torch.Tensor, mode: str) -> torch.Tensor:
        if mode == "add":
            return dst_region.add(src_region)
        if mode == "max":
            return torch.maximum(dst_region, src_region)
        if mode == "min":
            return torch.minimum(dst_region, src_region)
        raise ValueError("unsupported atomic mode for l0c_to_gm_nz2nd: " + str(mode))

    @staticmethod
    def _copy_logical_to_tensor(dst: torch.Tensor, logical: torch.Tensor) -> None:
        flat = dst.reshape(-1)
        values = logical.reshape(-1).to(dtype=dst.dtype, device=dst.device)
        if int(values.numel()) != int(flat.numel()):
            raise ValueError("destination tensor numel does not match logical payload")
        dst.copy_(values.reshape(dst.shape))

    def _decode_l0c(self, src: torch.Tensor, m: int, n: int, m_src: int) -> torch.Tensor:
        elem_size = int(src.element_size())
        if elem_size <= 0:
            raise ValueError("unsupported L0C element size: " + str(elem_size))
        c0 = 16
        src_stride_m = align16(m_src)
        src_needed = ((n + c0 - 1) // c0) * src_stride_m * c0
        src_flat = self._flat_tensor(src, "l0c source")
        if src_needed > int(src_flat.numel()):
            raise MemoryError("L0C source view is too small for NZ layout")
        return decode_nz_to_nd(src_flat, m, n, src_stride_m, c0)

    def _execute_l0c_to_gm_nz2nd(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        if task.opname != "l0c_to_gm_nz2nd":
            return False
        dst = tensor_store.tensor(str(task.args["dst"]))
        src = tensor_store.tensor(str(task.args["src"]))
        m = self._resolve_int(task.args.get("M"), "l0c_to_gm_nz2nd M")
        n = self._resolve_int(task.args.get("N"), "l0c_to_gm_nz2nd N")
        n_dst = self._resolve_int(task.args.get("N_dst"), "l0c_to_gm_nz2nd N_dst")
        m_src = self._resolve_int(task.args.get("M_src"), "l0c_to_gm_nz2nd M_src")
        relu = bool(task.args.get("relu", False))
        logical = self._decode_l0c(src, m, n, m_src).to(dst.dtype)
        if relu:
            logical = self._clamp_relu(logical)

        dst_flat = self._flat_tensor(dst, "l0c_to_gm_nz2nd dst")
        if m > 0 and n > 0 and (m - 1) * n_dst + n > int(dst_flat.numel()):
            raise MemoryError("l0c_to_gm_nz2nd destination pointer region is too small")
        atomic_enabled = bool(task.args.get("atomic_enabled", False))
        if atomic_enabled and m > 0 and n > 0:
            atomic_mode = str(task.args.get("atomic_mode", "add"))
            dst_region = gather_strided_region(dst_flat, m, n, n_dst)
            compute_dtype = self._choose_atomic_compute_dtype(dst_region.dtype)
            updated = self._apply_atomic_op(dst_region.to(compute_dtype), logical.to(compute_dtype), atomic_mode).to(dst_region.dtype)
            scatter_strided_region(dst_flat, updated, n_dst)
            return True
        scatter_strided_region(dst_flat, logical, n_dst)
        return True

    def _execute_l0c_to_l1(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        if task.opname != "l0c_to_l1":
            return False
        dst = tensor_store.tensor(str(task.args["dst"]))
        src = tensor_store.tensor(str(task.args["src"]))
        m = self._resolve_int(task.args.get("M"), "l0c_to_l1 M")
        n = self._resolve_int(task.args.get("N"), "l0c_to_l1 N")
        m_dst = self._resolve_int(task.args.get("M_dst"), "l0c_to_l1 M_dst")
        m_src = self._resolve_int(task.args.get("M_src"), "l0c_to_l1 M_src")
        relu = bool(task.args.get("relu", False))

        dst_flat = self._flat_tensor(dst, "l0c_to_l1 dst")
        logical = self._decode_l0c(src, m, n, m_src).to(dst.dtype)
        if relu:
            logical = self._clamp_relu(logical)

        elem_size_dst = int(dst_flat.element_size())
        if elem_size_dst <= 0 or (32 % elem_size_dst) != 0:
            raise ValueError("l0c_to_l1 unsupported dst element size: " + str(elem_size_dst))
        c0_dst = 32 // elem_size_dst
        dst_stride_m = align16(m_dst)
        dst_needed = ((n + c0_dst - 1) // c0_dst) * dst_stride_m * c0_dst
        if dst_needed > int(dst_flat.numel()):
            raise MemoryError("l0c_to_l1 destination view is too small for L1 NZ layout")

        dst_flat.zero_()
        if m == 0 or n == 0:
            return True
        encode_nd_to_nz(logical, dst_flat, m, n, dst_stride_m, c0_dst)
        return True

    def _execute_l0c_to_ub(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        if task.opname != "l0c_to_ub":
            return False
        # In mixed-lane dual-dst mode, dst may not exist in the store;
        # use vec0's UB to infer dtype for the decode step.
        dst_vec0_name = task.args.get("dst_vec0")
        dst_vec1_name = task.args.get("dst_vec1")
        has_dual_dst = isinstance(dst_vec0_name, str) and isinstance(dst_vec1_name, str)
        if has_dual_dst:
            dst = tensor_store.tensor(dst_vec0_name)
        else:
            dst = tensor_store.tensor(str(task.args["dst"]))
        src = tensor_store.tensor(str(task.args["src"]))
        m = self._resolve_int(task.args.get("M"), "l0c_to_ub M")
        n = self._resolve_int(task.args.get("N"), "l0c_to_ub N")
        m_src = self._resolve_int(task.args.get("M_src"), "l0c_to_ub M_src")
        dual_mode = self._resolve_dual_mode(task.args.get("dual_mode", 1))
        sub_block_id = self._resolve_int(task.args.get("sub_block_id", 0), "l0c_to_ub sub_block_id")
        relu = bool(task.args.get("relu", False))
        logical = self._decode_l0c(src, m, n, m_src).to(dst.dtype)
        if relu:
            logical = self._clamp_relu(logical)

        # Check for mixed-lane dual-destination mode (both vec UBs)
        dst_vec0_name = task.args.get("dst_vec0")
        dst_vec1_name = task.args.get("dst_vec1")
        has_dual_dst = isinstance(dst_vec0_name, str) and isinstance(dst_vec1_name, str)

        if dual_mode == 0:
            payload = logical
            self._copy_logical_to_tensor(dst, payload)
        elif dual_mode == 1:
            if m % 2 != 0:
                raise ValueError("l0c_to_ub SPLITM mode requires even M, got: " + str(m))
            half_m = m // 2
            if has_dual_dst:
                # Mixed-lane: write each half to its vec lane's UB
                dst0 = tensor_store.tensor(dst_vec0_name)
                dst1 = tensor_store.tensor(dst_vec1_name)
                self._copy_logical_to_tensor(dst0, logical[:half_m, :])
                self._copy_logical_to_tensor(dst1, logical[half_m:, :])
            else:
                row0 = sub_block_id * half_m
                payload = logical[row0 : row0 + half_m, :]
                self._copy_logical_to_tensor(dst, payload)
        else:
            if n % 2 != 0:
                raise ValueError("l0c_to_ub SPLITN mode requires even N, got: " + str(n))
            half_n = n // 2
            if has_dual_dst:
                dst0 = tensor_store.tensor(dst_vec0_name)
                dst1 = tensor_store.tensor(dst_vec1_name)
                self._copy_logical_to_tensor(dst0, logical[:, :half_n])
                self._copy_logical_to_tensor(dst1, logical[:, half_n:])
            else:
                col0 = sub_block_id * half_n
                payload = logical[:, col0 : col0 + half_n]
                self._copy_logical_to_tensor(dst, payload)
        return True

    def execute(self, task: PipeTask, tensor_store: SharedTensorStore, micro_runtime=None) -> bool:
        return (
            self._execute_l0c_to_gm_nz2nd(task, tensor_store)
            or self._execute_l0c_to_l1(task, tensor_store)
            or self._execute_l0c_to_ub(task, tensor_store)
        )
