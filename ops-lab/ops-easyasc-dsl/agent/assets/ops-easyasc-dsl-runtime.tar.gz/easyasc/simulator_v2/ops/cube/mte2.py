from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from ..layout_helpers import align16, align32
from ...memory.shared_tensor_store import SharedTensorStore
from ...program.task import PipeTask
from ..common import PipeDescriptor, PipeFamily
from ..pipe_base import PipeBaseV2


@dataclass
class MTE2PipeV2(PipeBaseV2):
    def __init__(self) -> None:
        super(MTE2PipeV2, self).__init__(PipeDescriptor(PipeFamily.CUBE, "MTE2"))

    @staticmethod
    def _resolve_int(value: Any, label: str) -> int:
        if isinstance(value, bool):
            return int(value)
        if not isinstance(value, (int, float)):
            raise TypeError(label + " must resolve to int/float, got: " + str(type(value)))
        return int(value)

    @staticmethod
    def _flat_tensor(tensor: torch.Tensor, label: str) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            raise TypeError(label + " requires torch.Tensor, got: " + str(type(tensor)))
        return tensor.reshape(-1)

    def _execute_gm_to_l1_nd2nz(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        if task.opname != "gm_to_l1_nd2nz":
            return False
        dst = self._flat_tensor(tensor_store.tensor(str(task.args["dst"])), "gm_to_l1_nd2nz dst")
        src = self._flat_tensor(tensor_store.tensor(str(task.args["src"])), "gm_to_l1_nd2nz src")

        h = self._resolve_int(task.args.get("M"), "gm_to_l1_nd2nz M")
        w = self._resolve_int(task.args.get("N"), "gm_to_l1_nd2nz N")
        w_src = self._resolve_int(task.args.get("N_src"), "gm_to_l1_nd2nz N_src")
        h_dst = self._resolve_int(task.args.get("M_dst", h), "gm_to_l1_nd2nz M_dst")
        if h < 0 or w < 0 or w_src < 0 or h_dst < 0:
            raise ValueError(
                "gm_to_l1_nd2nz requires non-negative M/N/N_src/M_dst, got: "
                + "M="
                + str(h)
                + ", N="
                + str(w)
                + ", N_src="
                + str(w_src)
                + ", M_dst="
                + str(h_dst)
            )
        if w > w_src:
            raise ValueError("gm_to_l1_nd2nz N=" + str(w) + " cannot exceed N_src=" + str(w_src))
        if h > h_dst:
            raise ValueError("gm_to_l1_nd2nz M=" + str(h) + " cannot exceed M_dst=" + str(h_dst))

        elem_size = int(dst.element_size())
        if elem_size <= 0 or (32 % elem_size) != 0:
            raise ValueError(
                "gm_to_l1_nd2nz unsupported dst element size for C0=32-byte layout: "
                + str(elem_size)
                + " bytes"
            )
        c0 = 32 // elem_size
        dst_stride_h = align16(h_dst)
        needed = ((w + c0 - 1) // c0) * dst_stride_h * c0
        if needed > int(dst.numel()):
            raise MemoryError(
                "gm_to_l1_nd2nz destination view is too small for NZ layout: "
                + "need="
                + str(needed)
                + ", have="
                + str(int(dst.numel()))
            )

        dst.zero_()
        if h == 0 or w == 0:
            return True

        src_need = (h - 1) * w_src + w
        if src_need > int(src.numel()):
            raise MemoryError(
                "gm_to_l1_nd2nz source view is too small for ND layout: "
                + "need="
                + str(src_need)
                + ", have="
                + str(int(src.numel()))
            )

        block_count = (w + c0 - 1) // c0
        dst_panel = dst[: block_count * dst_stride_h * c0].reshape(block_count, dst_stride_h, c0)
        src_2d = src.as_strided((h, w), (w_src, 1))
        full_blocks = w // c0
        if full_blocks > 0:
            src_full = src_2d[:, : full_blocks * c0].reshape(h, full_blocks, c0).permute(1, 0, 2)
            dst_panel[:full_blocks, :h, :].copy_(src_full)
        tail = w - full_blocks * c0
        if tail > 0:
            src_col = full_blocks * c0
            dst_panel[full_blocks, :h, :tail].copy_(src_2d[:, src_col : src_col + tail])
        return True

    def _execute_set_constant_to_l1(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        if task.opname != "set_constant_to_l1":
            return False
        tensor_name = task.args.get("tensor", task.args.get("dst"))
        if tensor_name is None:
            raise KeyError("set_constant_to_l1 requires tensor or dst")
        tensor = self._flat_tensor(tensor_store.tensor(str(tensor_name)), "set_constant_to_l1 tensor")
        n_blocks = self._resolve_int(task.args.get("n_blocks"), "set_constant_to_l1 n_blocks")
        if n_blocks < 0:
            raise ValueError("set_constant_to_l1 n_blocks must be non-negative, got: " + str(n_blocks))
        raw_val = task.args.get("val", task.args.get("value"))
        if isinstance(raw_val, bool) or not isinstance(raw_val, (int, float)):
            raise TypeError("set_constant_to_l1 val must resolve to numeric scalar, got: " + str(type(raw_val)))

        elem_size = int(tensor.element_size())
        if elem_size <= 0 or (32 % elem_size) != 0:
            raise ValueError(
                "set_constant_to_l1 unsupported tensor element size for 32-byte block layout: "
                + str(elem_size)
            )
        c0 = 32 // elem_size
        fill_elements = n_blocks * c0
        if fill_elements > int(tensor.numel()):
            raise MemoryError(
                "set_constant_to_l1 destination view is too small: "
                + "need="
                + str(fill_elements)
                + ", have="
                + str(int(tensor.numel()))
            )
        if fill_elements == 0:
            return True
        fill_value = torch.tensor(raw_val, dtype=tensor.dtype, device=tensor.device).item()
        tensor[:fill_elements].fill_(fill_value)
        return True

    def execute(self, task: PipeTask, tensor_store: SharedTensorStore, micro_runtime=None) -> bool:
        return self._execute_gm_to_l1_nd2nz(task, tensor_store) or self._execute_set_constant_to_l1(task, tensor_store)
