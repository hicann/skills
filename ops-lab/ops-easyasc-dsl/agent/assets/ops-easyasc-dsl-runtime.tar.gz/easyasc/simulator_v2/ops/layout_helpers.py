# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from typing import Optional

import torch


def align16(value: int) -> int:
    return ((value + 15) // 16) * 16


def align32(value: int) -> int:
    return ((value + 31) // 32) * 32


def align_to(value: int, align: int) -> int:
    if align <= 0:
        raise ValueError("align must be positive, got: " + str(align))
    return ((value + align - 1) // align) * align


def _alloc_logical_zeros(src: torch.Tensor, rows: int, cols: int) -> torch.Tensor:
    if str(src.dtype).startswith("torch.float8_"):
        return torch.zeros((rows, cols), dtype=torch.float32, device=src.device)
    return src.new_zeros((rows, cols))


def decode_nz_to_nd(
    src_flat: torch.Tensor,
    m_rows: int,
    n_cols: int,
    src_stride_m: int,
    c0: int,
) -> torch.Tensor:
    out = _alloc_logical_zeros(src_flat, m_rows, n_cols)
    if m_rows == 0 or n_cols == 0:
        return out
    blocks = (n_cols + c0 - 1) // c0
    src_panel = src_flat[: blocks * src_stride_m * c0].reshape(blocks, src_stride_m, c0)
    full_blocks = n_cols // c0
    if full_blocks > 0:
        src_full = src_panel[:full_blocks, :m_rows, :]
        out[:, : full_blocks * c0].copy_(
            src_full.permute(1, 0, 2).reshape(m_rows, full_blocks * c0)
        )
    tail = n_cols - full_blocks * c0
    if tail > 0:
        start_col = full_blocks * c0
        out[:, start_col : start_col + tail].copy_(src_panel[full_blocks, :m_rows, :tail])
    return out


def encode_nd_to_nz(
    logical: torch.Tensor,
    dst_flat: torch.Tensor,
    m_rows: int,
    n_cols: int,
    dst_stride_m: int,
    c0: int,
) -> None:
    if m_rows == 0 or n_cols == 0:
        return
    blocks = (n_cols + c0 - 1) // c0
    dst_panel = dst_flat[: blocks * dst_stride_m * c0].reshape(blocks, dst_stride_m, c0)
    full_blocks = n_cols // c0
    if full_blocks > 0:
        src_full = logical[:, : full_blocks * c0].reshape(m_rows, full_blocks, c0).permute(1, 0, 2)
        dst_panel[:full_blocks, :m_rows, :].copy_(src_full)
    tail = n_cols - full_blocks * c0
    if tail > 0:
        start_col = full_blocks * c0
        dst_panel[full_blocks, :m_rows, :tail].copy_(logical[:, start_col : start_col + tail])


def decode_zz_to_nd(
    src_flat: torch.Tensor,
    m_rows: int,
    n_cols: int,
    n_align: int,
    row_block: int = 16,
) -> torch.Tensor:
    out = _alloc_logical_zeros(src_flat, m_rows, n_cols)
    if m_rows == 0 or n_cols == 0:
        return out
    if row_block <= 0:
        raise ValueError("row_block must be positive, got: " + str(row_block))
    if n_align < n_cols:
        raise ValueError(
            "n_align must be >= n_cols for ZZ decode, got: "
            + str(n_align)
            + " < "
            + str(n_cols)
        )
    block_count = (m_rows + row_block - 1) // row_block
    needed = block_count * n_align * row_block
    if needed > int(src_flat.numel()):
        raise MemoryError(
            "ZZ decode source too small: need="
            + str(needed)
            + ", have="
            + str(int(src_flat.numel()))
            + ", m_rows="
            + str(m_rows)
            + ", n_cols="
            + str(n_cols)
            + ", n_align="
            + str(n_align)
            + ", row_block="
            + str(row_block)
        )
    src_panel = src_flat[:needed].reshape(block_count, n_align, row_block)
    for block_idx in range(block_count):
        row0 = block_idx * row_block
        row1 = min(row0 + row_block, m_rows)
        rows = row1 - row0
        out[row0:row1, :].copy_(src_panel[block_idx, :n_cols, :rows].transpose(0, 1))
    return out


def encode_nd_to_zz(
    logical: torch.Tensor,
    dst_flat: torch.Tensor,
    m_rows: int,
    n_cols: int,
    n_align: int,
    row_block: int = 16,
) -> None:
    if m_rows == 0 or n_cols == 0:
        return
    if row_block <= 0:
        raise ValueError("row_block must be positive, got: " + str(row_block))
    if n_align < n_cols:
        raise ValueError(
            "n_align must be >= n_cols for ZZ encode, got: "
            + str(n_align)
            + " < "
            + str(n_cols)
        )
    block_count = (m_rows + row_block - 1) // row_block
    needed = block_count * n_align * row_block
    if needed > int(dst_flat.numel()):
        raise MemoryError(
            "ZZ encode destination too small: need="
            + str(needed)
            + ", have="
            + str(int(dst_flat.numel()))
            + ", m_rows="
            + str(m_rows)
            + ", n_cols="
            + str(n_cols)
            + ", n_align="
            + str(n_align)
            + ", row_block="
            + str(row_block)
        )
    dst_panel = dst_flat[:needed].reshape(block_count, n_align, row_block)
    for block_idx in range(block_count):
        row0 = block_idx * row_block
        row1 = min(row0 + row_block, m_rows)
        rows = row1 - row0
        dst_panel[block_idx, :n_cols, :rows].copy_(logical[row0:row1, :].transpose(0, 1))


def gather_strided_region(flat: torch.Tensor, rows: int, cols: int, stride: int) -> torch.Tensor:
    out = _alloc_logical_zeros(flat, rows, cols)
    if rows == 0 or cols == 0:
        return out
    if stride < cols:
        # Preserve sequential overwrite behavior for overlapping row windows.
        for row_idx in range(rows):
            begin = row_idx * stride
            out[row_idx, :].copy_(flat[begin : begin + cols])
        return out
    row_offsets = torch.arange(rows, device=flat.device, dtype=torch.long).unsqueeze(1) * int(stride)
    col_offsets = torch.arange(cols, device=flat.device, dtype=torch.long).unsqueeze(0)
    gather_idx = row_offsets + col_offsets
    max_idx = int(gather_idx.max().item()) if gather_idx.numel() > 0 else -1
    if max_idx >= int(flat.numel()):
        raise MemoryError(
            "strided gather source pointer region is too small: "
            + "max_index="
            + str(max_idx)
            + ", numel="
            + str(int(flat.numel()))
        )
    return flat[gather_idx]


def scatter_strided_region(flat: torch.Tensor, values: torch.Tensor, stride: int) -> None:
    rows = int(values.shape[0])
    cols = int(values.shape[1]) if values.dim() >= 2 else 0
    if rows == 0 or cols == 0:
        return
    if stride < cols:
        # Preserve sequential overwrite behavior for overlapping row windows.
        for row_idx in range(rows):
            begin = row_idx * stride
            flat[begin : begin + cols].copy_(values[row_idx, :])
        return
    row_offsets = torch.arange(rows, device=flat.device, dtype=torch.long).unsqueeze(1) * int(stride)
    col_offsets = torch.arange(cols, device=flat.device, dtype=torch.long).unsqueeze(0)
    scatter_idx = row_offsets + col_offsets
    max_idx = int(scatter_idx.max().item()) if scatter_idx.numel() > 0 else -1
    if max_idx >= int(flat.numel()):
        raise MemoryError(
            "strided scatter destination pointer region is too small: "
            + "max_index="
            + str(max_idx)
            + ", numel="
            + str(int(flat.numel()))
        )
    flat[scatter_idx.reshape(-1)] = values.reshape(-1)


def resolve_ub_to_l1_dst_need(
    n_src: int,
    c0: int,
    dst_stride_m: int,
    m_src: int,
) -> int:
    block_count = (n_src + c0 - 1) // c0
    return block_count * dst_stride_m * c0 if m_src > 0 and n_src > 0 else 0


def first_overflow_block(
    have: int,
    copy_len_per_block: int,
) -> Optional[int]:
    if copy_len_per_block <= 0:
        return None
    if have < 0:
        return 0
    return have // copy_len_per_block
