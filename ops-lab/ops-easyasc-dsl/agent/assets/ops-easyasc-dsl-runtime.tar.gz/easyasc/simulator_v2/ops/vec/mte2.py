# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from ...memory.shared_tensor_store import SharedTensorStore
from ...program.task import PipeTask
from ..common import PipeDescriptor, PipeFamily
from ..pipe_base import PipeBaseV2


@dataclass
class MTE2PipeV2(PipeBaseV2):
    def __init__(self) -> None:
        super(MTE2PipeV2, self).__init__(PipeDescriptor(PipeFamily.VEC, "MTE2"))

    @staticmethod
    def _resolve_int(value: Any, label: str) -> int:
        if isinstance(value, bool):
            return int(value)
        if not isinstance(value, (int, float)):
            raise TypeError(label + " must resolve to int/float, got: " + str(type(value)))
        return int(value)

    @staticmethod
    def _align32(value: int) -> int:
        return ((value + 31) // 32) * 32

    @staticmethod
    def _linear_view_from_pointer(tensor: torch.Tensor) -> torch.Tensor:
        elem_size = int(tensor.element_size())
        if elem_size <= 0:
            raise ValueError("tensor element size must be positive, got: " + str(elem_size))
        storage_elems = int(tensor.untyped_storage().nbytes()) // elem_size
        available = storage_elems - int(tensor.storage_offset())
        if available < 0:
            raise MemoryError(
                "tensor storage offset exceeds storage capacity: "
                + "offset="
                + str(int(tensor.storage_offset()))
                + ", storage_elems="
                + str(storage_elems)
            )
        return tensor.as_strided((available,), (1,), storage_offset=int(tensor.storage_offset()))

    def execute(self, task: PipeTask, tensor_store: SharedTensorStore, micro_runtime=None) -> bool:
        if task.opname == "vec_mte2_load":
            src = tensor_store.tensor(str(task.args["src"]))
            dst = tensor_store.tensor(str(task.args["dst"]))
            dst.copy_(src.reshape(dst.shape))
            return True
        if task.opname == "gm_to_ub_pad":
            dst = self._linear_view_from_pointer(tensor_store.tensor(str(task.args["dst"])))
            src = self._linear_view_from_pointer(tensor_store.tensor(str(task.args["src"])))
            if int(src.element_size()) != int(dst.element_size()):
                raise ValueError(
                    "gm_to_ub_pad requires src/dst tensor views with identical element size, got "
                    + "src="
                    + str(int(src.element_size()))
                    + ", dst="
                    + str(int(dst.element_size()))
                )
            n_burst = self._resolve_int(task.args.get("n_burst"), "gm_to_ub_pad n_burst")
            burst_len_byte = self._resolve_int(task.args.get("burst_len_byte"), "gm_to_ub_pad burst_len_byte")
            src_stride_byte = self._resolve_int(task.args.get("src_stride_byte"), "gm_to_ub_pad src_stride_byte")
            dst_stride = self._resolve_int(task.args.get("dst_stride"), "gm_to_ub_pad dst_stride")
            if n_burst < 0 or burst_len_byte < 0 or src_stride_byte < 0 or dst_stride < 0:
                raise ValueError(
                    "gm_to_ub_pad requires non-negative n_burst/burst_len_byte/src_stride_byte/dst_stride, "
                    + "got n_burst="
                    + str(n_burst)
                    + ", burst_len_byte="
                    + str(burst_len_byte)
                    + ", src_stride_byte="
                    + str(src_stride_byte)
                    + ", dst_stride="
                    + str(dst_stride)
                )
            dst_stride_byte = dst_stride * 32
            aligned_burst_len_byte = self._align32(burst_len_byte)
            src_bytes = src.view(torch.uint8)
            dst_bytes = dst.view(torch.uint8)
            src_step = burst_len_byte + src_stride_byte
            dst_step = aligned_burst_len_byte + dst_stride_byte
            src_need = 0
            dst_need = 0
            if n_burst > 0:
                src_need = (n_burst - 1) * src_step + burst_len_byte
                dst_need = (n_burst - 1) * dst_step + burst_len_byte
            if src_need > int(src_bytes.numel()):
                raise MemoryError(
                    "gm_to_ub_pad source view is too small: "
                    + "need="
                    + str(src_need)
                    + " bytes, have="
                    + str(int(src_bytes.numel()))
                    + " bytes"
                )
            if dst_need > int(dst_bytes.numel()):
                raise MemoryError(
                    "gm_to_ub_pad destination view is too small: "
                    + "need="
                    + str(dst_need)
                    + " bytes, have="
                    + str(int(dst_bytes.numel()))
                    + " bytes"
                )
            if n_burst == 0 or burst_len_byte == 0:
                return True
            for burst_idx in range(n_burst):
                src_begin = burst_idx * src_step
                dst_begin = burst_idx * dst_step
                dst_bytes[dst_begin : dst_begin + burst_len_byte].copy_(
                    src_bytes[src_begin : src_begin + burst_len_byte]
                )
                if aligned_burst_len_byte > burst_len_byte:
                    dst_bytes[dst_begin + burst_len_byte : dst_begin + aligned_burst_len_byte].zero_()
            return True
        return False
