from __future__ import annotations

from dataclasses import dataclass

from ..memory.shared_tensor_store import SharedTensorStore
from ..program.task import PipeTask
from .common import PipeDescriptor


@dataclass
class PipeBaseV2:
    """Base class for V2 pipe implementations."""

    descriptor: PipeDescriptor

    def execute(self, task: PipeTask, tensor_store: SharedTensorStore, micro_runtime=None) -> bool:
        raise NotImplementedError("pipe execution is not implemented in the scaffold")
