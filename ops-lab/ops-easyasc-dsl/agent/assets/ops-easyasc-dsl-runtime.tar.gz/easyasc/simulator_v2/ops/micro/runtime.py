# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import torch

from ...memory.shared_tensor import torch_dtype_from_shared_name
from ...memory.shared_tensor_store import SharedTensorStore

import re

# Vector-lane width in bytes (A5 micro register width).
_VL_BYTES = 256

_TYPED_LITERAL_RE = re.compile(r"^\([\w]+\)(.+)$")


def _strip_typed_literal(text: str) -> str:
    """Strip cast prefix like '(half)2.0f' → '2.0' and trailing 'f'."""
    m = _TYPED_LITERAL_RE.match(text)
    if m:
        text = m.group(1)
    return text.rstrip("f")


def _lane_count(dtype: torch.dtype) -> int:
    return _VL_BYTES // dtype.itemsize


def _torch_dtype_from_dt(dt: Any) -> torch.dtype:
    if isinstance(dt, torch.dtype):
        return dt
    name = str(dt)
    mapping = {
        "half": torch.float16, "float": torch.float32,
        "int8_t": torch.int8, "uint8_t": torch.uint8,
        "int16_t": torch.int16, "uint16_t": torch.uint16,
        "int": torch.int32, "int32_t": torch.int32,
        "uint32_t": torch.int32, "int64_t": torch.int64,
        "bfloat16_t": torch.bfloat16,
    }
    if name in mapping:
        return mapping[name]
    if hasattr(dt, "torch_dtype") and isinstance(getattr(dt, "torch_dtype"), torch.dtype):
        return getattr(dt, "torch_dtype")
    try:
        return torch_dtype_from_shared_name(name)
    except Exception:
        pass
    if hasattr(torch, name):
        maybe = getattr(torch, name)
        if isinstance(maybe, torch.dtype):
            return maybe
    raise TypeError("cannot resolve torch dtype from: " + repr(dt))


def _dtype_size(dtype_ref: Any) -> int:
    return int(torch.empty((), dtype=_torch_dtype_from_dt(dtype_ref)).element_size())


@dataclass
class MicroContext:
    """Per-call_micro execution context: registers, masks, tensor views, vars."""
    regs: Dict[str, torch.Tensor] = field(default_factory=dict)
    masks: Dict[str, torch.Tensor] = field(default_factory=dict)
    tensor_views: Dict[str, torch.Tensor] = field(default_factory=dict)
    var_values: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MicroRuntime:
    """Micro-op execution state for the V2 simulator."""

    bindings: Dict[str, Any] = field(default_factory=dict)
    legacy_masks: Dict[str, Any] = field(default_factory=dict)
    _context_stack: List[MicroContext] = field(default_factory=list)

    def reset(self) -> None:
        self.bindings.clear()
        self.legacy_masks.clear()
        self._context_stack.clear()

    @property
    def _ctx(self) -> Optional[MicroContext]:
        if self._context_stack:
            return self._context_stack[-1]
        return None

    # ------------------------------------------------------------------
    # call_micro entry point
    # ------------------------------------------------------------------

    def execute_call_micro(
        self,
        micro_def: Dict[str, Any],
        tensor_views: Dict[str, torch.Tensor],
        var_values: Dict[str, Any],
        tensor_store: SharedTensorStore,
    ) -> None:
        ctx = MicroContext(
            tensor_views=dict(tensor_views),
            var_values=dict(var_values),
        )
        self._context_stack.append(ctx)
        try:
            instructions = micro_def.get("instructions", [])
            self._execute_instruction_list(instructions, tensor_store)
        finally:
            self._context_stack.pop()

    def _execute_instruction_list(self, instructions: list, tensor_store: SharedTensorStore) -> None:
        pc = 0
        while pc < len(instructions):
            inst = instructions[pc]
            opname = str(inst.opname)
            if opname == "start_micro_loop":
                loop_end = self._find_matching_end_loop(instructions, pc)
                self._execute_loop(inst.kwargs, instructions, pc + 1, loop_end, tensor_store)
                pc = loop_end + 1
                continue
            self._dispatch_micro_inst(opname, inst.kwargs, tensor_store)
            pc += 1

    def _find_matching_end_loop(self, instructions: list, start_pc: int) -> int:
        var = instructions[start_pc].kwargs.get("var")
        var_name = str(var.name) if hasattr(var, "name") else str(var)
        depth = 0
        for pc in range(start_pc, len(instructions)):
            op = str(instructions[pc].opname)
            if op == "start_micro_loop":
                depth += 1
            elif op == "end_loop":
                depth -= 1
                if depth == 0:
                    return pc
        return len(instructions) - 1

    def _execute_loop(self, kwargs: Dict[str, Any], instructions: list,
                      body_start: int, body_end: int, tensor_store: SharedTensorStore) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        var = kwargs.get("var")
        var_name = str(var.name) if hasattr(var, "name") else str(var)
        start = self._resolve_micro_scalar(kwargs.get("start", 0))
        stop = self._resolve_micro_scalar(kwargs.get("stop", 0))
        step = self._resolve_micro_scalar(kwargs.get("step", 1))
        body = instructions[body_start:body_end]
        for val in range(start, stop, step):
            ctx.var_values[var_name] = val
            self._execute_instruction_list(body, tensor_store)

    # ------------------------------------------------------------------
    # Instruction dispatch
    # ------------------------------------------------------------------

    def _dispatch_micro_inst(self, opname: str, kwargs: Dict[str, Any], tensor_store: SharedTensorStore) -> None:
        # Variable lifecycle and arithmetic
        if opname == "create_var":
            self._handle_create_var(kwargs)
            return
        if opname in ("var_add", "var_sub", "var_mul"):
            self._handle_var_arith(opname, kwargs)
            return
        if opname in ("start_micro_loop", "end_loop"):
            return

        # Register lifecycle
        if opname == "create_reg":
            self._handle_create_reg(kwargs)
            return
        if opname == "create_reglist":
            self._handle_create_reglist(kwargs)
            return
        if opname == "create_maskreg":
            self._handle_create_maskreg(kwargs)
            return
        if opname == "micro_slice_tensor":
            self._handle_micro_slice_tensor(kwargs)
            return
        if opname in ("micro_interleave", "micro_dinterleave"):
            self._handle_interleave(opname, kwargs)
            return

        # Datamove
        if opname == "micro_ub2reg":
            self._handle_ub2reg(kwargs)
            return
        if opname == "micro_reg2ub":
            self._handle_reg2ub(kwargs)
            return
        if opname == "micro_ub2regcont":
            self._handle_ub2regcont(kwargs)
            return
        if opname == "micro_reg2ubcont":
            self._handle_reg2ubcont(kwargs)
            return

        # Arange
        if opname == "micro_arange":
            self._handle_arange(kwargs)
            return

        # Gather / scatter datamove
        if opname == "micro_datacopygather":
            self._handle_datacopygather(kwargs)
            return
        if opname == "micro_datacopyscatter":
            self._handle_datacopyscatter(kwargs)
            return
        if opname == "micro_gather":
            self._handle_gather(kwargs)
            return
        if opname == "micro_gathermask":
            self._handle_gathermask(kwargs)
            return

        # Math dispatch (unary, binary, unary-scalar, dup, cast, compare, select)
        if self._execute_math(opname, kwargs, tensor_store):
            return

        # Mask register ops
        if opname in ("micro_masknot", "micro_maskmov"):
            self._handle_mask_unary(opname, kwargs)
            return
        if opname in ("micro_maskand", "micro_maskor", "micro_maskxor", "micro_masksel"):
            self._handle_mask_binary(opname, kwargs)
            return
        if opname in ("micro_maskinterl", "micro_maskdeinterl"):
            self._handle_mask_interleave(opname, kwargs)
            return
        if opname in ("micro_maskpack", "micro_maskunpack"):
            self._handle_mask_pack(opname, kwargs)
            return
        if opname == "micro_updatemask":
            self._handle_updatemask(kwargs)
            return
        if opname == "micro_movemaskspr":
            raise NotImplementedError("SPR-related mask ops are not supported in V2 simulator")

        # Skip unknown ops silently (future phases)
        return

    # ------------------------------------------------------------------
    # Variable lifecycle and arithmetic
    # ------------------------------------------------------------------

    def _handle_create_var(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        var = kwargs.get("val", kwargs.get("var"))
        if var is None:
            return
        name = str(var.name) if hasattr(var, "name") else str(var)
        if name not in ctx.var_values:
            value = getattr(var, "value", 0)
            if isinstance(value, bool):
                ctx.var_values[name] = int(value)
            elif isinstance(value, (int, float)):
                ctx.var_values[name] = value
            else:
                ctx.var_values[name] = 0

    def _resolve_micro_number(self, value: Any) -> Any:
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, (int, float)):
            return value
        ctx = self._ctx
        if hasattr(value, "name"):
            name = str(value.name)
            if ctx is not None and name in ctx.var_values:
                resolved = ctx.var_values[name]
                if isinstance(resolved, bool):
                    return int(resolved)
                if isinstance(resolved, (int, float)):
                    return resolved
        if hasattr(value, "value") and isinstance(getattr(value, "value"), bool):
            return int(getattr(value, "value"))
        if hasattr(value, "value") and isinstance(getattr(value, "value"), (int, float)):
            return getattr(value, "value")
        if ctx is not None and isinstance(value, str):
            if value in ctx.var_values:
                resolved = ctx.var_values[value]
                if isinstance(resolved, bool):
                    return int(resolved)
                if isinstance(resolved, (int, float)):
                    return resolved
        if isinstance(value, str):
            cleaned = _strip_typed_literal(value)
            try:
                return int(cleaned)
            except ValueError:
                pass
            try:
                return float(cleaned)
            except ValueError:
                pass
        raise TypeError("cannot resolve micro number: " + repr(value))

    def _handle_var_arith(self, opname: str, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        a = self._resolve_micro_number(kwargs.get("a", 0))
        b = self._resolve_micro_number(kwargs.get("b", 0))
        out = kwargs.get("out")
        if out is None:
            return
        out_name = str(out.name) if hasattr(out, "name") else str(out)
        if opname == "var_add":
            ctx.var_values[out_name] = a + b
        elif opname == "var_sub":
            ctx.var_values[out_name] = a - b
        elif opname == "var_mul":
            ctx.var_values[out_name] = a * b

    # ------------------------------------------------------------------
    # Register lifecycle
    # ------------------------------------------------------------------

    def _handle_create_reg(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        reg = kwargs.get("reg")
        if reg is None:
            return
        name = str(reg.name) if hasattr(reg, "name") else str(reg)
        dt = _torch_dtype_from_dt(reg.dtype) if hasattr(reg, "dtype") else torch.float32
        lanes = _lane_count(dt)
        ctx.regs[name] = torch.zeros((lanes,), dtype=dt)

    def _handle_create_reglist(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        reglist = kwargs.get("reglist")
        if reglist is None:
            return
        name = str(reglist.name) if hasattr(reglist, "name") else str(reglist)
        length = int(getattr(reglist, "length", 1))
        dt = _torch_dtype_from_dt(reglist.dtype) if hasattr(reglist, "dtype") else torch.float32
        lanes = _lane_count(dt)
        for i in range(length):
            ctx.regs["%s[%d]" % (name, i)] = torch.zeros((lanes,), dtype=dt)

    def _handle_create_maskreg(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        reg = kwargs.get("reg")
        if reg is None:
            return
        name = str(reg.name) if hasattr(reg, "name") else str(reg)
        ctx.masks[name] = self._mask_bits_from_mode(reg)

    # ------------------------------------------------------------------
    # Tensor view helpers
    # ------------------------------------------------------------------

    def _handle_micro_slice_tensor(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        src = kwargs.get("src")
        out = kwargs.get("out")
        if src is None or out is None:
            return
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        out_name = str(out.name) if hasattr(out, "name") else str(out)
        src_view = self._lookup_tensor(src_name)
        if src_view is None:
            return
        flat = src_view.reshape(-1)
        linear_offset = self._resolve_linear_offset(src, out, kwargs)
        ctx.tensor_views[out_name] = flat[linear_offset:]

    def _resolve_linear_offset(self, src: Any, out: Any, kwargs: Dict[str, Any]) -> int:
        offset = kwargs.get("offset")
        if offset is None:
            offset = getattr(out, "offset", None)
        if offset is None:
            return 0
        src_shape = getattr(src, "shape", None)
        if isinstance(offset, (int, float)):
            return int(offset)
        if isinstance(offset, (list, tuple)):
            shape = src_shape if isinstance(src_shape, (list, tuple)) else []
            total = 0
            for i in range(len(offset)):
                off = self._resolve_micro_scalar_safe(offset[i])
                stride = 1
                for j in range(i + 1, len(shape)):
                    stride *= self._resolve_micro_scalar_safe(shape[j])
                total += off * stride
            return total
        return int(self._resolve_micro_scalar_safe(offset))

    def _resolve_micro_scalar_safe(self, value: Any) -> int:
        if isinstance(value, (int, float, bool)):
            return int(value)
        if isinstance(value, (list, tuple)):
            if len(value) == 1:
                return int(value[0]) if isinstance(value[0], (int, float)) else 0
            return 0
        return self._resolve_micro_scalar(value)

    def _lookup_tensor(self, name: str) -> Optional[torch.Tensor]:
        ctx = self._ctx
        if ctx is not None:
            view = ctx.tensor_views.get(name)
            if view is not None:
                return view
        return None

    @staticmethod
    def _flat_view(tensor: torch.Tensor, label: str) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            raise TypeError(label + " requires torch.Tensor, got: " + str(type(tensor)))
        return tensor.reshape(-1)

    @staticmethod
    def _is_float8(dtype: torch.dtype) -> bool:
        return str(dtype).startswith("torch.float8_")

    @staticmethod
    def _gather_1d(values: torch.Tensor, indices: torch.Tensor) -> torch.Tensor:
        src_flat = values.reshape(-1)
        gather_idx = indices.to(device=src_flat.device, dtype=torch.long)
        if MicroRuntime._is_float8(src_flat.dtype):
            orig_dtype = src_flat.dtype
            return src_flat.view(torch.uint8)[gather_idx].view(orig_dtype)
        return src_flat[gather_idx]

    @staticmethod
    def _scatter_1d(dst: torch.Tensor, indices: torch.Tensor, values: torch.Tensor) -> None:
        dst_flat = dst.reshape(-1)
        scatter_idx = indices.to(device=dst_flat.device, dtype=torch.long)
        if MicroRuntime._is_float8(dst_flat.dtype):
            scatter_values = values.to(dtype=dst_flat.dtype, device=dst_flat.device)
            dst_flat.view(torch.uint8)[scatter_idx] = scatter_values.view(torch.uint8)
        else:
            scatter_values = values.to(dtype=dst_flat.dtype, device=dst_flat.device)
            dst_flat[scatter_idx] = scatter_values

    def _c0_lane_count(self, dtype_ref: Any) -> int:
        elem_size = _dtype_size(dtype_ref)
        if elem_size <= 0 or (32 % elem_size) != 0:
            raise ValueError("unsupported dtype element size for 32-byte C0 unit: " + str(elem_size))
        return 32 // elem_size

    def _mask_bits_from_mode(self, mask_ref: Any) -> torch.Tensor:
        dtype_ref = getattr(mask_ref, "dtype", torch.float16)
        lanes = _lane_count(_torch_dtype_from_dt(dtype_ref))
        out = torch.zeros((lanes,), dtype=torch.bool)
        mode = str(getattr(mask_ref, "init_mode", "ALL"))
        if mode == "ALL":
            out.fill_(True)
            return out
        if mode == "ALLF":
            return out
        if mode.startswith("VL") and mode[2:].isdigit():
            count = min(max(int(mode[2:]), 0), lanes)
            if count > 0:
                out[:count] = True
            return out
        if mode == "H":
            count = lanes // 2
            if count > 0:
                out[:count] = True
            return out
        if mode == "Q":
            count = lanes // 4
            if count > 0:
                out[:count] = True
            return out
        if mode == "M3":
            out[::3] = True
            return out
        if mode == "M4":
            out[::4] = True
            return out
        out.fill_(True)
        return out

    def _resolve_mask_bits(self, mask_ref: Any, dtype_ref: Any, label: str) -> torch.Tensor:
        lanes = _lane_count(_torch_dtype_from_dt(dtype_ref))
        if mask_ref is None:
            return torch.ones((lanes,), dtype=torch.bool)
        ctx = self._ctx
        name = str(mask_ref.name) if hasattr(mask_ref, "name") else str(mask_ref)
        if ctx is not None and name in ctx.masks:
            bits = ctx.masks[name]
        else:
            bits = self._mask_bits_from_mode(mask_ref)
        if not isinstance(bits, torch.Tensor):
            raise TypeError(label + " resolved mask must be torch.Tensor, got: " + str(type(bits)))
        if bits.dtype != torch.bool:
            raise TypeError(label + " resolved mask must be bool tensor, got: " + str(bits.dtype))
        if bits.dim() != 1:
            raise ValueError(label + " resolved mask must be 1D tensor, got dim=" + str(bits.dim()))
        if int(bits.numel()) != lanes:
            raise ValueError(
                label + " resolved mask lane count mismatch: expected=" + str(lanes) + ", actual=" + str(int(bits.numel()))
            )
        return bits

    def _expand_mask_bits_c0(self, mask_bits: torch.Tensor, dtype_ref: Any, label: str) -> torch.Tensor:
        if not isinstance(mask_bits, torch.Tensor):
            raise TypeError(label + " mask_bits must be torch.Tensor, got: " + str(type(mask_bits)))
        if mask_bits.dtype != torch.bool:
            raise TypeError(label + " mask_bits must be bool tensor, got: " + str(mask_bits.dtype))
        if mask_bits.dim() != 1:
            raise ValueError(label + " mask_bits must be 1D tensor, got dim=" + str(mask_bits.dim()))
        lanes = int(mask_bits.numel())
        c0 = self._c0_lane_count(dtype_ref)
        if lanes % c0 != 0:
            raise ValueError(label + " lane count must be divisible by C0, got lanes=" + str(lanes) + ", c0=" + str(c0))
        blocks = mask_bits.view(lanes // c0, c0)
        enabled_blocks = blocks.any(dim=1, keepdim=True)
        return enabled_blocks.expand(-1, c0).reshape(-1)

    @staticmethod
    def _align_mask_device(mask_bits: torch.Tensor, tensor: torch.Tensor) -> torch.Tensor:
        if mask_bits.device == tensor.device:
            return mask_bits
        return mask_bits.to(device=tensor.device)

    @staticmethod
    def _micro_cast_layout_slot(layout_name: str, ratio: int) -> int:
        if ratio <= 0:
            raise ValueError("micro_cast invalid layout ratio: " + str(ratio))
        mapping = {
            "ZERO": 0,
            "ONE": 1,
            "TWO": 2,
            "THREE": 3,
        }
        normalized = layout_name.strip().upper()
        if normalized not in mapping:
            raise ValueError("micro_cast unsupported RegLayout: " + str(layout_name))
        slot = mapping[normalized]
        if slot >= ratio:
            raise ValueError(
                "micro_cast RegLayout "
                + normalized
                + " is invalid for ratio "
                + str(ratio)
            )
        return slot

    @staticmethod
    def _micro_cast_float_dtype(dst_dtype: torch.dtype) -> bool:
        return bool(torch.empty((), dtype=dst_dtype).is_floating_point())

    @staticmethod
    def _micro_cast_is_float8_dtype(dtype: torch.dtype) -> bool:
        return str(dtype).startswith("torch.float8_")

    def _micro_cast_apply_dtype(self, values: torch.Tensor, dst_dtype: torch.dtype, mode_name: str, saturate: bool) -> torch.Tensor:
        work = values
        if work.dtype.is_floating_point and not self._micro_cast_float_dtype(dst_dtype):
            work = self._round_for_cast(work.to(dtype=torch.float32), mode_name)
        if not saturate:
            return work.to(dtype=dst_dtype)

        if self._micro_cast_float_dtype(dst_dtype):
            info = torch.finfo(dst_dtype)
            work = work.to(dtype=torch.float64)
            finite = torch.isfinite(work)
            if bool(finite.any().item()):
                work[finite] = torch.clamp(work[finite], min=float(info.min), max=float(info.max))
            return work.to(dtype=dst_dtype)

        info = torch.iinfo(dst_dtype)
        work = work.to(dtype=torch.float64)
        finite = torch.isfinite(work)
        if bool(finite.any().item()):
            work[finite] = torch.clamp(work[finite], min=float(info.min), max=float(info.max))
        pos_inf = work == float("inf")
        if bool(pos_inf.any().item()):
            work[pos_inf] = float(info.max)
        neg_inf = work == float("-inf")
        if bool(neg_inf.any().item()):
            work[neg_inf] = float(info.min)
        nan_mask = torch.isnan(work)
        if bool(nan_mask.any().item()):
            work[nan_mask] = 0.0
        return work.to(dtype=dst_dtype)

    def _c0_block_copy_indices(
        self,
        lane_indices: torch.Tensor,
        dtype_ref: Any,
        blk_stride: int,
        label: str,
    ) -> torch.Tensor:
        if not isinstance(lane_indices, torch.Tensor):
            raise TypeError(label + " lane_indices must be torch.Tensor, got: " + str(type(lane_indices)))
        if lane_indices.dim() != 1:
            raise ValueError(label + " lane_indices must be 1D tensor, got dim=" + str(lane_indices.dim()))
        if blk_stride <= 0:
            raise ValueError(label + " blk_stride must be positive, got: " + str(blk_stride))
        indices = lane_indices.to(dtype=torch.long)
        c0 = self._c0_lane_count(dtype_ref)
        block_indices = indices // c0
        inner_indices = indices % c0
        return block_indices * (blk_stride * c0) + inner_indices

    def _get_reg(self, name: str) -> torch.Tensor:
        ctx = self._ctx
        if ctx is None:
            raise RuntimeError("no active MicroContext")
        name = str(name)
        if name in ctx.regs:
            return ctx.regs[name]
        # Legacy compatibility path
        if name in self.bindings:
            v = self.bindings[name]
            if isinstance(v, torch.Tensor):
                return v
        raise KeyError("micro register not found: " + name)

    def _set_reg(self, name: str, value: torch.Tensor) -> None:
        ctx = self._ctx
        if ctx is None:
            raise RuntimeError("no active MicroContext")
        name = str(name)
        if isinstance(value, torch.Tensor):
            ctx.regs[name] = value.clone()
        else:
            ctx.regs[name] = value

    def _get_mask(self, name: Any) -> Optional[torch.Tensor]:
        if name is None:
            return None
        ctx = self._ctx
        if ctx is None:
            return None
        name_str = str(name.name) if hasattr(name, "name") else str(name)
        return ctx.masks.get(name_str)

    def _resolve_micro_scalar(self, value: Any) -> int:
        if isinstance(value, (int, float, bool)):
            return int(value)
        ctx = self._ctx
        if hasattr(value, "name"):
            name = str(value.name)
            if ctx is not None and name in ctx.var_values:
                return int(ctx.var_values[name])
        if hasattr(value, "value") and isinstance(getattr(value, "value"), (int, float)):
            return int(value.value)
        if ctx is not None and isinstance(value, str):
            if value in ctx.var_values:
                return int(ctx.var_values[value])
        if isinstance(value, str):
            cleaned = _strip_typed_literal(value)
            try:
                return int(cleaned)
            except ValueError:
                pass
            try:
                return int(float(cleaned))
            except ValueError:
                pass
        raise TypeError("cannot resolve micro scalar: " + repr(value))

    def _resolve_micro_float(self, value: Any) -> float:
        if isinstance(value, (int, float, bool)):
            return float(value)
        ctx = self._ctx
        if hasattr(value, "name"):
            name = str(value.name)
            if ctx is not None and name in ctx.var_values:
                return float(ctx.var_values[name])
        if hasattr(value, "value") and isinstance(getattr(value, "value"), (int, float)):
            return float(value.value)
        if ctx is not None and isinstance(value, str):
            if value in ctx.var_values:
                return float(ctx.var_values[value])
        if isinstance(value, str):
            cleaned = _strip_typed_literal(value)
            try:
                return float(cleaned)
            except ValueError:
                pass
        return float(self._resolve_micro_scalar(value))

    # ------------------------------------------------------------------
    # Datamove: ub <-> reg
    # ------------------------------------------------------------------

    def _handle_ub2reg(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        dst = kwargs.get("dst")
        src = kwargs.get("src")
        if dst is None or src is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        src_view = self._lookup_tensor(src_name)
        if src_view is None:
            raise ValueError("micro_ub2reg: source tensor not found: " + src_name)
        flat = self._flat_view(src_view, "micro_ub2reg src")
        dst_reg = self._get_reg(dst_name)
        blk_stride = self._resolve_micro_scalar(kwargs.get("blk_stride", 1))
        if blk_stride <= 0:
            raise ValueError("micro_ub2reg blk_stride must be positive, got: " + str(blk_stride))
        mask_bits = self._resolve_mask_bits(kwargs.get("mask"), getattr(dst, "dtype", dst_reg.dtype), "micro_ub2reg")
        mask_bits = self._align_mask_device(mask_bits, flat)
        lane_count = int(dst_reg.numel())
        if blk_stride == 1 and bool(mask_bits.all().item()):
            if lane_count > int(flat.numel()):
                raise ValueError(
                    "micro_ub2reg source view too small for full-mask contiguous copy: need="
                    + str(lane_count) + ", src_numel=" + str(int(flat.numel()))
                )
            dst_reg.copy_(flat[:lane_count].to(dtype=dst_reg.dtype, device=dst_reg.device))
            ctx.regs[dst_name] = dst_reg
            return
        mask_bits = self._expand_mask_bits_c0(mask_bits, getattr(dst, "dtype", dst_reg.dtype), "micro_ub2reg")
        active_idx = torch.nonzero(mask_bits, as_tuple=False).view(-1)
        dst_reg.zero_()
        if int(active_idx.numel()) == 0:
            ctx.regs[dst_name] = dst_reg
            return
        src_indices = self._c0_block_copy_indices(active_idx, getattr(dst, "dtype", dst_reg.dtype), blk_stride, "micro_ub2reg")
        max_index = int(src_indices.max().item())
        if max_index >= int(flat.numel()):
            raise ValueError(
                "micro_ub2reg source view too small: need_index="
                + str(max_index) + ", src_numel=" + str(int(flat.numel()))
            )
        values = self._gather_1d(flat, src_indices).to(dtype=dst_reg.dtype, device=dst_reg.device)
        self._scatter_1d(dst_reg, active_idx, values)
        ctx.regs[dst_name] = dst_reg

    def _handle_reg2ub(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        dst = kwargs.get("dst")
        src = kwargs.get("src")
        if dst is None or src is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        dst_view = self._lookup_tensor(dst_name)
        if dst_view is None:
            raise ValueError("micro_reg2ub: dest tensor not found: " + dst_name)
        flat = self._flat_view(dst_view, "micro_reg2ub dst")
        src_reg = self._get_reg(src_name)
        blk_stride = self._resolve_micro_scalar(kwargs.get("blk_stride", 1))
        if blk_stride <= 0:
            raise ValueError("micro_reg2ub blk_stride must be positive, got: " + str(blk_stride))
        mask_bits = self._resolve_mask_bits(kwargs.get("mask"), getattr(src, "dtype", src_reg.dtype), "micro_reg2ub")
        mask_bits = self._align_mask_device(mask_bits, flat)
        lane_count = int(src_reg.numel())
        if blk_stride == 1 and bool(mask_bits.all().item()):
            if lane_count > int(flat.numel()):
                raise ValueError(
                    "micro_reg2ub destination view too small for full-mask contiguous store: need="
                    + str(lane_count) + ", dst_numel=" + str(int(flat.numel()))
                )
            flat[:lane_count].copy_(src_reg.to(dtype=flat.dtype, device=flat.device))
            return
        mask_bits = self._expand_mask_bits_c0(mask_bits, getattr(src, "dtype", src_reg.dtype), "micro_reg2ub")
        active_idx = torch.nonzero(mask_bits, as_tuple=False).view(-1)
        if int(active_idx.numel()) == 0:
            return
        dst_indices = self._c0_block_copy_indices(active_idx, getattr(src, "dtype", src_reg.dtype), blk_stride, "micro_reg2ub")
        max_index = int(dst_indices.max().item())
        if max_index >= int(flat.numel()):
            raise ValueError(
                "micro_reg2ub destination view too small: need_index="
                + str(max_index) + ", dst_numel=" + str(int(flat.numel()))
            )
        values = self._gather_1d(src_reg, active_idx)
        self._scatter_1d(flat, dst_indices, values)

    def _handle_ub2regcont(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        dst = kwargs.get("dst")
        src = kwargs.get("src")
        mode = str(kwargs.get("mode", ""))
        if dst is None or src is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        src_view = self._lookup_tensor(src_name)
        if src_view is None:
            raise ValueError("micro_ub2regcont: source tensor not found: " + src_name)
        src_flat = self._flat_view(src_view, "micro_ub2regcont src")
        reg_view = self._get_reg(dst_name)
        lane_count = int(reg_view.numel())
        elem_size = _dtype_size(getattr(dst, "dtype", reg_view.dtype))
        mode_name = mode.strip().upper()
        supported_mode_elem_size = {
            "DIST_DS_B8": 1,
            "DIST_DS_B16": 2,
            "DIST_US_B8": 1,
            "DIST_US_B16": 2,
            "DIST_BRC_B8": 1,
            "DIST_BRC_B16": 2,
            "DIST_BRC_B32": 4,
            "DIST_E2B_B16": 2,
            "DIST_E2B_B32": 4,
            "DIST_UNPACK_B8": 1,
            "DIST_UNPACK_B16": 2,
            "DIST_UNPACK_B32": 4,
            "DIST_UNPACK4_B8": 1,
        }
        expected_elem_size = supported_mode_elem_size.get(mode_name)
        if expected_elem_size is None:
            raise NotImplementedError("micro_ub2regcont mode is not supported yet: " + mode)
        if elem_size != expected_elem_size:
            raise ValueError(
                "micro_ub2regcont mode/dtype mismatch: mode="
                + mode_name + ", expected_elem_size=" + str(expected_elem_size)
                + ", actual_elem_size=" + str(elem_size)
            )

        def _require_source_elements(required: int) -> None:
            actual = int(src_flat.numel())
            if actual < required:
                raise ValueError(
                    "micro_ub2regcont source view too small: mode=" + mode_name
                    + ", required=" + str(required) + ", actual=" + str(actual)
                )

        def _to_reg_dtype_and_device(values: torch.Tensor) -> torch.Tensor:
            out = values
            if out.dtype != reg_view.dtype or out.device != reg_view.device:
                out = out.to(dtype=reg_view.dtype, device=reg_view.device)
            return out

        if mode_name.startswith("DIST_BRC_"):
            _require_source_elements(1)
            reg_view.copy_(_to_reg_dtype_and_device(src_flat[:1]).repeat(lane_count))
            ctx.regs[dst_name] = reg_view
            return

        if mode_name.startswith("DIST_DS_"):
            _require_source_elements(lane_count * 2)
            src_idx = torch.arange(lane_count, device=src_flat.device, dtype=torch.long) * 2
            reg_view.copy_(_to_reg_dtype_and_device(self._gather_1d(src_flat, src_idx)))
            ctx.regs[dst_name] = reg_view
            return

        if mode_name.startswith("DIST_US_"):
            if lane_count % 2 != 0:
                raise ValueError("micro_ub2regcont " + mode_name + " requires even lane count, got: " + str(lane_count))
            required = lane_count // 2
            _require_source_elements(required)
            reg_view.copy_(_to_reg_dtype_and_device(src_flat[:required]).repeat_interleave(2))
            ctx.regs[dst_name] = reg_view
            return

        if mode_name.startswith("DIST_UNPACK4_"):
            if lane_count % 4 != 0:
                raise ValueError(
                    "micro_ub2regcont " + mode_name + " requires lane count divisible by 4, got: " + str(lane_count)
                )
            required = lane_count // 4
            _require_source_elements(required)
            values = _to_reg_dtype_and_device(src_flat[:required])
            self._scatter_1d(reg_view, torch.arange(0, lane_count, 4, device=reg_view.device, dtype=torch.long), values)
            ctx.regs[dst_name] = reg_view
            return

        if mode_name.startswith("DIST_UNPACK_"):
            if lane_count % 2 != 0:
                raise ValueError("micro_ub2regcont " + mode_name + " requires even lane count, got: " + str(lane_count))
            required = lane_count // 2
            _require_source_elements(required)
            values = _to_reg_dtype_and_device(src_flat[:required])
            self._scatter_1d(reg_view, torch.arange(0, lane_count, 2, device=reg_view.device, dtype=torch.long), values)
            ctx.regs[dst_name] = reg_view
            return

        if mode_name.startswith("DIST_E2B_"):
            c0 = self._c0_lane_count(getattr(dst, "dtype", reg_view.dtype))
            if lane_count % c0 != 0:
                raise ValueError(
                    "micro_ub2regcont " + mode_name + " requires lane count divisible by c0, got lanes="
                    + str(lane_count) + ", c0=" + str(c0)
                )
            block_count = lane_count // c0
            _require_source_elements(block_count)
            values = _to_reg_dtype_and_device(src_flat[:block_count])
            reg_view.copy_(values.view(block_count, 1).expand(block_count, c0).reshape(-1))
            ctx.regs[dst_name] = reg_view
            return

        raise NotImplementedError("micro_ub2regcont mode is not supported yet: " + mode)

    def _handle_reg2ubcont(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        dst = kwargs.get("dst")
        src = kwargs.get("src")
        mode = str(kwargs.get("mode", ""))
        if dst is None or src is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        dst_view = self._lookup_tensor(dst_name)
        if dst_view is None:
            raise ValueError("micro_reg2ubcont: dest tensor not found: " + dst_name)
        dst_flat = self._flat_view(dst_view, "micro_reg2ubcont dst")
        reg_view = self._get_reg(src_name)
        lane_count = int(reg_view.numel())
        elem_size = _dtype_size(getattr(src, "dtype", reg_view.dtype))
        mode_name = mode.strip().upper()
        supported_mode_elem_size = {
            "DIST_PACK_B16": 1,
            "DIST_PACK_B32": 2,
            "DIST_PACK_B64": 4,
            "DIST_PACK4_B32": 1,
            "DIST_FIRST_ELEMENT_B8": 1,
            "DIST_FIRST_ELEMENT_B16": 2,
            "DIST_FIRST_ELEMENT_B32": 4,
            "DIST_NORM_B8": 1,
            "DIST_NORM_B16": 2,
            "DIST_NORM_B32": 4,
        }
        expected_elem_size = supported_mode_elem_size.get(mode_name)
        if expected_elem_size is None:
            raise NotImplementedError("micro_reg2ubcont mode is not supported yet: " + mode)
        if elem_size != expected_elem_size:
            raise ValueError(
                "micro_reg2ubcont mode/dtype mismatch: mode="
                + mode_name + ", expected_elem_size=" + str(expected_elem_size)
                + ", actual_elem_size=" + str(elem_size)
            )
        mask_bits = self._resolve_mask_bits(kwargs.get("mask"), getattr(src, "dtype", reg_view.dtype), "micro_reg2ubcont")
        mask_bits = self._expand_mask_bits_c0(mask_bits, getattr(src, "dtype", reg_view.dtype), "micro_reg2ubcont")
        mask_bits = self._align_mask_device(mask_bits, reg_view)

        if mode_name.startswith("DIST_NORM_"):
            src_indices = torch.arange(lane_count, device=reg_view.device, dtype=torch.long)
            dst_indices = src_indices.clone()
        elif mode_name.startswith("DIST_PACK4_"):
            if lane_count % 4 != 0:
                raise ValueError(
                    "micro_reg2ubcont " + mode_name + " requires lane count divisible by 4, got: " + str(lane_count)
                )
            out_count = lane_count // 4
            dst_indices = torch.arange(out_count, device=reg_view.device, dtype=torch.long)
            src_indices = dst_indices * 4
        elif mode_name.startswith("DIST_PACK_"):
            if lane_count % 2 != 0:
                raise ValueError("micro_reg2ubcont " + mode_name + " requires even lane count, got: " + str(lane_count))
            out_count = lane_count // 2
            dst_indices = torch.arange(out_count, device=reg_view.device, dtype=torch.long)
            src_indices = dst_indices * 2
        elif mode_name.startswith("DIST_FIRST_ELEMENT_"):
            src_indices = torch.zeros((1,), device=reg_view.device, dtype=torch.long)
            dst_indices = torch.zeros((1,), device=reg_view.device, dtype=torch.long)
        else:
            raise NotImplementedError("micro_reg2ubcont mode is not supported yet: " + mode)

        selected = mask_bits[src_indices]
        selected_src = src_indices[selected]
        selected_dst = dst_indices[selected]
        if int(selected_dst.numel()) == 0:
            return
        max_dst = int(selected_dst.max().item())
        if max_dst >= int(dst_flat.numel()):
            raise ValueError(
                "micro_reg2ubcont destination view too small: mode=" + mode_name
                + ", need_index=" + str(max_dst) + ", dst_numel=" + str(int(dst_flat.numel()))
            )
        values = self._gather_1d(reg_view, selected_src)
        self._scatter_1d(dst_flat, selected_dst, values)

    def _handle_interleave(self, opname: str, kwargs: Dict[str, Any]) -> None:
        dst0 = kwargs.get("dst0")
        dst1 = kwargs.get("dst1")
        src0 = kwargs.get("src0")
        src1 = kwargs.get("src1")
        if dst0 is None or dst1 is None or src0 is None or src1 is None:
            return
        dst0_name = str(dst0.name) if hasattr(dst0, "name") else str(dst0)
        dst1_name = str(dst1.name) if hasattr(dst1, "name") else str(dst1)
        src0_name = str(src0.name) if hasattr(src0, "name") else str(src0)
        src1_name = str(src1.name) if hasattr(src1, "name") else str(src1)
        dst0_view = self._get_reg(dst0_name)
        dst1_view = self._get_reg(dst1_name)
        src0_view = self._get_reg(src0_name)
        src1_view = self._get_reg(src1_name)
        lane_count = int(dst0_view.numel())
        if (
            int(dst1_view.numel()) != lane_count
            or int(src0_view.numel()) != lane_count
            or int(src1_view.numel()) != lane_count
        ):
            raise ValueError(opname + " requires matching lane counts for dst/src regs")
        if lane_count % 2 != 0:
            raise ValueError(opname + " requires even lane count, got: " + str(lane_count))
        half_lane = lane_count // 2
        src0_snapshot = src0_view.clone()
        src1_snapshot = src1_view.clone()
        out0 = torch.empty_like(dst0_view)
        out1 = torch.empty_like(dst1_view)
        if opname == "micro_interleave":
            out0[0::2] = src0_snapshot[:half_lane]
            out0[1::2] = src1_snapshot[:half_lane]
            out1[0::2] = src0_snapshot[half_lane:]
            out1[1::2] = src1_snapshot[half_lane:]
        else:
            out0[:half_lane] = src0_snapshot[0::2]
            out1[:half_lane] = src0_snapshot[1::2]
            out0[half_lane:] = src1_snapshot[0::2]
            out1[half_lane:] = src1_snapshot[1::2]
        self._set_reg(dst0_name, out0)
        self._set_reg(dst1_name, out1)

    # ------------------------------------------------------------------
    # Arange
    # ------------------------------------------------------------------

    def _handle_arange(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        dst = kwargs.get("dst")
        mode = kwargs.get("mode")
        start = kwargs.get("v")
        if dst is None or mode is None or start is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        dst_reg = self._get_reg(dst_name)
        lane_count = int(dst_reg.numel())
        start_value = self._resolve_micro_float(start)
        increase = str(mode).endswith("INCREASE_ORDER")
        compute_dtype = torch.float64 if dst_reg.is_floating_point() else torch.int64
        indices = torch.arange(lane_count, dtype=compute_dtype, device=dst_reg.device)
        if dst_reg.is_floating_point():
            base = float(start_value)
        else:
            base = int(start_value)
        out = indices + base if increase else base - indices
        dst_reg.copy_(out.to(dst_reg.dtype))
        ctx.regs[dst_name] = dst_reg

    # ------------------------------------------------------------------
    # Bitwise and shift helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _int_view_dtype(src: torch.Tensor, signed: bool = False) -> torch.dtype:
        """Return an integer dtype with the same element size for bitwise view."""
        elem_size = int(src.element_size())
        if signed:
            return {1: torch.int8, 2: torch.int16, 4: torch.int32, 8: torch.int64}[elem_size]
        # Prefer unsigned when available
        if elem_size == 1:
            return torch.uint8
        for name in ("uint16", "uint32", "uint64"):
            if elem_size == {"uint16": 2, "uint32": 4, "uint64": 8}.get(name) and hasattr(torch, name):
                return getattr(torch, name)
        return {1: torch.int8, 2: torch.int16, 4: torch.int32, 8: torch.int64}[elem_size]

    @staticmethod
    def _bitwise_binary(lhs: torch.Tensor, rhs: torch.Tensor, label: str) -> torch.Tensor:
        """Element-wise bitwise AND/OR/XOR, handling bool and float dtypes via int view."""
        op = label.replace("micro_v", "")  # "and", "or", "xor"
        if lhs.dtype == torch.bool:
            if op == "and":
                return torch.logical_and(lhs, rhs)
            if op == "or":
                return torch.logical_or(lhs, rhs)
            return torch.logical_xor(lhs, rhs)
        bit_dtype = MicroRuntime._int_view_dtype(lhs, signed=False)
        lb = lhs.view(bit_dtype)
        rb = rhs.view(bit_dtype)
        if op == "and":
            out = lb & rb
        elif op == "or":
            out = lb | rb
        else:
            out = lb ^ rb
        return out.view(lhs.dtype)

    @staticmethod
    def _shift_bits(src: torch.Tensor, shift: int, left: bool) -> torch.Tensor:
        """Bit shift left/right, handling bool and float dtypes via int view."""
        if shift < 0:
            return MicroRuntime._shift_bits(src, -shift, not left)
        if src.dtype == torch.bool:
            bit_src = src.to(torch.uint8)
            out = (bit_src << shift) if left else (bit_src >> shift)
            return out.to(torch.bool)
        signed = src.dtype in (torch.int8, torch.int16, torch.int32, torch.int64)
        bit_dtype = MicroRuntime._int_view_dtype(src, signed=signed)
        bit_src = src.view(bit_dtype)
        out = (bit_src << shift) if left else (bit_src >> shift)
        return out.view(src.dtype)

    # ------------------------------------------------------------------
    # Gather / scatter datamove
    # ------------------------------------------------------------------

    def _handle_datacopygather(self, kwargs: Dict[str, Any]) -> None:
        """Gather from UB tensor into register using index register."""
        dst = kwargs.get("dst")
        src = kwargs.get("src")
        index = kwargs.get("index")
        if dst is None or src is None or index is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        idx_name = str(index.name) if hasattr(index, "name") else str(index)
        dst_reg = self._get_reg(dst_name)
        src_view = self._lookup_tensor(src_name)
        if src_view is None:
            return
        idx_reg = self._get_reg(idx_name)
        src_flat = self._flat_view(src_view, "micro_datacopygather src")
        gather_idx = idx_reg.to(dtype=torch.long)
        dst_reg.zero_()
        values = self._gather_1d(src_flat, gather_idx)
        if values.dtype != dst_reg.dtype:
            values = values.to(dst_reg.dtype)
        dst_reg.copy_(values)

    def _handle_datacopyscatter(self, kwargs: Dict[str, Any]) -> None:
        """Scatter from register into UB tensor using index register."""
        dst = kwargs.get("dst")
        src = kwargs.get("src")
        index = kwargs.get("index")
        if dst is None or src is None or index is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        idx_name = str(index.name) if hasattr(index, "name") else str(index)
        src_reg = self._get_reg(src_name)
        dst_view = self._lookup_tensor(dst_name)
        if dst_view is None:
            return
        idx_reg = self._get_reg(idx_name)
        dst_flat = self._flat_view(dst_view, "micro_datacopyscatter dst")
        scatter_indices = idx_reg.to(dtype=torch.long)
        src_values = src_reg
        if src_values.dtype != dst_flat.dtype:
            src_values = src_values.to(dst_flat.dtype)
        # Deterministic lane-order writes for duplicate indices
        for lane in range(int(scatter_indices.numel())):
            dst_idx = int(scatter_indices[lane].item())
            self._scatter_1d(
                dst_flat,
                torch.tensor([dst_idx], dtype=torch.long),
                src_values[lane:lane + 1],
            )

    def _handle_gather(self, kwargs: Dict[str, Any]) -> None:
        """Gather from source register to dst using integer index register."""
        dst = kwargs.get("dst")
        src = kwargs.get("src")
        index = kwargs.get("index")
        if dst is None or src is None or index is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        idx_name = str(index.name) if hasattr(index, "name") else str(index)
        src_reg = self._get_reg(src_name)
        idx_reg = self._get_reg(idx_name)
        # Snapshot source first so dst==src alias keeps gather semantics
        src_snap = src_reg.clone()
        gather_idx = idx_reg.to(dtype=torch.long)
        values = self._gather_1d(src_snap, gather_idx)
        if values.dtype != src_reg.dtype:
            values = values.to(src_reg.dtype)
        self._set_reg(dst_name, values)

    def _handle_gathermask(self, kwargs: Dict[str, Any]) -> None:
        """Select elements from src where mask is True, compact into lower lanes of dst."""
        dst = kwargs.get("dst")
        src = kwargs.get("src")
        mask_ref = kwargs.get("mask")
        if dst is None or src is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        src_reg = self._get_reg(src_name)
        # Snapshot source first so dst==src alias keeps semantics
        src_snap = src_reg.clone()
        # Resolve mask bits
        mask_bits = self._get_mask(mask_ref)
        if mask_bits is None:
            mask_bits = self._mask_bits_from_mode(mask_ref)
        # Select active lanes and compact
        selected = src_snap[mask_bits]
        dst_reg = self._get_reg(dst_name)
        dst_reg.zero_()
        selected_count = int(selected.numel())
        if selected_count > 0:
            if selected.dtype != dst_reg.dtype:
                selected = selected.to(dst_reg.dtype)
            dst_reg[:selected_count].copy_(selected)
        self._set_reg(dst_name, dst_reg)

    # ------------------------------------------------------------------
    # Mask register operations
    # ------------------------------------------------------------------

    def _handle_mask_unary(self, opname: str, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        dst = kwargs.get("dst")
        src = kwargs.get("src")
        if dst is None or src is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        src_val = ctx.masks.get(src_name)
        if src_val is None:
            src_val = self._mask_bits_from_mode(src)
        if opname == "micro_masknot":
            ctx.masks[dst_name] = torch.logical_not(src_val)
        elif opname == "micro_maskmov":
            ctx.masks[dst_name] = src_val.clone()

    def _handle_mask_binary(self, opname: str, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        dst = kwargs.get("dst")
        src1 = kwargs.get("src1")
        src2 = kwargs.get("src2")
        if dst is None or src1 is None or src2 is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        s1_name = str(src1.name) if hasattr(src1, "name") else str(src1)
        s2_name = str(src2.name) if hasattr(src2, "name") else str(src2)
        s1_val = ctx.masks.get(s1_name)
        if s1_val is None:
            s1_val = self._mask_bits_from_mode(src1)
        s2_val = ctx.masks.get(s2_name)
        if s2_val is None:
            s2_val = self._mask_bits_from_mode(src2)
        if opname == "micro_maskand":
            ctx.masks[dst_name] = torch.logical_and(s1_val, s2_val)
        elif opname == "micro_maskor":
            ctx.masks[dst_name] = torch.logical_or(s1_val, s2_val)
        elif opname == "micro_maskxor":
            ctx.masks[dst_name] = torch.logical_xor(s1_val, s2_val)
        elif opname == "micro_masksel":
            # For active lanes take src1, for inactive take src2.
            mask = kwargs.get("mask")
            if mask is not None:
                mask_name = str(mask.name) if hasattr(mask, "name") else str(mask)
                active = ctx.masks.get(mask_name)
                if active is None:
                    active = self._mask_bits_from_mode(mask)
                ctx.masks[dst_name] = torch.where(active, s1_val, s2_val)
            else:
                ctx.masks[dst_name] = s1_val.clone()

    def _handle_mask_interleave(self, opname: str, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        dst0 = kwargs.get("dst0")
        dst1 = kwargs.get("dst1")
        src0 = kwargs.get("src0")
        src1 = kwargs.get("src1")
        if dst0 is None or dst1 is None or src0 is None or src1 is None:
            return
        d0_name = str(dst0.name) if hasattr(dst0, "name") else str(dst0)
        d1_name = str(dst1.name) if hasattr(dst1, "name") else str(dst1)
        s0_name = str(src0.name) if hasattr(src0, "name") else str(src0)
        s1_name = str(src1.name) if hasattr(src1, "name") else str(src1)
        s0_val = ctx.masks.get(s0_name)
        if s0_val is None:
            s0_val = self._mask_bits_from_mode(src0)
        s1_val = ctx.masks.get(s1_name)
        if s1_val is None:
            s1_val = self._mask_bits_from_mode(src1)
        s0_snap = s0_val.clone()
        s1_snap = s1_val.clone()
        lane_count = int(s0_snap.numel())
        half = lane_count // 2
        out0 = torch.empty_like(s0_snap)
        out1 = torch.empty_like(s0_snap)
        if opname == "micro_maskinterl":
            out0[0::2] = s0_snap[:half]
            out0[1::2] = s1_snap[:half]
            out1[0::2] = s0_snap[half:]
            out1[1::2] = s1_snap[half:]
        else:  # micro_maskdeinterl
            out0[:half] = s0_snap[0::2]
            out1[:half] = s0_snap[1::2]
            out0[half:] = s1_snap[0::2]
            out1[half:] = s1_snap[1::2]
        ctx.masks[d0_name] = out0
        ctx.masks[d1_name] = out1

    def _handle_mask_pack(self, opname: str, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        dst = kwargs.get("dst")
        src = kwargs.get("src")
        mode = kwargs.get("mode", "")
        if dst is None or src is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        src_val = ctx.masks.get(src_name)
        if src_val is None:
            src_val = self._mask_bits_from_mode(src)
        src_snap = src_val.clone()
        lane_count = int(src_snap.numel())
        half = lane_count // 2
        is_low = str(mode).endswith("LOWEST")
        out = torch.zeros_like(src_snap)
        if opname == "micro_maskpack":
            even_values = src_snap[0::2]
            if is_low:
                out[:half] = even_values
            else:
                out[half:] = even_values
        else:  # micro_maskunpack
            packed = src_snap[:half] if is_low else src_snap[half:]
            out[0::2] = packed
        ctx.masks[dst_name] = out

    def _handle_updatemask(self, kwargs: Dict[str, Any]) -> None:
        ctx = self._ctx
        if ctx is None:
            return
        dst = kwargs.get("dst")
        cnt = kwargs.get("cnt")
        if dst is None or cnt is None:
            return
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        # Resolve counter value
        cnt_value = self._resolve_micro_scalar(cnt)
        # Resolve lane count from dst mask or create default
        existing = ctx.masks.get(dst_name)
        if existing is not None:
            lane_count = int(existing.numel())
        else:
            dtype_ref = getattr(dst, "dtype", torch.float16)
            lane_count = _lane_count(_torch_dtype_from_dt(dtype_ref))
        active_count = min(max(cnt_value, 0), lane_count)
        out = torch.zeros((lane_count,), dtype=torch.bool)
        if active_count > 0:
            out[:active_count] = True
        ctx.masks[dst_name] = out
        # Decrement counter: cnt -= lane_count (clamp to 0)
        # Only update the per-context var store — the Var object is shared
        # across vec lanes and must not be mutated.
        next_value = max(cnt_value - lane_count, 0)
        cnt_name = str(cnt.name) if hasattr(cnt, "name") else str(cnt)
        ctx.var_values[cnt_name] = next_value

    # ------------------------------------------------------------------
    # Math operations
    # ------------------------------------------------------------------

    def _execute_math(self, opname: str, kwargs: Dict[str, Any], tensor_store: SharedTensorStore) -> bool:
        # Unary ops
        _UNARY_OPS = {
            "micro_vabs": lambda x: x.abs(),
            "micro_vneg": lambda x: -x,
            "micro_vnot": lambda x: ~x if x.dtype in (torch.int32, torch.int64, torch.int16, torch.int8, torch.uint8) else (x == 0).to(x.dtype),
            "micro_vcopy": lambda x: x.clone(),
            "micro_vexp": lambda x: torch.exp(x),
            "micro_vrelu": lambda x: torch.relu(x),
            "micro_vsqrt": lambda x: torch.sqrt(x),
            "micro_vln": lambda x: torch.log(x),
            "micro_vlog": lambda x: torch.log(x),
            "micro_vlog2": lambda x: torch.log2(x),
            "micro_vlog10": lambda x: torch.log10(x),
        }
        if opname in _UNARY_OPS:
            src = kwargs.get("src")
            dst = kwargs.get("dst")
            if src is None or dst is None:
                return True
            src_name = str(src.name) if hasattr(src, "name") else str(src)
            dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
            src_val = self._get_reg(src_name)
            self._set_reg(dst_name, _UNARY_OPS[opname](src_val))
            return True

        # Binary ops
        _BINARY_OPS = {
            "micro_vadd": lambda a, b: a + b,
            "micro_vsub": lambda a, b: a - b,
            "micro_vmul": lambda a, b: a * b,
            "micro_vdiv": lambda a, b: a / b,
            "micro_vmax": lambda a, b: torch.maximum(a, b),
            "micro_vmin": lambda a, b: torch.minimum(a, b),
            "micro_vprelu": lambda a, b: torch.where(a > 0, a, a * b),
        }
        if opname in _BINARY_OPS:
            src1 = kwargs.get("src1")
            src2 = kwargs.get("src2")
            dst = kwargs.get("dst")
            if src1 is None or src2 is None or dst is None:
                return True
            s1_name = str(src1.name) if hasattr(src1, "name") else str(src1)
            s2_name = str(src2.name) if hasattr(src2, "name") else str(src2)
            dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
            s1_val = self._get_reg(s1_name)
            s2_val = self._get_reg(s2_name)
            self._set_reg(dst_name, _BINARY_OPS[opname](s1_val, s2_val))
            return True

        # Bitwise binary ops (need view-as-int for float dtypes)
        if opname in ("micro_vand", "micro_vor", "micro_vxor"):
            src1 = kwargs.get("src1")
            src2 = kwargs.get("src2")
            dst = kwargs.get("dst")
            if src1 is None or src2 is None or dst is None:
                return True
            s1_val = self._get_reg(str(src1.name) if hasattr(src1, "name") else str(src1))
            s2_val = self._get_reg(str(src2.name) if hasattr(src2, "name") else str(src2))
            dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
            self._set_reg(dst_name, self._bitwise_binary(s1_val, s2_val, opname))
            return True

        # Bit shift ops (unary-scalar style with int view)
        if opname in ("micro_shiftls", "micro_shiftrs"):
            src = kwargs.get("src", kwargs.get("reg"))
            dst = kwargs.get("dst", src)
            value = kwargs.get("value", kwargs.get("v", 0))
            if src is None or dst is None:
                return True
            src_name = str(src.name) if hasattr(src, "name") else str(src)
            dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
            src_val = self._get_reg(src_name)
            shift = int(self._resolve_micro_float(value))
            left = opname == "micro_shiftls"
            self._set_reg(dst_name, self._shift_bits(src_val, shift, left))
            return True

        # Unary-scalar ops
        if opname in ("micro_vadds", "micro_vmuls", "micro_vmaxs", "micro_vmins", "micro_vlrelu"):
            src = kwargs.get("src", kwargs.get("reg"))
            dst = kwargs.get("dst", src)
            value = kwargs.get("value", kwargs.get("v", 0))
            if src is None or dst is None:
                return True
            src_name = str(src.name) if hasattr(src, "name") else str(src)
            dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
            src_val = self._get_reg(src_name)
            scalar = self._resolve_micro_float(value)
            scalar_t = torch.tensor(scalar, dtype=src_val.dtype)
            if opname == "micro_vadds":
                result = src_val + scalar_t
            elif opname == "micro_vmuls":
                result = src_val * scalar_t
            elif opname == "micro_vmaxs":
                result = torch.maximum(src_val, scalar_t.expand_as(src_val))
            elif opname == "micro_vmins":
                result = torch.minimum(src_val, scalar_t.expand_as(src_val))
            elif opname == "micro_vlrelu":
                result = torch.where(src_val > 0, src_val, src_val * scalar_t)
            else:
                result = torch.minimum(src_val, scalar_t.expand_as(src_val))
            # Apply mask gating: only active lanes get the result
            mask_ref = kwargs.get("mask")
            if mask_ref is not None:
                mask_bits = self._get_mask(mask_ref)
                if mask_bits is None:
                    mask_bits = self._mask_bits_from_mode(mask_ref)
                dst_val = self._get_reg(dst_name)
                result = torch.where(mask_bits, result, dst_val)
            self._set_reg(dst_name, result)
            return True

        # dup
        if opname == "micro_vdup":
            dst = kwargs.get("dst")
            value = kwargs.get("src", kwargs.get("value", 0))
            if dst is None:
                return True
            dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
            # Reg source: broadcast src[0] into all lanes of dst
            if hasattr(value, "name") and hasattr(value, "dtype"):
                src_name = str(value.name) if hasattr(value, "name") else str(value)
                src_reg = self._get_reg(src_name)
                fill = src_reg[0].item()
            else:
                fill = self._resolve_micro_float(value)
            reg = self._get_reg(dst_name)
            self._set_reg(dst_name, torch.full_like(reg, fill))
            return True

        # axpy: dst = dst + src * scalar
        if opname == "micro_vaxpy":
            src = kwargs.get("src", kwargs.get("reg"))
            dst = kwargs.get("dst", src)
            value = kwargs.get("value", kwargs.get("v", 0))
            if src is None or dst is None:
                return True
            src_name = str(src.name) if hasattr(src, "name") else str(src)
            dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
            src_val = self._get_reg(src_name)
            dst_val = self._get_reg(dst_name)
            scalar = self._resolve_micro_float(value)
            self._set_reg(dst_name, dst_val + src_val * scalar)
            return True

        # group reduce ops: vcadd, vcmax, vcmin (full reduce)
        if opname in ("micro_vcadd", "micro_vcmax", "micro_vcmin"):
            src = kwargs.get("src")
            dst = kwargs.get("dst")
            if src is None or dst is None:
                return True
            src_name = str(src.name) if hasattr(src, "name") else str(src)
            dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
            src_val = self._get_reg(src_name)
            dst_reg = self._get_reg(dst_name)
            dst_reg.zero_()
            if opname == "micro_vcadd":
                dst_reg[0] = src_val.sum().to(dst_reg.dtype)
            elif opname == "micro_vcmax":
                dst_reg[0] = src_val.max().to(dst_reg.dtype)
            elif opname == "micro_vcmin":
                dst_reg[0] = src_val.min().to(dst_reg.dtype)
            self._set_reg(dst_name, dst_reg)
            return True

        # group block reduce ops: vcgadd, vcgmax, vcgmin (8-block reduce)
        if opname in ("micro_vcgadd", "micro_vcgmax", "micro_vcgmin"):
            src = kwargs.get("src")
            dst = kwargs.get("dst")
            if src is None or dst is None:
                return True
            src_name = str(src.name) if hasattr(src, "name") else str(src)
            dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
            src_val = self._get_reg(src_name)
            dst_reg = self._get_reg(dst_name)
            dst_reg.zero_()
            block_count = 8
            c0 = 32 // dst_reg.element_size()
            lane_count = int(src_val.numel())
            if lane_count != block_count * c0:
                raise ValueError(
                    "%s lane count mismatch: expected=%d, actual=%d"
                    % (opname, block_count * c0, lane_count))
            op = opname.replace("micro_vcg", "")
            for bi in range(block_count):
                block = src_val[bi * c0:(bi + 1) * c0]
                if op == "add":
                    dst_reg[bi] = block.sum().to(dst_reg.dtype)
                elif op == "max":
                    dst_reg[bi] = block.max().to(dst_reg.dtype)
                elif op == "min":
                    dst_reg[bi] = block.min().to(dst_reg.dtype)
            self._set_reg(dst_name, dst_reg)
            return True

        # pair-wise add: vcpadd
        if opname == "micro_vcpadd":
            src = kwargs.get("src")
            dst = kwargs.get("dst")
            if src is None or dst is None:
                return True
            src_name = str(src.name) if hasattr(src, "name") else str(src)
            dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
            src_val = self._get_reg(src_name)
            dst_reg = self._get_reg(dst_name)
            dst_reg.zero_()
            lane_count = int(src_val.numel())
            if lane_count % 2 != 0:
                raise ValueError(
                    "%s requires even lane count, got: %d" % (opname, lane_count))
            pair_count = lane_count // 2
            reduced = src_val.view(pair_count, 2).sum(dim=1).to(dst_reg.dtype)
            dst_reg[:pair_count] = reduced
            self._set_reg(dst_name, dst_reg)
            return True

        # cast
        if opname == "micro_cast":
            return self._handle_cast(kwargs)

        # compare / compare_scalar
        if opname in ("micro_compare", "micro_compares"):
            return self._handle_compare(kwargs)

        # select
        if opname == "micro_select":
            return self._handle_select(kwargs)

        # Legacy scalar ops (from existing MicroRuntime)
        return self._execute_legacy(opname, kwargs, tensor_store)

    def _handle_cast(self, kwargs: Dict[str, Any]) -> bool:
        src = kwargs.get("src")
        dst = kwargs.get("dst")
        dtype_ref = kwargs.get("dtype", kwargs.get("ddst"))
        if src is None or dst is None or dtype_ref is None:
            return True
        src_name = str(src.name) if hasattr(src, "name") else str(src)
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src_val = self._get_reg(src_name)
        dst_reg = self._get_reg(dst_name)
        src_snapshot = src_val.clone()
        dst_dtype = _torch_dtype_from_dt(dtype_ref)
        config = kwargs.get("config")
        mode_name = self._mode_name(kwargs.get("mode", getattr(config, "name", None)), "CAST_NONE")
        mask_bits = self._resolve_mask_bits(kwargs.get("mask"), getattr(dst, "dtype", dst_dtype), "micro_cast")
        saturate = bool(getattr(config, "saturate", False))

        src_indexable = src_snapshot
        if self._micro_cast_is_float8_dtype(src_snapshot.dtype):
            src_indexable = src_snapshot.to(dtype=torch.float32)

        dst_is_float8 = self._micro_cast_is_float8_dtype(dst_dtype)
        if dst_is_float8:
            dst_work = dst_reg.to(dtype=torch.float32)
            dst_work.zero_()
        else:
            dst_work = torch.zeros_like(dst_reg, dtype=dst_dtype, device=dst_reg.device)
        active = self._align_mask_device(mask_bits, dst_work)
        active_idx = torch.nonzero(active, as_tuple=False).view(-1)
        if int(active_idx.numel()) == 0:
            if dst_is_float8:
                self._set_reg(dst_name, dst_work.to(dtype=dst_dtype, device=dst_reg.device))
            else:
                self._set_reg(dst_name, dst_work)
            return True

        src_size = int(src_snapshot.element_size())
        dst_size = int(torch.empty((), dtype=dst_dtype).element_size())
        layout_name = str(getattr(getattr(config, "reg_layout", None), "name", getattr(config, "reg_layout", "ZERO")))
        if src_size == dst_size:
            src_idx = active_idx
            if src_idx.device != src_indexable.device:
                src_idx = src_idx.to(device=src_indexable.device)
            values = src_indexable[src_idx]
            values = self._micro_cast_apply_dtype(values, dst_dtype, mode_name, saturate)
            dst_idx = active_idx
            if dst_idx.device != dst_work.device:
                dst_idx = dst_idx.to(device=dst_work.device)
            dst_work[dst_idx] = values.to(dtype=dst_work.dtype, device=dst_work.device)
        elif src_size < dst_size:
            if (dst_size % src_size) != 0:
                raise ValueError(
                    "micro_cast unsupported cast ratio: src_size="
                    + str(src_size)
                    + ", dst_size="
                    + str(dst_size)
                )
            ratio = dst_size // src_size
            slot = self._micro_cast_layout_slot(layout_name, ratio)
            src_idx = active_idx * ratio + slot
            if src_idx.device != src_indexable.device:
                src_idx = src_idx.to(device=src_indexable.device)
            values = src_indexable[src_idx]
            values = self._micro_cast_apply_dtype(values, dst_dtype, mode_name, saturate)
            dst_idx = active_idx
            if dst_idx.device != dst_work.device:
                dst_idx = dst_idx.to(device=dst_work.device)
            dst_work[dst_idx] = values.to(dtype=dst_work.dtype, device=dst_work.device)
        else:
            if (src_size % dst_size) != 0:
                raise ValueError(
                    "micro_cast unsupported cast ratio: src_size="
                    + str(src_size)
                    + ", dst_size="
                    + str(dst_size)
                )
            ratio = src_size // dst_size
            slot = self._micro_cast_layout_slot(layout_name, ratio)
            selected = (active_idx % ratio) == slot
            if bool(selected.any().item()):
                dst_idx = active_idx[selected]
                src_idx = dst_idx // ratio
                if src_idx.device != src_indexable.device:
                    src_idx = src_idx.to(device=src_indexable.device)
                values = src_indexable[src_idx]
                values = self._micro_cast_apply_dtype(values, dst_dtype, mode_name, saturate)
                if dst_idx.device != dst_work.device:
                    dst_idx = dst_idx.to(device=dst_work.device)
                dst_work[dst_idx] = values.to(dtype=dst_work.dtype, device=dst_work.device)

        if dst_is_float8:
            self._set_reg(dst_name, dst_work.to(dtype=dst_dtype, device=dst_reg.device))
        else:
            self._set_reg(dst_name, dst_work)
        return True

    def _handle_compare(self, kwargs: Dict[str, Any]) -> bool:
        src1 = kwargs.get("src1")
        dst = kwargs.get("dst")
        if src1 is None or dst is None:
            return True
        ctx = self._ctx
        src1_name = str(src1.name) if hasattr(src1, "name") else str(src1)
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        lhs = self._get_reg(src1_name)
        rhs_arg = kwargs.get("src2", kwargs.get("value"))
        if rhs_arg is not None and hasattr(rhs_arg, "name"):
            rhs_name = str(rhs_arg.name)
            try:
                rhs = self._get_reg(rhs_name)
            except KeyError:
                rhs = torch.full_like(lhs, self._resolve_micro_float(rhs_arg))
        elif isinstance(rhs_arg, (int, float)):
            rhs = torch.full_like(lhs, rhs_arg)
        else:
            rhs = torch.full_like(lhs, self._resolve_micro_float(rhs_arg))
        mode = kwargs.get("mode")
        mode_name = str(getattr(mode, "name", mode) if mode is not None else "EQ").strip().upper()
        result_bool = self._compare(lhs, rhs, mode_name).to(torch.bool)
        if ctx is not None:
            ctx.masks[dst_name] = result_bool.clone()
        return True

    def _handle_select(self, kwargs: Dict[str, Any]) -> bool:
        dst = kwargs.get("dst")
        src1 = kwargs.get("src1")
        src2 = kwargs.get("src2")
        mask_ref = kwargs.get("selmask", kwargs.get("mask"))
        if dst is None or src1 is None or mask_ref is None:
            return True
        dst_name = str(dst.name) if hasattr(dst, "name") else str(dst)
        src1_name = str(src1.name) if hasattr(src1, "name") else str(src1)
        src1_val = self._get_reg(src1_name)
        mask_val = self._get_mask(mask_ref)
        if mask_val is None:
            mask_val = torch.ones(src1_val.shape, dtype=torch.bool)
        mask_bool = mask_val.to(dtype=torch.bool)
        if src2 is not None and hasattr(src2, "name"):
            src2_name = str(src2.name)
            try:
                src2_val = self._get_reg(src2_name)
            except KeyError:
                src2_val = torch.zeros_like(src1_val)
        elif isinstance(src2, (int, float)):
            src2_val = torch.full_like(src1_val, src2)
        else:
            src2_val = torch.zeros_like(src1_val)
        self._set_reg(dst_name, torch.where(mask_bool, src1_val, src2_val.to(dtype=src1_val.dtype)))
        return True

    # ------------------------------------------------------------------
    # Legacy compatibility (scalar micro ops used by existing tests)
    # ------------------------------------------------------------------

    @staticmethod
    def _clone_value(value: Any) -> Any:
        if isinstance(value, torch.Tensor):
            return value.clone()
        return value

    @staticmethod
    def _is_reg_name(value: Any, bindings: Dict[str, Any]) -> bool:
        return isinstance(value, str) and value in bindings

    @staticmethod
    def _to_scalar(value: Any) -> Any:
        if isinstance(value, torch.Tensor):
            if int(value.numel()) != 1:
                raise ValueError("micro scalar argument tensor must have numel == 1")
            return value.reshape(-1)[0].item()
        return value

    @staticmethod
    def _round_for_cast(values: torch.Tensor, mode_name: str) -> torch.Tensor:
        if mode_name in ("CAST_NONE", "CAST_TRUNC"):
            return torch.trunc(values)
        if mode_name == "CAST_FLOOR":
            return torch.floor(values)
        if mode_name == "CAST_CEIL":
            return torch.ceil(values)
        if mode_name == "CAST_ROUND":
            return torch.sign(values) * torch.ceil(torch.abs(values))
        if mode_name == "CAST_RINT":
            return torch.round(values)
        raise ValueError("unsupported micro_cast mode: " + str(mode_name))

    @staticmethod
    def _compare(lhs: torch.Tensor, rhs: torch.Tensor, mode_name: str) -> torch.Tensor:
        if mode_name == "LT":
            return lhs < rhs
        if mode_name == "LE":
            return lhs <= rhs
        if mode_name == "GT":
            return lhs > rhs
        if mode_name == "GE":
            return lhs >= rhs
        if mode_name == "EQ":
            return lhs == rhs
        if mode_name == "NE":
            return lhs != rhs
        raise ValueError("unsupported micro compare mode: " + str(mode_name))

    @staticmethod
    def _mode_name(value: Any, default: str) -> str:
        if value is None:
            return default
        if hasattr(value, "name"):
            return str(getattr(value, "name"))
        return str(value)

    @staticmethod
    def _resolve_torch_dtype(value: Any) -> torch.dtype:
        return _torch_dtype_from_dt(value)

    def set_reg(self, name: str, value: Any) -> Any:
        cloned = self._clone_value(value)
        self.bindings[str(name)] = cloned
        return cloned

    def get_reg(self, name: str) -> Any:
        return self.bindings[str(name)]

    def _resolve_value(self, ref: Any) -> Any:
        if self._is_reg_name(ref, self.bindings):
            return self.get_reg(str(ref))
        return ref

    def _resolve_scalar_value(self, ref: Any) -> Any:
        return self._to_scalar(self._resolve_value(ref))

    @staticmethod
    def _binary_apply(lhs: Any, rhs: Any, op) -> Any:
        if isinstance(lhs, torch.Tensor) or isinstance(rhs, torch.Tensor):
            if not isinstance(lhs, torch.Tensor):
                assert isinstance(rhs, torch.Tensor)
                lhs = torch.tensor(lhs, dtype=rhs.dtype, device=rhs.device)
            if not isinstance(rhs, torch.Tensor):
                rhs = torch.tensor(rhs, dtype=lhs.dtype, device=lhs.device)
            return op(lhs, rhs)
        return op(lhs, rhs)

    @staticmethod
    def _unary_scalar_apply(value: Any, scalar: Any, op) -> Any:
        if isinstance(value, torch.Tensor):
            scalar_tensor = torch.tensor(scalar, dtype=value.dtype, device=value.device)
            return op(value, scalar_tensor)
        return op(value, scalar)

    def _execute_legacy(self, opname: str, args: Dict[str, Any], tensor_store: SharedTensorStore) -> bool:
        """Legacy scalar micro ops for backward compat with existing tests."""
        return self.execute(opname, args, tensor_store)

    def execute(self, opname: str, args: Dict[str, Any], tensor_store: SharedTensorStore) -> bool:
        if opname == "micro_set_reg":
            self.set_reg(str(args["reg"]), args.get("value", 0))
            return True
        if opname == "micro_add_scalar":
            reg_name = str(args["reg"])
            base = self.get_reg(reg_name) if reg_name in self.bindings else 0
            self.set_reg(reg_name, self._unary_scalar_apply(base, args.get("value", 0), lambda x, y: x + y))
            return True
        if opname == "micro_sub_scalar":
            reg_name = str(args["reg"])
            base = self.get_reg(reg_name) if reg_name in self.bindings else 0
            self.set_reg(reg_name, self._unary_scalar_apply(base, args.get("value", 0), lambda x, y: x - y))
            return True
        if opname == "micro_mul_scalar":
            reg_name = str(args["reg"])
            base = self.get_reg(reg_name) if reg_name in self.bindings else 0
            self.set_reg(reg_name, self._unary_scalar_apply(base, args.get("value", 0), lambda x, y: x * y))
            return True
        if opname == "micro_load_shared_to_reg":
            tensor = tensor_store.tensor(str(args["src"]))
            if "index" in args and "count" not in args:
                index = int(args.get("index", 0))
                self.set_reg(str(args["reg"]), tensor.reshape(-1)[index].item())
            elif "count" in args:
                index = int(args.get("index", 0))
                count = int(args.get("count", 1))
                self.set_reg(str(args["reg"]), tensor.reshape(-1)[index : index + count].clone())
            else:
                self.set_reg(str(args["reg"]), tensor.clone())
            return True
        if opname == "micro_store_reg_to_shared":
            tensor = tensor_store.tensor(str(args["dst"]))
            value = self.get_reg(str(args["reg"]))
            if isinstance(value, torch.Tensor) and "count" in args:
                index = int(args.get("index", 0))
                count = int(args.get("count", int(value.numel())))
                tensor.reshape(-1)[index : index + count].copy_(
                    value.reshape(-1)[:count].to(dtype=tensor.dtype, device=tensor.device)
                )
                return True
            if "index" in args:
                index = int(args.get("index", 0))
                tensor.reshape(-1)[index] = self._resolve_scalar_value(value)
                return True
            if isinstance(value, torch.Tensor):
                if int(value.numel()) != int(tensor.numel()):
                    raise ValueError("micro_store_reg_to_shared requires reg/dst with matching numel")
                tensor.copy_(value.reshape(tensor.shape).to(dtype=tensor.dtype, device=tensor.device))
                return True
            if int(tensor.numel()) != 1:
                raise ValueError("micro_store_reg_to_shared scalar store requires dst numel == 1")
            tensor.reshape(-1)[0] = self._resolve_scalar_value(value)
            return True
        if opname == "micro_vadd":
            self.set_reg(str(args["dst"]), self._binary_apply(self.get_reg(str(args["src1"])), self.get_reg(str(args["src2"])), lambda lhs, rhs: lhs + rhs))
            return True
        if opname == "micro_vsub":
            self.set_reg(str(args["dst"]), self._binary_apply(self.get_reg(str(args["src1"])), self.get_reg(str(args["src2"])), lambda lhs, rhs: lhs - rhs))
            return True
        if opname == "micro_vmul":
            self.set_reg(str(args["dst"]), self._binary_apply(self.get_reg(str(args["src1"])), self.get_reg(str(args["src2"])), lambda lhs, rhs: lhs * rhs))
            return True
        if opname == "micro_vdiv":
            self.set_reg(str(args["dst"]), self._binary_apply(self.get_reg(str(args["src1"])), self.get_reg(str(args["src2"])), lambda lhs, rhs: lhs / rhs))
            return True
        if opname == "micro_vmax":
            self.set_reg(str(args["dst"]), self._binary_apply(self.get_reg(str(args["src1"])), self.get_reg(str(args["src2"])), lambda lhs, rhs: torch.maximum(lhs, rhs) if isinstance(lhs, torch.Tensor) or isinstance(rhs, torch.Tensor) else max(lhs, rhs)))
            return True
        if opname == "micro_vmin":
            self.set_reg(str(args["dst"]), self._binary_apply(self.get_reg(str(args["src1"])), self.get_reg(str(args["src2"])), lambda lhs, rhs: torch.minimum(lhs, rhs) if isinstance(lhs, torch.Tensor) or isinstance(rhs, torch.Tensor) else min(lhs, rhs)))
            return True
        if opname == "micro_vabs":
            src_value = self.get_reg(str(args["src"]))
            if isinstance(src_value, torch.Tensor):
                self.set_reg(str(args["dst"]), src_value.abs())
            else:
                self.set_reg(str(args["dst"]), abs(src_value))
            return True
        if opname == "micro_vdup":
            dst_name = str(args["dst"])
            value = self._resolve_scalar_value(args.get("src", args.get("value", 0)))
            current = self.bindings.get(dst_name)
            if isinstance(current, torch.Tensor):
                self.set_reg(dst_name, torch.full(current.shape, value, dtype=current.dtype, device=current.device))
            else:
                self.set_reg(dst_name, value)
            return True
        if opname in ("micro_vadds", "micro_vmuls", "micro_vmaxs", "micro_vmins"):
            src_name = str(args.get("src", args.get("reg", "")))
            dst_name = str(args.get("dst", src_name))
            base = self.get_reg(src_name)
            scalar = self._resolve_scalar_value(args.get("value", args.get("v", 0)))
            if opname == "micro_vadds":
                result = self._unary_scalar_apply(base, scalar, lambda x, y: x + y)
            elif opname == "micro_vmuls":
                result = self._unary_scalar_apply(base, scalar, lambda x, y: x * y)
            elif opname == "micro_vmaxs":
                result = self._unary_scalar_apply(base, scalar, lambda x, y: torch.maximum(x, y) if isinstance(x, torch.Tensor) else max(x, y))
            else:
                result = self._unary_scalar_apply(base, scalar, lambda x, y: torch.minimum(x, y) if isinstance(x, torch.Tensor) else min(x, y))
            self.set_reg(dst_name, result)
            return True
        if opname in ("micro_compare", "micro_compares"):
            lhs_value = self.get_reg(str(args["src1"]))
            rhs_arg = args.get("src2", args.get("value"))
            rhs_value = self._resolve_value(rhs_arg)
            mode_name = self._mode_name(args.get("mode"), "").strip().upper()
            if isinstance(lhs_value, torch.Tensor) or isinstance(rhs_value, torch.Tensor):
                if isinstance(lhs_value, torch.Tensor):
                    lhs_tensor = lhs_value
                elif isinstance(rhs_value, torch.Tensor):
                    lhs_tensor = torch.full(rhs_value.shape, self._to_scalar(lhs_value), dtype=rhs_value.dtype, device=rhs_value.device)
                else:
                    raise TypeError("micro_compare tensor mode requires tensor lhs or rhs")
                if isinstance(rhs_value, torch.Tensor):
                    rhs_tensor = rhs_value.to(dtype=lhs_tensor.dtype, device=lhs_tensor.device)
                else:
                    rhs_tensor = torch.full(lhs_tensor.shape, self._to_scalar(rhs_value), dtype=lhs_tensor.dtype, device=lhs_tensor.device)
                self.legacy_masks[str(args["dst"])] = self._compare(lhs_tensor, rhs_tensor, mode_name).to(torch.bool)
                return True
            lhs_scalar = self._to_scalar(lhs_value)
            rhs_scalar = self._to_scalar(rhs_value)
            scalar_result = bool(self._compare(torch.tensor([lhs_scalar]), torch.tensor([rhs_scalar]), mode_name)[0].item())
            self.legacy_masks[str(args["dst"])] = scalar_result
            return True
        if opname == "micro_select":
            mask_ref = args.get("selmask", args.get("mask"))
            if mask_ref is None:
                raise KeyError("micro_select requires selmask or mask")
            mask_name = str(mask_ref)
            if mask_name not in self.legacy_masks:
                raise KeyError("micro_select mask not found: " + mask_name)
            mask_value = self.legacy_masks[mask_name]
            src1_value = self.get_reg(str(args["src1"]))
            src2_value = self._resolve_value(args.get("src2"))
            if isinstance(mask_value, torch.Tensor) or isinstance(src1_value, torch.Tensor) or isinstance(src2_value, torch.Tensor):
                if not isinstance(src1_value, torch.Tensor):
                    raise TypeError("micro_select tensor mode requires tensor src1")
                mask_tensor = mask_value if isinstance(mask_value, torch.Tensor) else torch.full(src1_value.shape, bool(mask_value), dtype=torch.bool, device=src1_value.device)
                mask_tensor = mask_tensor.to(dtype=torch.bool, device=src1_value.device)
                if isinstance(src2_value, torch.Tensor):
                    src2_tensor = src2_value.to(dtype=src1_value.dtype, device=src1_value.device)
                else:
                    src2_tensor = torch.full(src1_value.shape, self._to_scalar(src2_value), dtype=src1_value.dtype, device=src1_value.device)
                self.set_reg(str(args["dst"]), torch.where(mask_tensor, src1_value, src2_tensor))
                return True
            chosen = src1_value if bool(mask_value) else src2_value
            self.set_reg(str(args["dst"]), chosen)
            return True
        if opname == "micro_cast":
            src_value = self.get_reg(str(args["src"]))
            dst_name = str(args["dst"])
            dtype_ref = args.get("dtype", args.get("ddst"))
            if dtype_ref is None:
                raise KeyError("micro_cast requires dtype or ddst")
            dst_dtype = self._resolve_torch_dtype(dtype_ref)
            config = args.get("config")
            mode_name = self._mode_name(args.get("mode", getattr(config, "name", None)), "CAST_NONE")
            if isinstance(src_value, torch.Tensor):
                if src_value.dtype.is_floating_point and not torch.empty((), dtype=dst_dtype).is_floating_point():
                    cast_value = self._round_for_cast(src_value.to(torch.float32), mode_name).to(dst_dtype)
                else:
                    cast_value = src_value.to(dst_dtype)
                self.set_reg(dst_name, cast_value)
                return True
            scalar = self._to_scalar(src_value)
            if isinstance(scalar, float):
                cast_tensor = torch.tensor([scalar], dtype=torch.float32)
            else:
                cast_tensor = torch.tensor([scalar])
            if cast_tensor.dtype.is_floating_point and not torch.empty((), dtype=dst_dtype).is_floating_point():
                cast_tensor = self._round_for_cast(cast_tensor.to(torch.float32), mode_name).to(dst_dtype)
            else:
                cast_tensor = cast_tensor.to(dst_dtype)
            self.set_reg(dst_name, cast_tensor.reshape(-1)[0].item())
            return True
        return False
