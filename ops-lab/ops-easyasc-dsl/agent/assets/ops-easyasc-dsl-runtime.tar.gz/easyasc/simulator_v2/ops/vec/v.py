from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Tuple

import torch

from ._legacy_vpipe import SimInstruction, VPipe, linear_view_from_pointer

from ...memory.shared_tensor_store import SharedTensorStore
from ...program.task import PipeTask
from ..common import PipeDescriptor, PipeFamily
from ..pipe_base import PipeBaseV2


_LEGACY_OP_ALIASES = {
    "vec_v_add": "add",
    "vec_v_sub": "sub",
    "vec_v_mul": "mul",
    "vec_v_div": "div",
    "vec_v_max": "vmax",
    "vec_v_min": "vmin",
    "vec_v_abs": "abs",
    "vec_v_relu": "relu",
    "vec_v_add_scalar": "adds",
    "vec_v_mul_scalar": "muls",
    "vec_v_dup": "dup",
    "vec_v_cast": "cast",
    "vec_v_compare": "compare",
    "vec_v_compare_scalar": "compare_scalar",
    "vec_v_select": "select",
    "vec_v_exp": "exp",
    "vec_v_ln": "ln",
    "vec_v_rec": "rec",
    "vec_v_sqrt": "sqrt",
    "vec_v_rsqrt": "rsqrt",
    "vec_v_not": "vnot",
    "vec_v_and": "vand",
    "vec_v_or": "vor",
    "vec_v_cmax": "cmax",
    "vec_v_cmin": "cmin",
    "vec_v_cadd": "cadd",
    "vec_v_cgmax": "cgmax",
    "vec_v_cgmin": "cgmin",
    "vec_v_cgadd": "cgadd",
    "vec_v_brcb": "brcb",
    "vec_v_muladddst": "muladddst",
    "vec_v_set_mask": "set_mask",
    "vec_v_reset_mask": "reset_mask",
    "vec_v_cpadd": "cpadd",
}

_LEGACY_LAYOUT_OPS = {
    "add", "sub", "mul", "div", "vmax", "vmin", "abs", "relu",
    "adds", "muls", "vmaxs", "vmins", "lrelu", "axpy",
    "dup", "cast",
    "exp", "ln", "rec", "sqrt", "rsqrt", "vnot", "vand", "vor",
    "cmax", "cmin", "cadd", "cgmax", "cgmin", "cgadd",
    "brcb", "muladddst", "set_mask", "reset_mask", "cpadd",
    "sort32", "mergesort4", "mergesort_2seq",
    "gather", "scatter",
    "ub_to_ub",
}

_LEGACY_LAYOUT_UNCONDITIONAL_OPS = {
    "set_mask", "reset_mask",
    "sort32", "mergesort4", "mergesort_2seq",
    "ub_to_ub",
}

_LEGACY_TENSOR_ARG_KEYS = (
    "dst",
    "src",
    "src1",
    "src2",
    "selmask",
    "offset",
    "idx",
)


@dataclass
class VPipeV2(PipeBaseV2):
    _legacy_pipe: VPipe = field(init=False, repr=False)
    _cmpmask_scalar: Any = field(init=False, repr=False, default=0.0)

    def __init__(self) -> None:
        super(VPipeV2, self).__init__(PipeDescriptor(PipeFamily.VEC, "V"))
        self._legacy_pipe = VPipe(core_idx=0, call_micro_executor=lambda instruction: None)
        self._cmpmask_scalar = 0.0

    @staticmethod
    def _normalize_legacy_opname(opname: str) -> str:
        return _LEGACY_OP_ALIASES.get(opname, opname)

    @staticmethod
    def _should_use_legacy_layout(task: PipeTask) -> bool:
        normalized = VPipeV2._normalize_legacy_opname(task.opname)
        if normalized not in _LEGACY_LAYOUT_OPS:
            return False
        if normalized in _LEGACY_LAYOUT_UNCONDITIONAL_OPS:
            return True
        return "repeat" in task.args

    @staticmethod
    def _legacy_args(task: PipeTask, normalized_opname: str) -> dict:
        args = dict(task.args)
        if normalized_opname in ("adds", "muls", "vmaxs", "vmins", "lrelu", "axpy") and "val" not in args and "value" in args:
            args["val"] = args["value"]
        if normalized_opname == "dup" and "src" not in args and "value" in args:
            args["src"] = args["value"]
        if normalized_opname == "set_mask":
            for key in ("low", "high"):
                value = args.get(key)
                if isinstance(value, int) and value < 0:
                    args[key] = value & ((1 << 64) - 1)
        return args

    @staticmethod
    def _resolve_legacy_tensors(tensor_store: SharedTensorStore, args: dict) -> Tuple[dict, dict]:
        tensors = {}
        tensor_dtypes = {}
        for key in _LEGACY_TENSOR_ARG_KEYS:
            ref = args.get(key)
            if not isinstance(ref, str) or not tensor_store.contains(ref):
                continue
            tensor = tensor_store.tensor(ref)
            pointer = linear_view_from_pointer(tensor)
            tensors[key] = pointer
            tensor_dtypes[key] = VPipe._infer_vec_dtype_name(pointer)
        return tensors, tensor_dtypes

    def _execute_legacy_layout(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        normalized = self._normalize_legacy_opname(task.opname)
        args = self._legacy_args(task, normalized)
        tensors, tensor_dtypes = self._resolve_legacy_tensors(tensor_store, args)
        if normalized in ("sort32", "mergesort4", "mergesort_2seq"):
            tensor_dtypes = {}
        instruction = SimInstruction(
            opname=normalized,
            args=args,
            tensors=tensors,
            tensor_dtypes=tensor_dtypes,
        )
        self._legacy_pipe.execute_instruction(instruction)
        return True

    @staticmethod
    def _resolve_scalar(value: Any) -> Any:
        if isinstance(value, torch.Tensor):
            if int(value.numel()) != 1:
                raise ValueError("scalar argument tensor must have numel == 1")
            return value.reshape(-1)[0].item()
        return value

    @staticmethod
    def _mode_name(value: Any, default: str) -> str:
        if value is None:
            return default
        if hasattr(value, "name"):
            return str(getattr(value, "name"))
        return str(value)

    @staticmethod
    def _compute_dtype(tensor: torch.Tensor) -> torch.dtype:
        if tensor.dtype in (torch.float16, torch.bfloat16):
            return torch.float32
        return tensor.dtype

    @staticmethod
    def _round_for_cast(values: torch.Tensor, mode_name: str) -> torch.Tensor:
        if mode_name in ("CAST_NONE", "CAST_TRUNC"):
            return torch.trunc(values)
        if mode_name == "CAST_FLOOR":
            return torch.floor(values)
        if mode_name == "CAST_CEIL":
            return torch.ceil(values)
        if mode_name == "CAST_ROUND":
            return torch.sign(values) * torch.ceil(torch.abs(values))
        if mode_name == "CAST_RINT":
            return torch.round(values)
        raise ValueError("unsupported vec_v_cast round mode: " + str(mode_name))

    @staticmethod
    def _compare(lhs: torch.Tensor, rhs: torch.Tensor, mode_name: str) -> torch.Tensor:
        if mode_name == "LT":
            return lhs < rhs
        if mode_name == "LE":
            return lhs <= rhs
        if mode_name == "GT":
            return lhs > rhs
        if mode_name == "GE":
            return lhs >= rhs
        if mode_name == "EQ":
            return lhs == rhs
        if mode_name == "NE":
            return lhs != rhs
        raise ValueError("unsupported vec compare mode: " + str(mode_name))

    @staticmethod
    def _copy_result(dst: torch.Tensor, value: torch.Tensor) -> None:
        if int(dst.numel()) != int(value.numel()):
            raise ValueError("vec pipe result numel mismatch")
        dst.copy_(value.reshape(dst.shape).to(dtype=dst.dtype, device=dst.device))

    @staticmethod
    def _bitwise_not(src: torch.Tensor) -> torch.Tensor:
        if src.dtype in (torch.uint8,):
            return torch.bitwise_not(src.to(torch.int8)).to(src.dtype)
        # For uint16/uint32 represented as int16/int32 in torch
        return torch.bitwise_not(src)

    def _execute_unary(self, task: PipeTask, tensor_store: SharedTensorStore, fn: Callable[[torch.Tensor], torch.Tensor]) -> bool:
        src = tensor_store.tensor(str(task.args["src"]))
        dst = tensor_store.tensor(str(task.args["dst"]))
        result = fn(src)
        self._copy_result(dst, result)
        return True

    def _execute_binary(
        self,
        task: PipeTask,
        tensor_store: SharedTensorStore,
        fn: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
    ) -> bool:
        src1 = tensor_store.tensor(str(task.args["src1"]))
        src2 = tensor_store.tensor(str(task.args["src2"]))
        dst = tensor_store.tensor(str(task.args["dst"]))
        result = fn(src1, src2)
        self._copy_result(dst, result)
        return True

    def _execute_group_reduce(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        src = tensor_store.tensor(str(task.args["src"]))
        dst = tensor_store.tensor(str(task.args["dst"]))
        compute = src.to(self._compute_dtype(src)).reshape(-1)
        if task.opname in ("cmax", "vec_v_cmax"):
            val = torch.max(compute)
        elif task.opname in ("cmin", "vec_v_cmin"):
            val = torch.min(compute)
        elif task.opname in ("cadd", "vec_v_cadd"):
            val = torch.sum(compute)
        elif task.opname in ("cgmax", "vec_v_cgmax"):
            # Per-block max: split into 8 blocks, max each
            n = int(compute.numel())
            block_size = max(n // 8, 1)
            results = []
            for i in range(8):
                blk = compute[i * block_size : (i + 1) * block_size]
                if int(blk.numel()) > 0:
                    results.append(torch.max(blk))
            if results:
                val = torch.stack(results)
                dst_flat = dst.reshape(-1)
                count = min(len(results), int(dst_flat.numel()))
                dst_flat[:count] = val[:count].to(dst.dtype)
            return True
        elif task.opname in ("cgmin", "vec_v_cgmin"):
            n = int(compute.numel())
            block_size = max(n // 8, 1)
            results = []
            for i in range(8):
                blk = compute[i * block_size : (i + 1) * block_size]
                if int(blk.numel()) > 0:
                    results.append(torch.min(blk))
            if results:
                val = torch.stack(results)
                dst_flat = dst.reshape(-1)
                count = min(len(results), int(dst_flat.numel()))
                dst_flat[:count] = val[:count].to(dst.dtype)
            return True
        elif task.opname in ("cgadd", "vec_v_cgadd"):
            n = int(compute.numel())
            block_size = max(n // 8, 1)
            results = []
            for i in range(8):
                blk = compute[i * block_size : (i + 1) * block_size]
                if int(blk.numel()) > 0:
                    results.append(torch.sum(blk))
            if results:
                val = torch.stack(results)
                dst_flat = dst.reshape(-1)
                count = min(len(results), int(dst_flat.numel()))
                dst_flat[:count] = val[:count].to(dst.dtype)
            return True
        else:
            return False
        # Scalar reductions write to first element of dst
        dst.reshape(-1)[0] = val.to(dst.dtype)
        return True

    def _execute_brcb(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        src = tensor_store.tensor(str(task.args["src"]))
        dst = tensor_store.tensor(str(task.args["dst"]))
        src_flat = src.reshape(-1)
        dst_flat = dst.reshape(-1)
        n_src = int(src_flat.numel())
        n_dst = int(dst_flat.numel())
        if n_src == 0 or n_dst == 0:
            return True
        # Broadcast: each src element fills a block in dst
        block_size = max(n_dst // n_src, 1) if n_src > 0 else n_dst
        for i in range(n_src):
            start = i * block_size
            end = min(start + block_size, n_dst)
            if start >= n_dst:
                break
            dst_flat[start:end].fill_(src_flat[i].item())
        return True

    def execute(self, task: PipeTask, tensor_store: SharedTensorStore, micro_runtime=None) -> bool:
        if self._should_use_legacy_layout(task):
            return self._execute_legacy_layout(task, tensor_store)
        if task.opname in ("vec_v_add_scalar", "adds", "muls", "vmaxs", "vmins", "lrelu", "axpy"):
            src = tensor_store.tensor(str(task.args["src"]))
            dst = tensor_store.tensor(str(task.args["dst"]))
            value = float(self._resolve_scalar(task.args.get("value", task.args.get("val", 0.0))))
            if task.opname in ("vec_v_add_scalar", "adds"):
                result = src.to(self._compute_dtype(src)) + value
            elif task.opname == "muls":
                result = src.to(self._compute_dtype(src)) * value
            elif task.opname == "vmaxs":
                src_value = src.to(self._compute_dtype(src))
                result = torch.maximum(src_value, torch.full(src.shape, value, dtype=src_value.dtype, device=src.device))
            elif task.opname == "vmins":
                src_value = src.to(self._compute_dtype(src))
                result = torch.minimum(src_value, torch.full(src.shape, value, dtype=src_value.dtype, device=src.device))
            elif task.opname == "lrelu":
                src_value = src.to(self._compute_dtype(src))
                result = torch.where(src_value > 0, src_value, src_value * value)
            else:
                result = dst.to(self._compute_dtype(dst)) + src.to(self._compute_dtype(src)) * value
            self._copy_result(dst, result)
            return True
        if task.opname == "vec_v_mul_scalar":
            src = tensor_store.tensor(str(task.args["src"]))
            dst = tensor_store.tensor(str(task.args["dst"]))
            value = float(task.args.get("value", 1.0))
            dst.copy_(src * value)
            return True
        if task.opname in ("vec_v_add", "add"):
            return self._execute_binary(
                task,
                tensor_store,
                lambda lhs, rhs: lhs.to(self._compute_dtype(lhs)) + rhs.to(self._compute_dtype(rhs)),
            )
        if task.opname in ("vec_v_sub", "sub"):
            return self._execute_binary(
                task,
                tensor_store,
                lambda lhs, rhs: lhs.to(self._compute_dtype(lhs)) - rhs.to(self._compute_dtype(rhs)),
            )
        if task.opname in ("vec_v_mul", "mul"):
            return self._execute_binary(
                task,
                tensor_store,
                lambda lhs, rhs: lhs.to(self._compute_dtype(lhs)) * rhs.to(self._compute_dtype(rhs)),
            )
        if task.opname in ("vec_v_div", "div"):
            return self._execute_binary(
                task,
                tensor_store,
                lambda lhs, rhs: lhs.to(self._compute_dtype(lhs)) / rhs.to(self._compute_dtype(rhs)),
            )
        if task.opname in ("vec_v_max", "vmax"):
            return self._execute_binary(
                task,
                tensor_store,
                lambda lhs, rhs: torch.maximum(lhs.to(self._compute_dtype(lhs)), rhs.to(self._compute_dtype(rhs))),
            )
        if task.opname in ("vec_v_min", "vmin"):
            return self._execute_binary(
                task,
                tensor_store,
                lambda lhs, rhs: torch.minimum(lhs.to(self._compute_dtype(lhs)), rhs.to(self._compute_dtype(rhs))),
            )
        if task.opname in ("vec_v_abs", "vabs"):
            return self._execute_unary(task, tensor_store, lambda src: src.abs())
        if task.opname in ("vec_v_exp", "exp"):
            return self._execute_unary(
                task, tensor_store,
                lambda src: torch.exp(src.to(self._compute_dtype(src))),
            )
        if task.opname in ("vec_v_ln", "ln"):
            return self._execute_unary(
                task, tensor_store,
                lambda src: torch.log(src.to(self._compute_dtype(src))),
            )
        if task.opname in ("vec_v_rec", "rec"):
            return self._execute_unary(
                task, tensor_store,
                lambda src: torch.reciprocal(src.to(self._compute_dtype(src))),
            )
        if task.opname in ("vec_v_sqrt", "sqrt"):
            return self._execute_unary(
                task, tensor_store,
                lambda src: torch.sqrt(src.to(self._compute_dtype(src))),
            )
        if task.opname in ("vec_v_rsqrt", "rsqrt"):
            return self._execute_unary(
                task, tensor_store,
                lambda src: torch.rsqrt(src.to(self._compute_dtype(src))),
            )
        if task.opname in ("vec_v_not", "vnot"):
            return self._execute_unary(
                task, tensor_store, self._bitwise_not,
            )
        if task.opname in ("vec_v_and", "vand"):
            return self._execute_binary(
                task, tensor_store,
                lambda s1, s2: torch.bitwise_and(s1, s2),
            )
        if task.opname in ("vec_v_or", "vor"):
            return self._execute_binary(
                task, tensor_store,
                lambda s1, s2: torch.bitwise_or(s1, s2),
            )
        if task.opname == "vec_v_relu":
            return self._execute_unary(
                task,
                tensor_store,
                lambda src: torch.clamp_min(src.to(self._compute_dtype(src)), 0),
            )
        if task.opname in ("vec_v_dup", "dup"):
            dst = tensor_store.tensor(str(task.args["dst"]))
            value = float(self._resolve_scalar(task.args.get("value", task.args.get("src", 0.0))))
            dst.fill_(value)
            return True
        if task.opname in ("vec_v_cast", "cast"):
            src = tensor_store.tensor(str(task.args["src"]))
            dst = tensor_store.tensor(str(task.args["dst"]))
            mode_name = self._mode_name(task.args.get("mode"), "CAST_NONE")
            if src.dtype.is_floating_point and not dst.dtype.is_floating_point:
                result = self._round_for_cast(src.to(torch.float32), mode_name).to(dst.dtype)
            else:
                result = src.to(dst.dtype)
            self._copy_result(dst, result)
            return True
        if task.opname in ("vec_v_compare", "vec_v_compare_scalar", "compare", "compare_scalar"):
            return self._execute_compare_bitpacked(task, tensor_store)
        if task.opname in ("vec_v_select", "select"):
            return self._execute_select_bitpacked(task, tensor_store)
        if task.opname in ("cmax", "cmin", "cadd", "cgmax", "cgmin", "cgadd",
                           "vec_v_cmax", "vec_v_cmin", "vec_v_cadd",
                           "vec_v_cgmax", "vec_v_cgmin", "vec_v_cgadd"):
            return self._execute_group_reduce(task, tensor_store)
        if task.opname in ("brcb", "vec_v_brcb"):
            return self._execute_brcb(task, tensor_store)
        if task.opname in ("muladddst", "vec_v_muladddst"):
            src1 = tensor_store.tensor(str(task.args["src1"]))
            src2 = tensor_store.tensor(str(task.args["src2"]))
            dst = tensor_store.tensor(str(task.args["dst"]))
            result = dst.to(self._compute_dtype(dst)) + src1.to(self._compute_dtype(src1)) * src2.to(self._compute_dtype(src2))
            self._copy_result(dst, result)
            return True
        if task.opname in ("set_mask", "reset_mask", "vec_v_set_mask", "vec_v_reset_mask"):
            return True  # no-op in simplified V2 model
        if task.opname in ("cpadd", "vec_v_cpadd"):
            return self._execute_cpadd(task, tensor_store)
        return False

    @staticmethod
    def _resolve_int_arg(value: Any, label: str) -> int:
        if isinstance(value, bool):
            return int(value)
        if not isinstance(value, (int, float)):
            raise TypeError(f"{label} must resolve to int/float, got: {type(value)}")
        return int(value)

    @staticmethod
    def _pack_bits_lsb_first(bool_vec: torch.Tensor, num_bytes: int) -> torch.Tensor:
        n = int(bool_vec.numel())
        packed = torch.zeros(num_bytes, dtype=torch.uint8)
        bits = bool_vec.to(torch.uint8).reshape(-1)
        for i in range(n):
            if bool(bits[i].item()):
                byte_idx = i // 8
                bit_idx = i % 8
                packed[byte_idx] = packed[byte_idx] | (1 << bit_idx)
        return packed

    @staticmethod
    def _unpack_bits_lsb_first(byte_vec: torch.Tensor, num_bits: int) -> torch.Tensor:
        out = torch.zeros(num_bits, dtype=torch.bool)
        flat = byte_vec.reshape(-1)
        for i in range(num_bits):
            byte_idx = i // 8
            bit_idx = i % 8
            out[i] = bool(((int(flat[byte_idx].item()) >> bit_idx) & 1) == 1)
        return out

    def _execute_compare_bitpacked(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        src1 = tensor_store.tensor(str(task.args["src1"]))
        dst = tensor_store.tensor(str(task.args["dst"]))
        if dst.dtype not in (torch.uint8, torch.int8):
            raise TypeError("compare dst must be uint8/int8 tensor, got: " + str(dst.dtype))
        mode_name = self._mode_name(task.args.get("mode"), "").strip().upper()

        is_scalar = task.opname in ("vec_v_compare_scalar", "compare_scalar")
        src2_ref = task.args.get("src2")

        if "repeat" in task.args:
            return self._execute_compare_repeat(
                src1, dst, mode_name, is_scalar, src2_ref, task, tensor_store
            )

        lhs_flat = src1.reshape(-1).to(self._compute_dtype(src1))
        if is_scalar:
            scalar = float(self._resolve_scalar(src2_ref if src2_ref is not None else task.args.get("value", 0)))
            rhs_flat = torch.full(lhs_flat.shape, scalar, dtype=lhs_flat.dtype, device=lhs_flat.device)
        else:
            src2 = tensor_store.tensor(str(src2_ref))
            rhs_flat = src2.reshape(-1).to(self._compute_dtype(src2))
        bool_result = self._compare(lhs_flat, rhs_flat, mode_name)
        num_bytes = (int(bool_result.numel()) + 7) // 8
        dst_flat = dst.reshape(-1)
        if num_bytes > int(dst_flat.numel()):
            raise MemoryError(
                f"compare dst view is too small: need={num_bytes}, have={int(dst_flat.numel())}"
            )
        packed = self._pack_bits_lsb_first(bool_result, num_bytes)
        dst_flat[:num_bytes] = packed.to(dst.dtype)
        return True

    def _execute_compare_repeat(
        self,
        src1: torch.Tensor,
        dst: torch.Tensor,
        mode_name: str,
        is_scalar: bool,
        src2_ref: Any,
        task: PipeTask,
        tensor_store: SharedTensorStore,
    ) -> bool:
        repeat = self._resolve_int_arg(task.args.get("repeat"), "compare repeat")
        if repeat == 0:
            return True
        src1_blk_stride = self._resolve_int_arg(task.args.get("src1_blk_stride"), "compare src1_blk_stride")
        src1_rep_stride = self._resolve_int_arg(task.args.get("src1_rep_stride"), "compare src1_rep_stride")
        if is_scalar:
            src2_blk_stride = 0
            src2_rep_stride = 0
        else:
            src2_blk_stride = self._resolve_int_arg(task.args.get("src2_blk_stride"), "compare src2_blk_stride")
            src2_rep_stride = self._resolve_int_arg(task.args.get("src2_rep_stride"), "compare src2_rep_stride")

        src1_flat = linear_view_from_pointer(src1)
        dst_flat = linear_view_from_pointer(dst)
        elem_size = int(src1.element_size())
        elems_per_block = 32 // elem_size
        elems_per_repeat = elems_per_block * 8
        bytes_per_repeat = elems_per_repeat // 8
        if bytes_per_repeat * repeat > int(dst_flat.numel()):
            raise MemoryError(
                f"compare dst view is too small: need={bytes_per_repeat * repeat}, have={int(dst_flat.numel())}"
            )

        if is_scalar:
            scalar = float(self._resolve_scalar(src2_ref if src2_ref is not None else task.args.get("value", 0)))
            compute_dtype = self._compute_dtype(src1)
            src2_flat = None
        else:
            src2_tensor = tensor_store.tensor(str(src2_ref))
            if src2_tensor.dtype != src1.dtype:
                raise TypeError("compare src1/src2 dtype mismatch")
            src2_flat = linear_view_from_pointer(src2_tensor)
            compute_dtype = self._compute_dtype(src1)
            scalar = 0.0

        for rep in range(repeat):
            src1_rep_base = rep * src1_rep_stride * elems_per_block
            lhs_blocks = []
            for blk in range(8):
                src1_begin = src1_rep_base + blk * src1_blk_stride * elems_per_block
                lhs_blocks.append(src1_flat[src1_begin : src1_begin + elems_per_block].clone())
            lhs = torch.cat(lhs_blocks, dim=0).to(compute_dtype)
            if is_scalar:
                rhs = torch.full((int(lhs.numel()),), scalar, dtype=compute_dtype, device=lhs.device)
            else:
                src2_rep_base = rep * src2_rep_stride * elems_per_block
                rhs_blocks = []
                for blk in range(8):
                    src2_begin = src2_rep_base + blk * src2_blk_stride * elems_per_block
                    rhs_blocks.append(src2_flat[src2_begin : src2_begin + elems_per_block].clone())
                rhs = torch.cat(rhs_blocks, dim=0).to(compute_dtype)
            bool_result = self._compare(lhs, rhs, mode_name)
            packed = self._pack_bits_lsb_first(bool_result, bytes_per_repeat)
            dst_begin = rep * bytes_per_repeat
            dst_flat[dst_begin : dst_begin + bytes_per_repeat] = packed.to(dst.dtype)
        return True

    def _execute_select_bitpacked(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        dst = tensor_store.tensor(str(task.args["dst"]))
        src1 = tensor_store.tensor(str(task.args["src1"]))
        selmask = tensor_store.tensor(str(task.args["selmask"]))
        if selmask.dtype != torch.uint8:
            raise TypeError("select requires uint8 selmask tensor, got: " + str(selmask.dtype))
        src2_ref = task.args.get("src2")
        if not isinstance(src2_ref, str) or not tensor_store.contains(str(src2_ref)):
            raise TypeError("select src2 must be a Tensor reference")
        src2 = tensor_store.tensor(str(src2_ref))
        if src2.dtype != src1.dtype or dst.dtype != src1.dtype:
            raise TypeError("select dst/src1/src2 dtype mismatch")

        mode_name = self._mode_name(task.args.get("mode"), "").strip().upper()
        if mode_name not in ("TENSOR_TENSOR", "TENSOR_SCALAR"):
            raise ValueError("select mode must be TENSOR_TENSOR or TENSOR_SCALAR, got: " + mode_name)

        if mode_name == "TENSOR_SCALAR":
            self._cmpmask_scalar = float(src2.reshape(-1)[0].item())
        else:
            self._cmpmask_scalar = float(selmask.reshape(-1)[0].item())

        if "repeat" in task.args:
            return self._execute_select_repeat(dst, src1, src2, selmask, mode_name, task)

        n = int(src1.numel())
        mask_bool = self._unpack_bits_lsb_first(selmask.reshape(-1), n)
        src1_flat = src1.reshape(-1)
        if mode_name == "TENSOR_SCALAR":
            fill = torch.full((n,), self._cmpmask_scalar, dtype=src1.dtype, device=src1.device)
            result = torch.where(mask_bool, src1_flat, fill)
        else:
            src2_flat = src2.reshape(-1)
            if int(src2_flat.numel()) != n:
                raise ValueError("select src1/src2 numel mismatch")
            result = torch.where(mask_bool, src1_flat, src2_flat)
        dst.reshape(-1).copy_(result.to(dst.dtype))
        return True

    def _execute_select_repeat(
        self,
        dst: torch.Tensor,
        src1: torch.Tensor,
        src2: torch.Tensor,
        selmask: torch.Tensor,
        mode_name: str,
        task: PipeTask,
    ) -> bool:
        repeat = self._resolve_int_arg(task.args.get("repeat"), "select repeat")
        if repeat == 0:
            return True
        dst_blk_stride = self._resolve_int_arg(task.args.get("dst_blk_stride"), "select dst_blk_stride")
        src1_blk_stride = self._resolve_int_arg(task.args.get("src1_blk_stride"), "select src1_blk_stride")
        src2_blk_stride = self._resolve_int_arg(task.args.get("src2_blk_stride"), "select src2_blk_stride")
        dst_rep_stride = self._resolve_int_arg(task.args.get("dst_rep_stride"), "select dst_rep_stride")
        src1_rep_stride = self._resolve_int_arg(task.args.get("src1_rep_stride"), "select src1_rep_stride")
        src2_rep_stride = self._resolve_int_arg(task.args.get("src2_rep_stride"), "select src2_rep_stride")

        dst_flat = linear_view_from_pointer(dst)
        src1_flat = linear_view_from_pointer(src1)
        src2_flat = linear_view_from_pointer(src2)
        selmask_flat = linear_view_from_pointer(selmask)

        elem_size = int(src1.element_size())
        elems_per_block = 32 // elem_size
        elems_per_repeat = elems_per_block * 8
        bytes_per_repeat = elems_per_repeat // 8

        if bytes_per_repeat * repeat > int(selmask_flat.numel()):
            raise MemoryError(
                f"select selmask view is too small: need={bytes_per_repeat * repeat}, have={int(selmask_flat.numel())}"
            )

        for rep in range(repeat):
            mask_begin = rep * bytes_per_repeat
            mask_bytes = selmask_flat[mask_begin : mask_begin + bytes_per_repeat]
            bits = self._unpack_bits_lsb_first(mask_bytes, elems_per_repeat)
            dst_rep_base = rep * dst_rep_stride * elems_per_block
            src1_rep_base = rep * src1_rep_stride * elems_per_block
            src2_rep_base = rep * src2_rep_stride * elems_per_block
            for blk in range(8):
                bit_off = blk * elems_per_block
                mask_block = bits[bit_off : bit_off + elems_per_block]
                src1_begin = src1_rep_base + blk * src1_blk_stride * elems_per_block
                src1_block = src1_flat[src1_begin : src1_begin + elems_per_block].clone()
                if mode_name == "TENSOR_SCALAR":
                    rhs_block = torch.full(
                        (elems_per_block,), self._cmpmask_scalar, dtype=src1.dtype, device=src1.device
                    )
                else:
                    src2_begin = src2_rep_base + blk * src2_blk_stride * elems_per_block
                    rhs_block = src2_flat[src2_begin : src2_begin + elems_per_block].clone()
                dst_begin = dst_rep_base + blk * dst_blk_stride * elems_per_block
                dst_flat[dst_begin : dst_begin + elems_per_block].copy_(
                    torch.where(mask_block, src1_block, rhs_block.to(src1.dtype))
                )
        return True

    def _execute_cpadd(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        src = tensor_store.tensor(str(task.args["src"]))
        dst = tensor_store.tensor(str(task.args["dst"]))
        compute = src.to(self._compute_dtype(src)).reshape(-1)
        n = int(compute.numel())
        block_size = max(n // 8, 1)
        results = []
        running_sum = torch.tensor(0.0, dtype=compute.dtype)
        for i in range(8):
            blk = compute[i * block_size : (i + 1) * block_size]
            if int(blk.numel()) > 0:
                running_sum = running_sum + torch.sum(blk)
                results.append(running_sum.clone())
        if results:
            val = torch.stack(results)
            dst_flat = dst.reshape(-1)
            count = min(len(results), int(dst_flat.numel()))
            dst_flat[:count] = val[:count].to(dst.dtype)
        return True
