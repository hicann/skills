from __future__ import annotations

from dataclasses import dataclass

from ...memory.shared_tensor_store import SharedTensorStore
from ...program.task import PipeTask
from .runtime import MicroRuntime
from ..pipe_base import PipeBaseV2


@dataclass
class MicroDispatch:
    """Dispatcher hook for micro runtime operations."""

    runtime: MicroRuntime

    def bind(self, pipe: PipeBaseV2) -> None:
        return None

    def execute(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        return self.runtime.execute(task.opname, task.args, tensor_store)
