# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass

from ...memory.shared_tensor_store import SharedTensorStore
from ...program.task import PipeTask
from .runtime import MicroRuntime
from ..pipe_base import PipeBaseV2


@dataclass
class MicroDispatch:
    """Dispatcher hook for micro runtime operations."""

    runtime: MicroRuntime

    def bind(self, pipe: PipeBaseV2) -> None:
        return None

    def execute(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        return self.runtime.execute(task.opname, task.args, tensor_store)
