from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from .... import globvars
from ..layout_helpers import align16, align_to, decode_nz_to_nd, decode_zz_to_nd, encode_nd_to_nz
from ...memory.shared_tensor_store import SharedTensorStore
from ...program.task import PipeTask
from ..common import PipeDescriptor, PipeFamily
from ..pipe_base import PipeBaseV2


@dataclass
class MPipeV2(PipeBaseV2):
    def __init__(self) -> None:
        super(MPipeV2, self).__init__(PipeDescriptor(PipeFamily.CUBE, "M"))

    @staticmethod
    def _resolve_int(value: Any, label: str) -> int:
        if isinstance(value, bool):
            return int(value)
        if not isinstance(value, (int, float)):
            raise TypeError(label + " must resolve to int/float, got: " + str(type(value)))
        return int(value)

    @staticmethod
    def _flat_tensor(tensor: torch.Tensor, label: str) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            raise TypeError(label + " requires torch.Tensor, got: " + str(type(tensor)))
        return tensor.reshape(-1)

    @staticmethod
    def _layout_name(value: Any, default: str) -> str:
        if value is None:
            return default
        return str(value).upper()

    @staticmethod
    def _choose_compute_dtype(dst_dtype: torch.dtype) -> torch.dtype:
        if dst_dtype in (torch.float16, torch.bfloat16):
            return torch.float32
        if dst_dtype in (torch.int8, torch.uint8, torch.int16):
            return torch.int32
        return dst_dtype

    def _execute_mmad(self, task: PipeTask, tensor_store: SharedTensorStore) -> bool:
        if task.opname != "mmad":
            return False

        dst = self._flat_tensor(tensor_store.tensor(str(task.args["dst"])), "mmad dst")
        src_a = self._flat_tensor(tensor_store.tensor(str(task.args["src_a"])), "mmad src_a")
        src_b = self._flat_tensor(tensor_store.tensor(str(task.args["src_b"])), "mmad src_b")
        if src_a.dtype != src_b.dtype:
            raise ValueError(
                "mmad requires src_a/src_b dtypes to match, got: "
                + str(src_a.dtype)
                + " vs "
                + str(src_b.dtype)
            )

        m = self._resolve_int(task.args.get("M"), "mmad M")
        n = self._resolve_int(task.args.get("N"), "mmad N")
        k = self._resolve_int(task.args.get("K"), "mmad K")
        is_init = bool(task.args.get("is_init", True))
        dst_row0 = self._resolve_int(task.args.get("dst_row0", 0), "mmad dst_row0")
        dst_col0 = self._resolve_int(task.args.get("dst_col0", 0), "mmad dst_col0")
        dst_rows = self._resolve_int(task.args.get("dst_rows", m), "mmad dst rows")
        dst_cols = self._resolve_int(task.args.get("dst_cols", n), "mmad dst cols")
        src_a_layout = self._layout_name(task.args.get("src_a_layout"), "NZ")
        src_b_layout = self._layout_name(task.args.get("src_b_layout"), "NZ")
        if m < 0 or n < 0 or k < 0:
            raise ValueError("mmad requires non-negative M/N/K")
        if dst_row0 < 0 or dst_col0 < 0:
            raise ValueError("mmad requires non-negative destination slice offsets")
        if dst_row0 + m > dst_rows or dst_col0 + n > dst_cols:
            raise ValueError("mmad destination slice exceeds destination shape")

        elem_a = int(src_a.element_size())
        elem_b = int(src_b.element_size())
        elem_dst = int(dst.element_size())
        if elem_a <= 0 or (32 % elem_a) != 0:
            raise ValueError("mmad unsupported src_a element size: " + str(elem_a))
        if elem_b <= 0 or (32 % elem_b) != 0:
            raise ValueError("mmad unsupported src_b element size: " + str(elem_b))
        if elem_dst <= 0:
            raise ValueError("mmad unsupported dst element size: " + str(elem_dst))

        c0_a = 32 // elem_a
        c0_b = 32 // elem_b
        c0_dst = 16
        device_type = str(getattr(globvars, "device_type", "")).lower()
        src_a_position = str(task.args.get("src_a_position", ""))
        use_b_device_zz_a = device_type.startswith("b") and src_a_position == "L0A"
        src_a_rows = m
        src_b_rows = n
        src_a_stride_m = align16(src_a_rows)
        src_b_stride_m = align16(src_b_rows)
        dst_stride_m = align16(dst_rows)

        if use_b_device_zz_a or src_a_layout == "ZZ":
            src_a_n_align = align_to(k, c0_a)
            need_src_a = ((src_a_rows + 15) // 16) * src_a_n_align * 16
            if need_src_a > int(src_a.numel()):
                raise MemoryError("mmad src_a view is too small for ZZ layout")
            a_nd = decode_zz_to_nd(src_a, m, k, src_a_n_align)
        else:
            need_src_a = ((k + c0_a - 1) // c0_a) * src_a_stride_m * c0_a
            if need_src_a > int(src_a.numel()):
                raise MemoryError("mmad src_a view is too small for NZ layout")
            a_nd = decode_nz_to_nd(src_a, m, k, src_a_stride_m, c0_a)

        if src_b_layout == "ZZ":
            src_b_n_align = align_to(k, c0_b)
            need_src_b = ((src_b_rows + 15) // 16) * src_b_n_align * 16
            if need_src_b > int(src_b.numel()):
                raise MemoryError("mmad src_b view is too small for ZZ layout")
            b_nd = decode_zz_to_nd(src_b, n, k, src_b_n_align)
        else:
            need_src_b = ((k + c0_b - 1) // c0_b) * src_b_stride_m * c0_b
            if need_src_b > int(src_b.numel()):
                raise MemoryError("mmad src_b view is too small for NZ layout")
            b_nd = decode_nz_to_nd(src_b, n, k, src_b_stride_m, c0_b)

        need_dst = ((dst_cols + c0_dst - 1) // c0_dst) * dst_stride_m * c0_dst
        if need_dst > int(dst.numel()):
            raise MemoryError("mmad dst view is too small for NZ layout")

        compute_dtype = self._choose_compute_dtype(dst.dtype)
        prod = torch.matmul(a_nd.to(compute_dtype), b_nd.to(compute_dtype).transpose(0, 1))

        logical_dst = decode_nz_to_nd(dst, dst_rows, dst_cols, dst_stride_m, c0_dst)
        if not is_init:
            prev = logical_dst[dst_row0 : dst_row0 + m, dst_col0 : dst_col0 + n].to(compute_dtype)
            prod = prev + prod
        logical_dst[dst_row0 : dst_row0 + m, dst_col0 : dst_col0 + n].copy_(prod.to(dst.dtype))
        dst.zero_()
        encode_nd_to_nz(logical_dst, dst, dst_rows, dst_cols, dst_stride_m, c0_dst)
        return True

    def execute(self, task: PipeTask, tensor_store: SharedTensorStore, micro_runtime=None) -> bool:
        if task.opname == "cube_m_copy":
            src = tensor_store.tensor(str(task.args["src"]))
            dst = tensor_store.tensor(str(task.args["dst"]))
            dst.copy_(src.reshape(dst.shape))
            return True
        if task.opname == "cube_m_scale":
            src = tensor_store.tensor(str(task.args["src"]))
            dst = tensor_store.tensor(str(task.args["dst"]))
            alpha = float(task.args.get("alpha", 1.0))
            dst.copy_(src * alpha)
            return True
        return self._execute_mmad(task, tensor_store)
