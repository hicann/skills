from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class PipeFamily(Enum):
    CUBE = "cube"
    VEC = "vec"
    MICRO = "micro"


@dataclass(frozen=True)
class PipeDescriptor:
    """Static identity for a pipe worker."""

    family: PipeFamily
    name: str

