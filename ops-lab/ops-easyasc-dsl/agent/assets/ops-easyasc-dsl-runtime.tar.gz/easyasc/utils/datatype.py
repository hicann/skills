class DataTypeValue:
    """Data type value class representing a concrete data type."""
    def __init__(self, name: str):
        self.name = name
    
    def __repr__(self):
        return f"DataTypeValue('{self.name}')"
    
    def __str__(self):
        return self.name
    
    def __hash__(self):
        return hash(self.name)
    
    def __eq__(self, other):
        """Check whether two data types are equal."""
        if self is other:
            return True
        if not isinstance(other, DataTypeValue):
            raise TypeError(f"Cannot compare DataTypeValue with {type(other)}")
        return self.name == other.name

    @property
    def C0(self):
        if self.name == "half":
            return 16
        elif self.name == "float":
            return 8
        elif self.name == "int":
            return 8
        elif self.name == "int8_t":
            return 32
        elif self.name == "uint8_t":
            return 32
        elif self.name == "int16_t":
            return 16
        elif self.name == "uint16_t":
            return 16
        elif self.name == "float8_e4m3_t":
            return 32
        elif self.name == "float8_e5m2_t":
            return 32
        elif self.name == "hifloat8_t":
            return 32 
        elif self.name == "bfloat16_t":
            return 16
        elif self.name == "uint32_t":
            return 8
        elif self.name == "uint64_t":
            return 4
        elif self.name == "int64_t":
            return 4
        else:
            raise ValueError(f"Unknown data type: {self.name}") 

    @property
    def size(self):
        if self.name == "half":
            return 2
        elif self.name == "float":
            return 4
        elif self.name == "int":
            return 4
        elif self.name == "int8_t":
            return 1
        elif self.name == "uint8_t":
            return 1
        elif self.name == "int16_t":
            return 2
        elif self.name == "uint16_t":
            return 2
        elif self.name == "float8_e4m3_t":
            return 1
        elif self.name == "float8_e5m2_t":
            return 1
        elif self.name == "hifloat8_t":
            return 1 
        elif self.name == "bfloat16_t":
            return 2
        elif self.name == "uint32_t":
            return 4
        elif self.name == "uint64_t":
            return 8
        elif self.name == "int64_t":
            return 8
        else:
            raise ValueError(f"Unknown data type: {self.name}") 

class Datatype:
    """Data type enum-like class containing supported members."""
    half = DataTypeValue("half")
    float = DataTypeValue("float")
    int = DataTypeValue("int")
    int8 = DataTypeValue("int8_t")
    uint8 = DataTypeValue("uint8_t")
    int16 = DataTypeValue("int16_t")
    uint16 = DataTypeValue("uint16_t")
    e4m3 = DataTypeValue("float8_e4m3_t")
    e5m2 = DataTypeValue("float8_e5m2_t")
    bfloat16 = DataTypeValue("bfloat16_t")
    uint32 = DataTypeValue("uint32_t")
    uint64 = DataTypeValue("uint64_t")
    int64 = DataTypeValue("int64_t")
    hif8 = DataTypeValue("hifloat8_t")
