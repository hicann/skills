# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
class SelectModeType:
    """Select mode value class representing a concrete select mode."""
    def __init__(self, name: str):
        self.name = name

    def __repr__(self):
        return f"SelectModeType('{self.name}')"

    def __str__(self):
        return self.name

    def __eq__(self, other):
        if self is other:
            return True
        if not isinstance(other, SelectModeType):
            raise TypeError(f"Cannot compare SelectModeType with {type(other)}")
        return self.name == other.name


class SelectMode:
    """Select mode enum-like class."""
    TENSOR_TENSOR = SelectModeType("TENSOR_TENSOR")
    TENSOR_SCALAR = SelectModeType("TENSOR_SCALAR")
