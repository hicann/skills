# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from __future__ import annotations

from typing import Any, Iterable, Optional, Set, Tuple

from .Tensor import DBuff, QBuff, TBuff, Tensor
from .var import Var


SyncKey = Tuple[str, ...]
SyncKeyGroup = Tuple[SyncKey, ...]


def _scalar_sync_token(value: Any) -> str:
    if isinstance(value, Var):
        if value.value is not None:
            return str(value.value)
        return value.name
    if value is None:
        return ""
    return str(value)


def tensor_sync_key(tensor: Any) -> Optional[SyncKey]:
    if not isinstance(tensor, Tensor):
        return None

    source_buf = getattr(tensor, "source_buf", None)
    source_index = getattr(tensor, "source_index", None)
    if isinstance(source_buf, (DBuff, TBuff, QBuff)):
        return (
            "buffer",
            type(source_buf).__name__,
            str(getattr(source_buf, "position", "")),
            str(getattr(source_buf, "name", "")),
            _scalar_sync_token(source_index),
        )

    name = str(getattr(tensor, "name", ""))
    if not name or name.startswith("_tmp_"):
        return None

    return (
        "tensor",
        str(getattr(tensor, "position", "")),
        name,
    )


def collect_tensor_sync_keys(value: Any) -> Set[SyncKey]:
    result: Set[SyncKey] = set()

    def _visit(item: Any) -> None:
        key = tensor_sync_key(item)
        if key is not None:
            result.add(key)
            return
        if isinstance(item, dict):
            for child in item.values():
                _visit(child)
            return
        if isinstance(item, (list, tuple, set)):
            for child in item:
                _visit(child)

    _visit(value)
    return result


def normalize_sync_key_group(keys: Iterable[SyncKey]) -> Optional[SyncKeyGroup]:
    unique = sorted(set(keys))
    if not unique:
        return None
    return tuple(unique)
