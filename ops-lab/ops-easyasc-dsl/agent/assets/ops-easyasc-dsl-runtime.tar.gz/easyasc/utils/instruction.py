# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
class Instruction:
    """Instruction class that stores operation name and keyword arguments."""
    def __init__(self, opname: str, **kwargs):
        if not isinstance(opname, str):
            raise TypeError(f"opname must be str, got: {type(opname)}")
        self.opname = opname
        self.kwargs = dict(kwargs)

    def __getattr__(self, name: str):
        kwargs = self.__dict__.get("kwargs")
        if kwargs is not None and name in kwargs:
            return kwargs[name]
        raise AttributeError(f"{type(self).__name__!s} object has no attribute {name!s}")

    def __repr__(self):
        return f"Instruction(opname={self.opname!r}, kwargs={self.kwargs!r})"
