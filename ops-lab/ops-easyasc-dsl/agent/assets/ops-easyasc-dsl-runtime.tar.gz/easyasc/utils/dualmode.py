class DualModeType:
    """Dual mode value class representing a concrete dual destination mode."""

    def __init__(self, name: str, value: int):
        self.name = name
        self.value = value

    def __repr__(self) -> str:
        return f"DualModeType(name={self.name!r}, value={self.value!r})"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: object) -> bool:
        if self is other:
            return True
        if not isinstance(other, DualModeType):
            raise TypeError(f"Cannot compare DualModeType with {type(other)}")
        return self.value == other.value and self.name == other.name


class DualMode:
    """Dual mode enum-like class for L0C to UB copy behavior."""

    SINGLE = DualModeType("SINGLE", 0)
    SPLITM = DualModeType("SPLITM", 1)
    SPLITN = DualModeType("SPLITN", 2)
