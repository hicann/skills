# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
class DualModeType:
    """Dual mode value class representing a concrete dual destination mode."""

    def __init__(self, name: str, value: int):
        self.name = name
        self.value = value

    def __repr__(self) -> str:
        return f"DualModeType(name={self.name!r}, value={self.value!r})"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: object) -> bool:
        if self is other:
            return True
        if not isinstance(other, DualModeType):
            raise TypeError(f"Cannot compare DualModeType with {type(other)}")
        return self.value == other.value and self.name == other.name


class DualMode:
    """Dual mode enum-like class for L0C to UB copy behavior."""

    SINGLE = DualModeType("SINGLE", 0)
    SPLITM = DualModeType("SPLITM", 1)
    SPLITN = DualModeType("SPLITN", 2)
