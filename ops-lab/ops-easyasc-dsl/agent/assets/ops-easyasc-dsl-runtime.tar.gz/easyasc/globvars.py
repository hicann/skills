# ----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------------------------------------
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .kernelbase.kernelbase import KernelBase
    from .micro.micromodule import MicroModule
    from .utils.datatype import DataTypeValue

active_kernel: Optional["KernelBase"] = None
active_micro: Optional["MicroModule"] = None
tmp_idx: int = 0
atomic_enabled: bool = False
atomic_type: Optional["DataTypeValue"] = None
device_type: str = "b3"
core_num: int = 20

l1_cap = 512
l0a_cap = 64 
l0b_cap = 64 
l0c_cap = 128
ub_cap = 192
trace_event: bool = False
